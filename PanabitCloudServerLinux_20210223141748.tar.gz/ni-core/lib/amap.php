<?php
// ********************************************************
// 高德API amap geo comm
//
// 根据地址信息获取经纬度
// ********************************************************

function amap_geo($address)
{
	/* 根据地址信息获取经纬度 */
	$gd_ak = "79670e6978f902e3fe1b61ca14ae682a";
	$url = "http://restapi.amap.com/v3/geocode/geo?address={$address}&output=json&key={$gd_ak}";

	$cmd = "/usr/logd/bin/curl --connect-timeout 10 --retry-max-time 10 --max-time 10 \"{$url}\" 2>/dev/null";

	$fp = popen($cmd, "r");
	$res = '';
	while (!feof($fp)) { 
		$buffer = fgets($fp, 4096); 
		$res .= $buffer;
	}
	pclose($fp);

	$json = json_decode($res, true);
	if(json_last_error() != JSON_ERROR_NONE) 
		return false;

	$lnglat = $json["geocodes"][0]["location"];
	$ds = explode(',', $lnglat);

	return array(
		'lng' => $ds[0],
		'lat' => $ds[1]
	);
}


