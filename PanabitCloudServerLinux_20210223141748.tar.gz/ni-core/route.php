<?php
// ********************************************************
// route node function
// ********************************************************

defined('ROUTE_DEFAULT') or define('ROUTE_DEFAULT', 'default');
defined('ROUTE_APPDIR') or define('ROUTE_APPDIR', 'apps');

$GLOBALS['global_route_info'] = array(
	'app'	=> ROUTE_DEFAULT,
	'method'=> 'list'
);

route_init();

function route_init()
{
	global $global_route_info;
	
	if(isset($_REQUEST['r'])) {
		if(preg_match("/^([a-zA-Z0-9-_]{1,})@([a-zA-Z0-9-_]{1,})$/", $_REQUEST['r'], $match) === false) {
			if(preg_match("/^([a-zA-Z0-9-_]{1,})$/", $_REQUEST['r'], $match) === false)
				return 0;
			$global_route_info['app'] = $match[1];
			return 1;
		}

		$global_route_info['app'] = $match[1];
		$global_route_info['method'] = $match[2];
		return 2;
	}

	return 0;
}

function route_info()
{
	global $global_route_info;
	
	return $global_route_info;
}

function route_current($app)
{
	global $global_route_info;
	
	if($global_route_info['app'] != $app) return false;

	if(func_num_args() < 2) return true;

	$node = func_get_args();
	array_shift($node);
	return in_array($global_route_info['method'], $node);
}

function route_currgrp($app)
{
	global $global_route_info;

	$node = func_get_args();
	return in_array($global_route_info['app'], $node);
}

function route_api()
{
	global $global_route_info;

	return ROUTE_APPDIR . '/' . $global_route_info['app'] . '/api/' . $global_route_info['method'] . '.php';
}

function route_modal()
{
	global $global_route_info;

	return ROUTE_APPDIR . '/' . $global_route_info['app'] . '/assets/modal/' . $global_route_info['method'] . '/index';
}

function route_page()
{
	global $global_route_info;

	return ROUTE_APPDIR . '/' . $global_route_info['app'] . '/' . $global_route_info['method'] . '.php';
}

function route_lib()
{
	global $global_route_info;

	return ROUTE_APPDIR . '/' . $global_route_info['app'] . '/lib/' . $global_route_info['method'] . '.php';
}

function route_404()
{
	return '404.html';
}