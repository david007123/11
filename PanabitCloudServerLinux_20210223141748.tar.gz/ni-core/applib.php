<?php
// ********************************************************
// app library load manage
// ********************************************************

$GLOBALS['global_applib_load'] = array();
$GLOBALS['global_applib_map'] = array();

function ni_app_get($name)
{
	global $global_applib_load, $global_applib_map;
	
	if(isset($global_applib_map[$name])) 
		return $global_applib_load[$global_applib_map[$name]];

	return false;
}

function ni_app_load($app, $method)
{
	global $global_applib_load, $global_applib_map;

	$name = $app . '_' . $method;
	if(isset($global_applib_map[$name])) return true;

	$path = ROOT_DIR . "/apps/$app/lib";

	if (is_dir($path) == false)
		return false;

	$loaderfile = $path . '/' . $method . '.php';
	$data = array(
			'app'	=> $app,
			'method'=> $method,
			'error'	=> NULL,
	);

	$count = array_push($global_applib_load, $data);
	$index = $count - 1;
	$global_applib_map[$name] = $index;

	if(file_exists($loaderfile) === false) {
		$global_applib_load[$index]['error'] = 'lib not found.';
		return false;
	}

	include_once $loaderfile;
	if(($global_applib_load[$index]['error'] = error_get_last()) === NULL)
		$global_applib_load[$index]['stat'] = true;
//	else
//		error_clear_last();

	return true;
}

function ni_app_load_all($app)
{
	$count = 0;
	
	$path = ROOT_DIR . "/apps/$app/lib";

	if (is_dir($path)){

		if ($dh = opendir($path)){
			while (($file = readdir($dh)) !== false) {
				if($file != "." && $file != ".." && ($pos = strpos($file, '.php')) !== false) {
					if(ni_app_load($app, substr($file, 0, $pos))) $count++;
				}
			}
			closedir($dh);
		}

	}

	return $count;
}
