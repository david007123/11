<?php
// ********************************************************
// function comm
// ********************************************************
function httpPost($url, $data = array(), $verify = true)
{
	$post = '';
	foreach($data as $k => $v) 
		$post .= "&$k=$v";
	
	if($post != '')
		$post = '--data "' . substr($post, 1) . '" ';
	
	$curl = '/usr/logd/bin/curl';
	if(!file_exists($curl))
		$curl = '/usr/local/bin/curl';
	
	if($verify)
		$cmd = $curl . ' -k --connect-timeout 10 --retry-max-time 10 --max-time 10 ' . $post . '"' . $url . '" 2>/dev/null';
	else
		$cmd = $curl . ' --connect-timeout 10 --retry-max-time 10 --max-time 10 ' . $post . '"' . $url . '" 2>/dev/null';

	$fp = popen($cmd, "r");
	$res = '';
	while (!feof($fp)) {
		$buffer = fgets($fp, 4096); 
		$res .= $buffer;
	}
	pclose($fp);
	//return str_replace(PHP_EOL, '', $res);
	return $res;
}

function httpPostV2($url, $data, $verify = true)
{
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_TIMEOUT, 500);
	//curl_setopt($curl, CURLOPT_SSLVERSION, 3); 
	curl_setopt($curl, CURLOPT_HEADER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, $verify);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, $verify);
	curl_setopt($curl, CURLOPT_URL, $url);
	if($data) {
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	}

	$res = curl_exec($curl);
	curl_close($curl);

	return $res;
}

function uuid()
{
     // Generate 128 bit random sequence 
     $randmax_bits = strlen(base_convert(mt_getrandmax(), 10, 2));  // how many bits is mt_getrandmax()
     $x = '';
     while (strlen($x) < 128) {
         $maxbits = (128 - strlen($x) < $randmax_bits) ? 128 - strlen($x) :  $randmax_bits;
         $x .= str_pad(base_convert(mt_rand(0, pow(2,$maxbits)), 10, 2), $maxbits, "0", STR_PAD_LEFT);
     }

     // break into fields
     $a = array();
     $a['time_low_part'] = substr($x, 0, 32);
     $a['time_mid'] = substr($x, 32, 16);
     $a['time_hi_and_version'] = substr($x, 48, 16);
     $a['clock_seq'] = substr($x, 64, 16);
     $a['node_part'] =  substr($x, 80, 48);
     
     // Apply bit masks for "random or pseudo-random" version per RFC
     $a['time_hi_and_version'] = substr_replace($a['time_hi_and_version'], '0100', 0, 4);
     $a['clock_seq'] = substr_replace($a['clock_seq'], '10', 0, 2);

    // Format output
    return sprintf('%s%s%s%s%s',
        str_pad(base_convert($a['time_low_part'], 2, 16), 8, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['time_mid'], 2, 16), 4, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['time_hi_and_version'], 2, 16), 4, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['clock_seq'], 2, 16), 4, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['node_part'], 2, 16), 12, "0", STR_PAD_LEFT));

}

function clouduuid($tag = 'c')
{
     // Generate 128 bit random sequence 
     $randmax_bits = strlen(base_convert(mt_getrandmax(), 10, 2));  // how many bits is mt_getrandmax()
     $x = '';
     while (strlen($x) < 128) {
         $maxbits = (128 - strlen($x) < $randmax_bits) ? 128 - strlen($x) :  $randmax_bits;
         $x .= str_pad(base_convert(mt_rand(0, pow(2,$maxbits)), 10, 2), $maxbits, "0", STR_PAD_LEFT);
     }

     // break into fields
     $a = array();
     $a['time_low_part'] = substr($x, 0, 32);
     $a['time_mid'] = substr($x, 32, 16);
     $a['time_hi_and_version'] = substr($x, 48, 16);
     $a['clock_seq'] = substr($x, 64, 16);
     $a['node_part'] =  substr($x, 80, 48);
     
     // Apply bit masks for "random or pseudo-random" version per RFC
     $a['time_hi_and_version'] = substr_replace($a['time_hi_and_version'], '0100', 0, 4);
     $a['clock_seq'] = substr_replace($a['clock_seq'], '10', 0, 2);

    // Format output
    return sprintf($tag . '%s-%s-%s%s%s%s',
		str_pad(base_convert(date('YmdHis'), 10, 16), 12, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['time_low_part'], 2, 16), 8, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['time_mid'], 2, 16), 4, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['time_hi_and_version'], 2, 16), 4, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['clock_seq'], 2, 16), 4, "0", STR_PAD_LEFT),
        str_pad(base_convert($a['node_part'], 2, 16), 12, "0", STR_PAD_LEFT));

}

function format_and_push($in_data, $name, &$out_data, $alias = '', $type = 'string', $can_be_empty = true)
{
	if(isset($in_data[$name]) == false) return false;

	if(gettype($in_data[$name]) == 'string') {
		$val = trim($in_data[$name]);
		if($can_be_empty !== true && $val == '') return false;
	}
	else {
		$val = $in_data[$name];
		if($can_be_empty !== true && empty($val)) return false;
	}
	
	switch ($type) {
		case 'integer':
		case 'int':
			$val = intval($val);
			break;
		case 'double':
		case 'float':
			$val = floatval($val);
			break;
		case 'array':
			$val = (array)$val;
			break;
		case 'object':
			$val = (object)$val;
			break;
		default:
			break;
	}

	if($alias != '')
		$out_data[$alias] = $val;
	else
		$out_data[$name] = $val;

	return true;
}

function format_list_arg($in_data, &$out_data, $def_orderdir = 'desc', $def_limit = 20)
{
	if(format_and_push($in_data, 'order', $out_data, '', 'array', false) == false) 
		$out_data['order'] = array();
	else {
		foreach($out_data['order'] as $k => $op) {
			if(in_array($op['dir'], array('asc', 'desc')) == false)
				$out_data['order'][$k]['dir'] = 'desc';
		}
	}

	if(format_and_push($in_data, 'limit', $out_data, '', 'int', false) == false) 
		$out_data['limit'] = $def_limit;
	else
	if($out_data['limit'] <= 0)
		$out_data['limit'] = $def_limit;
	format_and_push($in_data, 'length', $out_data, 'limit', 'int', false);

	if(format_and_push($in_data, 'offset', $out_data, '', 'int', false) == false) 
		$out_data['offset'] = 0;

	format_and_push($in_data, 'start', $out_data, 'offset', 'int', false);
	if(format_and_push($in_data, 'page', $out_data, 'offset', 'int', false)) {
		$out_data['offset']--;
		if($out_data['offset'] >= 0)
			$out_data['offset'] = $out_data['offset'] * $out_data['limit'];
		else
			$out_data['offset'] = 0;
	}
		
}

function get_real_ip()
{
	$ip = false;

	if(!empty($_SERVER["HTTP_CLIENT_IP"]))
		$ip = $_SERVER["HTTP_CLIENT_IP"];

	if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {

		$ips = explode(", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
		if ($ip) {
			array_unshift($ips, $ip);
			$ip = false;
		}

		for ($i = 0; $i < count($ips); $i++) {
			if (!eregi("^(10|172\.16|192\.168)\.", $ips[$i])) {
				$ip = $ips[$i];
				break;
			}
		}

	}

	return ($ip ? $ip : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1'));
}

function is_ipaddr($ip)
{
	return (long2ip(ip2long($ip)) === trim($ip));
}

function shell_filter($str)
{
	return str_replace(array('|', '>', '<', '&', '\\'), '', $str);
}

function system_version()
{
	exec("uname -a 2>&1", $sysinfo, $ret);
	if($ret != 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, implode(',', $sysinfo));
		unset($sysinfo);
		return false;
	}
	// FreeBSD iZ23bj12007Z 10.1-RELEASE FreeBSD 10.1-RELEASE
	$info = explode(' ', $sysinfo[0]);
	unset($sysinfo);

	$ver = explode('-', $info[2]);
	$ret = array(
		'os'	=> $info[0],
		'name'	=> $info[1],
		'ver'	=> $ver[0],
		'tag'	=> $ver[1],
	);

	return $ret;
}

function myconf_read($file, $data = array())
{
	$ret = array();
	
	if(is_array($data) == false)
		$data = array();

	if (!file_exists($file)) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '配置文件不存在！' . $file);
		return $ret;
	}

	if ($fp = fopen($file, "r")) {
		$cnt = 0;
		$keycnt = count($data);
		while (!feof($fp)) {
			if(($buf = fgets($fp)) === false)
				break;
			if(empty($buf = trim($buf)))
				continue;

			$col = explode('=', $buf, 2);
			if(count($col) != 2)
				continue;
			$key = trim($col[0]);
			if(strpos($key, ' ') !== false)
				continue;

			if($keycnt && in_array($key, $data) == false)
				continue;

			$ret[$key] = trim($col[1]);
			$cnt++;
			if($cnt == $keycnt) break;
		}
		fclose($fp);
	}
	else
		set_errmsg(MSG_LEVEL_DEF, __function__, '配置文件打开失败！' . $file);
		
	return $ret;
}

function myconf_save($file, $data = array())
{
	if(is_array($data) == false)
		$data = array();

	$ftmp = tempnam("/tmp", "myconf");
	if (!($fpw = fopen($ftmp, "w"))) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '临时配置文件打开失败！' . $ftmp);
		return false;
	}

	if (file_exists($file)) {
		if ($fp = fopen($file, "r")) {
			$keys = array_keys($data);
			while (!feof($fp)) {
				if(($line = fgets($fp)) === false)
					break;
				if(empty($buf = trim($line, " \t\n\r\0\x0B"))) {
					fwrite($fpw, "\n");
					continue;
				}

				$col = explode('=', $buf, 2);
				if(count($col) != 2){
					fwrite($fpw, "{$buf}\n");
					continue;
				}
				
				$key = trim($col[0]);
				if(($id = array_search($key, $keys)) === false) {
					fwrite($fpw, "{$buf}\n");
					continue;
				}
				$val = trim($data[$key], " \t\n\r\0\x0B");
				fwrite($fpw, "{$key}={$val}\n");

				unset($keys[$id]);
				unset($data[$key]);
			}
			foreach($data as $key => $val) {
				$val = trim($val, " \t\n\r\0\x0B");
				fwrite($fpw, "{$key}={$val}\n");
			}
			fclose($fp);
		}
		else {
			fclose($fpw);
			unlink($ftmp);
			set_errmsg(MSG_LEVEL_DEF, __function__, '配置文件打开失败！' . $file);
			return false;
		}
	}
	else {
		foreach($data as $key => $val) {
			$val = trim($val, " \t\n\r\0\x0B");
			fwrite($fpw, "{$key}={$val}\n");
		}
	}

	fclose($fpw);

	if(rename($ftmp, $file))
		return true;

	unlink($ftmp);
	set_errmsg(MSG_LEVEL_DEF, __function__, '保存配置文件失败！' . $file);

	return false;
}

function lsdir($path, $fliter = '')
{
	$ret = array();
	
	if ($dh = opendir($path)){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				if(empty($fliter) == false
				&& strpos($file, $fliter) === false)
					continue;
				//if (is_file($path . '/' . $file)) {
					array_push($ret, $file);
				//}
			}
		}
		closedir($dh);
	}

	return $ret;
}

function lsdir_dir($path)
{
	$ret = array();
	
	if ($dh = opendir($path)){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				if (is_dir($path . '/' . $file)) {
					array_push($ret, $file);
				}
			}
		}
		closedir($dh);
	}

	return $ret;
}

function lsdir_file($path)
{
	$ret = array();
	
	if (($dh = opendir($path))){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				if (is_file($path . '/' . $file)) {
					array_push($ret, $file);
				}
			}
		}
		closedir($dh);
	}

	return $ret;
}

function is_MobileWeb()
{
	$user_agent = $_SERVER['HTTP_USER_AGENT'];

	if(preg_match('/ipad/i', $user_agent, $matches))
		return true;
	if(preg_match('/iphone os/i', $user_agent, $matches))
		return true;
	if(preg_match('/midp/i', $user_agent, $matches))
		return true;
	if(preg_match('/rv:1.2.3.4/i', $user_agent, $matches))
		return true;
	if(preg_match('/ucweb/i', $user_agent, $matches))
		return true;
	if(preg_match('/android/i', $user_agent, $matches))
		return true;
	if(preg_match('/windows ce/i', $user_agent, $matches))
		return true;
	if(preg_match('/windows mobile/i', $user_agent, $matches))
		return true;

	// 微信浏览器
	if (strpos($user_agent, 'MicroMessenger'))
		return true;
	
	return false;
}

function readjson($file, $assoc = false)
{
	$content = file_get_contents($file);
	if(!$content) 
		return false;

	$result = json_decode($content, $assoc);
	if(!$result) 
		return false;

	return $result;
}

