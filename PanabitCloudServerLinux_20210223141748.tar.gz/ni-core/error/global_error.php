<?php
// ********************************************************
// lasterror msg manage
// ********************************************************
define( 'ERR_OK', 0);
define( 'ERR_FAILURE', -1);
define( 'ERR_302', 302);


define( 'MSG_LEVEL_DEF', 0);
define( 'MSG_LEVEL_ARG', 1);
define( 'MSG_LEVEL_EXP', 2);
define( 'MSG_LEVEL_LOAD', 3);


$GLOBALS['global_lasterror'] = '';

function set_errmsg($level, $func, $err)
{
	global $global_lasterror;
	
	$global_lasterror = $err;
}

function get_errmsg($tag = ' ')
{
	global $global_lasterror;
	
	if($global_lasterror == '')
		return '';
	
	if($tag == '')
		return $global_lasterror;
	else
		return $tag . $global_lasterror;
}

function print_errmsg()
{
	global $global_lasterror;
	
	echo $global_lasterror;
}


// ********************************************************
// lasterror data manage
// ********************************************************
$GLOBALS['global_web_error'] = array(
		'ret' => ERR_FAILURE,
		'data'=> 0,
		'msg' => ''
	);

function set_error_data($code, $msg = '', $data = 0)
{
	global $global_web_error;

	$global_web_error = array(
		'ret' => $code,
		'data'=> $data,
		'msg' => $msg
	);
}

function get_error_data()
{
	global $global_web_error, $global_lasterror;

	if(empty($global_web_error['msg']))
		$global_web_error['msg'] = $global_lasterror;
	else
		$global_web_error['msg'] .= ' ' . $global_lasterror;

	return $global_web_error;
}

function json_error_data_exit()
{
	echo json_encode(get_error_data());
	exit;
}

function json_error_exit($code, $msg = '', $data = 0)
{
	global $global_lasterror;

	$error = array(
		'ret' => $code,
		'data'=> $data,
	);
	
	if(empty($msg))
		$error['msg'] = $global_lasterror;
	else
		$error['msg'] = $msg . ' ' . $global_lasterror;

	echo json_encode($error);
	exit;
}

function dump_error_exit($code, $msg = '', $data = 0)
{
	global $global_lasterror;
	
	$error = array(
		'ret' => $code,
		'data'=> $data
	);

	if(empty($msg))
		$error['msg'] = $global_lasterror;
	else
		$error['msg'] = $msg . ' ' . $global_lasterror;
	
	var_dump($error);
	exit;
}
