<?php
// ********************************************************
// autoload class of manage
// ********************************************************

if (defined('DEV_MODE') == false)
	define( 'DEV_MODE', 1);

$GLOBALS['global_autoload_path'] = array();
$GLOBALS['global_autoload_path_load'] = array();

function global_autoload_path_push($path)
{
	global $global_autoload_path;

	if(in_array($path, $global_autoload_path))
		return;

	array_push($global_autoload_path, $path);
}

spl_autoload_register(function($class_name)
{
	global $global_autoload_path, $global_autoload_path_load;

	$class_fname = $class_name;
	$fpath = "/class/$class_fname.php";

	for($i = count($global_autoload_path) - 1; $i >= 0; $i--) {
		$file = $global_autoload_path[$i] . $fpath;
		if(file_exists($file)) {
			if(isset($global_autoload_path_load[$global_autoload_path[$i]]) == false)
				$global_autoload_path_load[$global_autoload_path[$i]] = array();

			array_push($global_autoload_path_load[$global_autoload_path[$i]], array(
				'class' => $class_fname,
				'file'	=> $file,
			));

			if(DEV_MODE)
				require_once($file);
			else
				@require_once($file);
			return true;
		}
	}

	set_errmsg(MSG_LEVEL_LOAD, __function__, "not found class '$class_name'.");

	return false;
});


$GLOBALS['global_object_manage_table'] = array();


function objectload($class_name, $data = array())
{
	global $global_object_manage_table;

	if(isset($global_object_manage_table[$class_name]))
		return $global_object_manage_table[$class_name];

	$obj = new $class_name($data);
	if($obj !== false)
		$global_object_manage_table[$class_name] = $obj;
	
	return $obj;
}