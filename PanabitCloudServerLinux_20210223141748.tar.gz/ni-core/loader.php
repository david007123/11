<?php
// ********************************************************
// ni-core load manage
// ********************************************************

// error_reporting(E_ALL ^ E_NOTICE);
$timezone_id = 'PRC';
if (file_exists(TIMEZONE_CONF) && $fp = fopen(TIMEZONE_CONF, "r")) {
	while (!feof($fp)) {
		if(($buf = fgets($fp)) === false)
			break;
		if(empty($buf = trim($buf, "\t\n\r\0\x0B")))
			continue;

		$col = explode('=', $buf, 2);
		if(count($col) != 2)
			continue;
		$key = trim($col[0]);
		$col[1] = trim($col[1]);
		if(strpos($key, ' ') !== false || empty($col[1]))
			continue;

		if($key != 'timezone_id')
			continue;

		$timezone_id = trim($col[1]);
		break;
	}
	fclose($fp);
}
date_default_timezone_set($timezone_id);

defined('ROOT_DIR') or define('ROOT_DIR', dirname(__DIR__));
defined('WEB_NAME') or define('WEB_NAME', basename(ROOT_DIR));
defined('WEB_TITLE') or define('WEB_TITLE', 'Panabit - 云平台');

require_once(__DIR__ . '/error/global_error.php');
require_once(__DIR__ . '/comm.php');

// class load
require_once(__DIR__ . '/class/ni_base.php');
require_once(__DIR__ . '/class/ni_db.php');
require_once(__DIR__ . '/class/verify.php');
// require_once(__DIR__ . '/class/language.php');
require_once(__DIR__ . '/class.php');

require_once(__DIR__ . '/hook.php');
require_once(__DIR__ . '/applib.php');

// lib load
require_once(__DIR__ . '/lib/amap.php');
require_once(__DIR__ . '/lib/phpqrcode.php');

require_once(__DIR__ . '/route.php');

if(file_exists(ROOT_DIR . '/lib/loader.php'))
	require_once(ROOT_DIR . '/lib/loader.php');
