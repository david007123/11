<?php
// ********************************************************
// hook of manage
// ********************************************************

$GLOBALS['global_hook_table'] = array();
$GLOBALS['global_hook_priority'] = array();

function hook_global_exec($data)
{
	global $global_hook_table;
	global $global_hook_priority;

	foreach($global_hook_priority as $key => $hook_name) 
		hook_exec($data, $hook_name);
}

function hook_create($name = 'default', $lastfunc = '', $remark = '')
{
	global $global_hook_table;
	
	if($name == '') return false;

	if(isset($global_hook_table[$name]) === false) {
		$global_hook_table[$name] = array(
			'table'	=> array(),		// 用于标记一个注册的 hook 在 hooks 中的位置，以便快速删除。
			'hooks'	=> array(),		// 注册的hook列表
			'remark'=> $remark,		// 备注勾子的作用
			'func'	=> $lastfunc,	// last call of func 在“hooks”表中最后被调用的函数
			'data'	=> array(),		// 勾子内产生的数据缓存
			'error'	=> array(		// 最后调用出错的勾子
				'index'	=> -1,		// 调用勾子函数时的索引
				'func'	=> '',		// 最后出错的勾子
			),
		);
	}

	return true;
}

function hook_destroy($name = 'default')
{
	global $global_hook_table;
	
	if(isset($global_hook_table[$name]) === false) return false;

	unset($global_hook_table[$name]);
}

function hook_lastfunc($name = 'default', $func = false)
{
	global $global_hook_table;
	
	if($name == '') return false;

	if(isset($global_hook_table[$name]) === false) return false;
	
	$global_hook_table[$name]['func'] = $func;

	return true;
}

function hook_remark($name = 'default', $remark = '')
{
	global $global_hook_table;
	
	if($name == '') return false;

	if(isset($global_hook_table[$name]) === false) return false;
	
	$global_hook_table[$name]['remark'] = $remark;

	return true;
}

function hook_register($func = '', $remark = '', $name = 'default')
{
	global $global_hook_table;
	
	if($name == '') return false;
	if($func == '') return false;

	if(isset($global_hook_table[$name]) === false) return false;
		
	if(isset($global_hook_table[$name]['table'][$func]) === false) {
		$count = array_push($global_hook_table[$name]['hooks'], array(
			'func'	=> $func,
			'remark'=> $remark,
		));
		$global_hook_table[$name]['table'][$func] = $count - 1;
	}
	else {
		$index = $global_hook_table[$name]['table'][$func];
		$global_hook_table[$name]['table'][$index]['remark'] = $remark;
	}
}

function hook_remove($func, $name)
{
	global $global_hook_table;
	
	if(isset($name) == false || empty($name)) $name = 'default';
	if(isset($global_hook_table[$name]) === false) return;

	if(isset($global_hook_table[$name]['table'][$func]) === false) return;

	$index = $global_hook_table[$name]['table'][$func];
	unset($global_hook_table[$name]['hooks'][$index]);
	unset($global_hook_table[$name]['table'][$func]);
}

function hook_exec($data = array(), $name = 'default')
{
	global $global_hook_table;

	if(isset($global_hook_table[$name]) === false) return $data;

	foreach($global_hook_table[$name]['hooks'] as $key => $hook) {

		if(function_exists($hook['func']) == false) {
			$global_hook_table[$name]['error']['index'] = $key;
			$global_hook_table[$name]['error']['func']	= $hook['func'];
			return false;
		}
		if(($data = call_user_func($hook['func'], $data)) === false)
			break;
	}

	if(empty($global_hook_table[$name]['func']) === false && function_exists($global_hook_table[$name]['func']))
		$data = call_user_func($global_hook_table[$name]['func'], $data);

	$global_hook_table[$name]['data'] = $data;

	return $data;
}
