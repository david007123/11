<?php

class ni_db extends PDO {
    protected $hasActiveTransaction = false;
	var $lastsql = '';

    function beginTransaction () {
       if ( $this->hasActiveTransaction ) {
          return false;
       } else {
          $this->hasActiveTransaction = parent::beginTransaction ();
          return $this->hasActiveTransaction;
       }
    }

    function commit () {
       parent::commit ();
       $this->hasActiveTransaction = false;
    }

    function rollback () {
       parent::rollback ();
       $this->hasActiveTransaction = false;
    }

	public function execParams($sql, $params) { 
		$stm = $this->prepare($sql); 
		$result = false;
		if( $stm && $stm->execute($params) ) { 
			$result = $stm->rowCount(); 
			while( $stm->fetch(PDO::FETCH_ASSOC) ) { 
				// do...
			}
		}
		return $result; 
	}

/*
		$type = array(
			'boolean'	=> PDO::PARAM_BOOL,
			'integer'	=> PDO::PARAM_INT,
			'double'	=> PDO::PARAM_INT,
			'string'	=> PDO::PARAM_STR,
			'array'		=> ,
			'object'	=> ,
			'resource'	=> PDO::PARAM_LOB,
			'NULL'		=> PDO::PARAM_NULL,
		);
*/
	public function insert( $table, $data, $calltype = null, array $driver_options = array() )
	{
		$fields = array_keys( $data );
		$fmt_fields = array();
		array_walk($data, function($val, $key) use(&$fmt_fields){
			$fmt_fields[":$key"] = $val;
		});
		$formatted_fields = array_keys( $fmt_fields );

		$this->lastsql = $sql = "INSERT INTO `$table` (`" . implode( '`,`', $fields ) . "`) VALUES (" . implode( ",", $formatted_fields ) . ")";
		if(($stm = parent::prepare($sql, $driver_options)) === false) 
			return $stm;

		if(is_string($calltype)) {
			foreach($fmt_fields as $key => $val) {
				$stm->bindValue($key, $val, $calltype(substr($key, 1)));
			}
		}
		else {
			foreach($fmt_fields as $key => $val) {
				$stm->bindValue($key, $val);
			}
		}

		return $stm;
	}

	public function update( $table, $data, $where, $calltype = null, array $driver_options = array() )
	{
		$bits = $fields = $keys = $wheres = array();
		// data
		foreach($data as $key => $val) {
			array_push($bits, "`$key` = ?");

			array_push($keys, $val);
			array_push($fields, $val);
		}
		// where
		foreach($where as $key => $val) {
			array_push($wheres, "`$key` = ?");

			array_push($keys, $val);
			array_push($fields, $val);
		}

		$this->lastsql = $sql = "UPDATE `$table` SET " . implode( ', ', $bits ) . ' WHERE ' . implode( ' AND ', $wheres );
		if(($stm = parent::prepare($sql, $driver_options)) === false) 
			return $stm;

		if(is_string($calltype)) {
			foreach($fields as $key => $val) {
				$stm->bindValue($key, $val, $calltype($keys[$key]));
			}
		}
		else {
			foreach($fields as $key => $val) {
				$stm->bindValue($key, $val);
			}
		}

		return $stm;
	}
	
	public function delete( $table, $where, $calltype = null, $driver_options = array() )
	{
		$keys = array_keys($where);
		$fields = array_values($where);
		$wheres = array();
		
		// where
		foreach($where as $key => $val) 
			array_push($wheres, "`$key` = ?");

		$this->lastsql = $sql = "DELETE FROM `$table` WHERE " . implode( ' AND ', $wheres );
		if(($stm = parent::prepare($sql, $driver_options)) === false) 
			return $stm;

		if(is_string($calltype)) {
			foreach($fields as $key => $val) {
				$stm->bindValue($key, $val, $calltype($keys[$key]));
			}
		}
		else {
			foreach($fields as $key => $val) {
				$stm->bindValue($key, $val);
			}
		}

		return $stm;
	}
	
	function wheresql($where = null)
	{
		if(is_array($where) == false)
			return '';

		if(is_array($where['keys']) == false)
			return '';

		if(is_array($where['opts']) == false) {
			foreach($where as $key => $val) {
				$where['opts'] = '=';
			}
		}

		// where
		$i = 0;
		$wheres = array(
			'sql'			=>	array(),
			'fields'		=>	array(),
			
		);
		foreach($where['keys'] as $key => $val) {
			array_push($wheres['sql'], "`:where_field_$i` " . $where['opts'][$i] . " :where_data_$i");
			
			$i++;
		}

		return $wheres;
	}
	
	public function select( $table, $fkeys = "*", array $where = array(), 
		$group_by = '', array $order_by = array(), 
		$calltype = null, array $driver_options = array() )
	{
		$keys = array_keys($where);
		$fields = array_values($where);
		$wheres = array();
		
		// fields
		if(is_array($fkeys)){
			$fkeya = array();
			foreach($fkeys as $val)
				array_push($fkeya, '`' . $val . '`');
			$fkeys = implode( ', ', $fkeya );
		}
		else {
			if(is_string($fkeys) == false)
				$fkeys = '*';
		}
		
		// where
		$i = 0;
		foreach($where as $key => $val) {
			array_push($wheres, "`$key` " . (isset($wherefrm[$i])?'=':$wherefrm[$i]) . " :where_$i");
			$i++;
		}
		
		$othesql = array();
		if($group_by != '') {
			$fkeys .= ", count(`:group_by_field`) as `_gbcount`";
			array_push($othesql, 'GROUP BY `:group_by_key`');
		}

		if(count($order_by)) {
			
			$fmt_fields = array();
			array_walk($order_by, function($val, $key) use(&$fmt_fields){
				$fmt_fields[] = "`:order_by_" . count($fmt_fields) . "` " . ($val? 'DESC' : 'ASC');
			});
			
			array_push($othesql, 'ORDER BY ' . implode( ', ', $fmt_fields ));
		}
		
		$this->lastsql = $sql = "SELECT $fkeys FROM `$table` WHERE " . implode( ' AND ', $wheres ) . implode( ' ', $othesql );
		
		if(($stm = parent::prepare($sql, $driver_options)) === false) 
			return $stm;
		
		// where
		if(count($order_by)) {
			$stm->bindValue(":group_by_field", $group_by, PDO::PARAM_STR);
			$stm->bindValue(":group_by_key", $group_by, PDO::PARAM_STR);
		}
		
		// group_by
		if($group_by != '') {
			$stm->bindValue(":group_by_field", $group_by, PDO::PARAM_STR);
			$stm->bindValue(":group_by_key", $group_by, PDO::PARAM_STR);
		}
		
		// order_by
		if(count($order_by)) {
			$ofkeys = array_keys($order_by);
			foreach($ofkeys as $key => $val) {
				$stm->bindValue(":order_by_$key", $val, PDO::PARAM_STR);
			}
		}
		
		if(is_string($calltype)) {
			foreach($fields as $key => $val) {
				$stm->bindValue($key, $val, $calltype($keys[$key]));
			}
		}
		else {
			foreach($fields as $key => $val) {
				$stm->bindValue($key, $val);
			}
		}

		return $stm;
	}
}

class NiDBException extends PDOException
{
    /**
     * Prettify error message output.
     *
     * @return string
     */
    public function errorMessage()
    {
        return '<strong>' . htmlspecialchars($this->getMessage()) . "</strong><br />\n";
    }
}
