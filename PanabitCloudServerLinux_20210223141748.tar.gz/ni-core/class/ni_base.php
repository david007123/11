<?PHP
class ni_base
{
	protected $last_error = '';

	public function lastError() 
	{
		return $this->last_error;
	}
	
	public function setError($err) 
	{
		return $this->last_error = $err;
	}
	
	public function ClassName()
	{
		echo get_class($this);
	}
}

class ni_filter extends ni_base
{
	var $isMust;
	var $alias;
	var $defval;
	var $errmsg;

	public function __construct($isMust = false, $alias = null, $defval = '__NULL__', $errmsg = null)
	{
		$this->isMust = $isMust;
		$this->alias = $alias;
		$this->defval = $defval;
		$this->errmsg = $errmsg;
	}

    public function filter(array $var, string $key, array &$ret)
	{
		if(empty($this->alias))
			$name = $key;
		else
			$name = $this->alias;

        if (!isset($var[$key])) {
			if($this->isMust) {
				if($this->defval === '__NULL__') {
					if(empty($this->errmsg)) 
						$this->setError("the \"$key\" can not be empty!");
					else
						$this->setError($this->errmsg);
				}
				else {
					$ret[$name] = $this->defval;
					return $name;
				}
			}
			return false;
		}

		$ret[$name] = $var[$key];

		return $name;
    }
}

class FilterVarInt extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

        $ret[$name] = intval($ret[$name]);
		return true;
    }
}

class FilterVarID extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

        $ret[$name] = intval($ret[$name]);
		if($ret[$name] <= 0) {
			$this->setError("the \"$key\" value \"" . $ret[$name] . "\", must be > 0.");
			return false;
		}
			
		return true;
    }
}

class FilterVarStr extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

        $ret[$name] = trim($ret[$name]);
		return true;
    }
}

class FilterVarIP extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

        $ret[$name] = ip2long(trim($ret[$name]));
		return true;
    }
}

class FilterVarFloat extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

        $ret[$name] = floatval($ret[$name]);
		return true;
    }
}

class FilterVarBool extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

        $ret[$name] = boolval($ret[$name]);
		return true;
    }
}

class FilterVarArr extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

		if(is_array($ret[$name]))
			$ret[$name] = $ret[$name];
		else
			$ret[$name] = (array)($ret[$name]);
		return true;
    }
}

class FilterVarUkn extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

		$ret[$name] = $ret[$name];
		return true;
    }
}

class FilterVarSerialNo extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

		$ret[$name] = trim($ret[$name]);

		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $ret[$name], $match) == false) {
			$this->setError("the \"$key\" value \"" . $ret[$name] . "\" is wrong!");
			return false;
		}

		return true;
    }
}

class FilterVarMachineNo extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

		$ret[$name] = trim($ret[$name]);

		if(preg_match("/^([a-zA-Z0-9-]{83})$/", $ret[$name], $match) == false) {
			$this->setError("the \"$key\" value \"" . $ret[$name] . "\" is wrong!");
			return false;
		}

		return true;
    }
}

class FilterVarEmail extends ni_filter
{
    public function filter(array $var, string $key, array &$ret)
	{
		if(($name = parent::filter($var, $key, $ret)) === false)
			return false;

		$ret[$name] = trim($ret[$name]);

		if(preg_match("/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/", $ret[$name], $match) == false) {
			$this->setError("the \"$key\" value \"" . $ret[$name] . "\" is wrong!");
			return false;
		}

		return true;
    }
}

function filter_data($var, $filter, &$errmsg)
{
    $ret = array();

    foreach ($filter as $key => $filterobj) {
		if($filterobj->filter($var, $key, $ret) == false) {
			if(($errmsg = $filterobj->lastError()) != '')
				return false;
		}
    }

    return $ret;
}

function filter_request($var, $default_structure) {

    $ret = array();

    foreach ($default_structure as $key => $value) {
        if (!isset($var[$key])) {
            $ret[$key] = $value;
        } elseif (is_array($value)) {
            $ret[$key] = filter_request($var[$key], $value);
        } elseif (is_array($var[$key])) {
            $ret[$key] = $value;
        } else {
            $ret[$key] = $var[$key];
        }
    }

    return $ret;
}

/*
Example:

function check($data)
{

	$filter = array(
		'ipcnt'		=> new FilterVarInt(),
		'months'	=> new FilterVarInt(),
		'days'		=> new FilterVarInt(),
		'remark'	=> new FilterVarString(),
		'money'		=> new FilterVarInt(),
		'rebate'	=> new FilterVarFloat(true, 'xx'),
	);
	if(($frmData = filter_data($data, $filter, $errmsg)) === false) {
		// set_globalerror(1, $errmsg);
		echo $errmsg . "\n";
		return false;
	}

	return $frmData;
}

$data = array(
	'ipcnt'		=> 33,
	'months'	=> 23,
	'days'		=> 11,
	'remark'	=> 3,
	'money'		=> 44,
//	'rebate'	=> 4.4,
);

var_dump(check($data));

// print_globalerror_tojson_exit(); 
*/