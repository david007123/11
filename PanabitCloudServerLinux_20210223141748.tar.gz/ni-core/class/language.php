<?php

class language
{
	private $lang = 'zh';
	private $config = [];

    public function __construct(string $lang)
    {
		$this->lang = $lang;
    }
	
	public function set(string $lang)
	{
		$this->lang = $lang;
	}

	public function get()
	{
		return $this->lang;
	}
	
	function readjson($file, $assoc = false)
	{
		$content = file_get_contents($file);
		if(!$content) 
			return false;

		$result = json_decode($content, $assoc);
		if(!$result) 
			return false;

		return $result;
	}
	
	public function load(string $path, string $name)
	{
		$file = "{$path}/language/{$this->lang}{$name}";
		if(!file_exists($file))
			return false;
		$config = $this->readjson($file, true);
		if($config !== false) {
			$this->config = $config;
			return true;
		}
		return false;
	}

	public function dump(string $id, string $default)
	{
		if(!isset($this->config[$id]))
			return $default;

		$str = $this->config[$id];
		return ($str !== NULL ? $str : $default);
	}
	
	public function format(string $id, $data)
	{
		if(!$id) {
			return $data;
		}

		if(!isset($this->config[$id]))
			return $data;

		$template = $this->config[$id];

		if(is_array($data))
			return self::vsprintfn($template, $data);
		else
			return self::vsprintfn($template, (array)$data);
	}

	/**
	* Returns a formatted string. Accepts named arguments.
	* @param string $format
	* @param array $args
	* @return string
	**/
	public static function vsprintfn($format, $args) {
		// search format patterns
		// $exampleData = array(0=>2.2314123123,'test'=>2.1234883);
		// echo vsprintfn('%%2.5f = %2.5f', $exampleData) . "\n";
		// echo vsprintfn('%%(test)09.5f = %(test)\'%9.5f', $exampleData) . "\n";
		preg_match_all('/((?:^|[^%])(?:%%)*)%(\([a-z][a-zA-Z0-9_]*\))?((\+|-)?(0| |\'.)?-?[0-9\.]*[bcdeEufFgGosxX])/', $format, $matches);
		// determine the order of the arguments
		$j = 0;
		$order = array();
		foreach ($matches[0] as $i => $match) {
			if ($matches[2][$i] == '') {
				$key = $j++;
			} else {
				$key = substr($matches[2][$i],1,-1);
			}
			$order[] = $key;
		}
		// prepare the data array for vsprintf in the given order
		$data = array();
		foreach ($order as $key) {
			if (isset($args[$key])) {
				$data[] = $args[$key];
			}
		}
		// replace named format patterns with default format patterns
		$format = preg_replace('/((?:^|[^%])(?:%%)*)%(\([a-z][a-zA-Z0-9_]*\))((\+|-)?(0| |\'.)?-?[0-9\.]*[bcdeEufFgGosxX])/', '$1%$3', $format);
		// return formatted string
		return vsprintf($format, $data);
	}
}
