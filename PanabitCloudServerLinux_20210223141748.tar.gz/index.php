<?php
require_once(__DIR__ . '/conf/config.php');
require_once(__DIR__ . '/apps/user/lib/login.php');

\cloud\apps\user\_auth_js_exit('', '');

if($user->username != ADMIN_ACCT) {
	$conf = \cloud\apps\user\sms_usecheck();
	if(is_array($conf)) {
		if(!empty($conf['mustbind']) && !$user->mobile) {
			header("Content-type: text/html; charset=utf-8");
			echo "<script>location='page.php?r=user@bindphone';</script>";
			exit;
		}
	}
}

?>
<!doctype html>
<html class="x-admin-sm">
	<head>
		<meta charset="UTF-8">
		<title>Panabit - 云平台</title>
		<meta name="renderer" content="webkit|ie-comp|ie-stand">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<!-- <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" /> -->
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="stylesheet" type="text/css" href="assets/css/font.css">
		<link rel="stylesheet" type="text/css" href="assets/css/xadmin.css">
		<link rel="stylesheet" type="text/css" href="assets/css/cloud.css" />
		<link rel="stylesheet" type="text/css" href="assets/lib/font-awesome/4.7.0/css/font-awesome.min.css">
		<!-- <link rel="stylesheet" href="assets/css/theme5.css"> -->
		<script type="text/javascript"  src="assets/js/jquery.min.js" charset="utf-8"></script>
		<script type="text/javascript" src="assets/js/jq.cookie.js" charset="utf-8"></script>
		<script type="text/javascript" src="assets/lib/layui/layui.js" charset="utf-8"></script>
		<script type="text/javascript" src="assets/js/comm.js" charset="utf-8"></script>
		<style>
			.layui-nav-item .layui-nav-more{
				display: none !important;
			}
			.layui-nav-item a{
				height: 16px !important;
				line-height: 16px !important;
			}
			.layui-nav-child dd a{
				padding-left: 65px !important;
				font-size: 12px !important;
				color: rgba(255,255,255,.7) !important;
			}
			.layui-nav-child dd a:hover{
				color: white !important;
			}
			.alarmTip{
				border-radius: 50%;
				height: 13px;
				width: 13px;
				background: red;
				padding: 2px;
				display: inline-block;
				text-align: center;
				position: absolute;
				right: 35px;
				top: 4px;
			}
		</style>
		<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
		<!--[if lt IE 9]>
          <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
          <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
		<script>
			// 是否开启刷新记忆tab功能
			// var is_remember = false;
		</script>
	</head>
	<body class="index">
		<!-- 顶部开始 -->
		<div class="container">
			<div class="logo">
				<a href="index.php"><img class="logoimg" src="assets/img/logo.gif"></a>
			</div>
			<ul class="left_open">
				<li class="work_menu"><a><i class="iconfont">&#xe699;</i></a></li>
				<li class="work_mgd_project" style="display: none;"><a><i class="fa fa-cog"></i></a></li>
				<li class="work_project"><a><i class="fa fa-flag"></i></a></li>
			</ul>
			<ul class="rightinfo cpuplane">
				<li>
					<p class="rightinfo-title username"><?php echo $user->username;?></p>
					<p class="rightinfo-content exit">退出</p>
				</li>
				<li>
					<p class="rightinfo-title">已运行</p>
					<p class="rightinfo-content running">7d22h50m37s</p>
				</li>
				<li>
					<p class="rightinfo-title">硬盘使用率</p>
					<p class="rightinfo-content disk">44% / 18 G</p>
				</li>
				<li>
					<p class="rightinfo-title">内存使用率</p>
					<p class="rightinfo-content ram">99% / 1G</p>
				</li>
				<li>
					<p class="rightinfo-title">CPU使用率</p>
					<p class="rightinfo-content cpu">14% / 1核</p>
				</li>
			</ul>
		</div>
		<!-- 顶部结束 -->
		
		<!-- 左侧菜单开始 -->
		<div class="left-nav">
					<div id="side-nav">
						<ul id="nav" class="layui-nav layui-nav-tree layui-bg-cyan layui-inline" style="width: 155px;" lay-filter="demo">
							<!--
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('设备告警','page.php?r=alarm@list')">
									<i class="fa fa-warning left-nav-li" lay-tips="设备告警"></i>
									<cite>设备告警&nbsp;<span></span></cite>
									<div class="alarmTip">9</div>
								</a>
							</li> -->
							<li class="layui-nav-item">
							    <a href="javascript:;" style="font-size: 12px;">
									<i class="fa fa-desktop left-nav-li" lay-tips="网关设备" style="padding-right: 20px;"></i>网关设备
									<i class="fa angle fa-angle-down left-nav-li" style="padding-left: 5px;"></i>
								</a>
							    <ul class="layui-nav-child">
							      <li><a href="javascript:;" onclick="xadmin.add_tab('设备列表','page.php?r=gateway@list')">设备列表</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('游戏快线','page.php?r=gamecloud@list')">游戏快线</a></li>							      
							      <li><a href="javascript:;" onclick="xadmin.add_tab('APP升级','page.php?r=upgrade@apps')">APP升级</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('内网访问','page.php?r=intranet@list')">内网访问</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('资源管理','page.php?r=source@ipgrp-list')">资源管理</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('配置备份','page.php?r=backup@list')">配置备份</a></li>
								</ul>
							</li>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('缓存设备','page.php?r=ixcache@list')">
									<i class="fa fa-cloud-download left-nav-li" lay-tips="缓存设备"></i>
									<cite>缓存设备&nbsp;<span></span></cite>
								</a>
							</li>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('日志设备','page.php?r=panalog@list')">
									<i class="fa fa-line-chart left-nav-li" lay-tips="日志设备"></i>
									<cite>日志设备&nbsp;<span></span></cite>
								</a>
							</li>
		<?php
					if (is_dir(ROOT_DIR . "/apps/zeropen")) {
		?>
							<li class="layui-nav-item">
							    <a href="javascript:;" style="font-size: 12px;">
									<i class="fa fa-cogs left-nav-li" lay-tips="SD-WAN" style="padding-right: 20px;"></i>SD-WAN
									<i class="fa angle fa-angle-down left-nav-li" style="padding-left: 4px;"></i>
								</a>
							    <ul class="layui-nav-child">
							      <li><a href="javascript:;" onclick="xadmin.add_tab('拓扑图','page.php?r=topo@list')">拓扑图</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('连接管理','page.php?r=sdwan@list')">连接管理</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('策略下发','page.php?r=devops@list')">策略下发</a></li>
							      <li><a href="javascript:;" onclick="xadmin.add_tab('零配置开通','page.php?r=zeropen@list')">零配置开通</a></li>
								</ul>
							</li>

		<?php
					}
		?>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('SAC','page.php?r=sac@list')">
									<i class="fa fa-wifi left-nav-li" lay-tips="SAC"></i>
									<cite>SAC</cite>
								</a>
							</li>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('设备地图','page.php?r=pamap@list')">
									<i class="fa fa-location-arrow left-nav-li" lay-tips="设备地图"></i>
									<cite>&nbsp;设备地图</cite>
								</a>
							</li>
		<?php
					if ($user->username == "XXXXXXXXXadmin") {
		?>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('网桥拓扑','page.php?r=patopo@list')">
									<i class="fa fa-sitemap left-nav-li" lay-tips="网桥拓扑"></i>
									<cite>网桥拓扑</cite>
								</a>
							</li>
		<?php
					}
		?>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('设备升级','page.php?r=upgrade@equipment')">
									<i class="fa fa-arrow-up left-nav-li" lay-tips="设备升级"></i>
									<cite>设备升级</cite>
								</a>
							</li>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('系统升级','page.php?r=system@upgrade')">
									<i class="fa fa-rocket left-nav-li" lay-tips="系统升级"></i>
									<cite>系统升级</cite>
								</a>
							</li>
		<?php
					//}
					if (is_supadmin($user->username)) {
		?>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('用户管理','page.php?r=user@list')">
									<i class="fa fa-user-circle left-nav-li" lay-tips="用户管理"></i>
									<cite>用户管理</cite>
								</a>
							</li>
		<?php
					}
					if ($user->username == ADMIN_ACCT) {
		?>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('系统日志','page.php?r=system@logger')">
									<i class="fa fa-list-alt left-nav-li" lay-tips="系统日志"></i>
									<cite>系统日志</cite>
								</a>
							</li>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('一键断网','page.php?r=netoff@list')">
									<i class="fa fa-power-off left-nav-li" lay-tips="一键断网"></i>
									<cite>一键断网</cite>
								</a>
							</li>
		<?php
					}
		?>
							<li>
								<a href="javascript:;" onclick="xadmin.add_tab('微信通知','page.php?r=wechatinfo@list')">
									<i class="fa fa-weixin left-nav-li" lay-tips="微信通知"></i>
									<cite>微信通知</cite>
								</a>
							</li>
						</ul>
						</li>
						</ul>
					</div>
				</div>
		
		<!-- <div class="x-slide_left"></div> -->
		<!-- 左侧菜单结束 -->
		<!-- 右侧主体开始 -->
		<div class="page-content">
			<div class="layui-tab tab" lay-filter="xbs_tab" lay-allowclose="false">
				<ul class="layui-tab-title">
				</ul>
				<div class="layui-unselect layui-form-select layui-form-selected" id="tab_right">
					<dl>
						<dd data-type="this">关闭当前</dd>
						<dd data-type="other">关闭其它</dd>
						<dd data-type="all">关闭全部</dd>
					</dl>
				</div>
				<div class="layui-tab-content">
				</div>
				<div id="tab_show"></div>
			</div>
		</div>
		<div class="page-content-bg"></div>
		<style id="theme_style"></style>
		<!-- 右侧主体结束 -->
		<!-- 中部结束 -->
		<script type="text/javascript" src="assets/js/xadmin.js"></script>
		<script>
			layui.use('element', function(){
			  var element = layui.element;
			  element.render('nav', 'demo')
			});
			function sysrun() {
				$.ajax({
					url:'api.php?r=system@sysrun',
					data:{ipdata_checked: 1},
					type:'post',
					dataType:'json',
					success:function(d) {
						if(ajax_resultCallBack(d) == false) return;
						var data = d.data.sysrun;
						
						$(".cpuplane .cpu").html(data.cpu + '% / ' + data.ncpu + '核');
						$(".cpuplane .ram").html(data.mem + '% / ' + parseInt(data.totalmem) +'G');
						$(".cpuplane .disk").html(data.hard + '% / ' + data.hsize);
						$(".cpuplane .running").html(parsesysrun(d.data.now - d.data.boottime));
					}
				});
			}
			setInterval(sysrun, 60000);
			sysrun();
			
			$('.cpuplane .exit').click(function(){
				$.ajax({
					url:'api.php?r=user@logout',
					data:{ipdata_checked: 1},
					type:'post',
					dataType:'json',
					success:function(d) {
						if(ajax_resultCallBack(d) == false) return;
					}
				});
			});

			//页面自动退出
			var lastTime = new Date().getTime();
			var currentTime = new Date().getTime();
			var leaveTime = <?=\cloud\apps\user\security_no_opstm()?> * 60 * 1000; //10分钟

			$(function(){
				$(document).mouseover(function(){
					lastTime = new Date().getTime();

				});
			});

			function testTime(){
				currentTime = new Date().getTime();
				if(currentTime - lastTime > leaveTime){
					$('.cpuplane .exit').click();
					return;
				}
			}
			if(leaveTime && leaveTime > 0)
				window.setInterval(testTime, 1000);
		</script>
	</body>

</html>
