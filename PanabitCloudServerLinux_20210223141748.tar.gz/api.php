<?php
require_once(__DIR__ . '/conf/config.php');

if(($page_file = route_api()) === false)
	exit;

$page_file = ROOT_DIR . '/' . $page_file;

if(file_exists($page_file) === false) 
	json_error_exit(ERR_FAILURE, 'fail: not this api!');

require_once($page_file);
