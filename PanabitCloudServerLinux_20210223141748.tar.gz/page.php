<?php
require_once(__DIR__ . '/conf/config.php');
require_once(__DIR__ . '/apps/user/lib/login.php');

$page_file = ROOT_DIR . '/' . route_page();

$user = \cloud\apps\user\logged();


if($_REQUEST['r'] == 'user@login') {
	if($user !== false) {
		header("Content-type: text/html; charset=utf-8");
		echo "<script>location='index.php';</script>";
		exit;
	}
}
else
if($user === false)
	\cloud\apps\user\_dump_login_page(get_errmsg(''));

if($_REQUEST['r'] != 'user@bindphone' && $_REQUEST['r'] != 'user@login') {
	if($user->username != ADMIN_ACCT) {
		$conf = \cloud\apps\user\sms_usecheck();
		if(is_array($conf)) {
			if(!empty($conf['mustbind']) && !$user->mobile) {
				header("Content-type: text/html; charset=utf-8");
				echo "<script>location='page.php?r=user@bindphone';</script>";
				exit;
			}
		}
	}
}

if(file_exists($page_file) === false) {
	$page_file = ROOT_DIR . '/' . route_404();
	require_once($page_file);
	exit;
}

require_once($page_file);
