function openssh_m(licenseid, ip, webenable, sshenable)
{
	cloud_tips_show();
	
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'openssh_m', licenseid: licenseid, webenable:webenable, sshenable:sshenable},
		dataType:'json',
		type:'post',
		success:function(data){
			cloud_tips_hide();
			
			as = (data.str).split('-');
			
			if (data.yn == "yes") {
				surl = '';
				if (as[2] != "" && as[2] != "none")
					surl = '/login/userverify.cgi?pakey='+as[2]+'&username=admin';
				window.open("https://"+ip+":"+as[0]+surl, "_blank");
			}
			else
				alert(data.str);
		}
	});
}

function detailclose()
{
	$("#detail-dialog").hide();
}

function device_version_list(render)
{
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'task_version_list'},
		dataType:'json',
		type:'post',
		success:function(json) {
			var s = '<option value="">所有版本</option>';
			for (i = 0; i < json.rows.length; i++)
				s += '<option value="'+json.rows[i]+'">'+json.rows[i]+'</option>';
			$("#"+render).find("option").remove();
			$(s).appendTo("#"+render);
		}
	})
}

var usragp_group;
var usrapp_info;

function usragp_syn_before()
{
	usragp_group = usrapp_info = "";

	var arr_group = [], arr = [];
	var arr_app = [];

	$("[name='usragp_onesel']").each(function() {
		arr.length = 0;

		if ($(this).attr("checked")) {
			arr.push($(this).attr("agp_name"));
			arr.push($(this).attr("agp_cname"));
			if ($(this).attr("son_name") == "")
				arr.push("none");
			else
				arr.push($(this).attr("son_name"));
		}
		
		str = arr.join(',');
		arr_group.push(str);
	});

	$("[name='usrapp_onesel']").each(function() {
		arr.length = 0;
		if ($(this).attr("checked")) {
			arr.push($(this).attr("app_name"));
			arr.push($(this).attr("app_cname"));
			arr.push($(this).attr("nodettl"));
			arr.push($(this).attr("tports"));
			arr.push($(this).attr("uports"));
		
			str = arr.join('|');
			arr_app.push(str);
		}
	});

	if (arr_group.length == 0 && arr_app.length == 0) {
		alert("请选择要同步的自定义协议组或者自定义协议");
		return false;
	}

	if (arr_group.length != 0)
		usragp_group = arr_group.join(';');
	if (arr_app.length != 0)
		usrapp_info = arr_app.join(';');

	return true;
}

function usragp_showdevice()
{
	$.ajax({
		url:'ajax_usragp.php',
		data:{action:'usragp_showdevice'},
		dataType:'json',
		type:'post',
		success:function(data) {
			var list = document.getElementById("usragp_showdevice_table");
		       	while (list.rows.length > 1)
			       	list.deleteRow(1);
		       	for (i = 0; i < data.rows.length; i++) {
			       	r = data.rows[i]; 
				var obj = list.insertRow(-1);

				var pos = 0;
			       	var cell = obj.insertCell(pos++);
			       	cell.innerHTML = i + 1;
		
				var cell = obj.insertCell(pos++);
			       	cell.innerHTML = r.license_id12;
			
				var cell = obj.insertCell(pos++);
			       	cell.innerHTML = r.sysname;
			
				var cell = obj.insertCell(pos++);
				if (r.error == "")
					cell.innerHTML = '<img src="../img/loading.gif" /> 准备同步，请稍后';
				else {
					switch(r.status) {
					case "0":
					case "1":
						img = '<img src="../img/loading.gif" />';
						break;
					case "2":
						img = '<img src="../img/10.png" width="12px" />';
						break;
					case "3":
						img = '<img src="../img/12.png" width="12px;" />';
						break;
					}
					cell.innerHTML = img + r.error;
				}
			}
		}
	})
}

var ints1;
function usragp_syn_after()
{
	$("#usragp-showdevice-outer").dialog({
		width: 600,
		height: 600,
		close: function(event, ui) {
			clearInterval(ints1);
		},
		buttons:[{
			text:"取消",
			click: function(){
				$(this).dialog("close");
				clearInterval(ints1);
			}
		}]
	});

	usragp_showdevice();

	ints1 = setInterval(usragp_showdevice, 1000);

}

function usragp_syn_handle()
{
	var device;
	var arr_device = [];

	$("[name='usragp_device_onesel']").each(function() {
		if ($(this).attr("checked")) {
			arr_device.push($(this).val());
		}
	});

	if (arr_device.length == 0) {
		alert("请选择要同步的设备");
		return false;
	}

	device = arr_device.join(';');

	if (!confirm("确定要为这些设备同步选择的协议组吗"))
		return false;

	$.ajax({
		url:'ajax_usragp.php',
		data:{action:'usragp_syn', device: device, usragp_group: usragp_group, usrapp_info: usrapp_info},
		dataType:'json',
		type:'post',
		success:function(json) {
			usragp_syn_after();
		}
	})
}

function usragp_syn_open()
{
	if (!usragp_syn_before())
		return false;

	$("#usragp-syn-outer").dialog({
		width: 800,
		height: 600,
		buttons:[{
			text:"取消",
			click: function(){
				$(this).dialog("close");
			}
		}, {
			text: "开始同步",
			click: function() {
				usragp_syn_handle();
			}
		}]
	});

	$("#usragp_grpid").find("option").remove();
	$('<option value="0">所有组</option>').appendTo("#usragp_grpid");

	getallgrp("", "usragp_grpid");
	device_version_list("usragp_version");
	usragp_device_list();
}

function usragp_device_list()
{
	var arr = [];
	var grpid = $("#usragp_grpid").val();
	var license_id12 = $("#usragp_id12").val();
	var name = $("#usragp_name").val();
	var version = $("#usragp_version").val();
	if (name != "")
		arr.push(name);
	if (license_id12 != "")
		arr.push(license_id12);
	if (version != "")
		arr.push(version);
	var sch = "";
	if (arr.length != 0)
		sch = arr.join('|');

	var sort = "license_end";
	var g_ascdesc = "desc";
	var expire = 2;
	var page = 1;
	var limit = 0;

	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'cloud_devlist', grpid: grpid, sch: sch, sort: sort, g_ascdesc:g_ascdesc, expire:expire, page:page, limit:limit},
		dataType:'json',
		type:'post',
		success:function(data){
			var list = document.getElementById("usragp_syn_table");
			while (list.rows.length > 1)
				list.deleteRow(1);
			for (i = 0; i < data.rows.length; i++) {
				r = data.rows[i];

				var obj = list.insertRow(-1);

				var pos = 0;
				var cell = obj.insertCell(pos++);
				cell.innerHTML = i + 1;

				var cell = obj.insertCell(pos++);
				cell.innerHTML = '<input type="checkbox" value="'+r.license_id12+'" name="usragp_device_onesel" />';

				var cell = obj.insertCell(pos++);
				cell.innerHTML = r.license_id12;

				var cell = obj.insertCell(pos++);
				if (r.sys_name2 != "")
					cell.innerHTML = r.sys_name2;
				else
					cell.innerHTML = r.sys_name;

				var cell = obj.insertCell(pos++);
				cell.innerHTML = r.grpname;

				var cell = obj.insertCell(pos++);
				cell.innerHTML = r.version;
			}
		}
	})
}

function device_detail(sys_name, license_id12, ipaddr, license_start_str, license_end_str, license_id83, max_flowcont, max_ipcnt, webport, sshport, localip, outip, ipaddr)
{
	cloud_nav_change('cloud-device-info-outer', 0);

	$("#cloud-device-info-outer").dialog({
		width: 800,
		height: 600,
		buttons:[{
			text:"取消",
			click: function(){
				$(this).dialog("close");
			}
		}, {
			text: "下一步，选择设备",
			click: function() {
				usragp_syn_open();
			}
		}]
	});

	var s = '<table style="width:100%;margin:20px 0 0 10px;height:350px;">';
	s += '<tr><td width="100px">系统名称</td><td>'+sys_name+'</td></tr>';
	s += '<tr><td>管理口地址</td><td>'+ipaddr+'</td></tr>';
	s += '<tr><td>公网地址</td><td>'+outip+'</td></tr>';
	s += '<tr><td>编号</td><td>'+license_id12+'</td></tr>';
	//s += '<tr><td>起始日期</td><td>'+license_start_str+'</td></tr>';
	//s += '<tr><td>结束日期</td><td>'+license_end_str+'</td></tr>';
	s += '<tr><td>机器码</td><td>'+license_id83+'</td></tr>';
	s += '<tr><td>许可使用时间</td><td>'+license_start_str+' - '+license_end_str+'</td></tr>';
	s += '<tr><td>最大连接数</td><td>'+max_flowcont+'</td></tr>';
	s += '<tr><td>最大用户数</td><td>'+max_ipcnt+'</td></tr>';
	s += '<tr><td>访问地址</td><td>'+localip+'</td></tr>';
	s += '<tr><td>Web登录</td><td><a href="javascript:check_port'+ '(\''+license_id12+'\', \''+localip+'\', \'web\')">登录Web页面</a></td></tr>';
	s += '<tr><td>SSH登录</td><td><a href="javascript:check_port'+ '(\''+license_id12+'\', \''+localip+'\', \'ssh\')">登录SSH；</a>'+
		'(火狐浏览器可以安装插件firessh直接登录到SSH后台，其它浏览器暂不支持)</td></tr>';
	s += '<tr id="'+license_id12+'_ssh" style="display:none"><td>SSH信息</td><td>'+localip+'</td></tr>';
	$('#cloud-device-info').html("");
	$(s).appendTo('#cloud-device-info');

	cloud_device_usragp_get(license_id12);
}

function cloud_device_usragp_get(license_id12)
{
	$("#usragp_license_id12").val(license_id12);

	$.ajax({
		url:'../Maintain/ajax_usragp.php',
		data:{action:'usragp_get', license_id12: license_id12},
		type:'post',
		dataType:'json',
		success:function(json) {
		}
	})
}

function check_port(licenseid, localip, st)
{
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'device_checkport', licenseid: licenseid},
		type:'post',
		dataType:'json',
		success:function(json) {
			if (st == "web") {
				if (json[0].enable) {
					surl = '';
					if (json[0].md5str != "" && json[0].md5str != "none")
						surl = '/login/userverify.cgi?pakey='+json[0].md5str+'&username=admin';
					window.open("https://"+localip+":"+json[0].port+surl, "_blank");
				}
				else
					openssh_m(licenseid, localip, json[0].port, 1, 0);
			}
			
			if (st == "ssh") {
				if (json[1].enable)
					window.open("ssh://"+localip+":"+json[1].port, "_blank");
				else
					openssh_m2(licenseid, localip, json[1].port);
				
				$("#"+licenseid+"_ssh").show();
				$("#"+licenseid+"_ssh").find("td").eq(2).text(localip+":"+json[1].port);
			}
		}
	});
}

function openssh_m2(licenseid, ip, port)
{
	cloud_tips_show();
	
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'openssh_m', licenseid: licenseid, sshenable:1},
		dataType:'json',
		type:'post',
		success:function(data){
			cloud_tips_hide();
			
			as = (data.str).split('-');
			
			if (data.yn == "yes")				
				window.open("ssh://"+ip+":"+as[1], "_blank");
			else
				alert(data.str);
		}
	});
}

function device_myrecord(license_id12, sys_name)
{
	var width = 900;
	var height = $(window).height();
	var top = 0;
	var left = ($(window).width()-width)/2;
	window.open("device_myrecord.php?license_id12="+license_id12+"&sys_name="+encodeURIComponent(sys_name), 
		"_blank", "width="+width+"px,height="+height+"px,left="+left+"px,top="+top+"px,resizable=no");
}

function openset(sysname, licenseid, grpid, map_address)
{
	var id = "report_pop_box_set";
	var title_id = "report_pop_box_title_set";
	var content_id = "report_pop_box_content_set";
	
	if (map_address == "none") map_address = "";
	var loginuser = $("#loginuser").val();
	
	if (loginuser != "admin")
		rp_showbox(580, 220, "set");
	else
		rp_showbox(580, 220, "set");
	$("#report_pop_box_title_set").text(sysname);
	
	var s = '<table style="margin-top:15px;">'+
		'<tr>'+
			'<td width="20px"></td>'+
			'<td width="60px">系统名称</td>'+
			'<td>'+
				'<input type="text" id="sys_name" value="'+sysname+'" style="width:430px" class="form-group-text" />'+
			'</td>'+
		'</tr>';
	/* if (loginuser != "" && loginuser == "admin") */
	s += '<tr><td width="20px"></td>'+
				'<td>所属组</td>'+
				'<td>'+
					'<select id="grplist" style="width:150px;" class="form-control">'+
						'<option value="0">所有组</option>'+
					'</select>'+
				'</td>'+
			'</tr>';
	s += '<tr><td width="20px"></td>'+
				'<td>地理位置</td>'+
				'<td>'+
				'<input type="text" value="'+map_address+'" id="map_address" class="form-group-text" '+
				'style="width:250px;" /> (具体位置：省+市+区+镇+街道+楼)'+
				'</td>'+
			'</tr>'+
		'</table>';
		
	$(s).appendTo("#"+content_id);
	
	$("#sys_name").val(sysname);
	
	getallgrp(grpid, "grplist");
	
	$("#"+id+" .foot-ok").unbind("click");
	
	$("#"+id+" .foot-ok").click(function(){sethandle(licenseid)});
}

function grpshow()
{
	var rpid = "addgrp";
	var id = "report_pop_box_"+rpid;
	var title_id = "report_pop_box_title_"+rpid;
	var content_id = "report_pop_box_content_"+rpid;
	
	rp_showbox(400, 160, rpid);
	$("#report_pop_box_title_"+rpid).text("添加组");
	
	var s = '<table style="margin-top:20px;">'+
		'<tr>'+
			'<td width="20px">&nbsp;</td>'+
			'<td width="60px">组名称</td>'+
			'<td>'+
				'<input type="text" id="grpname" value="" style="width:230px; padding:3px 0;" />'+
			'</td>'+
		'</tr>'+
	'</table>';
	
	$(s).appendTo("#"+content_id);
	$("#grpname").focus();
	
	$("#"+id+" .foot-ok").click(function(){addgrp(id)});
}

function addgrp(rpid)
{
	var grpname = $("#grpname").val();
	if (grpname == "") {
		alert("请输入正确的组名称");
		return false;
	}
	
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'cloud_addgrp', grpname: grpname},
		type:'post',
		dataType:'json',
		success:function(json){
			if (json.yn == "no")
				alert(json.str);
			else {
				$("#"+rpid).remove();
				/*
				s = '<option value="'+json.str+'">'+grpname+'</option>';
				$(s).appendTo('#grplist');
				$("#grplist").val(json.str);
				*/

				grpdialog_update();
			}
		}
	});
}

function deletegrp(id, name)
{
	var grpid, grpname;

	if (id == "") {
		grpid = $("#grplist").val();
		grpname = $("#grplist option[value="+grpid+"]").text();
	}else {
		grpid = id;
		grpname = name;
	}
	
	if (grpid == 0)
		return;
	
	if (!confirm("确定要删除组 '"+grpname+"' 吗"))
		return false;

	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'cloud_deletegrp', grpid: grpid},
		type:'post',
		dataType:'json',
		success:function(json){
			if (json.yn == "no")
				alert(json.str);
			else {
				if (id == "") {
					$("#grplist option[value="+grpid+"]").remove();
					alert("操作成功");
				}else
					grpdialog_update();
			}
		}
	});
}

function enterEvent(callback)
{
	page = 1;
	$("#grplisthdr").val("0");
	
	var sch = $("#sch").val();
	
	var ev = window.event || arguments.callee.caller.arguments[0];
	var th = ev.keyCode || ev.whick;
	if (th == 13) {
		if (typeof callback == "function")
			callback();
		else {
			cloud_devlist();
		}
	}
	else return false;
}

function sethandle(licenseid)
{
	var grpid = $("#grplist").val();
	var sysname = $("#sys_name").val();
	sysname = TrimAll(sysname);
	var map_address = $("#map_address").val();
	map_address = TrimAll(map_address);
	if (map_address == "") map_address = "none";
	
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'cloud_sethandle', 
			licenseid: licenseid, sysname: sysname, 
			grpid: grpid, 
			map_address: (map_address)},
		type:'post',
		dataType:'json',
		success:function(json){
			if (json.yn == "no")
				alert(json.str);
			else {
				$("#report_pop_box_set").hide();
			}
			
			cloud_devlist();
		}
	});
}

function closehandle()
{
	$("#set-dialog").hide();
}

function device_delete(listtype)
{
	var idstr = "";
	var namestr = "";
	var arid = [], arname = [];

	$("[name='mypa']").each(function(){
		if ($(this).attr("checked")) {
			arid.push($(this).val());
			arname.push($(this).attr("cname"));
		}
	});
	if (arid.length == 0) {
		alert("请选择要删除的设备");
		return false;
	}

	idstr = arid.join('|');
	namestr = arname.join('|');

	if (!confirm("确定要删除选中的设备吗"))
		return false;
	
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'device_delete', idstr: idstr},
		type:'post',
		dataType:'json',
		success:function(json) {
			if (json.yn == "no")
				alert(json.str);
		
			if (listtype == 0)	
				cloud_devlist();
			else
				expire_devlist();
		}
	});
}

function hd_sort(sort)
{
	g_sort = sort;
	
	if (g_ascdesc == "desc")
		g_ascdesc = "asc";
	else
		g_ascdesc = "desc";
	
	cloud_devlist();
}

function grplist(type, grpid)
{
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'cloud_grplist'},
		type:'post',
		dataType:'json',
		success:function(json) {
			$('#grplist').find("option").remove();
			
			for (i = 0; i < json.rows.length; i++) {
				r = json.rows[i];
				
				s = '<option value="'+r.grpid+'">'+r.grpname+'</option>';
				if (type == 1)
					$(s).appendTo('#grplist');
				if (type == 2)
					$(s).appendTo('#grplisthdr');
			}
			
			if (type == 1)
				$('#grplist').val(grpid);
		}
	});
}

function getallgrp(grpid, render)
{
	$.ajax({
		url:'/Maintain/system_handle.php',
		data:{type:'getallgrp'},
		type:'post',
		dataType:'json',
		success:function(json) {
			$('#grplist').find("option").remove();
			
			for (i = 0; i < json.rows.length; i++) {
				r = json.rows[i];
				s = '<option value="'+r.grpid+'">'+r.grpname+'</option>';
				$(s).appendTo('#'+render);
			}
			$('#'+render).val(grpid);
		}
	});
}

