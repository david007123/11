(function($) {
	var D = $(document).data("func", {});
	$.smartMenu = $.noop;
	$.fn.smartMenu = function(data, options) {
		var B = $("body"),
			defaults = {
				name: "",
				container: "",
				offsetX: 2,
				offsetY: 2,
				textLimit: 6,
				beforeShow: $.noop,
				afterShow: $.noop
			};
		var params = $.extend(defaults, options || {});

		var htmlCreateMenu = function(datum) {
				var dataMenu = datum || data,
					nameMenu = datum ? Math.random().toString() : params.name,
					htmlMenu = "",
					htmlCorner = "",
					clKey = "smart_menu_";
				if ($.isArray(dataMenu) && dataMenu.length) {
					htmlMenu = '<div id="smartMenu_' + nameMenu + '" class="' + clKey + 'box">' +
						'<div class="' + clKey + 'body">' +
						'<ul class="' + clKey + 'ul">';

					$.each(dataMenu, function(i, arr) {
						if (i) {
							htmlMenu = htmlMenu + '<li class="' + clKey + 'li_separate">&nbsp;</li>';
						}
						if ($.isArray(arr)) {
							$.each(arr, function(j, obj) {
								var text = obj.text,
									htmlMenuLi = "",
									strTitle = "",
									rand = Math.random().toString().replace(".", "");
								if (text) {
									if (text.length > params.textLimit) {
										text = text.slice(0, params.textLimit) + "...";
										strTitle = ' title="' + obj.text + '"';
									}
									if ($.isArray(obj.data) && obj.data.length) {
										htmlMenuLi = '<li class="' + clKey + 'li" data-hover="true">' + htmlCreateMenu(obj.data) +
											'<a href="javascript:" class="' + clKey + 'a"' + strTitle + ' data-key="' + rand + '"><i class="' +
											clKey + 'triangle"></i>' + text + '</a>' +
											'</li>';
									} else {
										htmlMenuLi = '<li class="' + clKey + 'li">' +
											'<a href="javascript:" class="' + clKey + 'a"' + strTitle + ' data-key="' + rand + '">' + text +
											'</a>' +
											'</li>';
									}

									htmlMenu += htmlMenuLi;

									var objFunc = D.data("func");
									objFunc[rand] = obj.func;
									D.data("func", objFunc);
								}
							});
						}
					});

					htmlMenu = htmlMenu + '</ul>' +
						'</div>' +
						'</div>';
				}
				return htmlMenu;
			},
			funSmartMenu = function() {
				//TODO 修改为事件代理
				var idKey = "#smartMenu_",
					clKey = "smart_menu_",
					jqueryMenu = $(idKey + params.name);
				if (!jqueryMenu.length) {
					$("body").append(htmlCreateMenu());


					$(idKey + params.name + " a").bind("click", function() {
						var key = $(this).attr("data-key"),
							callback = D.data("func")[key];
						if ($.isFunction(callback)) {
							callback.call(D.data("trigger"));
						}
						$.smartMenu.hide();
						return false;
					});
					$(idKey + params.name + " li").each(function() {
						var isHover = $(this).attr("data-hover"),
							clHover = clKey + "li_hover";

						$(this).hover(function() {
							var jqueryHover = $(this).siblings("." + clHover);
							jqueryHover.removeClass(clHover).children("." + clKey + "box").hide();
							jqueryHover.children("." + clKey + "a").removeClass(clKey + "a_hover");

							if (isHover) {
								$(this).addClass(clHover).children("." + clKey + "box").show();
								$(this).children("." + clKey + "a").addClass(clKey + "a_hover");
							}

						});

					});
					return $(idKey + params.name);
				}
				return jqueryMenu;
			};

		$(this).on('contextmenu', params.container, function(e) {
			if ($.isFunction(params.beforeShow)) {
				params.beforeShow.call(this);
			}
			e = e || window.event;

			e.cancelBubble = true;
			if (e.stopPropagation) {
				e.stopPropagation();
			}

			$.smartMenu.hide();
			var st = D.scrollTop();
			var jqueryMenu = funSmartMenu();
			if (jqueryMenu) {
				jqueryMenu.css({
					display: "block",
					left: e.clientX + params.offsetX,
					top: e.clientY + st + params.offsetY
				});
				D.data("target", jqueryMenu);
				D.data("trigger", this);

				if ($.isFunction(params.afterShow)) {
					params.afterShow.call(this);
				}
				return false;
			}
		});
		if (!B.data("bind")) {
			B.bind("click", $.smartMenu.hide).data("bind", true);
		}
	};
	$.extend($.smartMenu, {
		hide: function() {
			var target = D.data("target");
			if (target && target.css("display") === "block") {
				target.hide();
			}
		},
		remove: function() {
			var target = D.data("target");
			if (target) {
				target.remove();
			}
		}
	});
})(jQuery);

var userMenuData = [
	[{
		text: "创建POP点",
		func: function(d) {
			var data = $(this)[0].__data__;
			var id = $(this).attr("id");
			setPop(data);
		}
	}, {
		text: "添加CPE",
		func: function(d) {
			var data = $(this)[0].__data__;
			var id = $(this).attr("id");
			setCpe(data);
		}
	}, {
		text: "删除设备",
		func: function(d) {
			var data = $(this)[0].__data__;
			var id = $(this).attr("id");
			delNode(data);
		}
	}]
];

//事件监听
$("body").smartMenu(userMenuData, {
	name: "chatRightControl",
	container: "g.node"
});

function strtobps(bps) {
	var u = bps[bps.length - 1],
		val = parseFloat(bps);

	if (u == 'M')
		val *= 1000;
	else
	if (u == 'G')
		val *= 1000000;
	else
	if (u != 'K')
		val = 0;

	return val;
}

function bpstostr(bps) {
	var val;

	if (bps > 1000000)
		val = (Math.round(bps / 10000) / 100) + 'M';
	else
	if (bps > 1000)
		val = (Math.round(bps / 10) / 100) + 'K';
	else
		val = bps;

	return val;
}

//点击右侧应用路由
function guestBtn(node, name) {
	var box = $('.winController.routerBox[data-serial=' + node.id + name + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('routerBox');
			win.attr('data-serial', node.id + name);
			win.find('.winRefresh').click(function() {
				guestBtn(node, name);
			});
		});
	}

	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		titleName += '/iWAN在线用户' + (name ? (': ' + name) : '');
		title.text(titleName);
		wrap.html([
			'<table>',
			'<thead>',
			'<tr>',
			'<td>序号</td>',
			'<td>当前</td>',
			'<td>用户组</td>',
			'<td>源接口</td>',
			'<td>VLAN</td>',
			'<td>TTL</td>',
			'<td>源地址/端口</td>',
			'<td>目标地址/端口</td>',
			'<td>协议</td>',
			'<td>应用</td>',
			'<td>DHCP</td>',
			'<td>用户类型</td>',
			'<td>动作</td>',
			'<td>目标线路</td>',
			'<td>下一跳</td>',
			'<td>DNAT地址</td>',
			'<td>匹配次数</td>',
			'<td>备注</td>',
			'</tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'iwan/route_policy.php',
			type: 'post',
			data: {
				id: node.id,
			},
			dataType: 'json',
			success: function(d) {
				var data = d.data.rows;
				var utype = {
					'ippxy': '代拨',
					'nonippxy': '非代拨'
				};
				var act = {
					'nat': 'NAT',
					'route': '路由',
					'ippxy': '走代拨线',
					'ippxy': '走代拨线'
				};
				var nh = {
					'__ippxytype__': '代拨线路',
					'NULL': '空线路'
				};
				var port;
				for (var i in data) {
					if (data[i].iniftype == 'posvr') {
						if (data[i].inifname == 'all') {
							port = 'PPPOE服务';
						} else {
							port = data[i].inifname;
						}
					} else if (data[i].iniftype == 'proxy') {
						if (data[i].standby == 'yes') {
							port = '<a style="color:green;" class="port" data-type="' + data[i].iniftype + '">' + data[i].inifname +
								'</a>';
						} else {
							port = '<a style="color:#2e8ae3;" class="port" data-type="' + data[i].iniftype + '">' + data[i].inifname +
								'</a>';
						}
					} else if (data[i].iniftype == 'if') {
						port = '<a style="color:#2e8ae3;" class="port" data-type="' + data[i].iniftype + '">' + data[i].inifname +
							'</a>';
					} else {
						port = data[i].inifname;
					}

					wrap.find('tbody').append([
						'<tr>',
						'<td>' + data[i].polno + '</td>',
						'<td>' + (data[i].rtptimename == 'NULL' ? '任意时间' : data[i].rtptimename) + '</td>',
						'<td>' + data[i].pname + '</td>',
						'<td>' + port + '</td>', //源接口
						'<td>' + (data[i].vlan == '0-0' ? '' : data[i].vlan) + '</td>',
						'<td>' + (data[i].ttl == '0-255' ? '' : data[i].ttl) + '</td>',
						'<td>' + data[i].srcip + (data[i].srcport == 'any' ? '' : ':' + data[i].srcport) + '</td>',
						'<td>' + data[i].dstip + (data[i].dstport == 'any' ? '' : ':' + data[i].dstport) + '</td>',
						'<td>' + data[i].proto + '</td>',
						'<td data-appid="' + data[i].appid + '">' + (data[i].appid == 'any' ? 'any' : data[i].appname) + '</td>',
						'<td data-dscp="' + data[i].dscp + '">' + (data[i].dscp == '0' && data[i].dscp == '' ? data[i].dscp : '') +
						'</td>',
						'<td data-usrtype="' + data[i].usrtype + '">' + (utype[data[i].usrtype] ? data[i].usrtype : 'any') +
						'</td>',
						'<td data-action="' + data[i].action + '">' + (act[data[i].action] ? act[data[i].action] : data[i].action) +
						'</td>',
						'<td data-nhtype="' + (data[i].nhtype != 'pxy' ? '"' : 'iwan" class="targetRoute"') + '>' + (nh[data[i].nhtype] ?
							nh[data[i].nhtype] : data[i].nexthop) + '</td>',
						'<td>' + (data[i].gateway == '0.0.0.0' || data[i].gateway == 'NULL' ? '' : data[i].gateway) + '</td>',
						'<td>' + (data[i].newdstip == '0.0.0.0' ? '' : data[i].newdstip) + '</td>', //DNAT地址
						'<td>' + data[i].pkts + '</td>', //匹配次数
						'<td>' + data[i].desc + '</td>',
						'</tr>'
					].join(''));
				}
				if (data[i].iniftype == 'proxy') {
					wrap.find('tbody .port').click(function() {
						clickFuc(node, $(this).text(), 'iwan');
					})
				} else if (data[i].iniftype == 'if') {
					wrap.find('tbody .port').click(function() {
						clickFuc(node, $(this).text());
					})
				}
				wrap.find('tbody .targetRoute[data-nhtype="iwan"]').click(function() {
					clickFuc(node, $(this).text(), 'iwan');
				})
			}
		});
	})
}

//点击右侧应用路由-源接口
function interface(node, name) {
	var key = node.id + '_if_' + name;
	var box = $('.winController.interfaceBox[data-serial=' + key + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('interfaceBox');
			win.attr('data-serial', key);
			win.find('.winRefresh').click(function() {
				interface(node, name);
			});
		});
	}

	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		title.text(titleName + '/网络接口: ' + name);
	}, function(title, tool, wrap) {
		$.ajax({
			url: '/Maintain/iwan/ifinfo.php',
			type: 'post',
			data: {
				id: node.id,
				ifname: name
			},
			dataType: 'json',
			success(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var cont = '';
				var data = d.data;
				for (var i in data) {
					cont += "<p>" + i + ": " + data[i] + "</p>";
				}
				wrap.html(cont);
			}
		})
	})
}

//点击右侧在线客户
function rightBtn(key, name) {
	var box = $('.winController.middleBox[data-serial=' + key + name + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('middleBox');
			win.attr('data-serial', key + name);
			win.find('.winRefresh').click(function() {
				rightBtn(key, name);
			});
		});
	}

	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		titleName += '/iWAN在线用户' + (name ? (': ' + name) : '');
		title.text(titleName);
		wrap.html([
			'<table>',
			'<thead>',
			'<tr>',
			'<td>服务名称</td>',
			'<td>账号</td>',
			'<td>IP地址</td>',
			'<td>状态</td>',
			'<td>MTU</td>',
			'<td>网关</td>',
			'<td>延时(cur/min/max)</td>',
			'<td>在线时长</td>',
			'<td>剩余时间</td>',
			'<td>连接数</td>',
			'<td>下行</td>',
			'<td>上行</td>',
			'<td>连接信息</td>',
			'</tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-cpe-list',
			type: 'post',
			data: {
				serialno: key,
				name: name
			},
			dataType: 'json',
			success: function(d) {
				if (d.ret != 0) {
					alert('Data error(s):\n\n' + d.errors.join('\n'));
					return;
				}
				var data = d.data;
				for (var i in data) {
					wrap.find('tbody').append([
						'<tr>',
						'<td>' + data[i].pxyname + '</td>',
						'<td>' + data[i].name + '</td>',
						'<td>' + data[i].ip + '</td>',
						'<td class="' + (data[i].state == 'DATA' ? 'ok' : 'redwarning') + '">' + (data[i].state == 'DATA' ? '正常' :
							'断开') + '</td>',
						'<td>' + data[i].mtu + '</td>',
						'<td>' + data[i].gateway + '</td>',
						'<td>' + data[i].curdelay + '/' + data[i].mindelay + '/' + data[i].maxdelay + '</td>',
						'<td>' + data[i].onlinetime + '</td>',
						'<td>' + data[i].leftime + '</td>',
						'<td>' + data[i].flowcnt + '</td>',
						'<td>' + data[i].inbps + '</td>',
						'<td>' + data[i].outbps + '</td>',
						'<td>' + data[i].peerip + ':' + data[i].peerport + '->' + data[i].myip + ':' + data[i].myport + '</td>',
						'</tr>'
					].join(''));
				}
			}
		});
	});
}

//点击iWAN服务名称弹框
function showSvrMiddleBox(key, name) {
	var box = $('.winController.iwanSvrMiddleBox[data-serial=' + key + name + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('iwanSvrMiddleBox');
			win.attr('data-serial', key + name);
			win.find('.winRefresh').click(function() {
				showSvrMiddleBox(key, name);
			});
		});
	}

	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		title.text(titleName + '/iWAN服务: ' + name);
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-pop-info',
			type: 'post',
			data: {
				serialno: key,
				name: name
			},
			dataType: 'json',
			success(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var cont = '';
				var data = d.data;
				for (var i in data) {
					if (i == "wan") {
						for (var j in data[i])
							cont += "<p>wan=" + j + " : [" + data[i][j].join(',') + "]</p>";
					} else
						cont += "<p>" + i + ": " + data[i] + "</p>";
				}
				wrap.html(cont);
			}
		});
	});
}

//点击路径
function showPathBox(link) {
	var key = link.source.id + '_' + link.target.id;
	var box = $('.winController.pathBox[data-serial=' + key + ']');
	var PathTopo = new PathTopoChart();
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('pathBox');
			win.addClass('pathBox2');
			win.attr('data-serial', key);
			win.find('.winRefresh').click(function() {
				showPathBox(link);
			});
			tab.create(win.children('.winTool'), win.children('.winWrap'),
				[{
						name: '拓扑图',
						content: '',
						tabfuc: function(btn) {
							var that = this;
							PathTopo.init(that);
							PathTopo.refresh(link.source.id, link.target.id);
							win.children('.winWrap').each(function(i, e) {
								e.__win_resize_ = function() {
									var e = d3.select(this);
									width = parseInt(e.style('width')),
										height = parseInt(e.style('height'));

									d3.select(that).style('width', width + 'px');
									d3.select(that).style('height', height + 'px');
									PathTopo.resize();
								}
							});
						}
					},
					{
						name: 'iWAN线路列表',
						active: true,
						content: ['<table><thead>',
							'<tr>',
							'<td>线路名称</td>',
							'<td>状态</td>',
							'<td>接口</td>',
							'<td>类型</td>',
							'<td>线路IP</td>',
							'<td>带宽</td>',
							'<td>禁用</td>',
							'<td>上行</td>',
							'<td>下行</td>',
							'<td>服务器</td>',
							'<tr>',
							'</thead><tbody></tbody></table>'
						],
						tabfuc: function(btn) {
							var wrap = $(this);

							wrap.find('tbody tr').remove();
							$.ajax({
								url: 'api.php?r=topo@sdwan-links',
								type: 'post',
								data: {
									source: link.source.id,
									target: link.target.id
								},
								dataType: 'json',
								success(d) {
									var bps, warning, data = d.data.rows;
									if (d.ret !== 0) {
										alert(d.msg);
										return;
									}
									for (var i in data) {
										if (data[i].bandwidth) {
											bps = strtobps($.trim(data[i].inbps));
											bps /= data[i].bandwidth;
											if (bps >= 0.95)
												warning = ' class="redwarning"';
											else
											if (bps >= 0.8)
												warning = ' class="warning"';
											else
												warning = ' class="ok"';
										} else
											warning = '';
										wrap.find('tbody').append([
											'<tr>',
											'<td class="linkName" data-pxyid="' + data[i].proxyid + '">' + data[i].name + '</td>',
											'<td>' + (data[i].linkup ? '正常' : '断开') + '</td>',
											'<td>' + data[i].ifname + '</td>',
											'<td>' + data[i].type + '</td>',
											'<td>' + data[i].addr + '</td>',
											'<td>' + data[i].bandwidth + '</td>',
											'<td>' + (data[i].disabled ? '是' : '否') + '</td>',
											'<td' + warning + '>' + data[i].outbps + '</td>',
											'<td' + warning + '>' + data[i].inbps + '</td>',
											'<td>' + (!(data[i].type == 'iwan' || data[i].type == 'l2tpwan') ? "" : (data[i].peerip + ':' + data[
												i].peerport)) +
											'</td>',
											'</tr>'
										].join(''));
									}
									wrap.find('tbody .linkName').click(function() {
										getiwanMore(link.source, $(this).text(), $(this).attr('data-pxyid'));
									})
								}
							})
						}
					},
				]
			);
		});
	}
	win.show(box, function(title, tool, wrap) {
		title.html(link.source.name + ' ---> ' + link.target.name);
	}, function(title, tool, wrap) {
		tool.find("button.active").click();
	});
}

function clickFuc(node, name, type) {
	if (type == "iwan" || type == "l2tpwan") {
		$.ajax({
			url: 'api.php?r=topo@gw-wan-list',
			type: 'post',
			data: {
				serialno: node.id,
				name: name
			},
			dataType: 'json',
			success(d) {
				var data = d.data.rows;
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				if (data.length == 0) {
					alert('找不到指定线路。');
					return;
				};
				getiwanMore(node, data[0].name, data[0].proxyid);
			}
		});
	} else
		getCardMore(node, name);
}

//点击iwan线路名称
function getiwanMore(node, pxyname, id) {
	var key = node.id + '_wan_' + id;
	var box = $('.winController.getiwanMoreBox[data-serial=' + key + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('getiwanMoreBox');
			win.attr('data-serial', key);
			win.find('.winRefresh').click(function() {
				getiwanMore(node, pxyname, id);
			});
			tab.create(win.children('.winTool'), win.children('.winWrap'),
				[{
						name: '线路信息',
						active: true,
						content: '<div></div>',
						tabfuc: function(btn) {
							var wrap = $(this);
							$.ajax({
								url: 'api.php?r=topo@gw-wan-info',
								type: 'post',
								data: {
									serialno: node.id,
									pxyid: id
								},
								dataType: 'json',
								success(d) {
									var data = d.data;
									if (d.ret !== 0) {
										alert(d.msg);
										return;
									}
									data.linkup = Number(data.linkup);
									data.gwpxy = Number(data.gwpxy);
									data.disable = Number(data.disable);

									wrap.find('div').html([
										'<p>线路类型: ' + data.type + '</p>',
										'<p>名称: ' + data.name + '</p>',
										'<p>所在接口: <span class="c_ifname" style="color:#2e8ae3;cursor:pointer;" data-type="' + data.type +
										'">' + data.ifname + '</span></p>',
										'<p>MTU: ' + data.mtu + '</p>',
										'<p>VLAN: ' + data.vlan + '</p>',
										'<p>状态: <span class="' + (data.linkup ? 'ok' : 'redwarning') + '">' + (data.linkup ? '正常' : '断开') +
										'</span></p>',
										'<p>是否禁用: <span class="' + (data.disable == 0 ? 'ok' : 'redwarning') + '">' + (data.disable == 0 ?
											'启用' : '禁用') + '</span></p>',
										'<p>最近掉线: ' + (data.lastdowntime ? data.lastdowntime : '未掉线') + '</p>',
										'<p>IP地址: ' + data.addr + '</p>',
										'<p>MAC地址: ' + data.ifmac + '</p>',
										'<p>网关IP: ' + data.gateway + (data.gwpxy ? '(这是互联地址' : '') + '</p>',
										'<p>网关MAC: ' + data.ifmac + '</p>',
										'<p>DNS服务器: ' + data.dnsaddr + '</p>',
										'<p>心跳服务器: ' + data.hbfail + '</p>',
										'<p>连接数: ' + data.flowcnt + '</p>',
										'<p>流入bps: ' + data.inbps + '</p>',
										'<p>流出bps: ' + data.outbps + '</p>',
										'<p>DNS牵引统计: ' + data.dnsreqs + '/' + data.dnsokper + '[总数/成功率]</p>',
										'<p>线路延迟ms: ' + data.curping_ms + '/' + data.minping_ms + '/' + data.maxping_ms + '[当前/最小/最大]</p>',
									].join(''));

									wrap.find('div .c_ifname').click(function() {
										clickFuc(node, $(this).text(), $(this).attr('data-type'));
									});
								}
							})
						}
					},
					{
						name: 'TOP应用',
						content: ['<table><thead>',
							'<tr>',
							'<td>名称</td>',
							'<td>上行</td>',
							'<td>下行</td>',
							'<td>bps</td>',
							'<tr>',
							'</thead><tbody></tbody></table>'
						],
						tabfuc: function(btn) {
							var wrap = $(this);
							wrap.find('tbody tr').remove();
							$.ajax({
								url: 'api.php?r=topo@gw-wan-app',
								type: 'post',
								data: {
									serialno: node.id,
									pxyid: id
								},
								dataType: 'json',
								success(d) {
									var data = d.data.rows;
									if (d.ret !== 0) {
										alert(d.msg);
										return;
									}
									for (var i in data) {
										wrap.find('tbody').append([
											'<tr>',
											'<td data-name="' + data[i].name + '">' + data[i].cname + '</td>',
											'<td>' + data[i].bpsout + '</td>',
											'<td>' + data[i].bpsin + '</td>',
											'<td>' + data[i].bps + '</td>',
											'</tr>'
										].join(''));
									}
								}
							})
						}
					},
				]
			);
		});
	}
	win.show(box, function(title, tool, wrap) {
		title.html(node.name + '/外网线路: ' + pxyname);
	}, function(title, tool, wrap) {
		tool.find("button.active").click();
	});
}
//点击网卡
function netCard(node) {
	var box = $('.winController.netCardBox[data-serial=' + node.id + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('netCardBox');
			win.attr('data-serial', node.id);
			win.find('.winRefresh').click(function() {
				netCard(node);
			});
		});
	}
	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		title.html(titleName + '/网络接口')
		wrap.html([
			'<table>',
			'<thead>',
			'<tr>',
			'<td>名称</td>',
			'<td>接入模式</td>',
			'<td>接入位置</td>',
			'<td>对端接口</td>',
			'<td>链路捆绑</td>',
			'<td>状态</td>',
			'<td>驱动</td>',
			'<td>工作速率</td>',
			'<td>型号</td>',
			'<td>MAC</td>',
			'<td>流入速率</td>',
			'<td>流出速率</td>',
			'<td>流入PPS</td>',
			'<td>流出PPS</td>',
			'<tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-if-list',
			data: {
				serialno: node.id,
			},
			dataType: 'json',
			type: 'post',
			success: function(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var wan = d.data.rows;
				for (var i = 0; i < wan.length; i++) {
					wrap.find('tbody').append([
						'<tr>',
						'<td class="card">' + wan[i].name + '</td>',
						'<td>' + (wan[i].mode == 0 ? '监控' : wan[i].bdgname) + '</td>',
						'<td>' + (wan[i].zone == 'inside' ? '接内' : '接外') + '</td>',
						'<td>' + (wan[i].ifpeer == 'NULL' ? '' : wan[i].ifpeer) + '</td>',
						'<td>' + (wan[i].lagroup == 0 ? '' : '链路组' + wan[i].lagroup) + '</td>',
						'<td class="' + (wan[i].status == 'up' ? 'ok' : 'redwarning') + '">' + (wan[i].status == 'up' ? '正常' :
							'断开') + '</td>',
						'<td>' + (wan[i].driver == 'PANAOS' ? '增强型' : wan[i].driver) + '</td>',
						'<td>' + (wan[i].ifspeed == "NONE" ? '' : wan[i].ifspeed) + '</td>',
						'<td>' + wan[i].type + '</td>',
						'<td>' + wan[i].mac + '</td>',
						'<td>' + wan[i].bpsin + '</td>',
						'<td>' + wan[i].bpsout + '</td>',
						'<td>' + wan[i].ppsin + '</td>',
						'<td>' + wan[i].ppsout + '</td>',
						'</tr>'
					].join(''))
				}
				wrap.find('tbody .card').click(function() {
					getCardMore(node, $(this).text());
				});
			}
		});
	})
}
//网卡详细信息
function getCardMore(node, name) {
	var key = node.id + '_if_' + name;
	var box = $('.winController.netCardInfoBox[data-serial=' + key + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('netCardInfoBox');
			win.attr('data-serial', key);
			win.find('.winRefresh').click(function() {
				getCardMore(node, name);
			});
		});
	}

	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		console.log(titleName);
		title.text(titleName + '/网络接口: ' + name);
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-if-info',
			type: 'post',
			data: {
				serialno: node.id,
				name: name
			},
			dataType: 'json',
			success(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var cont = '<div class="wrapContent">';
				var data = d.data;
				for (var i in data) {
					cont += "<p>" + i + ": " + data[i] + "</p>";
				}
				cont += '</div>'
				wrap.html(cont);
			}
		})
	})
}

//点击iwan线路数弹框
function iwanLineCnt(node) {
	var box = $('.winController.iwanMidBox[data-serial=' + node.id + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('iwanMidBox');
			win.attr('data-serial', node.id);
			win.find('.winRefresh').click(function() {
				iwanLineCnt(node);
			});
		});
	}
	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		title.html(titleName + '/iWAN线路')
		wrap.html([
			'<table>',
			'<thead>',
			'<tr>',
			'<td>线路名称</td>',
			'<td>接口</td>',
			'<td>线路状态</td>',
			'<td>IP地址</td>',
			'<td>带宽</td>',
			'<td>上行</td>',
			'<td>下行</td>',
			'<td>服务器</td>',
			'<td>禁用</td>',
			'<tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-wan-list',
			data: {
				serialno: node.id,
				type: 'iwan'
			},
			dataType: 'json',
			type: 'post',
			success: function(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var bps, warning, wan = d.data.rows;
				for (var i = 0; i < wan.length; i++) {
					if (wan[i].bandwidth) {
						bps = strtobps($.trim(wan[i].inbps));
						bps /= wan[i].bandwidth;
						if (bps >= 0.95)
							warning = ' class="redwarning"';
						else
						if (bps >= 0.8)
							warning = ' class="warning"';
						else
							warning = ' class="ok"';
					} else
						warning = '';
					wrap.find('tbody').append([
						'<tr>',
						'<td class="iwancount" data-proxyid="' + wan[i].proxyid + '">' + wan[i].name + '</td>',
						'<td>' + wan[i].ifname + '</td>',
						'<td class="' + (wan[i].linkup ? 'ok' : 'redwarning') + '">' + (wan[i].linkup == 0 ? "断开" : "正常") +
						'</td>',
						'<td>' + wan[i].addr + '</td>',
						'<td>' + wan[i].bandwidth + '</td>',
						'<td' + warning + '>' + wan[i].inbps + '</td>',
						'<td' + warning + '>' + wan[i].outbps + '</td>',
						'<td>' + wan[i].peerip + ':' + wan[i].peerport + '</td>',
						'<td>' + (wan[i].disabled ? "是" : "否") + '</td>',
						'</tr>'
					].join(''))
				}
				wrap.find('tbody .iwancount').click(function() {
					getiwanMore(node, $(this).text(), $(this).attr('data-proxyid'));
				})
			}
		});
	})
}

//点击外网线路数弹框
function outerNetCnt(node) {
	var box = $('.winController.outnetBox[data-serial=' + node.id + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('outnetBox');
			win.attr('data-serial', node.id);
			win.find('.winRefresh').click(function() {
				outerNetCnt(node);
			});
			var html = [
				'<table>',
				'<thead>',
				'<tr>',
				'<td>线路名称</td>',
				'<td>接口</td>',
				'<td>状态</td>',
				'<td>类型</td>',
				'<td>线路IP</td>',
				'<td>带宽</td>',
				'<td>禁用</td>',
				'<td>上行</td>',
				'<td>下行</td>',
				'<td>服务器</td>',
				'<tr>',
				'<tbody>',
				'</tbody>',
				'</table>'
			].join('');

			tab.create(win.children('.winTool'), win.children('.winWrap'),
				[{
						name: '全部',
						active: true,
						content: html,
					},
					{
						name: 'iWAN',
						content: html,
					},
					{
						name: '静态',
						content: html,
					},
					{
						name: 'PPPOE',
						content: html,
					},
					{
						name: 'DHCP',
						content: html,
					},
					{
						name: 'L2TP',
						content: html,
					}
				]
			);

			var typeArr = ['all', 'iwan', 'proxy', 'pppoe', 'dhcpwan', 'l2tpwan'];
			wrap = win.find('.winWrap table');
			for (var i = 0; i < typeArr.length; i++)
				wrap.eq(i).addClass(typeArr[i]);
		});
	}

	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		title.html(titleName + '/外网线路');

		wrap.find('tbody tr').remove();
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-wan-list',
			data: {
				serialno: node.id,
			},
			dataType: 'json',
			type: 'post',
			success: function(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var bps, warning, wan = d.data.rows;
				for (var i = 0; i < wan.length; i++) {
					if (wan[i].bandwidth) {
						bps = strtobps($.trim(wan[i].inbps));
						bps /= wan[i].bandwidth;
						if (bps >= 0.95)
							warning = ' class="redwarning"';
						else
						if (bps >= 0.8)
							warning = ' class="warning"';
						else
							warning = ' class="ok"';
					} else
						warning = '';
					var row = [
						'<tr>',
						'<td class="outLinkName" data-pxyid="' + wan[i].proxyid + '">' + wan[i].name + '</td>',
						'<td class="ifNames" data-type="' + wan[i].type + '">' + wan[i].ifname + '</td>',
						'<td class="' + (wan[i].linkup ? 'ok' : 'redwarning') + '">' + (wan[i].linkup ? '正常' : '断开') + '</td>',
						'<td>' + wan[i].type + '</td>',
						'<td>' + wan[i].addr + '</td>',
						'<td>' + wan[i].bandwidth + '</td>',
						'<td>' + (wan[i].disabled ? '是' : '否') + '</td>',
						'<td' + warning + '>' + wan[i].outbps + '</td>',
						'<td' + warning + '>' + wan[i].inbps + '</td>',
						'<td>' + (!(wan[i].type == 'iwan' || wan[i].type == 'l2tpwan') ? "" : (wan[i].peerip + ':' + wan[i].peerport)) +
						'</td>',
						'</tr>'
					].join('')
					wrap.find('.' + wan[i].type + ' tbody').append(row);
					wrap.find('.all tbody').append(row);
				}
				wrap.find('tbody .outLinkName').click(function() {
					getiwanMore(node, $(this).text(), $(this).attr('data-pxyid'));
				})
				wrap.find('tbody .ifNames').click(function() {
					clickFuc(node, $(this).text(), $(this).attr('data-type'));
				})
			}
		});
	});
}

//点击iwan服务数弹框
function svrCount(node) {
	var box = $('.winController.svrCntBox[data-serial=' + node.id + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('svrCntBox');
			win.attr('data-serial', node.id);
			win.find('.winRefresh').click(function() {
				svrCount(node);
			});
		});
	}
	win.show(box, function(title, tool, wrap) {
		var titleName = $('#r_aside>div.title').text();
		title.html(titleName + '/iWAN服务')
		wrap.html([
			'<table>',
			'<thead>',
			'<tr>',
			'<td>服务名称</td>',
			'<td>网卡</td>',
			'<td>网关地址</td>',
			'<td>DNS</td>',
			'<td>MTU</td>',
			'<td>地址池</td>',
			'<td>认证方式</td>',
			'<td>RADIUS</td>',
			'<td>在线用户</td>',
			'<td>流入速率</td>',
			'<td>流出速率</td>',
			'<td>可访问WAN线路</td>',
			'<tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-pop-list',
			data: {
				serialno: node.id
			},
			dataType: 'json',
			type: 'post',
			success: function(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var data = d.data.rows;
				var i, j, svrwan, dns = '',
					wan = d.data.rows.wan;
				var way = {
					'local': '本地认证',
					'radius': 'RADIUS',
					'localrad': '先本地后RADIUS',
					'free': '免认证'
				};
				for (i in data) {
					svrwan = '';
					for (j in data[i].wan) {
						svrwan += (svrwan ? ', ' : '') + '<span>' + j + '</span>: [' + data[i].wan[j].join(', ') + ']';
					}
					wrap.find('tbody').append([
						'<tr>',
						'<td class="isvrName">' + data[i].name + '</td>',
						'<td>' + data[i].ifname + '</td>',
						'<td>' + data[i].addr + '</td>',
						'<td>' + data[i].dns.join(', ') + '</td>',
						'<td>' + data[i].mtu + '</td>',
						'<td>' + data[i].poolname + '</td>',
						'<td>' + (way[data[i].auth] ? way[data[i].auth] : 'UNKONWN') + '</td>',
						'<td>' + ((data[i].auth == "radius" || data[i].auth == "localrad") ? data[i].radsvrname : '') + '</td>',
						'<td>' + data[i].clntcnt + '</td>',
						'<td>' + data[i].inbps + '</td>',
						'<td>' + data[i].outbps + '</td>',
						'<td class="visitWan">' + svrwan + '</td>',
						'</tr>'
					].join(''))
				}
				wrap.find('tbody .isvrName').click(function() {
					showSvrMiddleBox(node.id, $(this).text());
				})
				wrap.find('tbody .visitWan span').click(function() {
					clickFuc(node, $(this).text(), 'iwan');
				});
			}
		});
	})
}

//创建pop点
function setPop(node) {
	var name = node.name;
	var box = $('.winController.setpopBox[data-serial=' + node.id + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('setpopBox');
			win.attr('data-serial', node.id);
			win.find('.winRefresh').click(function() {
				setPop(node);
			});
		});
	}
	win.show(box, function(title, tool, wrap) {
		title.html('创建POP点 -- ' + name);
		wrap.html([
			'<button class="winBtn popBtn"><i class="layui-icon">&#xe624;</i> 创建POP点</button>',
			'<table>',
			'<thead>',
			'<tr>',
			'<td>服务名称</td>',
			// '<td>网卡</td>',
			'<td>网关地址</td>',
			'<td>DNS</td>',
			'<td>MTU</td>',
			'<td>地址池</td>',
			'<td>认证方式</td>',
			'<td>RADIUS</td>',
			'<td>在线用户</td>',
			'<td>流入速率</td>',
			'<td>流出速率</td>',
			'<td>可访问WAN线路</td>',
			'<tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
		layui.use(['form', 'element', 'table', 'layer', 'transfer', 'laydate'], function() {
			var element = layui.element;
			var form = layui.form;
			var table = layui.table;
			var layer = layui.layer;
			$('.popBtn').click(function() {
				layer.open({
					type: 1,
					title: '创建POP点',
					area: ['320px', ''],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#addpopWrap').html(),
					success: function(layero, index) {
						form.render();
					},
					yes: function(index, layero) {
						$.ajax({
							url: '',
							data: {

							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.ret == 0) layer.msg('添加成功', {
									icon: 1
								});
								layer.close(index);
								setPop(node);
							},
							error: function() {
								layer.msg('连接超时，请稍后再试。', {
									icon: 2
								});
							}
						});
					}
				});
			});
		});
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-pop-list',
			data: {
				serialno: node.id,
			},
			dataType: 'json',
			type: 'post',
			success: function(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var data = d.data.rows;
				var i, j, svrwan, dns = '',
					wan = d.data.rows.wan;
				var way = {
					'local': '本地认证',
					'radius': 'RADIUS',
					'localrad': '先本地后RADIUS',
					'free': '免认证'
				};
				for (i in data) {
					svrwan = '';
					for (j in data[i].wan) {
						svrwan += (svrwan ? ', ' : '') + '<span>' + j + '</span>: [' + data[i].wan[j].join(', ') + ']';
					}
					wrap.find('tbody').append([
						'<tr>',
						'<td class="isvrName">' + data[i].name + '</td>',
						// '<td>' + data[i].ifname + '</td>', 
						'<td>' + data[i].addr + '</td>',
						'<td>' + data[i].dns.join(', ') + '</td>',
						'<td>' + data[i].mtu + '</td>',
						'<td>' + data[i].poolname + '</td>',
						'<td>' + (way[data[i].auth] ? way[data[i].auth] : 'UNKONWN') + '</td>',
						'<td>' + ((data[i].auth == "radius" || data[i].auth == "localrad") ? data[i].radsvrname : '') + '</td>',
						'<td>' + data[i].clntcnt + '</td>',
						'<td>' + data[i].inbps + '</td>',
						'<td>' + data[i].outbps + '</td>',
						'<td class="visitWan">' + svrwan + '</td>',
						'</tr>'
					].join(''))
				}
				wrap.find('tbody .isvrName').click(function() {
					showSvrMiddleBox(node.id, $(this).text());
				})
				wrap.find('tbody .visitWan span').click(function() {
					clickFuc(node, $(this).text(), 'iwan');
				});
			}
		});
	});
}

//添加CPE
function setCpe(node) {
	var name = node.name;
	var box = $('.winController.setpopBox[data-serial=' + node.id + ']');
	if (box.length == 0) {
		box = win.create(true, function(win) {
			win.addClass('setpcpeBox');
			win.attr('data-serial', node.id);
			win.find('.winRefresh').click(function() {
				setCpe(node);
			});
		});
	}
	win.show(box, function(title, tool, wrap) {
		title.html('添加CPE -- ' + name);
		wrap.html([
			'<button class="winBtn cpeBtn"><i class="layui-icon">&#xe624;</i> 添加CPE</button>',
			'<table>',
			'<thead>',
			'<tr>',
			'<td>线路名称</td>',
			'<td>接口</td>',
			'<td>线路状态</td>',
			'<td>IP地址</td>',
			'<td>带宽</td>',
			'<td>上行</td>',
			'<td>下行</td>',
			'<td>服务器</td>',
			'<td>禁用</td>',
			'<tr>',
			'</thead>',
			'<tbody>',
			'</tbody>',
			'</table>'
		].join(''));
		layui.use(['form', 'element', 'table', 'layer', 'transfer', 'laydate'], function() {
			var element = layui.element;
			var form = layui.form;
			var table = layui.table;
			var layer = layui.layer;
			$('.cpeBtn').click(function() {
				layer.open({
					type: 1,
					title: '添加CPE',
					area: ['390px', ''],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#addcpeWrap').html(),
					success: function(layero, index) {
						form.render();
					},
					yes: function(index, layero) {
						$.ajax({
							url: '',
							data: {

							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.ret == 0) layer.msg('添加成功', {
									icon: 1
								});
								layer.close(index);
								setCpe(node);
							},
							error: function() {
								layer.msg('连接超时，请稍后再试。', {
									icon: 2
								});
							}
						});
					}
				});
			});
		});
	}, function(title, tool, wrap) {
		$.ajax({
			url: 'api.php?r=topo@gw-wan-list',
			data: {
				serialno: node.id,
				type: 'iwan'
			},
			dataType: 'json',
			type: 'post',
			success: function(d) {
				if (d.ret !== 0) {
					alert(d.msg);
					return;
				}
				var bps, warning, wan = d.data.rows;
				for (var i = 0; i < wan.length; i++) {
					if (wan[i].bandwidth) {
						bps = strtobps($.trim(wan[i].inbps));
						bps /= wan[i].bandwidth;
						if (bps >= 0.95)
							warning = ' class="redwarning"';
						else
						if (bps >= 0.8)
							warning = ' class="warning"';
						else
							warning = ' class="ok"';
					} else
						warning = '';
					wrap.find('tbody').append([
						'<tr>',
						'<td class="iwancount" data-proxyid="' + wan[i].proxyid + '">' + wan[i].name + '</td>',
						'<td>' + wan[i].ifname + '</td>',
						'<td class="' + (wan[i].linkup ? 'ok' : 'redwarning') + '">' + (wan[i].linkup == 0 ? "断开" : "正常") +
						'</td>',
						'<td>' + wan[i].addr + '</td>',
						'<td>' + wan[i].bandwidth + '</td>',
						'<td' + warning + '>' + wan[i].inbps + '</td>',
						'<td' + warning + '>' + wan[i].outbps + '</td>',
						'<td>' + wan[i].peerip + ':' + wan[i].peerport + '</td>',
						'<td>' + (wan[i].disabled ? "是" : "否") + '</td>',
						'</tr>'
					].join(''))
				}
				wrap.find('tbody .iwancount').click(function() {
					getiwanMore(node, $(this).text(), $(this).attr('data-proxyid'));
				})
			}
		});
	});
}

function table(id) {
	var domid = id || '',
		data,
		tb;

	function init() {
		tb = $(domid);
		tb.find('table thead').html([
			'<tr>',
			'<td>编号</td>',
			'<td>名称</td>',
			'<td>类型</td>',
			'<td>状态</td>',
			// '<td>用户组</td>',
			'<td>iWAN服务数</td>',
			'<td>iWAN拨入数</td>',
			'<td>iWAN线路数</td>',
			'</tr>'
		].join(''));

		//搜素编号
		tb.find('.searchSerialno').on('click', function() {
			var tr, keyword = tb.find('.keySerialno').val();
			if (keyword == '') {
				tb.find('.canSearchSerialno').click();
			} else {
				tb.find('>table tbody tr').hide();
				tr = tb.find('>table tbody td').filter(":contains(" + keyword + ")").parent().show();
				col.call(tr);
			}
		});

		//取消搜索
		tb.find('.canSearchSerialno').click(function() {
			var tr = tb.find('>table tbody tr').show();

			tb.find('.keySerialno').val('');
			col.call(tr);
		});
		//关闭弹框
		$(window).click(function(event) {
			var that = event.srcElement;
			var box = tb.parent();
			if ($(that).hasClass('serialno') == false && (box.is(that) || box.find(that).length) &&
				$(that).parents('svg').length == 0 &&
				$('svg').is(that) == false &&
				$('#r_aside').is(that) == false) {
				topo.unselect();
			}
		});
		return this;
	}

	function load(d) {
		return;
		var row, html = [];
		data = d.nodes;
		for (var i in data) {
			row = data[i];
			html.push([
				'<tr>',
				'<td><span class="serialno">' + row.id + '</span></td>',
				'<td>' + row.name + '</td>',
				'<td>' + topo.categorie(row.type) + '</td>',
				'<td>' + (row.linkup ? '在线' : '离线') + '</td>',
				// '<td>' + row.group + '</td>',
				'<td>' + row.svccnt + '</td>',
				'<td>' + row.iwancnt + '</td>',
				'<td>' + row.iworkcnt + '</td>',
				'</tr>'
			].join(''));
		}

		tb.find('table tbody').html(html.join(''));
		col.call(tb.find('>table tbody tr'));

		//点击编号弹出右边栏
		tb.find('.serialno').click(function() {
			var that = this.parentElement.parentElement;
			if (topo.selected(data[that.rowIndex - 1].serialno) == 0)
				topo.dispatch('selected').call(that, data[that.rowIndex - 1]);
		})
	}

	function col() {
		this.filter(":odd").css("background", "#F4F7FC");
		this.filter(":even").css("background", "white");
	}

	return {
		init: init,
		load: load,
	};
}

//tab插件
function tabController() {
	function init() {

	}

	function bind() {

	}

	function create(btnWrap, contentWrap, opt) {
		var i,
			btnbox = $('<div class="tabBtnWrap"><div class="tabBtnGroup"></div></div>'),
			btn,
			content = [];

		btnWrap.append(btnbox);
		btnbox = btnbox.children();

		for (i = 0; i < opt.length; i++) {
			btn = $('<button' + (opt[i].active ? ' class="active"' : '') + '>' + opt[i].name + '</button>');
			btn[0]._tab_activefuc_ = opt[i].tabfuc;
			btnbox.append(btn);

			content.push('<div class="tabContent">');
			if (typeof opt[i].content == 'string')
				content.push(opt[i].content);
			else
			if (typeof opt[i].content == 'function')
				content.push(opt[i].content());
			else
			if (typeof opt[i].content == 'object') {
				if (opt[i].content.join)
					content.push(opt[i].content.join(''));
				else
					content.push(opt[i].content.toString());
			}
			content.push('</div>');
		}

		contentWrap.append(content.join(''));

		btnWrap.find("button").click(function() {
			var index = $(this).index();

			$(this).addClass("active").siblings().removeClass('active');
			wrap = contentWrap.children().hide().eq(index).show();

			if (wrap.length && typeof this._tab_activefuc_ == 'function')
				this._tab_activefuc_.call(wrap[0], this);
		});

		// btnWrap.find("button.active").click();
		var index = btnWrap.find("button").filter('.active').index();
		contentWrap.children().hide().eq(index).show();
	}

	return {
		init: init,
		create: create
	};
}

//弹窗
function winController() {
	var z_index = 101;

	function init() {
		bind($('div.winController'));
	}

	function bind(wins) {
		wins.find('.winClose').click(function(e) {
			var p = $(this).parents('div.winController');
			if (p.length > 0)
				close(p[0]);
		});
		dragBox(wins);
		biggr(wins);
		lockWin(wins);
		// 加类名
		wins.mousedown(function(e) {
			var win = $(e.target).parents('div.winController')
			active(win);
		});
	}

	function create(isDestroy, cb) {
		var win,
			html = [
				'<div class="winController', (isDestroy ? ' winRmv' : ''), '">',
				'<div class="winTop" title="双击放大窗口">',
				'<span class="winTitle"></span>',
				'<span class="winClose wintopBtn" title="关闭窗口"><img src="/cloud/assets/img/close.png"/></span>',
				'<span class="winMax wintopBtn" title=""><img src="/cloud/assets/img/max.png" /></span>',
				'<span class="winLock wintopBtn" title="锁定窗口"><img src="/cloud/assets/img/unlock3.png" /></span>',
				'<span class="winRefresh wintopBtn" title="刷新"><img src="/cloud/assets/img/refresh3.png" /></span>',
				'</div>',
				'<div class="winTool"></div>',
				'<div class="winWrap"></div>',
				'</div>'
			].join('');

		win = $(html);
		$('.viewFramework-product').append(win);

		if (typeof cb == 'function') cb(win);
		bind(win);
		return win;

	}

	function show(winName, beforeCb, afterCb) {
		var win = $(winName);

		if (!win.attr('data-left')) {
			var left = ($(window).width() - win.width()) / 2;
			var top = ($(window).height() - win.height()) / 2;
			win.attr('data-left', left);
			win.attr('data-top', top);
			win.css('left', left + 'px');
			win.css('top', top + 'px');
		}
		active(win);
		if (typeof beforeCb == 'function') {
			beforeCb.call(win, win.find('.winTitle'), win.find('.winTool'), win.children('.winWrap'));
		}
		win.css('display', 'block');
		setWrapHeight(win);
		if (typeof afterCb == 'function') {
			afterCb.call(win, win.find('.winTitle'), win.find('.winTool'), win.children('.winWrap'));
		}
	}

	//点击关闭弹框
	function close(winName, beforeCb, afterCb) {
		var win = $(winName);
		if (typeof beforeCb == 'function') {
			beforeCb.call(win, win.find('.winTitle'), win.find('.winTool'), win.children('.winWrap'));
		}
		win.remove();
		// win.hasClass('winRmv').remove();
		if (typeof afterCb == 'function') {
			afterCb.call(win, win.find('.winTitle'), win.find('.winTool'), win.children('.winWrap'));
		}
	}

	//锁定窗口
	function lockWin(wins) {
		var count = 0;
		wins.find('.winLock').click(function() {
			count++;
			if (count % 2 == 0) {
				$(this).children('img').attr('src', '/cloud/assets/img/unlock3.png');
				$(this).attr('title', '锁定窗口')
				$(this).parents('div.winController').removeClass('lock');
			} else {
				$(this).children('img').attr('src', '/cloud/assets/img/lock_.png');
				$(this).attr('title', '窗口已锁定')
				$(this).parents('div.winController').addClass('lock');
			}
		});
	}

	//关闭非锁定窗口
	function closeAll() {
		var wins = $('div.winController:not(.lock)'); //选出非锁定从窗口
		wins.hide(); //隐藏非锁定窗口
		wins.filter('.winRmv').remove(); //销毁动态创建的窗口
	}

	function resize() {
		var wins = $('div.winController');
		wins.each(function(i, e) {
			setWrapHeight($(e));
		});
	}

	//拖拽
	function dragBox(win) {

		var winTop = win.children('.winTop');

		winTop.mousedown(function(e) { //e鼠标事件 
			var win = $(e.target).parents('div.winController');
			var offset = win.offset(); //DIV在页面的位置  
			var x = e.pageX - offset.left; //获得鼠标指针离DIV元素左边界的距离  
			var y = e.pageY - offset.top; //获得鼠标指针离DIV元素上边界的距离  

			$(window).bind("mousemove", function(ev) {
				if (win.css('position') == 'absolute')
					return;
				var _x = ev.pageX - x; //获得X轴方向移动的值  
				var _y = ev.pageY - y; //获得Y轴方向移动的值  
				//窗口移动范围
				var w = $(window).width() - 100;
				var h = $(window).height() - 40;
				var nx = _x + win.width();
				var ny = _y + win.height();
				var t = $(window).height() - winTop.height();
				if (_y > t) {
					_y = t
				}
				if (nx < 100) {
					_x = 100 - win.width()
				}
				if (_y < 0) _y = 0;
				else if (y > h) _y = h;
				else if (_x > w) _x = w;
				win.css({
					left: _x + "px",
					top: _y + "px",
				});
				win.attr('data-left', _x);
				win.attr('data-top', _y);
			});
		});

		$(window).mouseup(function() {
			$(window).unbind("mousemove");
		});
	}

	//窗口高
	function setWrapHeight(win) {
		var wrap = win.children('.winWrap');
		var h = 0;

		win.children().each(function(i, e) {
			if (wrap.is(e)) {
				return;
			}
			h += $(e).outerHeight(true);
		});
		wrap.height(win.height() - h);

		if (wrap.length) {
			if (wrap[0].__win_resize_)
				wrap[0].__win_resize_.call(wrap[0]);
		}
	}

	//双击放大
	function biggr(wins) {
		$('.wintopBtn').dblclick(function() {
			return false;
		});
		var wins = $('.winController');
		var count = 0;
		wins.each(function(i, e) {
			var win = $(e);
			var w = win.width();
			var h = win.height();
			win.attr('data-width', w);
			win.attr('data-height', h);
		});
		wins.find('.winMax').click(function() {
			var win = $(this).parents('div.winController');
			count++;
			if (count % 2 == 0) {
				$(this).children('img').attr('src', '/cloud/assets/img/max.png');
				$(this).children('img').attr('title', '放大窗口');
				var w = win.attr('data-width');
				var h = win.attr('data-height');
				var left = win.attr('data-left');
				var top = win.attr('data-top');
				win.css({
					width: w,
					height: h,
					position: 'fixed',
					top: top + 'px',
					left: left + 'px',
					margin: 0
				});
				if (win.hasClass('big')) win.removeClass('big');
			} else {
				$(this).children('img').attr('src', '/cloud/assets/img/min.png');
				$(this).children('img').attr('title', '缩小窗口');
				win.find('.winTop').attr('title', '双击缩小窗口');
				win.css({
					'width': '99.9%',
					'height': '100%',
					'position': 'absolute',
					'margin': 'auto',
					top: 0,
					left: 0,
				});
				if (!win.hasClass('big')) win.addClass('big');
			}
			setWrapHeight(win);
		});

		wins.find('.winTop').dblclick(function(e) {
			var win = $(this).parents('div.winController');
			count++;
			if (count % 2 == 0) {
				var w = win.attr('data-width');
				var h = win.attr('data-height');
				var left = win.attr('data-left');
				var top = win.attr('data-top');
				win.css({
					width: w,
					height: h,
					position: 'fixed',
					top: top + 'px',
					left: left + 'px',
					margin: 0
				});
				if (win.hasClass('big')) win.removeClass('big');
			} else {
				win.css({
					'width': '99.9%',
					'height': '100%',
					'position': 'absolute',
					'margin': 'auto',
					top: 0,
					left: 0,
				});
				if (!win.hasClass('big')) win.addClass('big');
			}
			setWrapHeight(win);
		});
	}

	function active(win) {

		if (win.length == 0) return;

		// 找所有 winController 类名的标签集合
		var wins = $('div.winController');

		// 排序窗口顺序
		var ascwin = wins.sort(function(a, b) {
			var azi = parseInt(a.style.zIndex),
				bzi = parseInt(b.style.zIndex);

			return azi - bzi;
		});

		// 依据排序结果 重新设置 z-index
		for (var i = 0; i < ascwin.length; i++) {
			if (ascwin[i] !== win[0])
				$(ascwin[i]).css('z-index', z_index + i);
		}
		win.css('z-index', i + z_index + 1);
	}


	return {
		init: init,
		bind: bind,
		show: show,
		close: close,
		resize: resize,
		active: active,
		closeAll: closeAll,
		create: create
	}
}

function aside(id) {
	var domid = id || '',
		width = 0,
		height = 0,
		showed = 0,
		serialno,
		content,
		table,
		title,
		body,
		svrData;

	function init() {
		content = d3.select(domid);
		title = content.append('div').classed('title', true);
		body = content.append('div').classed('content', true);
		//opt = content.append('div').classed('opt', true);
		//ptitle = opt.append('span').classed('ptitle', true).html('iWAN服务:');
		//iwanSvrTable = opt.append('table').classed('iwanSvrTable', true);

		content.select('button.guestBtn').on('click', function() {
			rightBtn(serialno, '');
		});
		content.select('button.routerBtn').on('click', function() {
			if (svrData)
				guestBtn(svrData, '');
		});

		return this;
	}

	function refresh() {
		if (!showed) return;

		draw(svrData);
	}

	function show(d) {
		showed = 1;
		d3.select(domid).transition()
			.style('padding-left', '16px')
			.style('padding-right', '16px')
			.style('right', '0px');

		draw(d);
		svrData = d;
		return this;
	}

	function draw(node) {
		title.transition().text(node.name);
		serialno = node.id;
		$.ajax({
			url: 'api.php?r=topo@sdwan-info',
			data: {
				serialno: serialno
			},
			dataType: 'json',
			type: 'post',
			success: function(data) {
				function showiwansvc(id, cb) {
					var d = data.data.pop.rows;
					var tableData = "<tr><td width='42%'>名称</td>" + "<td width='15%'>上行</td>" + "<td width='15%'>下行</td>" +
						"<td width='16%'>在线客户</td></tr>"
					for (var i in d) {
						tableData += '<tr><td class="iwanSvrName">' + d[i].name + '</td><td>' + d[i].outbps + '</td><td>' +
							d[i].inbps + '</td><td class="clntcnt" onclick="rightBtn(\'' + id + '\',\'' + d[i].name + '\')">' +
							d[i].clntcnt + '</td>';
					}
					tableData += "</tr>";
					cb(tableData);
				}

				var host = window.document.location.protocol + '//' + window.document.location.hostname;
				var d = data;
				var state_png, usedays, usedayscolor;
				var dt = new Date();
				var n = parseInt(dt.getTime() / 1000);
				if (d.length <= 0) {
					d = {
						cpu: "0",
						downbps: 0,
						flowcont: 0,
						grpid: "0",
						grpname: "",
						ipaddr: "",
						latitude: "",
						license_end: 0,
						license_end_str: "",
						license_id12: "",
						license_id83: "",
						license_start: "0",
						license_start_str: "",
						localip: "",
						longitude: "",
						map_address: "none",
						max_flowcont: 0,
						max_ipcnt: 0,
						max_users: "0",
						outip: "",
						servertime: 0,
						sshport: "0",
						sys_name: "",
						sys_name2: "",
						sys_run: "",
						temp: "0",
						time: 0,
						time_str: "",
						upbps: 0,
						users: 0,
						version: "",
						webport: "0"
					}
				} else
					d = data.data;
				if (d.license_end == 0) {
					usedays = '';
					state_png =
						'<span style="color: #5dff36">当前在线<img src="../img/10.png" style="width:15px;margin-left:4px;"/></span>';
				} else {
					usedays = parseInt((d.license_end - n) / 86400);
					if (usedays <= 7) {
						state_png =
							'<span style="color: #dbdb7f">License即将到期<img src="../img/16.png"/ style="width:15px;margin-left:4px;"></span>';
					} else
						state_png =
						'<span style="color: #5dff36">当前在线<img src="../img/10.png"/ style="width:15px;margin-left:4px;"></span>';
				}
				if (usedays != "" && usedays >= 0)
					usedays += '天';
				if ((d.time + 15) < d.servertime) {
					state_png =
						'<span style="color: #ff3636">断开连接<img src="../img/12.png" style="width:15px;margin-left:4px;"/></span>';
				}

				var c = ['<p>类型：' + topo.categorie(node.catid) + '</p>'];

				if (node.svccnt) {
					c.push('<p>iWAN服务：<span class="svrCount">' + node.svccnt + '</span></p>');
					// c.push('<p>iWAN拨入数：' + 0 + '</p>');
				}
				if (node.iwancnt) {
					c.push('<p>iWAN线路：<span class="iwanLineCnt">' + node.iwancnt + '</span></p>');
				}
				c.push('<p>外网线路：<span class="outerNetCnt">' + node.wancnt + '</span></p>');
				var xc = c.length;
				c.push('<p>网络接口：<span class="netCard">' + d.ifcnt + '</span></p>');
				c.push('<p>软件编号：<a class="setBtn" href="javascript:;" onclick="open_https(\'' + d.serialno + '\', \'' + host +
					'\', \'web\');">' + d.serialno + '</a></p>');
				c.push('<p>属组：' + d.grpname + '</p>');
				c.push('<p>当前版本：' + d.version + '</p>');
				c.push('<p>CPU使用率 / 温度：' + d.cpu + '% / ' + d.temp + '°C</p>');
				c.push('<p>已运行时间：' + $.myTime.UnixToStrDate(d.sysrun, 'HH:mm:ss') + '</p>');
				c.push('<p>有效期：' + usedays + '</p>');
				c.push('<p>状态：' + state_png + '</p>');
				c.push('<p>上行(bps)：' + numberformats(d.bpsout) + '</p>');
				c.push('<p>下行(bps)：' + numberformats(d.bpsin) + '</p>');
				c.push('<p>连接数：' + d.flowcont + ' / ' + parseInt(d.max_flowcont / 1000) + 'K' + '</p>');
				c.push('<p>用户数：' + d.users + ' / ' + d.max_users + '/' + ' [curr/max]</p>');
				c.push('<p>用户授权数：' + d.max_ipcnt + '</p>');
				c.push('<p>最后在线：' + $.myTime.UnixToStrDate(d.lasttime, 'yyyy-MM-dd HH:mm:ss') + '</p>');

				c.push('<div class="opt"><span class="ptitle">iWAN服务:</span><table class="iwanSvrTable">');
				var tableData = "<tr><td width='42%'>名称</td>" + "<td width='15%'>上行</td>" + "<td width='15%'>下行</td>" +
					"<td width='16%'>在线客户</td></tr>"
				for (var i in d) {
					tableData += '<tr><td class="iwanSvrName">' + d[i].name + '</td><td>' + d[i].outbps + '</td><td>' +
						d[i].inbps + '</td><td class="clntcnt" onclick="rightBtn(\'' + id + '\',\'' + d[i].name + '\')">' +
						d[i].clntcnt + '</td>';
				}
				tableData += "</tr>";
				showiwansvc(node.id, function(str) {
					c.push(str);
					c.push('</table></div>');
					body.html(c.join(''));

					body.selectAll('.iwanLineCnt').on('click', function() {
						iwanLineCnt(svrData);
					});
					body.selectAll('.outerNetCnt').on('click', function() {
						outerNetCnt(svrData);
					});
					body.selectAll('.iwanSvrTable .iwanSvrName').on('click', function() {
						var name = $(this).text();
						showSvrMiddleBox(svrData.id, name);
					});
					body.selectAll('.netCard').on('click', function() {
						netCard(svrData);
					});
					body.selectAll('.svrCount').on('click', function() {
						svrCount(svrData);
					})
				});
			}
		});
	}

	//关闭
	function close() {
		showed = 0;
		d3.select(domid).transition()
			.style('padding-left', '0px')
			.style('padding-right', '0px')
			.style('right', -width + 'px');

		return this;
	}

	function resize(w, h) {
		width = w * 0.18,
			height = h + 40;

		if (width < 265) width = 265;
		else
		if (width > 315) width = 315;
		d3.select('#r_aside').style('right', (showed ? 0 : -width) + 'px');
		d3.select('#r_aside').style('width', width + 'px');
		d3.select('#r_aside').style('height', height + 'px');

		// padding: 16px => 32px
		width += 32;
		return this;
	}

	return {
		show: show,
		close: close,
		resize: resize,
		refresh: refresh,
		init: init
	};
}

//二级拓扑图
function PathTopoChart() {
	var dispatch = d3.dispatch('selected', 'unselect', 'data');
	var graph = {};
	var selected = {};
	var highlighted = null;
	var svg;
	var dom;
	var width;
	var height;
	var fd_width = 1890;
	var fd_height = 1417;
	var nodes = [];
	var links = [];
	var iflink_size = 0;
	var maxLineChars = 16;
	var domCount = 0;
	var chart = {
		source: {},
		target: {}
	};
	//Scale
	var scaleX = d3.scaleLinear();
	var scaleY = d3.scaleLinear();
	// tabe head
	var tbhead = [{
			name: "",
			width: 0
		},
		{
			name: "iWAN线路",
			width: 115,
			type: 2
		}, {
			name: "承载线路",
			width: 115,
			type: 1
		}, {
			name: "网卡",
			width: 50,
			type: 0
		},
		{
			name: "网卡",
			width: 50,
			type: 0
		}, {
			name: "承载线路",
			width: 115,
			type: 1
		}, {
			name: "iWAN服务",
			width: 115,
			type: 3
		},
	];
	scaleX.domain([0, fd_width]);
	scaleY.domain([0, fd_height]);

	function init(wrap) {
		if (svg) {
			return;
		}

		dom = wrap;

		function create_device(container, classname) {
			var grp = container.append('g').classed(classname, true);
			// 初始化iwan线路与服务
			grp.append('g').classed('iwanContainer', true);
			// 初始化承载线路
			grp.append('g').classed('proxyContainer', true);
			// 初始化网卡
			grp.append('g').classed('ncardContainer', true);

			return grp;
		}
		svg = d3.select(dom).append('svg');
		var container = svg.append('g')
			.classed('pathContainer', true)
			.attr('transform', 'translate(10, 10)');

		var linkContainer = container.append('g').classed('linkContainer', true); //创建连线容器
		create_device(container, 'source');
		create_device(container, 'target');
		container.append('g').classed('nodeContainer', true); //创建节点容器

		// 创建小箭头对象
		linkContainer.append('defs').selectAll('marker')
			.data(['path_end', 'path_end_red', 'path_end_green', 'path_end_yellow'])
			.enter().append('marker')
			.attr('id', String)
			.attr('viewBox', '0 -5 10 10')
			.attr('refX', 11)
			.attr('refY', 0)
			.attr('fill', function(e, i) {
				return ['black', '#E10601', 'green', '#f6f617'][i];
			})
			.attr('markerWidth', 6)
			.attr('markerHeight', 6)
			.attr('orient', 'auto')
			.append('path')
			.attr('d', 'M0,-5L10, 0L0,5');

		svg.style('width', '100%');
		svg.style('height', '100%');
		resize();

		// 缩放对象
		var zoom = d3.zoom().scaleExtent([1 / 2, 8])
			.on('zoom', function() {
				container.attr('transform', d3.event.transform);
			});

		// 添加缩放功能
		svg.call(zoom);

		// 设置节点容器位置
		container
			.call(zoom.transform,
				d3.zoomIdentity
				.translate(width / -1, height / -1)
				.scale(3))
			.transition()
			.duration(750)
			.call(zoom.transform,
				d3.zoomIdentity
				.translate(50, 40)
				.scale(1));
	}

	function resize() {
		var e = d3.select(dom);
		width = parseInt(e.style('width')),
			height = parseInt(e.style('height'));
		/*
				if(svg) {
					svg.style('width', width + 'px');
					svg.style('height', height + 'px');
				}
		*/
		if (width < 1200) width = 1200;
		// Scale
		scaleX.range([0, width - 20]);
		scaleY.range([0, height - 50]);

		draw();
	}

	function refresh(source, target) {
		$.ajax({
			url: "api.php?r=topo@sdwan-link-info",
			type: 'post',
			data: {
				source: source,
				target: target
			},
			dataType: 'json',
			success(d) {
				if (d.ret != 0) return;
				if (!d.data.source || !d.data.target) return;
				chart = d.data;
				chart.source.peer = [];

				nodes = [];
				links = [];

				domCount = 0;

				iflink_size = 0;
				create_links();
				draw(1);
			}
		});
	}

	function wrap(text) {
		if (text.length <= maxLineChars) {
			return [text];
		} else {
			for (var k = 0; k < wrapChars.length; k++) {
				var c = wrapChars[k];
				for (var i = maxLineChars; i >= 0; i--) {
					if (text.charAt(i) === c) {
						var line = text.substring(0, i + 1);
						return [line].concat(wrap(text.substring(i + 1)));
					}
				}
			}
			return [text.substring(0, maxLineChars)]
				.concat(wrap(text.substring(maxLineChars)));
		}
	}

	function draw_Nodes() {
		function update_nodes(that) {
			that.classed('licensing', function(d) {
				var e = d3.select(this);
				if (d.linkup) {
					e.classed('close', false);
				} else {
					e.classed('close', true);
				}
				e.attr('data-x', d.index);
				return d.linkup;
			});

			that.selectAll('g.title').each(function(d, i) {
				var e = d3.select(this);

				d.title = wrap(d.name);
				e.selectAll(':scope>text').data(d.title)
					.join(
						function(enter) {
							enter.append('text')
								.text(function(text) {
									return text;
								})
								.attr('text-anchor', 'middle');
						},
						function(update) {
							update.text(function(text) {
								return text;
							});
						},
						function(exit) {
							exit.remove();
						}
					);
			});

			node_position(that);
		}

		function node_position(that) {
			that.each(function(d) {
				var e = d3.select(this);
				var dx = d.x - (d.width / 2),
					dy = d.y - 14;

				e.attr('transform', 'translate(' + dx + ', ' + dy + ')');
				e.select('rect').attr('x', '0em')
					.attr('y', '0em')
					.attr('width', function(d) {
						return d.width + 'px';
					})
					.attr('height', '28px');
				e.select('text').attr('dx', function(d) {
						if (d.type) return '4.7em';
						return '2.05em';
					})
					.attr('dy', '1.55em');
			});
		}
		//高亮
		svg.select('g.nodeContainer')
			.selectAll(':scope>g.node')
			.data(nodes)
			.join(
				function(enter) {
					var nodeGrp = enter.append('g').classed('node', true)
						.on('mouseover', function(d) {
							highlightObject(d);
						})
						.on('mouseout', function(d) {
							highlightObject();
						})
						.on('click', function(d) {
							selectObject(d, this);
						})

					nodeGrp.append('rect');
					nodeGrp.append('g').classed('title', true);
					update_nodes(nodeGrp);
				},
				function(update) {
					update_nodes(update);
				},
				function(exit) {
					exit.remove();
				}
			);


	}

	function highlightObject(obj) {
		if (obj) {
			if (obj !== highlighted) {
				svg.selectAll('.pathContainer [data-x]')
					.classed('inactive', function(d) {
						return (typeof obj.index != 'undefined' && obj.index != d.index && obj.nodeArr.indexOf(d.index) == -1);
					});

				highlighted = obj;
			}
		} else {
			if (highlighted) {
				svg.selectAll('.pathContainer [data-x].inactive').classed('inactive', false);
			}
			highlighted = null;
		}
	}


	// 		 						var glow = graph.linkContainer.append('filter')
	// 		 							.attr('cx', '-50%')
	// 		 							.attr('cy', '-50%')
	// 		 							.attr('width', '200%')
	// 		 							.attr('height', '200%')
	// 		 							.attr('id', 'blue-glow');
	// 		 						
	// 		 						glow.append('feColorMatrix')
	// 		 							.attr('type', 'matrix')
	// 		 							.attr('values', '0 0 0 0  0 ' +
	// 		 								'0 0 0 0  0 ' +
	// 		 								'0 0 0 0  .7 ' +
	// 		 								'0 0 0 1  0 ');
	// 		 						glow.append('feGaussianBlur')
	// 		 							.attr('stdDeviation', 3)
	// 		 							.attr('result', 'coloredBlur');
	// 		 						
	// 		 						glow.append('feMerge').selectAll('feMergeNode')
	// 		 							.data(['coloredBlur', 'SourceGraphic'])
	// 		 							.enter().append('feMergeNode')
	// 		 							.attr('in', String);


	function selectObject(obj, el) {
		var node;

		if (el) {
			node = d3.select(el);
		} else {
			svg.node.each(function(d) {
				if (d === obj)
					node = d3.select(el = this);
			});
		}
		if (!node) return;

		if (node.classed('selected')) {
			deselectObject();
			dispatch.call('unselect', el, obj);
			return;
		}
		deselectObject(false);

		selected = {
			obj: obj,
			el: el
		};

		highlightObject(obj);
		node.classed('selected', true);
		// 		
		dispatch.call('selected', el, obj);

		resize();
	}

	function onselectObject(id) {
		var nodes = d3.select('#node_' + id);

		nodes.each(function(d, i) {
			selectObject(d, this);
			return;
		});

		return nodes.size();
	}

	function unselectObject() {
		if (highlighted)
			deselectObject(false);

		dispatch.apply('unselect');
		return this;
	}

	function deselectObject(doResize) {
		if (doResize || typeof doResize == 'undefined') {
			resize();
		}
		svg.selectAll('g.nodeContainer>g.selected')
			.classed('selected', false);
		selected = {};
		highlightObject(null);
	}

	function create_links() {
		var i, iwan, key,
			wan, proxy, name, svc, p, v,
			src, dst,
			d = chart.source.data,
			source, target, node = [],
			peer = chart.source.peer;

		var iflist = {};

		// make source peer obj
		for (i = 0; i < d.length; i++) {
			iwan = d[i];
			iwan.pxy = chart.source.proxy[iwan.proxy];
			// iwan.pxy.pxy = iwan.pxy;
			iwan.pxy.ifd = chart.source.ifs[iwan.pxy.ifname];
			iwan.ifd = iwan.pxy.ifd;
			key = iwan.peerip + '_' + iwan.peerport;
			if (peer[key])
				peer[key].push(i);
			else
				peer[key] = [i];

			iwan.index = domCount++;
			if (!iwan.pxy.index)
				iwan.pxy.index = domCount++;

			if (!iwan.ifd.index)
				iwan.ifd.index = domCount++;

			iwan.dstlink = {
				index: domCount++,
				source: iwan,
				target: iwan.pxy,
				size: 1,
				linknum: 1,
				issource: 1,
				nodeArr: [iwan.pxy.index, iwan.ifd.index, iwan.index]
			};
			links.push(iwan.dstlink);

			if (!iflist[iwan.ifd.name]) {
				iflist[iwan.ifd.name] = 1;

				iwan.pxy.dstlink = {
					index: domCount++,
					source: iwan.pxy,
					target: iwan.ifd,
					size: 1,
					linknum: 1,
					issource: 1,
					nodeArr: [iwan.pxy.index, iwan.ifd.index, iwan.index, iwan.dstlink.index]
				};
				links.push(iwan.pxy.dstlink);
			} else
				iwan.pxy.dstlink.nodeArr.push(iwan.index, iwan.dstlink.index);

			iwan.dstlink.nodeArr.push(iwan.pxy.dstlink.index);

			iwan.nodeArr = [iwan.dstlink.index, iwan.pxy.index, iwan.pxy.dstlink.index, iwan.ifd.index];

			if (!iwan.pxy.nodeArr)
				iwan.pxy.nodeArr = [iwan.index, iwan.dstlink.index, iwan.pxy.dstlink.index, iwan.ifd.index];
			else {
				iwan.pxy.nodeArr.push(iwan.index, iwan.dstlink.index);
				if (iwan.pxy.nodeArr.indexOf(iwan.ifd.index))
					iwan.pxy.nodeArr.push(iwan.ifd.index, iwan.pxy.dstlink.index);
			}

			if (!iwan.ifd.nodeArr)
				iwan.ifd.nodeArr = [iwan.index, iwan.dstlink.index, iwan.pxy.index, iwan.pxy.dstlink.index];
			else {
				iwan.ifd.nodeArr.push(iwan.index, iwan.dstlink.index);
				if (iwan.ifd.nodeArr.indexOf(iwan.pxy.index))
					iwan.ifd.nodeArr.push(iwan.pxy.index, iwan.pxy.dstlink.index);
			}
		}

		iflist = {};
		var tmplist = [];
		// find iwan peer obj
		d = chart.target.data;
		for (i = 0; i < d.length; i++) {
			svc = d[i];
			svc.index = domCount++;
			svc.nodeArr = [];

			for (name in svc.proxy) {
				wan = svc.proxy[name];
				proxy = chart.target.proxy[wan.id];
				proxy.ifd = chart.target.ifs[proxy.ifname];
				wan.pxy = proxy;
				wan.ifd = proxy.ifd;

				if (!wan.pxy.index)
					wan.pxy.index = domCount++;

				if (!wan.ifd.index)
					wan.ifd.index = domCount++;

				svc.dstlink = {
					index: domCount++,
					source: proxy,
					target: svc,
					size: 1,
					linknum: 1,
					issource: 0,
					nodeArr: [svc.index, iwan.pxy.index, wan.ifd.index]
				};
				links.push(svc.dstlink);

				if (typeof iflist[proxy.ifd.name]) {
					iflist[proxy.ifd.name] = 1;

					wan.pxy.dstlink = {
						index: domCount++,
						source: proxy.ifd,
						target: proxy,
						size: 1,
						linknum: 1,
						issource: 0,
						nodeArr: [svc.index, svc.dstlink.index, iwan.pxy.index, wan.ifd.index]
					};

					links.push(wan.pxy.dstlink);
				} else {
					/*
					if(!wan.pxy.dstlink)
						wan.pxy.dstlink = {
							index: domCount++,
							source: proxy.ifd,
							target: proxy,
							size: 1,
							linknum: 1,
							issource: 0,
							nodeArr: [svc.index, svc.dstlink.index, wan.pxy.index, wan.ifd.index]
						};
					else
					*/
					wan.pxy.dstlink.nodeArr.push(svc.index, svc.dstlink.index);
				}

				svc.dstlink.nodeArr.push(wan.pxy.dstlink.index);

				if (!svc.nodeArr)
					svc.nodeArr = [svc.dstlink.index, wan.pxy.index, wan.pxy.dstlink.index, wan.ifd.index];
				else
					svc.nodeArr.push(svc.dstlink.index, wan.pxy.index, wan.pxy.dstlink.index, wan.ifd.index);

				if (!wan.pxy.nodeArr)
					wan.pxy.nodeArr = [svc.index, svc.dstlink.index, wan.pxy.dstlink.index, wan.ifd.index];
				else
					wan.pxy.nodeArr.push(svc.index, svc.dstlink.index);

				if (!wan.ifd.nodeArr)
					wan.ifd.nodeArr = [svc.index, svc.dstlink.index, wan.pxy.index, wan.pxy.dstlink.index];
				else {
					wan.ifd.nodeArr.push(svc.index, svc.dstlink.index);
					if (wan.ifd.nodeArr.indexOf(wan.pxy.index) == -1)
						wan.ifd.nodeArr.push(wan.pxy.index, wan.pxy.dstlink.index);
				}

				for (p = 0; p < wan.port.length; p++) {
					key = proxy.ip + '_' + wan.port[p];
					if (!peer[key]) continue;

					for (v = 0; v < peer[key].length; v++) {
						source = chart.source.data[peer[key][v]];
						target = svc;

						// push ifs links
						dst = {
							index: domCount++,
							type: 4,
							source: {
								name: source.name,
								iwan: source,
								proxy: source.pxy.name,
								pxy: source.pxy,
								ifd: source.pxy.ifd
							},
							target: {
								name: svc.name,
								iwan: svc,
								proxy: name,
								pxy: proxy,
								port: wan.port[p],
								ifd: proxy.ifd
							},
							issource: 2,
							nodeArr: []
						};
						node.push(dst);
						tmplist.push(dst);
					}
				}
			}
		}

		for (i = 0; i < tmplist.length; i++) {
			src = tmplist[i].source;
			dst = tmplist[i].target;
			for (p = 0; p < src.iwan.nodeArr.length; p++) {
				dst.iwan.nodeArr.push(tmplist[i].index, src.iwan.index, src.iwan.nodeArr[p]);
			}

			for (p = 0; p < dst.pxy.dstlink.nodeArr.length; p++) {
				src.iwan.nodeArr.push(tmplist[i].index, dst.pxy.index, dst.pxy.dstlink.nodeArr[p]);
			}
		}

		// set links
		var linkGroup = [];
		var linkmap = [];

		for (var i = 0; i < node.length; i++) {
			if (node[i].source.name < node[i].target.name)
				key = node[i].source.name + ':' + node[i].target.name;
			else
				key = node[i].target.name + ':' + node[i].source.name;

			if (!linkmap.hasOwnProperty(key)) {
				linkmap[key] = {
					count: 0,
					isme: (node[i].source.name == node[i].target.name)
				};
			}
			linkmap[key].count++;
			if (!linkGroup.hasOwnProperty(key))
				linkGroup[key] = [];

			linkGroup[key].push(node[i]);

			links.push(node[i]);
		}

		for (var i = 0; i < node.length; i++) {
			if (node[i].source.name < node[i].target.name)
				key = node[i].source.name + ':' + node[i].target.name;
			else
				key = node[i].target.name + ':' + node[i].source.name;

			node[i].linknum = linkmap[key].count;

			setLinkNumber(linkGroup[key], linkmap[key].isme);
		}
	}

	function setLinkNumber(group, isme) {
		if (group.length == 0) return;

		// 对该分组内的关系按照方向进行分类，此处根据连接的实体ASCII值大小分成两部分
		var i, linksA = [],
			linksB = [];

		for (i = 0; i < group.length; i++) {
			var link = group[i];
			if (link.source.name < link.target.name)
				linksA.push(link);
			else
				linksB.push(link);
		}

		// 确定关系最大编号。为了使得连接两个实体的关系曲线呈现对称，根据关系数量奇偶性进行平分。
		// 特殊情况：当关系都是连接到同一个实体时，不平分
		var maxLinkNumber = group.length;
		if (!isme) {
			if (maxLinkNumber % 2)
				maxLinkNumber++;
			maxLinkNumber = maxLinkNumber / 2;
		}

		// 如果两个方向的关系数量一样多，直接分别设置编号即可
		if (linksA.length == linksB.length) {
			var startLinkNumber = 1;
			for (i = 0; i < linksA.length; i++) {
				linksA[i].linknum = startLinkNumber++;
			}
			startLinkNumber = 1;
			for (i = 0; i < linksB.length; i++) {
				linksB[i].linknum = startLinkNumber++;
			}
		} else {
			// 当两个方向的关系数量不对等时，先对数量少的那组关系从最大编号值进行逆序编号，
			// 然后在对另一组数量多的关系从编号1一直编号到最大编号，再对剩余关系进行负编号
			// 如果抛开负号，可以发现，最终所有关系的编号序列一定是对称的
			// （对称是为了保证后续绘图时曲线的弯曲程度也是对称的）
			var biggerLinks, smallerLinks;
			if (linksA.length > linksB.length) {
				biggerLinks = linksA;
				smallerLinks = linksB;
			} else {
				biggerLinks = linksB;
				smallerLinks = linksA;
			}

			var startLinkNumber = maxLinkNumber;
			for (var i = 0; i < smallerLinks.length; i++) {
				smallerLinks[i].linknum = startLinkNumber--;
			}
			var tmpNumber = startLinkNumber;

			startLinkNumber = 1;
			var p = 0;
			while (startLinkNumber <= maxLinkNumber) {
				biggerLinks[p++].linknum = startLinkNumber++;
			}
			//开始负编号
			startLinkNumber = 0 - tmpNumber;
			for (var i = p; i < biggerLinks.length; i++) {
				biggerLinks[i].linknum = startLinkNumber++;
			}
		}
	}

	function init_position(first) {
		function push_node(x, d, type, box_width) {
			var vx = scaleX(x);
			var baseY, i, node;

			baseY = fd_height / (d.length + 3) + 45;
			for (i = 0; i < d.length; i++) {
				node = d[i];
				node.x = vx;
				node.y = scaleY(baseY + baseY * i);
				node.width = box_width;
				node.type = type;
				if (first)
					nodes.push(node);
			}
		}

		if (!chart.source.data) return;

		if (first) {
			for (var i = 0; i < tbhead.length; i++)
				nodes.push(tbhead[i]);
		}

		var offeX = 0;
		var offeY = 15;
		for (var i = 1; i < 4; i++) {
			offeX += tbhead[i].width / 2;
			tbhead[i].x = offeX;
			tbhead[i].y = offeY;
			offeX += tbhead[i].width / 2 + 150;
		}
		offeX += 300;
		for (var i = 4; i < tbhead.length; i++) {
			offeX += tbhead[i].width / 2;
			tbhead[i].x = offeX;
			tbhead[i].y = offeY;
			offeX += tbhead[i].width / 2 + 150;
		}

		push_node(tbhead[1].x, chart.source.data, 2, tbhead[1].width);
		push_node(tbhead[2].x, chart.source.proxy, 1, tbhead[2].width);
		push_node(tbhead[3].x, chart.source.ifs, 0, tbhead[3].width);

		push_node(tbhead[4].x, chart.target.ifs, 0, tbhead[4].width);
		push_node(tbhead[5].x, chart.target.proxy, 1, tbhead[5].width);
		push_node(tbhead[6].x, chart.target.data, 3, tbhead[6].width);

		nodes[0].x = nodes[1].x;
		nodes[0].y = scaleY(0);
		nodes[0].width = scaleX(nodes[6].x + nodes[6].width - nodes[1].x);

		for (var i = 0; i < tbhead.length; i++) {
			nodes[i].x = scaleX(nodes[i].x);
			nodes[i].y = scaleY(0);
		}
		nodes[0].x = nodes[0].width / 2;

	}

	function update_links() {
		function lineupdate(that) {
			that.classed('line', function(d) {
					var e = d3.select(this);

					if (d.type == 4) {
						if (d.source.ifd.linkup && d.target.ifd.linkup) {
							e.classed('licensing', true);
							e.classed('close', false);
						} else {
							e.classed('licensing', false);
							e.classed('close', true);
						}
					} else {
						if (d.source.linkup && d.target.linkup) {
							e.classed('licensing', true);
							e.classed('close', false);
						} else {
							e.classed('licensing', false);
							e.classed('close', true);
						}
					}
					return true;
				})
				.attr('id', function(d, i) {
					if (d.type == 4) {
						return 'path_' + d.issource + '_' + d.source.ifd.name + '_' + d.target.ifd.name;
					}
					return 'path_' + d.issource + '_' + d.source.name + '_' + d.target.name;
				}).attr('data-x', function(d) {
					return d.index;
				});
		}

		svg.select('g.linkContainer')
			.selectAll(':scope>path.line')
			.data(links)
			.join(
				function(enter) {
					var line = enter.append('path')
						.on('click', function(d) {
							alert('type: ' + d.type)
						});
					lineupdate(line);
				},
				function(update) {
					lineupdate(update);
				},
				function(exit) {
					exit.remove();
				}
			);
	}

	function draw(first) {
		init_position(first);
		update_links();

		draw_Nodes();

		svg.selectAll('g.linkContainer>path')
			.attr("d", function(d) {
				var dr;
				var x1, x2, y1, y2;


				// 如果连接线连接的是同一个实体，则对path属性进行调整，
				// 绘制的圆弧属于长圆弧，同时对终点坐标进行微调，避免因坐标一致导致弧无法绘制
				// 如果不是画两连网卡的连线，则都为直线。
				if (d.issource != 2) {

					x1 = d.source.x + d.source.width / 2;
					y1 = d.source.y;
					x2 = d.target.x - d.target.width / 2;
					y2 = d.target.y;
					return 'M ' + x1 + ' ' + y1 + ' L ' + x2 + ' ' + y2;
				}

				x1 = d.source.ifd.x + d.source.ifd.width / 2;
				y1 = d.source.ifd.y;
				x2 = d.target.ifd.x - d.target.ifd.width / 2;
				y2 = d.target.ifd.y;
				if (d.source.iwan === d.target.iwan && d.source.ifd === d.target.ifd) {
					dr = 30 / d.linknum;
					return "M" + x1 + "," + y1 + "A" + dr + "," + dr + " 0 1,1 " + x2 + "," + (y2 + 1);
				} else if (d.size % 2 != 0 && d.linknum == 1) {
					// 如果两个节点之间的连接线数量为奇数条，则设置编号为1的连接线为直线，
					// 其他连接线会均分在两边
					return 'M ' + x1 + ' ' + y1 + ' L ' + x2 + ' ' + y2;
				}

				// 根据连接线编号值来动态确定该条椭圆弧线的长半轴和短半轴，当两者一致时绘制的是圆弧
				// 注意A属性后面的参数，前两个为长半轴和短半轴，第三个默认为0，
				// 第四个表示弧度大于180度则为1，
				// 小于则为0，这在绘制连接到相同节点的连接线时用到；第五个参数，0表示正角，1表示负角，
				// 即用来控制弧形凹凸的方向。本文正是结合编号的正负情况来控制该条连接线的凹凸方向，
				// 从而达到连接线对称的效果
				var curve = 1.5;
				var homogeneous = 1.2;
				var dx = x2 - x1,
					dy = y2 - y1,
					dr = Math.sqrt(dx * dx + dy * dy) * (d.linknum + homogeneous) / (curve * homogeneous);

				//当节点编号为负数时，对弧形进行反向凹凸，达到对称效果
				if (d.linknum < 0) {
					dr = Math.sqrt(dx * dx + dy * dy) * (-1 * d.linknum + homogeneous) / (curve * homogeneous);
					return "M" + x1 + "," + y1 + "A" + dr + "," + dr + " 0 0,0 " + x2 + "," + y2;
				}
				return "M" + x1 + "," + y1 + "A" + dr + "," + dr + " 0 0,1 " + x2 + "," + y2;
			})
			.attr('marker-end', function(d) {
				var tag, link;

				if (d.type == 4) {
					tag = (d.source.ifd.linkup && d.target.ifd.linkup ? 'green' : 'red');
					return 'url(#path_end_' + tag + ')';
				}
				tag = (d.source.linkup && d.target.linkup ? 'green' : 'red');
				return 'url(#path_end_' + tag + ')';
			});
	}

	return {
		init: init,
		draw: draw,
		refresh: refresh,
		resize: resize
	};
}

function taskTimer() {
	var tasklist = {};
	var rmvlist = [];

	function add(name, time, task) {
		if (typeof task != 'object' || typeof task.fuc != 'function') {
			rmv(name);
			return;
		}
		if (!task.obj)
			task.obj = window;
		if (!task.arg)
			task.arg = [];

		if (tasklist[name])
			tasklist[name].time = time;
		else
			tasklist[name] = {
				time: time,
				curr: 0
			};

		tasklist[name].task = task;
	}

	function rmv(name) {
		rmvlist.push(name);
	}

	function go() {
		var i, task;

		for (i in rmvlist) {
			if (tasklist[rmvlist[i]]) delete tasklist[rmvlist[i]];
		}
		rmvlist = [];

		for (i in tasklist) {
			task = tasklist[i];
			if (task.curr >= task.time) {
				task.curr = 0;
				task.task.fuc.apply(task.task.obj, task.task.arg);
			} else
				task.curr++;
		}

		setTimeout(go, 1000);
	}

	setTimeout(go, 1000);

	return {
		add: add
	};
}
//拓扑图
function PaTopoChart(id) {
	var graph = {},
		selected = {},
		positiontask = {},
		highlighted = null,
		domid = '',
		config = {},
		dispatch = d3.dispatch('selected', 'unselect', 'lineclick', 'data'),
		url = 'apps/topo/assets/js/config.json',
		drawCnt = 0,
		maxLineChars = 26,
		wrapChars = ' /_-.'.split('');
	var dragNoRefresh = 0;

	domid = id || '';

	function init() {
		if (graph.svg) return;

		graph.svg = d3.select(domid);
		graph.svg.empty();
		graph.svg.on('click', function(d) {
			var tclass;
			var d = d3.select(d3.event.target).data()[0];
			if (typeof d == 'undefined' &&
				d3.event.target.parentElement.getAttribute('class').indexOf('node') &&
				selected.el)
				selectObject(selected.obj, selected.el);
			else if (d3.event.target.parentElement.parentElement.getAttribute('class').indexOf('licensing') == -1 &&
				d3.event.target.parentElement.getAttribute('class').indexOf('linkContainer') == -1 &&
				((tclass = d3.event.target.getAttribute('class')) == null || tclass.indexOf('off') == -1)
			) {
				win.closeAll(d);
			}
		});

		// 初始化拓扑图容器对象
		graph.container = graph.svg.append('g').classed('container', true);
		// 初始化连接线容器
		graph.linkContainer = graph.container.append('g').classed('linkContainer', true);
		// 初始化标签容器
		graph.labelContainer = graph.container.append('g').classed('labelContainer', true);
		// 初始化节点容器
		graph.nodeContainer = graph.container.append('g').classed('nodeContainer', true);

		// 缩放对象
		graph.zoom = d3.zoom().scaleExtent([1 / 2, 8])
			.on('zoom', function() {
				graph.container.attr('transform', d3.event.transform);
			});

		// 添加缩放功能
		graph.svg.call(graph.zoom);

		// 设置节点容器位置
		graph.container
			.call(graph.zoom.transform,
				d3.zoomIdentity
				.translate(graph.width / -1, graph.height / -1)
				.scale(3))
			.transition()
			.duration(750)
			.call(graph.zoom.transform,
				d3.zoomIdentity
				.translate(0, 0)
				.scale(1));

		// 创建小箭头对象
		graph.linkContainer.append('defs').selectAll('marker')
			.data(['end', 'end_red', 'end_green', 'end_yellow'])
			.enter().append('marker')
			.attr('id', String)
			.attr('viewBox', '0 -5 10 10')
			.attr('refX', 32)
			.attr('refY', 0)
			.attr('fill', function(e, i) {
				return ['black', '#E10601', 'green', '#f6f617'][i];
			})
			.attr('markerWidth', 6)
			.attr('markerHeight', 6)
			.attr('orient', 'auto')
			.append('path')
			.attr('d', 'M0,-5L10, 0L0,5');

		// 创建反向小箭头对象
		graph.linkContainer.append('defs').selectAll('marker')
			.data(['start', 'start_red', 'start_green', 'start_yellow'])
			.enter().append('marker')
			.attr('id', String)
			.attr('viewBox', '0 -5 10 10')
			.attr('refX', -22)
			.attr('refY', 0)
			.attr('fill', function(e, i) {
				return ['black', '#E10601', 'green', '#f6f617'][i];
			})
			.attr('markerWidth', 6)
			.attr('markerHeight', 6)
			.attr('orient', 'auto')
			.append('path')
			.attr('d', 'M 10,-5 0,0 10,5');

		// 节点高亮对象
		var glow = graph.linkContainer.append('filter')
			.attr('cx', '-50%')
			.attr('cy', '-50%')
			.attr('width', '200%')
			.attr('height', '200%')
			.attr('id', 'blue-glow');

		glow.append('feColorMatrix')
			.attr('type', 'matrix')
			.attr('values', '0 0 0 0  0 ' +
				'0 0 0 0  0 ' +
				'0 0 0 0  .7 ' +
				'0 0 0 1  0 ');

		glow.append('feGaussianBlur')
			.attr('stdDeviation', 3)
			.attr('result', 'coloredBlur');

		glow.append('feMerge').selectAll('feMergeNode')
			.data(['coloredBlur', 'SourceGraphic'])
			.enter().append('feMergeNode')
			.attr('in', String);

		// 设置类型图到左上角
		graph.legendbox = graph.svg.append('g')
			.attr('class', 'legend')
			.attr('transform', 'translate(20,-20)');

		// 左上角相对位置
		graph.legendConfig = {
			rectWidth: 12,
			rectHeight: 12,
			xOffset: -10,
			yOffset: 40,
			xOffsetText: 20,
			yOffsetText: 10,
			lineHeight: 15
		};

		graph.legendConfig.xOffsetText += graph.legendConfig.xOffset;
		graph.legendConfig.yOffsetText += graph.legendConfig.yOffset;

		return this;
	}

	function reload() {
		if(dragNoRefresh == 1) 
			return this;
		d3.json(url).then(function(d) {
			config = d;
			refresh();
		});
		return this;
	}

	function refresh() {
		d3.json(config.datasource).then(function(d) {
			if (d.errors.length) {
				alert('Data error(s):\n\n' + d.errors.join('\n'));
				return;
			}

			var self = this;
			graph.originData = d.data;

			init_position(d.data);
			init_categories();

			bind_nodes();
			bind_links();
			bind_label();


			draw_legend();
			draw_links();
			draw_nodes();

			graph.force.restart();

			dispatch.call('data', self, graph.originData);
			return this;
		});
	}

	function init_position(d) {
		var i, sid, tid, node, key,
			pop = [],
			cpe = [],
			keys = [];

		if(!d.nodes) d = {
			currtm: 0,
			nodes: [],
			links: []
		}

		graph.currtm = d.currtm;
		graph.data = d.nodes;
		graph.links = [];

		// set nodes
		for (i = 0; i < d.nodes.length; i++) {
			node = d.nodes[i];

			if (node.type & 2)
				pop.push(i);
			else
			if (node.type & 1)
				cpe.push(i);

			node.pop = [];
			node.cpe = [];

			keys.push(node.id);

			node.positionConstraints = [];
			node.linkStrength = 1;

			config.constraints.forEach(function(c) {
				for (var k in c.has) {
					if (c.has[k] !== node[k]) {
						return true;
					}
				}

				switch (c.type) {
					case 'position':
						node.positionConstraints.push({
							weight: c.weight,
							x: c.x * graph.width,
							y: c.y * graph.height
						});
						break;

					case 'linkStrength':
						node.linkStrength *= c.strength;
						break;
				}
			});
		}

		// reset links
		for (i = 0; i < d.links.length; i++) {
			node = d.links[i];
			if ((sid = keys.indexOf(node.source)) == -1)
				continue;
			if ((tid = keys.indexOf(node.target)) == -1)
				continue;

			graph.data[sid].pop.push(graph.data[tid].id);
			graph.data[tid].cpe.push(graph.data[sid].id);

			graph.links.push({
				source: graph.data[sid],
				target: graph.data[tid],
				links: node.links
			});
		}

		// set position
		function SetRow(base, count, nRow, nCol, yPosition, one) {
			for (var i = 0; i < count; i++) {
				node = graph.data[base[nRow * nCol + i]];
				if (node.vx)
					node.fx = graph.width * node.vx;
				else
					node.fx = (graph.width - count * size) / 2 + i * size;
				if (node.vy)
					node.fy = graph.height * node.vy;
				else
					node.fy = yPosition + (nRow * yDis * one);
			}
		}

		graph.vWidth = 0.8;
		var i,
			x = (graph.width * graph.vWidth),
			yPop = graph.height * 0.35,
			yCpe = graph.height * 0.65,
			hNum = parseInt((graph.width * graph.vWidth) / 120),
			vNum = parseInt(pop.length / hNum),
			size = 120,
			yDis = 60;

		// set pop position
		for (i = 0; i < vNum; i++)
			SetRow(pop, hNum, i, hNum, yPop, -1);

		SetRow(pop, pop.length % hNum, vNum, hNum, yPop, -1);

		var nCpe = cpe.length; //客户端个数
		vNum = parseInt(nCpe / hNum); //客户端行数
		for (i = 0; i < vNum; i++)
			SetRow(cpe, hNum, i, hNum, yCpe, 1);

		SetRow(cpe, nCpe % hNum, vNum, hNum, yCpe, 1);

		// set links
		var linkGroup = [];
		var linkmap = [];

		node = graph.links;
		for (var i = 0; i < node.length; i++) {
			if (node[i].source.id < node[i].target.id)
				key = node[i].source.id + ':' + node[i].target.id;
			else
				key = node[i].target.id + ':' + node[i].source.id;

			if (!linkmap.hasOwnProperty(key)) {
				linkmap[key] = {
					count: 0,
					isme: (node[i].source.id == node[i].target.id)
				};
			}
			linkmap[key].count++;
			if (!linkGroup.hasOwnProperty(key))
				linkGroup[key] = [];

			linkGroup[key].push(node[i]);
		}

		for (var i = 0; i < node.length; i++) {
			if (node[i].source.id < node[i].target.id)
				key = node[i].source.id + ':' + node[i].target.id;
			else
				key = node[i].target.id + ':' + node[i].source.id;

			node[i].linknum = linkmap[key].count;

			setLinkNumber(linkGroup[key], linkmap[key].isme);
		}
	}

	function setLinkNumber(group, isme) {
		if (group.length == 0) return;

		// 对该分组内的关系按照方向进行分类，此处根据连接的实体ASCII值大小分成两部分
		var i, linksA = [],
			linksB = [];

		for (i = 0; i < group.length; i++) {
			var link = group[i];
			if (link.source.id < link.target.id)
				linksA.push(link);
			else
				linksB.push(link);
		}

		// 确定关系最大编号。为了使得连接两个实体的关系曲线呈现对称，根据关系数量奇偶性进行平分。
		// 特殊情况：当关系都是连接到同一个实体时，不平分
		var maxLinkNumber = group.length;
		if (!isme) {
			if (maxLinkNumber % 2)
				maxLinkNumber++;
			maxLinkNumber = maxLinkNumber / 2;
		}

		// 如果两个方向的关系数量一样多，直接分别设置编号即可
		if (linksA.length == linksB.length) {
			var startLinkNumber = 1;
			for (i = 0; i < linksA.length; i++) {
				linksA[i].linknum = startLinkNumber++;
			}
			startLinkNumber = 1;
			for (i = 0; i < linksB.length; i++) {
				linksB[i].linknum = startLinkNumber++;
			}
		} else {
			// 当两个方向的关系数量不对等时，先对数量少的那组关系从最大编号值进行逆序编号，
			// 然后在对另一组数量多的关系从编号1一直编号到最大编号，再对剩余关系进行负编号
			// 如果抛开负号，可以发现，最终所有关系的编号序列一定是对称的
			// （对称是为了保证后续绘图时曲线的弯曲程度也是对称的）
			var biggerLinks, smallerLinks;
			if (linksA.length > linksB.length) {
				biggerLinks = linksA;
				smallerLinks = linksB;
			} else {
				biggerLinks = linksB;
				smallerLinks = linksA;
			}

			var startLinkNumber = maxLinkNumber;
			for (var i = 0; i < smallerLinks.length; i++) {
				smallerLinks[i].linknum = startLinkNumber--;
			}
			var tmpNumber = startLinkNumber;

			startLinkNumber = 1;
			var p = 0;
			while (startLinkNumber <= maxLinkNumber) {
				biggerLinks[p++].linknum = startLinkNumber++;
			}
			//开始负编号
			startLinkNumber = 0 - tmpNumber;
			for (var i = p; i < biggerLinks.length; i++) {
				biggerLinks[i].linknum = startLinkNumber++;
			}
		}
	}

	function init_categories() {
		graph.categories = {};
		for (var key in config.devs) {
			graph.categories[key] = {
				key: key + ':0',
				type: 0,
				typeName: config.devs[key].short,
				ico: config.devs[key].ico,
				count: 0
			};
		}
		for (var name in graph.data) {
			var obj = graph.data[name],
				map = ['internet', 'panabit'],
				key;

			obj.devstr = map[obj.dev];
			key = obj.devstr + ':' + obj.type;
			obj.catid = key;
			cat = graph.categories[key];

			if (!cat) {
				if (!config.devs[obj.devstr] ||
					!config.devs[obj.devstr].types[obj.type])
					continue;

				cat = graph.categories[key] = {
					key: key,
					type: obj.type,
					typeName: config.devs[obj.devstr].types[obj.type].short,
					ico: config.devs[obj.devstr].types[obj.type].ico,
					count: 0
				};
			}
			cat.count++;
		}

		graph.categoryKeys = d3.keys(graph.categories);
		graph.colors = colorbrewer.Set3[config.graph.numColors];

		// 生成群组矩形方块填充颜色集
		graph.strokeColor = getColorScale(0.7);
		graph.fillColor = getColorScale(-0.1);
	}

	function getColorScale(darkness) {
		return d3.scaleOrdinal()
			.domain(graph.categoryKeys)
			.range(graph.colors.map(function(c) {
				return d3.hsl(c).darker(darkness).toString();
			}));
	}

	function clicklabel(d) {
		var self = this;
		dispatch.call('lineclick', self, d);
	}

	function bind_links() {
		function lineupdate(that) {
			that.classed('line', function(d) {
					var e = d3.select(this);

					if (d.source.workcnt) {
						e.classed('licensing', true);
						e.classed('close', false);
					} else {
						e.classed('licensing', false);
						e.classed('close', true);
					}
					return true;
				})
				.attr('id', function(d, i) {
					return 'pxy_' + d.source.id + '_' + d.target.id;
				});
		}

		graph.svg.select('g.linkContainer')
			.selectAll(':scope>path.line')
			.data(graph.force.force('link').links())
			.join(
				function(enter) {
					var line = enter.append('path')
						.on('click', clicklabel);
					lineupdate(line);
				},
				function(update) {
					lineupdate(update);
				},
				function(exit) {
					exit.remove();
				}
			);
	}

	function bind_label() {
		function labelupdate(that) {
			that.classed('label', function(d) {
					var e = d3.select(this);
					if (d.source.workcnt) {
						e.classed('licensing', true);
						e.classed('close', false);
					} else {
						e.classed('licensing', false);
						e.classed('close', true);
					}

					return true;
				})
				.each(function(d, i) {
					var lightning, e = d3.select(this);

					if (d.source.workcnt) {
						e.selectAll("path.off").remove();
						if (e.selectAll("text").size() == 0) {
							e.append('text')
								.attr('dy', 2).classed('inbps', true)
								.on('click', clicklabel)
								.append('textPath');
							e.append('text')
								.attr('dy', -3).classed('outbps', true)
								.on('click', clicklabel)
								.append('textPath');
						}

						e.select('text.outbps textPath').text(function(d) {
								return '上行：' + bpstostr(d.links.outbps);
							})
							.attr('dominant-baseline', 'text-after-edge');

						e.select('text.inbps textPath').text(function(d) {
								return '下行：' + bpstostr(d.links.inbps);
							})
							.attr('dominant-baseline', 'text-before-edge');

						e.selectAll('text textPath')
							.attr('startOffset', '50%')
							.attr('xlink:href', function(d, i) {
								return '#pxy_' + d.source.id + '_' + d.target.id;
							});
					} else {
						e.selectAll("text").remove();
						if (e.select('path.off').size()) return;
						lightning = e.append("path").classed("off", true)
							.attr('d',
								'M 4.4956536,29.007182 0,38.007191 4.5004495,38.001791 1.5049447,47 12,35.74415 5.9993993,35.75135 10.49625,29 Z'
							)
							.on('click', clicklabel);

						lightning.append("animate")
							.attr('id', function(d) {
								return "lightning_a" + d.index
							})
							.attr('attributeName', "fill-opacity")
							.attr('attributeType', "XML")
							.attr('begin', function(d) {
								return "0s;lightning_b" + d.index + ".end"
							})
							.attr('dur', "1s")
							.attr('from', "1")
							.attr('to', "0")
							.attr('fill', "freeze");

						lightning.append("animate")
							.attr('id', function(d) {
								return "lightning_b" + d.index
							})
							.attr('attributeName', "fill-opacity")
							.attr('attributeType', "XML")
							.attr('begin', function(d) {
								return "lightning_a" + d.index + ".end"
							})
							.attr('dur', "1s")
							.attr('from', "0")
							.attr('to', "1")
							.attr('fill', "freeze");
					}
				});
		}

		graph.svg.select('g.labelContainer')
			.selectAll(':scope>g.label')
			.data(graph.force.force('link').links())
			.join(
				function(enter) {
					var label = enter.append('g');
					labelupdate(label);
				},
				function(update) {
					labelupdate(update);
				},
				function(exit) {
					exit.remove();
				}
			);
	}

	function bind_nodes() {
		graph.nodeValues = d3.values(graph.data);
		if (!graph.force) {
			// init D3 force layout
			graph.force = d3.forceSimulation(graph.nodeValues)
				// 绑定连线关系数据 设置节点的连线距离
				.force('link', d3.forceLink(graph.links)
					.id(function(d) {
						return d.id;
					})
					.distance(config.graph.linkDistance))
				// 设置引力的节点间距 
				.force('charge', d3.forceManyBody()
					.strength(config.graph.charge))
				// 设置在图的正中央位置画出
				.force('x', d3.forceX((graph.width - graph.width * 0.18) / 2))
				.force('y', d3.forceY(graph.height / 2))
				// 设置引力画图事件
				.on('tick', ticked);
		} else {
			graph.force.nodes(graph.nodeValues)
				.force('link').links(graph.links);
		}

		function nodeupdate(that) {
			that.each(function(d, i) {
				var i, node = d3.select(this),
					lines = wrap(d.name),
					ddy = -0.5,
					dy = -ddy * lines.length / 2 + .5;

				node.attr('id', function(d) {
					return 'node_' + d.id;
				});
				node.select('g.title').selectAll('text').each(function(d, i) {
					var text = d3.select(this);
					if (i < lines.length) {
						text.text(lines[i]);
						dy += ddy;
					} else
						text.remove();
				});

				var title = node.select('g.title');
				for (i = title.selectAll(':scope>text').size(); i < lines.length; i++) {
					title.append('text')
						.text(lines[i])
						.attr('text-anchor', 'middle')
						.attr('dy', dy * 5 + 'em')
						.attr('dx', dy + 'em');
					dy += ddy;
				}

				node.select('image.ico').each(function(d, i) {
					var ico = d3.select(this);

					ico.attr('href', geticolink(d.catid));
					if (d.linkup) {
						ico.selectAll('animate').remove();
					} else {
						ico.append("animate")
							.attr('id', function(d) {
								return "node_a" + d.index
							})
							.attr('attributeName', "fill-opacity")
							.attr('attributeType', "XML")
							//.attr('begin', function(d) {return "0s;node_b" + d.index + ".end"})
							.attr('dur', "1s")
							.attr('from', "1")
							.attr('to', "0.1")
							.attr('fill', "freeze");

						ico.append("animate")
							.attr('id', function(d) {
								return "node_b" + d.index
							})
							.attr('attributeName', "fill-opacity")
							.attr('attributeType', "XML")
							//.attr('begin', function(d) {return "node_a" + d.index + ".end"})
							.attr('dur', "1s")
							.attr('from', "0.1")
							.attr('to', "1")
							.attr('fill', "freeze");
					}
				});
			});
		}

		graph.svg.select('g.nodeContainer')
			.selectAll(':scope>g.node')
			.data(graph.force.nodes())
			.join(
				function(enter) {
					var node = enter.append('g')
						.classed('node', true)
						.on('mouseover', function(d) {
							if (!selected.obj) {
								if (graph.mouseoutTimeout) {
									clearTimeout(graph.mouseoutTimeout);
									graph.mouseoutTimeout = null;
								}
								highlightObject(d);
							}
						})
						.on('mouseout', function() {
							if (!selected.obj) {
								if (graph.mouseoutTimeout) {
									clearTimeout(graph.mouseoutTimeout);
									graph.mouseoutTimeout = null;
								}
								graph.mouseoutTimeout = setTimeout(function() {
									highlightObject(null);
								}, 300);
							}
						}).on('click', function(d) {
							selectObject(d, this);
						})
						.call(
							d3.drag()
							.on("start", function(d) {
								if (!d3.event.active)
									graph.force.alphaTarget(0.3).restart();

								d.mx = d.fx;
								d.my = d.fy;
								d.fx = d.x;
								d.fy = d.y;
								dragNoRefresh = 1;
							})
							.on("drag", function(d) {
								d.fx = d3.event.x;
								d.fy = d3.event.y;
							})
							.on("end", function dragended(d) {
								if (!d3.event.active)
									graph.force.alphaTarget(0);
								//d.fx = null;
								//d.fy = null;
								if (d.mx != d.fx || d.my != d.fy)
									positiontask[d.id] = {
										fx: d.fx,
										fy: d.fy
									};
								dragNoRefresh = 0;
							})
						);

					// title
					node.append('g').classed('title', true);

					// circle
					node.append('circle')
						.attr('cx', 10)
						.attr('cy', 10)
						.attr('r', 20)
						.attr('stroke', function(d) {
							return graph.strokeColor(d.catid);
						})
						.attr('fill', function(d) {
							return graph.fillColor(d.catid);
						});

					// ico
					node.append('image')
						.classed('ico', true)
						.attr('x', -3.5)
						.attr('y', -3.5)
						.attr('width', 28)
						.attr('height', 28);

					nodeupdate(node);
				},
				function(update) {
					nodeupdate(update);
				},
				function(exit) {
					exit.remove();
				}
			);
	}

	function draw_legend() {
		// 设置类型图到左上角
		graph.svg.select('g.legend')
			.selectAll(':scope>g.category')
			.data(d3.values(graph.categories))
			.join(
				function(enter) {
					var e = enter.append('g').classed('category', true);

					// 创建左上角颜色分组方块
					e.append('rect')
						.attr('x', graph.legendConfig.xOffset)
						.attr('y', function(d, i) {
							return graph.legendConfig.yOffset + i * graph.legendConfig.lineHeight;
						})
						.attr('height', graph.legendConfig.rectHeight)
						.attr('width', graph.legendConfig.rectWidth)
						.attr('fill', function(d) {
							return graph.fillColor(d.key);
						})
						.attr('stroke', function(d) {
							return graph.strokeColor(d.key);
						});

					// 设置类型名称
					e.append('text')
						.attr('x', graph.legendConfig.xOffsetText)
						.attr('y', function(d, i) {
							return graph.legendConfig.yOffsetText + i * graph.legendConfig.lineHeight;
						})
						.text(function(d, i) {
							return d.typeName + (d.group ? ': ' + d.group : '') + ' ' + d.count;
						});
				},
				function(update) {
					update.selectAll('text').text(function(d, i) {
						return d.typeName + (d.group ? ': ' + d.group : '') + ' ' + d.count;
					});
				},
				function(exit) {
					exit.remove();
				}
			);
	}

	function draw_links() {
		graph.svg.selectAll('g.linkContainer>path')
			.attr("d", function(d) {
				var dr;
				var x1, x2, y1, y2;

				if (d.source.x <= d.target.x) {
					x1 = d.source.x;
					y1 = d.source.y;
					x2 = d.target.x;
					y2 = d.target.y;
				} else {
					x1 = d.target.x;
					y1 = d.target.y;
					x2 = d.source.x;
					y2 = d.source.y;
				}
				// 如果连接线连接的是同一个实体，则对path属性进行调整，
				// 绘制的圆弧属于长圆弧，同时对终点坐标进行微调，避免因坐标一致导致弧无法绘制
				if (d.target.id == d.source.id) {
					dr = 30 / d.linknum;
					return "M" + x1 + "," + y1 + "A" + dr + "," + dr + " 0 1,1 " + x2 + "," + (y2 + 1);
				} else if (d.size % 2 != 0 && d.linknum == 1) {
					// 如果两个节点之间的连接线数量为奇数条，则设置编号为1的连接线为直线，
					// 其他连接线会均分在两边
					return 'M ' + x1 + ' ' + y1 + ' L ' + x2 + ' ' + y2;
				}
				// 根据连接线编号值来动态确定该条椭圆弧线的长半轴和短半轴，当两者一致时绘制的是圆弧
				// 注意A属性后面的参数，前两个为长半轴和短半轴，第三个默认为0，
				// 第四个表示弧度大于180度则为1，
				// 小于则为0，这在绘制连接到相同节点的连接线时用到；第五个参数，0表示正角，1表示负角，
				// 即用来控制弧形凹凸的方向。本文正是结合编号的正负情况来控制该条连接线的凹凸方向，
				// 从而达到连接线对称的效果
				var curve = 1.5;
				var homogeneous = 1.2;
				var dx = d.target.x - d.source.x,
					dy = d.target.y - d.source.x,
					dr = Math.sqrt(dx * dx + dy * dy) * (d.linknum + homogeneous) / (curve * homogeneous);

				//当节点编号为负数时，对弧形进行反向凹凸，达到对称效果
				if (d.linknum < 0) {
					dr = Math.sqrt(dx * dx + dy * dy) * (-1 * d.linknum + homogeneous) / (curve * homogeneous);
					return "M" + x1 + "," + y1 + "A" + dr + "," + dr + " 0 0,0 " + x2 + "," + y2;
				}
				return "M" + x1 + "," + y1 + "A" + dr + "," + dr + " 0 0,1 " + x2 + "," + y2;
			})
			.attr('marker-end', function(d) {
				var tag, link;

				if (d.source.x <= d.target.x) {
					tag = (d.source.workcnt ? 'green' : 'red');
					return 'url(#end_' + tag + ')';
				}

				return '';
			})
			.attr('marker-start', function(d) {
				var tag, link;

				if (d.source.x > d.target.x) {
					tag = (d.source.workcnt ? 'green' : 'red');
					return 'url(#start_' + tag + ')';
				}

				return '';
			});
	}

	function draw_label() {

		graph.svg.selectAll('g.labelContainer>path.off')
			.attr("transform", function(d) {
				var x1 = d.source.x,
					x2 = d.target.x,
					y1 = d.source.y,
					y2 = d.target.y,
					x = x1 - (x1 - x2) / 2,
					y = y1 - (y1 - y2) / 2,
					rightAngleSide1 = Math.abs(y2 - y1),
					rightAngleSide2 = Math.abs(x2 - x1),
					_asin = 0,
					_rotateAngle = 0,
					x3 = x1 - (x1 - x) / 2,
					y3 = y1 - (y1 - y) / 2;

				if (x1 < x2) {
					_asin = (y2 - y1) / Math.sqrt(Math.pow(rightAngleSide1, 2) + Math.pow(rightAngleSide2, 2));
					_rotateAngle = Math.asin(_asin) * 180 / Math.PI;
				} else {
					_asin = (y1 - y2) / Math.sqrt(Math.pow(rightAngleSide1, 2) + Math.pow(rightAngleSide2, 2));
					_rotateAngle = Math.asin(_asin) * 180 / Math.PI;
					if (y1 < y2)
						_rotateAngle = _rotateAngle > 0 ? (180 + _rotateAngle) : _rotateAngle;
					else
						_rotateAngle = _rotateAngle < 0 ? (180 + _rotateAngle) : _rotateAngle;
				}

				return 'rotate(' + (_rotateAngle) + ',' + x3 + ' ' + y3 + ')';
			});

		graph.svg.selectAll('g.labelContainer>g.label>path.off')
			.attr("transform", function(d) {
				var x1 = d.source.x,
					x2 = d.target.x,
					y1 = d.source.y,
					y2 = d.target.y,
					x = (x1 + x2 - 12) / 2,
					y = (y1 + y2 - 74) / 2;
				return 'translate(' + x + ' ' + y + ')';
			});

		graph.svg.selectAll('g.labelContainer>g.label>path>animate')
			.each(function(d, i) {
				var self = d3.select(this);
				self.attr('begin', self.attr('begin'));
			});
	}

	function draw_nodes() {
		graph.svg.selectAll('g.nodeContainer>g.node').each(function(d, i) {
			var node = d3.select(this);

			node.attr('transform', function(d) {
				return 'translate(' + (d.x - 10) + ',' + (d.y - 10) + ')';
			});

			if (!d.linkup) {
				node.classed('off', true)
					.select(':scope>image.ico')
					.selectAll('animate')
					.each(function(d, i) {
						var id, self = d3.select(this);
						if (self.attr('id').indexOf('node_a') == -1) {
							self.attr('begin', function(d) {
								return "node_a" + d.index + ".end"
							});
						} else {
							self.attr('begin', function(d) {
								return "0s;node_b" + d.index + ".end"
							});
						}
					});
			} else
				node.classed('off', false);
		});
	}

	function wrap(text) {
		if (text.length <= maxLineChars) {
			return [text];
		} else {
			for (var k = 0; k < wrapChars.length; k++) {
				var c = wrapChars[k];
				for (var i = maxLineChars; i >= 0; i--) {
					if (text.charAt(i) === c) {
						var line = text.substring(0, i + 1);
						return [line].concat(wrap(text.substring(i + 1)));
					}
				}
			}
			return [text.substring(0, maxLineChars)]
				.concat(wrap(text.substring(maxLineChars)));
		}
	}

	function highlightObject(obj) {
		if (obj) {
			if (obj !== highlighted) {
				graph.svg.selectAll('g.nodeContainer>g.node')
					.classed('inactive', function(d) {
						return (obj.id !== d.id &&
							d.pop.indexOf(obj.id) == -1 &&
							d.cpe.indexOf(obj.id) == -1);
					});
				graph.svg.selectAll('g.linkContainer>path')
					.classed('inactive', function(d) {
						return (obj.id !== d.source.id &&
							obj.id !== d.target.id);
					});
				graph.svg.selectAll('g.labelContainer>g')
					.classed('inactive', function(d) {
						return (obj.id !== d.source.id &&
							obj.id !== d.target.id);
					});

				highlighted = obj;
			}
		} else {
			if (highlighted) {
				graph.svg.selectAll('g.nodeContainer>g.node').classed('inactive', false);
				graph.svg.selectAll('g.linkContainer>path').classed('inactive', false);
				graph.svg.selectAll('g.labelContainer>g').classed('inactive', false);
			}
			highlighted = null;
		}
	}

	function selectObject(obj, el) {
		var node;

		if (el) {
			node = d3.select(el);
		} else {
			graph.node.each(function(d) {
				if (d === obj)
					node = d3.select(el = this);
			});
		}
		if (!node) return;

		if (node.classed('selected')) {
			deselectObject();
			dispatch.call('unselect', el, obj);
			return;
		}
		deselectObject(false);

		selected = {
			obj: obj,
			el: el
		};

		highlightObject(obj);
		node.classed('selected', true);

		dispatch.call('selected', el, obj);

		resize();
	}

	function onselectObject(id) {
		var nodes = d3.select('#node_' + id);

		nodes.each(function(d, i) {
			selectObject(d, this);
			return;
		});

		return nodes.size();
	}

	function unselectObject() {
		if (highlighted)
			deselectObject(false);

		dispatch.apply('unselect');
		return this;
	}

	function deselectObject(doResize) {
		if (doResize || typeof doResize == 'undefined') {
			resize();
		}
		graph.svg
			.selectAll('g.nodeContainer>g.selected')
			.classed('selected', false);
		selected = {};
		highlightObject(null);
	}

	function ticked() {
		var alpha = this.alpha();
		/*
				for (var name in graph.data) {
					var obj = graph.data[name];

					obj.positionConstraints.forEach(function(c) {
						var w = c.weight * alpha;
						if(!isNaN(obj.fx))
							obj.x = obj.fx;
						else {
							if (!isNaN(c.x)) {
								obj.x = (c.x * w + obj.x * (1 - w));
							}
						}
						if(!isNaN(obj.fy))
							obj.y = obj.fy;
						else {
							if (!isNaN(c.y)) {
								obj.y = (c.y * w + obj.y * (1 - w));
							}
						}
					});
				}
		*/
		draw_links();
		draw_label();
		draw_nodes();
	}

	function resize() {
		graph.width = $(domid).width();
		graph.height = $(domid).height();
		return this;
	}

	function set_event() {
		dispatch.on.apply(dispatch, arguments);
		return this;
	}

	function dispatch_event() {
		return dispatch.on.apply(dispatch, arguments);
	}

	function categorie(key) {
		if (graph.categories[key])
			return graph.categories[key].typeName;
		return '未知';
	}

	function geticolink(key) {
		if (graph.categories[key])
			return graph.categories[key].ico;
		return '';
	}

	function position_auto_save_task() {
		var count = 0;
		if (dragNoRefresh == 0) {
			for (id in positiontask) {
				count++;
				$.ajax({
					url: 'api.php?r=topo@gw-position',
					type: 'post',
					data: {
						serialno: id,
						vx: (positiontask[id].fx / graph.width),
						vy: (positiontask[id].fy / graph.height),
					},
					dataType: 'json',
					error: function() {
						setTimeout(position_auto_save_task, 1000);
					},
					success: function(d) {
						if (d.ret == 0 && positiontask[id])
							delete positiontask[id];
						setTimeout(position_auto_save_task, 1000);
					}
				});
			}
		}
		if (count == 0) {
			setTimeout(position_auto_save_task, 1000);
			return;
		}
	}

	position_auto_save_task();

	return {
		on: set_event,
		dispatch: dispatch_event,
		init: init,
		reload: reload,
		refresh: refresh,
		resize: resize,
		selected: onselectObject,
		unselect: unselectObject,
		categorie: categorie
	};
}

function delNode(node) {
	layer.confirm('确认删除 <span class="redTip">' + node.name + '</span> 吗?', {
		icon: 0,
		title: '设备删除'
	}, function(index) {
		$.ajax({
			url: 'api.php?r=gateway@remove',
			type: 'post',
			data: {
				dev: node.id
			},
			dataType: 'json',
			success: function() {
				layer.msg('删除成功', {
					icon: 1,
					time: 1000
				});
				topo.reload();
			},
			error: function() {
				layer.msg('删除失败，请稍后再试。', {
					icon: 2,
					time: 1000
				});
			}
		});
		layer.close(index);
	});
}

d3.dispatch.prototype.add = function(type) {
	if (!this._.hasOwnProperty(type))
		this._[type] = [];
}
d3.dispatch.prototype.rmv = function(type) {
	if (this._.hasOwnProperty(type))
		delete this._[type];
}

epool = d3.dispatch('load', 'resize');

d3.select(window).on('load', function() {
	var resize = d3.select(window).on("resize");

	d3.select(window).on("resize", function() {
		if (typeof resize == 'function')
			resize.call(window, arguments);

		epool.apply('resize', this, arguments);
	});

	epool.apply('load', this, arguments);
});

var topo = new PaTopoChart('#device_map');
var r_aside = new aside('#r_aside');
var listtable = new table('#listTable');
var win = new winController();
var tab = new tabController();
var task = new taskTimer();

epool.on('resize', function() {
	var e = d3.select('.product-body'),
		w = parseInt(e.style('width')),
		h = parseInt(e.style('height'));

	d3.select('#device_map')
		.style('width', w)
		.style('height', h);

	topo.resize();
	r_aside.resize(w, h);
	win.resize();
});

epool.on('load', function() {
	epool.apply('resize', this, arguments);

	topo.on('selected', function(d) {
			r_aside.show(d);
			win.closeAll(d);
		})
		.on('unselect', function(d) {
			r_aside.close(d);
			win.closeAll(d);
		})
		.on('lineclick', function(d) {
			showPathBox(d);
		})
		.on('data', function(d) {
			listtable.load(d);
		});

	r_aside.init();
	listtable.init();
	win.init();
	tab.init();
	topo.init().reload();

	// add task
	task.add('topo', 180, {
		fuc: topo.refresh
	});
	// 	task.add('aside', 3, {
	// 		fuc: r_aside.refresh
	// 	});

	//图、表tab切换
	$(".btnTab>button").click(function() {
		$(".btnTab>button").eq($(this).index()).addClass("active").siblings().removeClass('active');
		$(".product-body>div.wraplist").hide().eq($(this).index()).show();
	});
	$('#listTable').hide();
	//外网线路类型切换
});


// This product includes color specifications and designs developed by Cynthia Brewer (http://colorbrewer.org/).
var colorbrewer = {
	YlGn: {
		3: ["#f7fcb9", "#addd8e", "#31a354"],
		4: ["#ffffcc", "#c2e699", "#78c679", "#238443"],
		5: ["#ffffcc", "#c2e699", "#78c679", "#31a354", "#006837"],
		6: ["#ffffcc", "#d9f0a3", "#addd8e", "#78c679", "#31a354", "#006837"],
		7: ["#ffffcc", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#005a32"],
		8: ["#ffffe5", "#f7fcb9", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#005a32"],
		9: ["#ffffe5", "#f7fcb9", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#006837", "#004529"]
	},
	YlGnBu: {
		3: ["#edf8b1", "#7fcdbb", "#2c7fb8"],
		4: ["#ffffcc", "#a1dab4", "#41b6c4", "#225ea8"],
		5: ["#ffffcc", "#a1dab4", "#41b6c4", "#2c7fb8", "#253494"],
		6: ["#ffffcc", "#c7e9b4", "#7fcdbb", "#41b6c4", "#2c7fb8", "#253494"],
		7: ["#ffffcc", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#0c2c84"],
		8: ["#ffffd9", "#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#0c2c84"],
		9: ["#ffffd9", "#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#253494", "#081d58"]
	},
	GnBu: {
		3: ["#e0f3db", "#a8ddb5", "#43a2ca"],
		4: ["#f0f9e8", "#bae4bc", "#7bccc4", "#2b8cbe"],
		5: ["#f0f9e8", "#bae4bc", "#7bccc4", "#43a2ca", "#0868ac"],
		6: ["#f0f9e8", "#ccebc5", "#a8ddb5", "#7bccc4", "#43a2ca", "#0868ac"],
		7: ["#f0f9e8", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#08589e"],
		8: ["#f7fcf0", "#e0f3db", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#08589e"],
		9: ["#f7fcf0", "#e0f3db", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#0868ac", "#084081"]
	},
	BuGn: {
		3: ["#e5f5f9", "#99d8c9", "#2ca25f"],
		4: ["#edf8fb", "#b2e2e2", "#66c2a4", "#238b45"],
		5: ["#edf8fb", "#b2e2e2", "#66c2a4", "#2ca25f", "#006d2c"],
		6: ["#edf8fb", "#ccece6", "#99d8c9", "#66c2a4", "#2ca25f", "#006d2c"],
		7: ["#edf8fb", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#005824"],
		8: ["#f7fcfd", "#e5f5f9", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#005824"],
		9: ["#f7fcfd", "#e5f5f9", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#006d2c", "#00441b"]
	},
	PuBuGn: {
		3: ["#ece2f0", "#a6bddb", "#1c9099"],
		4: ["#f6eff7", "#bdc9e1", "#67a9cf", "#02818a"],
		5: ["#f6eff7", "#bdc9e1", "#67a9cf", "#1c9099", "#016c59"],
		6: ["#f6eff7", "#d0d1e6", "#a6bddb", "#67a9cf", "#1c9099", "#016c59"],
		7: ["#f6eff7", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016450"],
		8: ["#fff7fb", "#ece2f0", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016450"],
		9: ["#fff7fb", "#ece2f0", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016c59", "#014636"]
	},
	PuBu: {
		3: ["#ece7f2", "#a6bddb", "#2b8cbe"],
		4: ["#f1eef6", "#bdc9e1", "#74a9cf", "#0570b0"],
		5: ["#f1eef6", "#bdc9e1", "#74a9cf", "#2b8cbe", "#045a8d"],
		6: ["#f1eef6", "#d0d1e6", "#a6bddb", "#74a9cf", "#2b8cbe", "#045a8d"],
		7: ["#f1eef6", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#034e7b"],
		8: ["#fff7fb", "#ece7f2", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#034e7b"],
		9: ["#fff7fb", "#ece7f2", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#045a8d", "#023858"]
	},
	BuPu: {
		3: ["#e0ecf4", "#9ebcda", "#8856a7"],
		4: ["#edf8fb", "#b3cde3", "#8c96c6", "#88419d"],
		5: ["#edf8fb", "#b3cde3", "#8c96c6", "#8856a7", "#810f7c"],
		6: ["#edf8fb", "#bfd3e6", "#9ebcda", "#8c96c6", "#8856a7", "#810f7c"],
		7: ["#edf8fb", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#6e016b"],
		8: ["#f7fcfd", "#e0ecf4", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#6e016b"],
		9: ["#f7fcfd", "#e0ecf4", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#810f7c", "#4d004b"]
	},
	RdPu: {
		3: ["#fde0dd", "#fa9fb5", "#c51b8a"],
		4: ["#feebe2", "#fbb4b9", "#f768a1", "#ae017e"],
		5: ["#feebe2", "#fbb4b9", "#f768a1", "#c51b8a", "#7a0177"],
		6: ["#feebe2", "#fcc5c0", "#fa9fb5", "#f768a1", "#c51b8a", "#7a0177"],
		7: ["#feebe2", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177"],
		8: ["#fff7f3", "#fde0dd", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177"],
		9: ["#fff7f3", "#fde0dd", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177", "#49006a"]
	},
	PuRd: {
		3: ["#e7e1ef", "#c994c7", "#dd1c77"],
		4: ["#f1eef6", "#d7b5d8", "#df65b0", "#ce1256"],
		5: ["#f1eef6", "#d7b5d8", "#df65b0", "#dd1c77", "#980043"],
		6: ["#f1eef6", "#d4b9da", "#c994c7", "#df65b0", "#dd1c77", "#980043"],
		7: ["#f1eef6", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#91003f"],
		8: ["#f7f4f9", "#e7e1ef", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#91003f"],
		9: ["#f7f4f9", "#e7e1ef", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#980043", "#67001f"]
	},
	OrRd: {
		3: ["#fee8c8", "#fdbb84", "#e34a33"],
		4: ["#fef0d9", "#fdcc8a", "#fc8d59", "#d7301f"],
		5: ["#fef0d9", "#fdcc8a", "#fc8d59", "#e34a33", "#b30000"],
		6: ["#fef0d9", "#fdd49e", "#fdbb84", "#fc8d59", "#e34a33", "#b30000"],
		7: ["#fef0d9", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#990000"],
		8: ["#fff7ec", "#fee8c8", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#990000"],
		9: ["#fff7ec", "#fee8c8", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#b30000", "#7f0000"]
	},
	YlOrRd: {
		3: ["#ffeda0", "#feb24c", "#f03b20"],
		4: ["#ffffb2", "#fecc5c", "#fd8d3c", "#e31a1c"],
		5: ["#ffffb2", "#fecc5c", "#fd8d3c", "#f03b20", "#bd0026"],
		6: ["#ffffb2", "#fed976", "#feb24c", "#fd8d3c", "#f03b20", "#bd0026"],
		7: ["#ffffb2", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#b10026"],
		8: ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#b10026"],
		9: ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#bd0026", "#800026"]
	},
	YlOrBr: {
		3: ["#fff7bc", "#fec44f", "#d95f0e"],
		4: ["#ffffd4", "#fed98e", "#fe9929", "#cc4c02"],
		5: ["#ffffd4", "#fed98e", "#fe9929", "#d95f0e", "#993404"],
		6: ["#ffffd4", "#fee391", "#fec44f", "#fe9929", "#d95f0e", "#993404"],
		7: ["#ffffd4", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#8c2d04"],
		8: ["#ffffe5", "#fff7bc", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#8c2d04"],
		9: ["#ffffe5", "#fff7bc", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#993404", "#662506"]
	},
	Purples: {
		3: ["#efedf5", "#bcbddc", "#756bb1"],
		4: ["#f2f0f7", "#cbc9e2", "#9e9ac8", "#6a51a3"],
		5: ["#f2f0f7", "#cbc9e2", "#9e9ac8", "#756bb1", "#54278f"],
		6: ["#f2f0f7", "#dadaeb", "#bcbddc", "#9e9ac8", "#756bb1", "#54278f"],
		7: ["#f2f0f7", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#4a1486"],
		8: ["#fcfbfd", "#efedf5", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#4a1486"],
		9: ["#fcfbfd", "#efedf5", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#54278f", "#3f007d"]
	},
	Blues: {
		3: ["#deebf7", "#9ecae1", "#3182bd"],
		4: ["#eff3ff", "#bdd7e7", "#6baed6", "#2171b5"],
		5: ["#eff3ff", "#bdd7e7", "#6baed6", "#3182bd", "#08519c"],
		6: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"],
		7: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#084594"],
		8: ["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#084594"],
		9: ["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c", "#08306b"]
	},
	Greens: {
		3: ["#e5f5e0", "#a1d99b", "#31a354"],
		4: ["#edf8e9", "#bae4b3", "#74c476", "#238b45"],
		5: ["#edf8e9", "#bae4b3", "#74c476", "#31a354", "#006d2c"],
		6: ["#edf8e9", "#c7e9c0", "#a1d99b", "#74c476", "#31a354", "#006d2c"],
		7: ["#edf8e9", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#005a32"],
		8: ["#f7fcf5", "#e5f5e0", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#005a32"],
		9: ["#f7fcf5", "#e5f5e0", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#006d2c", "#00441b"]
	},
	Oranges: {
		3: ["#fee6ce", "#fdae6b", "#e6550d"],
		4: ["#feedde", "#fdbe85", "#fd8d3c", "#d94701"],
		5: ["#feedde", "#fdbe85", "#fd8d3c", "#e6550d", "#a63603"],
		6: ["#feedde", "#fdd0a2", "#fdae6b", "#fd8d3c", "#e6550d", "#a63603"],
		7: ["#feedde", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#8c2d04"],
		8: ["#fff5eb", "#fee6ce", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#8c2d04"],
		9: ["#fff5eb", "#fee6ce", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#a63603", "#7f2704"]
	},
	Reds: {
		3: ["#fee0d2", "#fc9272", "#de2d26"],
		4: ["#fee5d9", "#fcae91", "#fb6a4a", "#cb181d"],
		5: ["#fee5d9", "#fcae91", "#fb6a4a", "#de2d26", "#a50f15"],
		6: ["#fee5d9", "#fcbba1", "#fc9272", "#fb6a4a", "#de2d26", "#a50f15"],
		7: ["#fee5d9", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#99000d"],
		8: ["#fff5f0", "#fee0d2", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#99000d"],
		9: ["#fff5f0", "#fee0d2", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#a50f15", "#67000d"]
	},
	Greys: {
		3: ["#f0f0f0", "#bdbdbd", "#636363"],
		4: ["#f7f7f7", "#cccccc", "#969696", "#525252"],
		5: ["#f7f7f7", "#cccccc", "#969696", "#636363", "#252525"],
		6: ["#f7f7f7", "#d9d9d9", "#bdbdbd", "#969696", "#636363", "#252525"],
		7: ["#f7f7f7", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525"],
		8: ["#ffffff", "#f0f0f0", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525"],
		9: ["#ffffff", "#f0f0f0", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525", "#000000"]
	},
	PuOr: {
		3: ["#f1a340", "#f7f7f7", "#998ec3"],
		4: ["#e66101", "#fdb863", "#b2abd2", "#5e3c99"],
		5: ["#e66101", "#fdb863", "#f7f7f7", "#b2abd2", "#5e3c99"],
		6: ["#b35806", "#f1a340", "#fee0b6", "#d8daeb", "#998ec3", "#542788"],
		7: ["#b35806", "#f1a340", "#fee0b6", "#f7f7f7", "#d8daeb", "#998ec3", "#542788"],
		8: ["#b35806", "#e08214", "#fdb863", "#fee0b6", "#d8daeb", "#b2abd2", "#8073ac", "#542788"],
		9: ["#b35806", "#e08214", "#fdb863", "#fee0b6", "#f7f7f7", "#d8daeb", "#b2abd2", "#8073ac", "#542788"],
		10: ["#7f3b08", "#b35806", "#e08214", "#fdb863", "#fee0b6", "#d8daeb", "#b2abd2", "#8073ac", "#542788", "#2d004b"],
		11: ["#7f3b08", "#b35806", "#e08214", "#fdb863", "#fee0b6", "#f7f7f7", "#d8daeb", "#b2abd2", "#8073ac", "#542788",
			"#2d004b"
		]
	},
	BrBG: {
		3: ["#d8b365", "#f5f5f5", "#5ab4ac"],
		4: ["#a6611a", "#dfc27d", "#80cdc1", "#018571"],
		5: ["#a6611a", "#dfc27d", "#f5f5f5", "#80cdc1", "#018571"],
		6: ["#8c510a", "#d8b365", "#f6e8c3", "#c7eae5", "#5ab4ac", "#01665e"],
		7: ["#8c510a", "#d8b365", "#f6e8c3", "#f5f5f5", "#c7eae5", "#5ab4ac", "#01665e"],
		8: ["#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#c7eae5", "#80cdc1", "#35978f", "#01665e"],
		9: ["#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#f5f5f5", "#c7eae5", "#80cdc1", "#35978f", "#01665e"],
		10: ["#543005", "#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#c7eae5", "#80cdc1", "#35978f", "#01665e", "#003c30"],
		11: ["#543005", "#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#f5f5f5", "#c7eae5", "#80cdc1", "#35978f", "#01665e",
			"#003c30"
		]
	},
	PRGn: {
		3: ["#af8dc3", "#f7f7f7", "#7fbf7b"],
		4: ["#7b3294", "#c2a5cf", "#a6dba0", "#008837"],
		5: ["#7b3294", "#c2a5cf", "#f7f7f7", "#a6dba0", "#008837"],
		6: ["#762a83", "#af8dc3", "#e7d4e8", "#d9f0d3", "#7fbf7b", "#1b7837"],
		7: ["#762a83", "#af8dc3", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#7fbf7b", "#1b7837"],
		8: ["#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837"],
		9: ["#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837"],
		10: ["#40004b", "#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837", "#00441b"],
		11: ["#40004b", "#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837",
			"#00441b"
		]
	},
	PiYG: {
		3: ["#e9a3c9", "#f7f7f7", "#a1d76a"],
		4: ["#d01c8b", "#f1b6da", "#b8e186", "#4dac26"],
		5: ["#d01c8b", "#f1b6da", "#f7f7f7", "#b8e186", "#4dac26"],
		6: ["#c51b7d", "#e9a3c9", "#fde0ef", "#e6f5d0", "#a1d76a", "#4d9221"],
		7: ["#c51b7d", "#e9a3c9", "#fde0ef", "#f7f7f7", "#e6f5d0", "#a1d76a", "#4d9221"],
		8: ["#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221"],
		9: ["#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#f7f7f7", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221"],
		10: ["#8e0152", "#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221", "#276419"],
		11: ["#8e0152", "#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#f7f7f7", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221",
			"#276419"
		]
	},
	RdBu: {
		3: ["#ef8a62", "#f7f7f7", "#67a9cf"],
		4: ["#ca0020", "#f4a582", "#92c5de", "#0571b0"],
		5: ["#ca0020", "#f4a582", "#f7f7f7", "#92c5de", "#0571b0"],
		6: ["#b2182b", "#ef8a62", "#fddbc7", "#d1e5f0", "#67a9cf", "#2166ac"],
		7: ["#b2182b", "#ef8a62", "#fddbc7", "#f7f7f7", "#d1e5f0", "#67a9cf", "#2166ac"],
		8: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac"],
		9: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#f7f7f7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac"],
		10: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac", "#053061"],
		11: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#f7f7f7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac",
			"#053061"
		]
	},
	RdGy: {
		3: ["#ef8a62", "#ffffff", "#999999"],
		4: ["#ca0020", "#f4a582", "#bababa", "#404040"],
		5: ["#ca0020", "#f4a582", "#ffffff", "#bababa", "#404040"],
		6: ["#b2182b", "#ef8a62", "#fddbc7", "#e0e0e0", "#999999", "#4d4d4d"],
		7: ["#b2182b", "#ef8a62", "#fddbc7", "#ffffff", "#e0e0e0", "#999999", "#4d4d4d"],
		8: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#e0e0e0", "#bababa", "#878787", "#4d4d4d"],
		9: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#ffffff", "#e0e0e0", "#bababa", "#878787", "#4d4d4d"],
		10: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#e0e0e0", "#bababa", "#878787", "#4d4d4d", "#1a1a1a"],
		11: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#ffffff", "#e0e0e0", "#bababa", "#878787", "#4d4d4d",
			"#1a1a1a"
		]
	},
	RdYlBu: {
		3: ["#fc8d59", "#ffffbf", "#91bfdb"],
		4: ["#d7191c", "#fdae61", "#abd9e9", "#2c7bb6"],
		5: ["#d7191c", "#fdae61", "#ffffbf", "#abd9e9", "#2c7bb6"],
		6: ["#d73027", "#fc8d59", "#fee090", "#e0f3f8", "#91bfdb", "#4575b4"],
		7: ["#d73027", "#fc8d59", "#fee090", "#ffffbf", "#e0f3f8", "#91bfdb", "#4575b4"],
		8: ["#d73027", "#f46d43", "#fdae61", "#fee090", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4"],
		9: ["#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4"],
		10: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695"],
		11: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4",
			"#313695"
		]
	},
	Spectral: {
		3: ["#fc8d59", "#ffffbf", "#99d594"],
		4: ["#d7191c", "#fdae61", "#abdda4", "#2b83ba"],
		5: ["#d7191c", "#fdae61", "#ffffbf", "#abdda4", "#2b83ba"],
		6: ["#d53e4f", "#fc8d59", "#fee08b", "#e6f598", "#99d594", "#3288bd"],
		7: ["#d53e4f", "#fc8d59", "#fee08b", "#ffffbf", "#e6f598", "#99d594", "#3288bd"],
		8: ["#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#e6f598", "#abdda4", "#66c2a5", "#3288bd"],
		9: ["#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#e6f598", "#abdda4", "#66c2a5", "#3288bd"],
		10: ["#9e0142", "#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#e6f598", "#abdda4", "#66c2a5", "#3288bd", "#5e4fa2"],
		11: ["#9e0142", "#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#e6f598", "#abdda4", "#66c2a5", "#3288bd",
			"#5e4fa2"
		]
	},
	RdYlGn: {
		3: ["#fc8d59", "#ffffbf", "#91cf60"],
		4: ["#d7191c", "#fdae61", "#a6d96a", "#1a9641"],
		5: ["#d7191c", "#fdae61", "#ffffbf", "#a6d96a", "#1a9641"],
		6: ["#d73027", "#fc8d59", "#fee08b", "#d9ef8b", "#91cf60", "#1a9850"],
		7: ["#d73027", "#fc8d59", "#fee08b", "#ffffbf", "#d9ef8b", "#91cf60", "#1a9850"],
		8: ["#d73027", "#f46d43", "#fdae61", "#fee08b", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850"],
		9: ["#d73027", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850"],
		10: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee08b", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850", "#006837"],
		11: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850",
			"#006837"
		]
	},
	Accent: {
		3: ["#7fc97f", "#beaed4", "#fdc086"],
		4: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99"],
		5: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0"],
		6: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f"],
		7: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f", "#bf5b17"],
		8: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f", "#bf5b17", "#666666"]
	},
	Dark2: {
		3: ["#1b9e77", "#d95f02", "#7570b3"],
		4: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a"],
		5: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e"],
		6: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02"],
		7: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02", "#a6761d"],
		8: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02", "#a6761d", "#666666"]
	},
	Paired: {
		3: ["#a6cee3", "#1f78b4", "#b2df8a"],
		4: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c"],
		5: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99"],
		6: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c"],
		7: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f"],
		8: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00"],
		9: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6"],
		10: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a"],
		11: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a",
			"#ffff99"
		],
		12: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a",
			"#ffff99", "#b15928"
		]
	},
	Pastel1: {
		3: ["#fbb4ae", "#b3cde3", "#ccebc5"],
		4: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4"],
		5: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6"],
		6: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc"],
		7: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd"],
		8: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd", "#fddaec"],
		9: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd", "#fddaec", "#f2f2f2"]
	},
	Pastel2: {
		3: ["#b3e2cd", "#fdcdac", "#cbd5e8"],
		4: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4"],
		5: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9"],
		6: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae"],
		7: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae", "#f1e2cc"],
		8: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae", "#f1e2cc", "#cccccc"]
	},
	Set1: {
		3: ["#e41a1c", "#377eb8", "#4daf4a"],
		4: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3"],
		5: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00"],
		6: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33"],
		7: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628"],
		8: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628", "#f781bf"],
		9: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628", "#f781bf", "#999999"]
	},
	Set2: {
		3: ["#66c2a5", "#fc8d62", "#8da0cb"],
		4: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3"],
		5: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854"],
		6: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f"],
		7: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f", "#e5c494"],
		8: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f", "#e5c494", "#b3b3b3"]
	},
	Set3: {
		3: ["#8dd3c7", "#ffffb3", "#bebada"],
		4: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072"],
		5: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3"],
		6: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462"],
		7: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69"],
		8: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5"],
		9: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9"],
		10: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd"],
		11: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd",
			"#ccebc5"
		],
		12: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd",
			"#ccebc5", "#ffed6f"
		]
	}
};

task.add('refresh', 3, {
	fuc: function() {
		topo.reload();
	}
}, 0);
