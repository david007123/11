function panalog_ajax(url, data, callback)
{
	$.ajax({
		url: url,
		data: data,
		type:'post',
		dataType: 'json',
		success:function(json) {
			cluster_load_hide();

			if (data.bexport == 0)
				callback(json);
			else
				cluster_downloadfile("");
		}
	})
}

function unixtimetodate(tm)
{
	var dt = new Date();
	dt.setTime(tm * 1000);

	return dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate()+'/'+dt.getHours()+':'+dt.getMinutes()+':'+dt.getSeconds();
}

function IsDigit(str)
{
	var i;

	if (str == "")
		return false;

	i = 0
	if (str.charAt(0) == '-')
		i = 1

	for (; i < str.length; i++) {
		if (str.charAt(i) < '0' || str.charAt(i) > '9')
			return false;
	}

	return true;
}

function IsChar(str)
{
	if (str == "")
		return false;

	for (i = 0; i < str.length; i++) {
		if (str.charCodeAt(i) >= 255)
			return false;
        }

	return true;
}

function IsDigitIn(str, min, max)
{
	var i;

	if (!IsDigit(str))
		return false;

	if (str >= min && str <= max)
		return true;

	return false;
}

function IsEngString(str)
{
	var i;

	if (str == "")
		return false;

	for (i = 0; i < str.length; i++) {
		if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z' ||
		    str.charAt(i) >= 'A' && str.charAt(i) <= 'Z' ||
		    str.charAt(i) >= '0' && str.charAt(i) <= '9') {
			continue;
		}
		else {
			return false;
		}
	}

	return true;
}

function IsIPAddr(str)
{
	var i;
	var ar = [];

	ar = str.split(".");
	if (ar.length != 4)
		return false;

	for (i = 0; i < ar.length; i++) {
		if (ar[i] == "") return false;
		if (isNaN(ar[i])) return false;
		if (ar[i] >= 0 && ar[i] <= 255)
			return true;
	}

	return false;
}

function IsMacAddr(str)
{
	var ar;

	ar = str.split(":");
	if (ar.length != 6)
		return false;

	return true;
}

function IP2Int(str)
{
	var ar;
	var ipval;

	ar = str.split(".");
	ipval = ar[0] * 16777216 + ar[1] * 65536 +
		ar[2] * 256 + ar[3];

	return ipval;
}

function IsValidatePort(str)
{
	var ar;

	ar = str.split("-");

	if (ar.length == 1) {
		if (IsDigitIn(ar[0], 1, 65535))
			return true;
	}

	if (ar.length == 2) {
		if (!IsDigitIn(ar[0], 1, 65535))
			return false;
		if (!IsDigitIn(ar[1], 1, 65535))
			return false;
		if (ar[0] > ar[1])
			return false;

		return true;
	}

	return false;
}

function IsNet(str)
{
	var ar;

	ar = str.split("/");
	if (ar.length != 2) return false;
	if (!IsIPAddr(ar[0])) return false;
	if (!IsDigitIn(ar[1], 1, 32)) return false;

	return true;
}

function IsMAC(str)
{
	var ar;

	ar = str.split(":");
	if (ar.length != 6)
		return false;

	for (i = 0; i < ar.length; i++) {
		if (ar[i].length != 1 && ar[i].length != 2)
			return false;

		for (j = 0; j < ar[i].length; j++) {
			var ch = ar[i].charAt(j);

			if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F')))
				return false;
		}
	}

	return true;
}

function IsNetmask(str)
{
	if (!IsIPAddr(str))
		return false;

	var n = str.split(".");
	i = 0;
	while (i < 4) {
		if (n[i] == 255)
			i++;
		else break;
	}

	if (i == 4)
		return true;

	if ((n[i] % 2) != 0)
		return false;

	for (j = i + 1; j < 4; j++) {
		if (n[j] != 0)
			return false;
	}

	return true;
}

function TrimAll(str)
{
	var s="";

	for (i = 0; i < str.length; i++) {
		if (str.charAt(i) != ' ') {
			s = s + str.charAt(i);
		}
	}

	return s;
}

function EnableIt(obj, enable)
{
	if (enable) {
		obj.readonly = false;
		obj.style.backgroundColor = 0xffffff;
	}
	else {
		obj.readonly = true;
		obj.style.backgroundColor = 0xd0d0d0;
	}
}

function ShowDialog(url, args, width, height)
{
	var attr = "dialogWidth:" + width + "px;" +
	           "dialogHeight:" + height + "px;" +
		"edge:raised;status:no;scroll:no;help:no";
	return showModalDialog(url, args, attr);
}

function ShowWindow(url, args, width, height)
{
	if (height == 0)
		height = window.screen.height - 150;

	var left = (window.screen.width - width) / 2;
	var top  = (window.screen.height - height) / 2;

	if (args == "")
		args = "scrollbars=1,toolbar=0,menubar=0,status=0,location=0";
	else
		args += ",location=0";

	args += ",top=" + top + ",left=" + left + ",height=" + height + ",width=" + width;
	window.open(url, "_blank", args);
}

function ShowPage(page)
{
	document.all(page).style.display = "block";
}

function HidePage(page)
{
	document.all(page).style.display = "none";
}

function OnCancel()
{
	window.close();
}

function OnValidateIP(obj, allowEmpty)
{
        obj.value = TrimAll(obj.value);

        if (obj.value == "" && allowEmpty ||
            obj.value != "" && IsIPAddr(obj.value))
        {
                return true;
        }

        return false;
}

function OnValidateMask(obj, allowEmpty)
{
        obj.value = TrimAll(obj.value);

        if (obj.value == "" && allowEmpty ||
            obj.value != "" && IsNetmask(obj.value))
        {
                return true;
        }

        return false;
}

function IsName(str)
{
	var i;

	if (str == "")
		return false;

	for (i = 0; i < str.length; i++) {
		if (str.charAt(i) == '&' || str.charAt(i) == ',' ||
		    str.charAt(i) == ';' || str.charAt(i) == '?' ||
		    str.charAt(i) == '+' || str.charAt(i) == '=' ||
		    str.charAt(i) == '$' || str.charAt(i) == '%' ||
		    str.charAt(i) == '*' || str.charAt(i) == '!' ||
		    str.charAt(i) == '~') {
			return false;
		}
	}

	return true;
}

function standardtop()
{	
	$.get("../isstandard.php", function(json){
		if (json == "0")
		{
			$("#keyinfo-topimg").html('<a href="javascript:freelicense();void(0);" style="color:#f00;font-weight:bold;text-decoration:none;">免费版</a>');
		}
	});
}

function load_top_html(type)
{
	$("#tophtml").load("../top.php?css="+type, function(){
		setInterval(function(){var s = datecon(); $("#dtime").html(s)}, 60000);
	});
}

var left_bl = 0;
function sh_left()
{
	if (! left_bl){
		$('div.left-div').hide(500);
		left_bl = 1;
		$('#sl-btn').css('background-position', '-12px 0');
	}else if(parseInt(left_bl)){
		$('div#left-div').show(500);
		$('#sl-btn').css('background-position', '0 0');
		left_bl = 0;
	}

}

function numberformats(num)
{
	if (num >= 1000 * 1000 * 1000 * 1000)
		return Math.round(parseFloat(num/1000/1000/1000/1000)*100)/100+'T';
	else if (num >= 1000 * 1000 * 1000)
		return Math.round(parseFloat(num/1000/1000/1000)*100)/100+'G';
	else if (num >= 1000 * 1000)
		return Math.round(parseFloat(num/1000/1000)*100)/100+'M';
	else if (num >= 1000)
		return Math.round(parseFloat(num/1000)*100)/100+'K';
	else return Math.round(num*100)/100;
}

function numformats(num)
{
    if (num >= 1000 * 1000 * 1000)
        return Math.round(parseFloat(num/1000/1000/1000)*100)/100+'G';
    else if (num >= 1000 * 1000)
        return Math.round(parseFloat(num/1000/1000)*100)/100+'M';
    else if (num >= 1000)
        return Math.round(parseFloat(num/1000)*100)/100+'K';
    else return Math.round(num*100)/100;
}

function getnumberper(num)
{
	if (num >= 1000 * 1000 * 1000)
		return 'G';
	else if (num >= 1000 * 1000)
		return 'M';
	else if (num >= 1000)
		return 'K';
	else return 'B';
}

function set_tdcolor(id)
{
	var tbtb = document.getElementById(id).getElementsByTagName('tr');
	for (var i = 0; i < tbtb.length; i++){
		if (i % 2 == 0)
			tbtb[i].className = 'add-bak';
	}
}
function validate()
{
	var start, end;
	start = $('#startip').val();
	end = $('#endip').val();

	if (start != '' && !IsIPAddr(start)){
		$('#startip')[0].select();
		return false;
	}
	if (end != '' && !IsIPAddr(end)){
		$('#endip')[0].select();
		return false;
	}
	return true;
}

function filltime(hours)
{
    if (!hours)
        hours = 1;
    var h = "";
    var dt = new Date();
    var dt2 = dt - hours * 3600 * 1000;
    dt2 = new Date(dt2);

    var days = 30;
    var curyear = dt.getFullYear();
    var curmonth = dt.getMonth()+1;
    var curdate = dt.getDate();
    var curhour = dt.getHours();
    var curminute = dt.getMinutes();
    var curyear2 = dt2.getFullYear();
    var curmonth2 = dt2.getMonth()+1;
    var curdate2 = dt2.getDate();
    var curhour2 = dt2.getHours();
    var curminute2 = dt2.getMinutes();

    switch(curmonth)
    {
        case 1: days = 31;
            break;
        case 2: days = 29;
            break;
        case 3: days = 31;
            break;
        case 4: days = 30;
            break;
        case 5: days = 31;
            break;
        case 6: days = 30;
            break;
        case 7: days = 31;
            break;
        case 8: days = 31;
            break;
        case 9: days = 30;
            break;
        case 10: days = 31;
            break;
        case 11: days = 30;
            break;
        case 12: days = 31;
            break;
    }

    for (var i = 2010; i <= 2020; i++)
    {
        h = "<option value='"+i+"'>"+i+"</option>";
        $(h).appendTo("#startyear");
        $(h).appendTo("#endyear");
    }

    for (var i = 1; i <= 12; i++)
    {
        h = "<option value='"+i+"'>"+i+"</option>";
        $(h).appendTo("#startmonth");
        $(h).appendTo("#endmonth");
    }

    for (var i = 1; i <= days; i++)
    {
        h = "<option value='"+i+"'>"+i+"</option>";
        $(h).appendTo("#startdate");
        $(h).appendTo("#enddate");
    }

    for (var i = 0; i <= 23; i++)
    {
        h = "<option value='"+i+"'>"+i+"</option>";
        $(h).appendTo("#starthour");
        $(h).appendTo("#endhour");
    }

    for (var i = 0; i <= 59; i++)
    {
        h = "<option value='"+i+"'>"+i+"</option>";
        $(h).appendTo("#startminute");
        $(h).appendTo("#endminute");
    }

    for (var i = 0; i <= 59; i++)
    {
        h = "<option value='"+i+"'>"+i+"</option>";
        $(h).appendTo("#startsec");
        $(h).appendTo("#endsec");
    }

    $("#startyear").val(curyear2);
    $("#startmonth").val(curmonth2);
    $("#startdate").val(curdate2);
    $("#starthour").val(curhour2);
    $("#startminute").val(curminute2);

    $("#endyear").val(curyear);
    $("#endmonth").val(curmonth);
    $("#enddate").val(curdate);
    $("#endhour").val(curhour);
    $("#endminute").val(curminute);

    /********************************************/
    $("#startmonth").change(function(){
        var monstart = $(this).val();
        $("#startdate").html('');

        switch(parseInt(monstart)){
            case 1: days = 31;
                break;
            case 2: days = 29;
                break;
            case 3: days = 31;
                break;
            case 4: days = 30;
                break;
            case 5: days = 31;
                break;
            case 6: days = 30;
                break;
            case 7: days = 31;
                break;
            case 8: days = 31;
                break;
            case 9: days = 30;
                break;
            case 10: days = 31;
                break;
            case 11: days = 30;
                break;
            case 12: days = 31;
                break;
        }
        for (var i = 1; i <= days; i++){
            h = "<option value='"+i+"'>"+i+"</option>";
            $(h).appendTo("#startdate");
            //$(h).appendTo("#enddate");
        }
    });

    $("#endmonth").change(function(){
        var monend = $(this).val();
        $("#enddate").html('');

        switch(parseInt(monend)){
            case 1: days = 31;
                break;
            case 2: days = 29;
                break;
            case 3: days = 31;
                break;
            case 4: days = 30;
                break;
            case 5: days = 31;
                break;
            case 6: days = 30;
                break;
            case 7: days = 31;
                break;
            case 8: days = 31;
                break;
            case 9: days = 30;
                break;
            case 10: days = 31;
                break;
            case 11: days = 30;
                break;
            case 12: days = 31;
                break;
        }
        for (var i = 1; i <= days; i++){
            h = "<option value='"+i+"'>"+i+"</option>";
            $(h).appendTo("#enddate");
        }
    });
}

function bind_bottom_cls(id)
{
    var i, o;
    var len = $("#"+id+" .blank_gr").children('div').length;

    for (i = 0; i < len; i++){
        o = $("#"+id+" .blank_gr").children('div').eq(i);
        if (o.attr("id") == "exit")
            continue;
        o.mouseover(function(){$(this).addClass('big-button-mouse-over')});
        o.mouseout(function(){$(this).removeClass('big-button-mouse-over')});
        o.click(function(){
            for (i = 0; i < len; i++){
                o = $("#"+id+" .blank_gr").children('div').eq(i);
                if (o.hasClass("big-button-mouse-click")) {
                    o.removeClass("big-button-mouse-click");
                    o.addClass("big-button");
                }
            }
            $(this).addClass('big-button-mouse-click');
        });
    }
}
function small_bt_over()
{
	$('td.popup-bar-right').mouseover(function(){
		$(this).addClass('small-button-mouseover');
	});
	$('td.popup-bar-right').mouseout(function(){
		$(this).removeClass('small-button-mouseover');
	});
	
	$(".big-button-mouse-click").mousedown(function(){
		$(this).addClass("big-button-mousedown");	
	});
	$(".big-button-mouse-click").mouseup(function(){
		$(this).removeClass("big-button-mousedown");	
	});

	$('#exit').mouseover(function(){
		$(this).addClass('exits-over');
	})
	$('.exit').mouseout(function(){
		$(this).removeClass('exits-over');
	});
	
	$('.confirm').mouseover(function(){
		$(this).addClass('confirm-mouseover');
	})
	
	$('.confirm').mouseout(function(){
		$(this).removeClass('confirm-mouseover');
	});
}

function setWinpos(id, w, h, conid)
{
	var top = 0;
	var outer_h = 0;
	var width= document.body.clientWidth;
	var height = document.body.clientHeight;

	var body_h = $(window).height();

	if (body_h > h)
		outer_h = h;
	else outer_h = body_h;

	top = (body_h - outer_h)/2 + $(document).scrollTop();

	$('#'+id).css('position', 'absolute');
	$('#'+id).css('left', ((width-w-177)/2) +'px');
	$('#'+id).css('top', top +'px');

	$('#'+id).css('width', w+'px');
	$('#'+id).css('height', outer_h+'px');

	$('#'+conid).css('border', '2px solid #3AA4D4');
	$('#'+conid).css('border-bottom', 'none');
	
	$('#'+conid).css("background", "fff");
	$('#'+conid).css('width', (w-4)+'px!important;');
		
	$('#'+conid).css('height', (outer_h-25-30)+'px');
	$('#'+conid).css('background', '#fff');
	$('#'+conid).css('overflow-y', 'auto');
	$('#'+conid).css('overflow-x', 'hidden');
	$('#'+conid).css('text-align', 'left');

	$('#'+id+' .blank_gr').css('width', (w-4)+'px!important;');
	$('#'+id+' .blank_gr').css('height', '30px');
	
	$('#'+id).css('display', 'block');

    $("#"+id+" .popup-bar-right-close").click(function(){
        $("#"+id).remove();
    });
    $("#"+id).find("#exit").click(function(){
        $("#"+id).remove();
    });

    $('.bridge-head').mousedown(function(){$(this).parent().css('z-index', config.zindex++);});

    $("#"+id).draggable({cursor:'move',handle:'div.bridge-head,div.blank_gr',stop:function(){
        if (parseInt($(this).css("top")) < 0) $(this).css("top", 0);
    }});

    small_bt_over();
    bind_bottom_cls(id);
}

function popwindow_tips(tips)
{
	if ($(".popwindow-tips"))
		$(".popwindow-tips").remove();
		
	$("<div class='popwindow-tips'>"+tips+"</div>").appendTo("body");
	$(".popwindow-tips").css('left', ($(window).width()-240)/2 + 'px');
	$(".popwindow-tips").css('top', ($(window).height()-55)/2+$(document).scrollTop() + 'px');
	$(".popwindow-tips").css('z-index', 100000);
	$(".popwindow-tips").fadeIn('slow');
	setTimeout(function(){$(".popwindow-tips").fadeOut('slow');}, 2000);
}

function setlang(zh)
{
	$.get("../config.php", {lang:zh}, function(json){
		location.reload();
	})
}

function sethostname()
{
	$.get("../Maintain/sysname.php?type=0", function(json){
		var md;
		eval("md="+json);
		document.title = md.sysname;
	});
}

function logout()
{
	$.get("../logout.php", function(json){
		parent.location.href = "../index.php";
	});
}

function datecon()
{
	var d, day, x, s = "";
	var ds, mon, h, mi;
	
	var x = new Array("星期日", "星期一", "星期二");
	var x = x.concat("星期三","星期四", "星期五");
	var x = x.concat("星期六");
	
	d = new Date();
	day = d.getDay();

	if (d.getDate() < 10)
		ds = "0" + d.getDate();
	else ds = d.getDate();
	
	if ((d.getMonth()+1) < 10)
		mon = "0" + (d.getMonth()+1);
	else mon = (d.getMonth()+1);
	
	if (d.getHours() < 10)
		h = "0" + d.getHours();
	else h = d.getHours();
	
	if (d.getMinutes() < 10)
		mi = "0" + d.getMinutes();
	else mi = d.getMinutes();

	s += d.getFullYear() +'-'+ mon + '-'+ ds + ' ' + h + ':' + mi + ' ' + x[day];
	
	return s;
}

function closewin(id)
{
	$('#'+id).remove();
}

function killprocess(filename)
{
	$.getJSON("../kill.php", {file:filename}, function(json){
		popwindow_tips(json.str);
	});
}

function createrightbox()
{
	var mon, dat, hours, minute, second;
	
	$.get("../sysinfo.php", function(data){
		if (data == "" || data == null) 
			return false;
			
		var htl = "<div id='rightbox-d'>";
		htl += "<div id='rightbox-head'>";
		htl += "<div style='float:left;vertical-align:middle;line-height:25px;'><img src='../img/73.png' style='margin:5px 5px 0 0;' /></div>";
		htl += "<div style='float:left;vertical-align:middle;line-height:25px;font-family:微软雅黑,arial'>系统提示</div>";
		htl += "<div style='float:right'><a href='javascript:closerightbox();void(0)'>"+
			"<img src='../img/icon-closeC.png' border='0' title='关闭' style='margin:5px 5px 0 0;'></a></div>";
		htl += "</div>";
		htl += "<div id='rightbox-con'></div>";
		htl += "</div>";
	
		$(htl).appendTo("body");
		
		$('#rightbox-d').draggable({cursor:'move',handle:'div.rightbox-head'});

		var sys = data.split(';');
		var dt = new Date();
		
		if ((dt.getMonth()+1) < 10)
			mon = '0'+(dt.getMonth()+1);
		else mon = (dt.getMonth()+1);
		if (dt.getDate() < 10)
			dat = '0'+dt.getDate();
		else dat = dt.getDate();
		if (dt.getHours() < 10)
			hours = '0'+dt.getHours();
		else hours = dt.getHours();
		if (dt.getMinutes() < 10)
			minute = '0'+dt.getMinutes();
		else minute = dt.getMinutes();
		if (dt.getSeconds() < 10)
			second = '0'+dt.getSeconds();
		else second = dt.getSeconds();
		
		var fullyear = dt.getFullYear()+'/'+mon+'/'+dat+' '+hours+':'+minute+':'+second;
		
		var tbcon = "<table style='width:100%;height:100px;'>";
		tbcon += "<tr><td width='10px'></td><td align='left'>"+sys[0]+"</td></tr>";
		tbcon += "<tr><td width='10px'></td><td align='left'>"+sys[1]+"</td></tr>";
		tbcon += "<tr><td width='10px'></td><td align='left'>"+sys[2]+"</td></tr>";
		tbcon += "<tr><td width='10px'></td><td align='left'>本地时间："+fullyear+"</td></tr>";
		tbcon += "</table>";
		
		$("#rightbox-con").html(tbcon);
	});
}

function closerightbox()
{
	$("#rightbox-d").hide();
}

function kill_logeye()
{
    $.ajax({
        url:'../kill.php',
        success:function(data){
            clearInterval(intervalid);
        }
    });
}

/* 集群环境下查询进度条 */
function cluster_load_show()
{
	var height = $(window).height();
	var width = $(window).width();
	
	if (parent.window.parent.window.frames.length > 1)
		left = (width - 300) / 2 - 100;
	else
		left = (width - 300) / 2;
	
	$(".cluster_load_show").remove();
	
	var css = 'style="position:fixed; border: none; border-radius:5px;';
	css += 'width:320px; top: 150px; left:'+left+'px; font-size:12px;';
	css += 'background:#157f6c; padding: 5px 0; color:#eee; z-index:200000000"';
	
	str = '<div class="load-panel"></div>';
	str += '<div '+css+' class="ui-widget">'+
			'<div class="cluster_load_show" style="position:relative;width:300px; margin:0 auto;"></div>'+
		'</div>';
	
	$(str).appendTo("body");
	
	/* top.php */
	if (parent.window.parent.window.frames.length > 1)
		if (typeof(eval("parent.window.parent.window.frames[0].loadshow")) == "function")
			parent.window.parent.window.frames[0].loadshow();
	/* menu.php */
	if (parent.window.parent.window.frames.length > 1) {
		if (typeof(eval("parent.window.parent.window.frames[1].loadshow")) == "function")
			parent.window.parent.window.frames[1].loadshow();
	}
}

function cluster_load_hide()
{
	$(".cluster_load_show").parent().remove();
	$(".load-panel").remove();
	
	/* top.php */
	if (parent.window.parent.window.frames.length > 1)
		if (typeof(eval("parent.window.parent.window.frames[0].loadhide")) == "function")
			parent.window.parent.window.frames[0].loadhide();
	/* menu.php */
	if (parent.window.parent.window.frames.length > 1) {
		if (typeof(eval("parent.window.parent.window.frames[1].loadhide")) == "function")
			parent.window.parent.window.frames[1].loadhide();
	}
}

function return_masterstr(per, usetime, errname)
{
	var s = '<label class="cluster-label">主服务 (<span id="cluster-usetime">'+usetime+'s</span>)';
	s += '&nbsp;<a style="color:#fff" href="javascript:node_cancel(\'master\', \''+errname+'\')">停止</a></label>';
	s += '<div class="cluster-outer">'+
		'<div class="cluster-cont1"></div>'+
		'<div class="master-1 cluster-master-1" style="width:'+per+'%;"></div>'+
		'<div class="master-2 cluster-master-2">'+per+'%</div>'+
		'</div>';
	return s;
}

function return_nodestr(uuid, per, recnum, errname)
{
	$("#cluster-usetime").html(usetime+'s');

	var v = '<label style="margin-top:5px; display:block;">节点 '+uuid;
	v += '&nbsp;<a style="color:#fff" href="javascript:node_cancel(\''+uuid+'\', \''+errname+'\')">停止</a>';
	v += '</label>';
	v += '<div style="width:300px;margin-top:5px; color:#000; height:20px;">'+
		'<div style="position:absolute; height:20px; width:300px; background:#fff;"></div>'+
		'<div class="'+uuid+'-1 cluster-master-1" style="width:'+per+'%;"></div>'+
		'<div class="'+uuid+'-2 cluster-master-2">'+per+'% / '+recnum+'</div>'+
	'</div>';

	return v;
}

var intervalid;
var ntimes = 0;
var usetime = 0;
function cluster_get_status(errname)
{
	var val = 0;
	
	$.ajax({
		url:'../cluster_error.php',
		data:{type:"errcret", errname:errname},
		type:'post',
		dataType:'json',
		success:function(json) {
		}
	});

	usetime = 0;
	var s = return_masterstr(0, usetime, errname);

	if ($(".master-1").length == 0) {
		$(".cluster_load_show").html("");
		$(s).appendTo(".cluster_load_show");
	}
	
	ntimes = 0;

	if (intervalid) clearInterval(intervalid);

	intervalid = setInterval(function(){
		usetime++;

		$.ajax({
			url:'../cluster_error.php',
			data:{errname:errname},
			type:'post',
			dataType:'json',
			success:function(json) {
				if (json.rows && json.rows.length != 0) {
					v = '';
					m = 0;
					for (i = 0; i < json.rows.length; i++) {
						r = json.rows[i];
						per = 0;
						if (r.total != 0)
							per = parseInt((r.curr / r.total) * 100);
						
						if (r.uuid == "master") {
							m = 1;
							if ($("."+r.uuid+"-1").length == 0) {
								v += return_masterstr(per, usetime, errname);
							} else {
								$("."+r.uuid+"-1").css("width", per+'%');
								$("."+r.uuid+"-2").text(per+'%');
								$("#cluster-usetime").html(parseInt(usetime / 2) +'s');
							}
						}
					}

					if (m == 0 && $(".master-1").length == 0)
						v += s;

					for (i = 0; i < json.rows.length; i++) {
						r = json.rows[i];
						per = 0;
						if (r.total != 0)
							per = parseInt((r.curr / r.total) * 100);
						if (r.uuid != "" && r.uuid != "master") {
							if ($("."+r.uuid+"-1").length == 0) {
								v += return_nodestr(r.uuid, per, r.recnum, errname);
							}
							else {
								$("."+r.uuid+"-1").css("width", per+'%');
								$("."+r.uuid+"-2").text(per+'% / '+r.recnum);
								$("#cluster-usetime").html(parseInt(usetime / 2) +'s');
							}
						}
					}

					if (v != "")
						$(v).appendTo(".cluster_load_show");
				}
				else {
					if (json.yn && json.yn == "rename")
						return;
					if (++ntimes >= 5)
						clearInterval(intervalid);
				}
			}
		});
	}, 500);
	
	return intervalid;
}

/* 集群取消查询 */
function node_cancel(uuid, errname)
{
	$.ajax({
		url:'../node_cancel.php',
		data:{uuid: uuid, errname: errname},
		type:'post',
		dataType:'json',
		success:function(json) {
			if (uuid == "master") {
				alert("停止所有节点查询任务！");
				clearInterval(intervalid);
				cluster_load_hide();
			}
			else
				alert("停止节点 "+uuid+" 查询任务！");
		}
	});
}

function downloadfile(masterip, nodeip, filename)
{
	if (masterip == nodeip) {
		window.open("../download.php?filename="+filename, "_blank");
		return false;
	}
	
	$.ajax({
		url:'../fetchfile.php',
		type:'post',
		data: {type:'downloadfile', nodeip: nodeip, filename: filename},
		dataType:'json',
		success:function(json) {
			window.open("../download.php?filename="+filename, "_blank");
		}
	})
}

function delefile(masterip, nodeip, filename)
{
	if (masterip == nodeip) {
		window.open("../delefile.php?filename="+filename, "_blank");
		
		$.ajax({
			url:"../delefile.php?filename="+filename,
			dataType:'json',
			success:function(json) {
			}
		})
		
		return false;
	}
	
	$.ajax({
		url:'../fetchfile.php',
		type:'post',
		data: {type:'delefile', nodeip: nodeip, filename: filename},
		dataType:'json',
		success:function(json) {
		}
	})
}

function hisfile_delete()
{
	if (!confirm("确定要删除所有历史文件吗"))
		return false;

	$.ajax({
		url:'../fetchfile.php',
		type:'post',
		data: {type:'deleteallfile'},
		dataType:'json',
		success:function(json) {
		}
	})
}

function cluster_tmpfile_list()
{
	var host = window.location.host;
	var port = 4816;
	
	var dt = new Date();
	var month = dt.getMonth() + 1;
	month = month < 10 ? "0"+month : month;
	mdate = dt.getDate();
	mdate = mdate < 10 ? "0"+mdate : mdate;
	var tday = dt.getFullYear()+''+month + mdate;

	$.ajax({
		url:'../cluster_filelist.php',
		type:'post',
		dataType:'json',
		success:function(json) {
			if (json.yn && json.yn == "no")
				alert(json.str);
			else {
				s = '<table style="width:100%;">';
				s += '<tr><td colspan=3 style="font-size:12px; font-weight:bold; color:#000; padding:10px 0;">今日文件&nbsp;&nbsp;'+
					'<a style="color:#00f" href="javascript:hisfile_delete()">删除所有历史文件</a>';
				s += '</td></tr>';
				s += '<tr><td>文件名称</td>';
				s += '<td>来源</td>';
				s += '<td>文件大小</td>';
				s += '<td>创建时间</td>';
				s += '<td>操作</td></tr>';
				for (i = 0; i < json.rows.length; i++) {
					r = json.rows[i];
					if (r.ipaddr != "") 
						host = r.ipaddr;
					
					if ((r.fname).indexOf(tday) != -1) {
						s += '<tr>';
						s += '<td style="padding:3px 0; border-bottom:1px solid #ddd;">';
						s += r.fname;
						s += '</td>';
						s += '<td style="padding:3px 0;border-bottom:1px solid #ddd;">'+r.nodeip+'</td>';
						s += '<td style="padding:3px 0;border-bottom:1px solid #ddd;">'+r.fsize+'</td>';
						s += '<td style="padding:3px 0;border-bottom:1px solid #ddd;">'+r.ctimestr+'</td>';
						s += '<td style="padding:3px 0;border-bottom:1px solid #ddd;">'+
							'<a href="javascript:downloadfile(\''+r.masterip+'\', \''+r.nodeip+'\', \''+r.fname+'\')">&nbsp;下载</a>';
						s += '<a href="javascript:delefile(\''+r.masterip+'\', \''+r.nodeip+'\', \''+r.fname+'\')">&nbsp;删除</a>';
						s += '</td></tr>';
					}
				}
				s += '<tr><td colspan=3 style="font-size:12px; font-weight:bold; color:#000; padding:10px 0;">历史文件';
				s += '</td></tr>';
				for (i = 0; i < json.rows.length; i++) {
					r = json.rows[i];
					if (r.ipaddr != "") host = r.ipaddr;
					
					if ((r.fname).indexOf(tday) == -1) {
						s += '<tr>';
						s += '<td style="padding:3px 0; border-bottom:1px solid #ddd;">';
						s += r.fname;
						s += '</td>';
						s += '<td style="padding: 3px 0;border-bottom:1px solid #ddd;">'+r.nodeip+'</td>';
						s += '<td style="padding: 3px 0;border-bottom:1px solid #ddd;">'+r.fsize+'</td>';
						s += '<td style="padding: 3px 0;border-bottom:1px solid #ddd;">'+
							'<a href="javascript:downloadfile(\''+r.masterip+'\', \''+r.nodeip+'\', \''+r.fname+'\')">&nbsp;下载</a>';
						s += '<a href="javascript:delefile(\''+r.masterip+'\', \''+r.nodeip+'\', \''+r.fname+'\')">&nbsp;删除</a>';
						s += '</td></tr>';
					}
				}
				s += '</table>';
				$(".download-file-list").html(s);
			}
		}
	});
}

function dwfile_select()
{
	var files = '';
	var a = [];

	$("[name='dwfile']").each(function(){
		if ($(this).attr("checked"))
			a.push($(this).val());
	});

	if (a.length > 0)
		files = a.join(',');
}

var _downfilelist;
function cluster_downloadfile(filename)
{
	var host = window.location.host;
	var port = 4816;
		
	if ($(".download-file-list").length > 0)
		$(".download-file-list").remove();
	var s = '<div class="download-file-list" title="下载列表"></div>';
	$(s).appendTo("body");
	
	$(".download-file-list").dialog({
		width:800,
		height:$(window).height() - 100
	});

	cluster_tmpfile_list();

	/*
	 if (_downfilelist)
		clearInterval(_downfilelist);	
	_downfilelist = setInterval(cluster_tmpfile_list, 2000);
	*/
}

function cluster_file_del(host, port, filename)
{
	window.open("http://"+host+":"+port+"/download.php?filename="+filename+"&type=del", "_blank");
	
	$(".download-file-list").html("");
	cluster_tmpfile_list();
}

function load_show()
{
	var height = $(window).height();
	var width = $(window).width();
	var w = 400;
	var h = 26;
	var left = (width - w - 177)/2;
	var top = (height - h - 60)/2;
	
	var left2 = left + 190;
	var top2 = top+3;
	var left3 = left + 380;
	var top3 = top+5;

	$("<div class='load-panel-value' style='position:absolute;left:"+left2+
		"px;top:"+top2+"px;width:30px;z-index:105;color:#94B73E;z-index:10002'>0%</div>"+
		"<div class='load-panel-close' style='position:absolute;left:"+left3+
		"px;top:"+top3+"px;width:30px;z-index:105;color:#94B73E;z-index:10003;'>"+
		"<a href='javascript:proexit()'><img src='../img/b_drop.png' /></a></div>"+
        "<div class='load-panel-inner' style='position:absolute;left:"+left+"px;top:"+top+"px;width:"+w+"px;"+
        "text-align:center;color:#fff;border:1px solid #666;z-index:10001'></div>").appendTo("body");
}

function load_hide()
{
	$(".load-panel-inner").remove();
	$(".load-panel-value").remove();
	$(".load-panel-close").remove();
}

function retstr_getnum(str)
{
	var s = str.split(' ');
	
	var pos = parseInt(s[1]);
	var total = parseInt(s[3]);
	
	return parseFloat(((pos / total) * 100).toFixed(2));
}

var _logeye_pid = 0;
var _errfilename = '';
function getpid(str)
{
	var s = str.split(' ');
	
	_logeye_pid = parseInt(s[5]);
	
	return _logeye_pid;
}

function proexit()
{
	$.ajax({
		url:'../kill.php',
		data:{pid:_logeye_pid, errfile: _errfilename},
		type:'post',
		success:function(json) {
			load_hide();
		}
	});
}

function get_status(errname)
{
	var val = 0;
	
	$( ".load-panel-inner" ).progressbar({
	  value: val
	});
	
	/* 提前创建滚动条文件 */
	$.ajax({
		url:'../error.php',
		data:{type:"errcret", errname:errname},
		type:'post',
		dataType:'json',
		success:function(json) {
		}
	});
	
	var intervalid;
						
	intervalid=setInterval(function(){
        $.ajax({
            url:'../error.php',
            data:{errname:errname},
            type:'post',
            dataType:'json',
            success:function(json){
                if (json.yn == "yes"){
                    if (json.str != "") {
						val = retstr_getnum(json.str);
						getpid(json.str);
						_errfilename = errname;
						
						$( ".load-panel-inner" ).progressbar({
						  value: val
						});
						$( ".load-panel-value" ).html(val+'%');
					}
                }
		else if (json.yn == "no") {
                    clearInterval(intervalid);
                }
            }
        });
    }, 500);
	
	return intervalid;
}

var z_index = 9000;
function rp_showbox(width, height, rp_id)
{
    var s = '';

    var id = "report_pop_box_"+rp_id;
    var title_id = "report_pop_box_title_"+rp_id;
    var content_id = "report_pop_box_content_"+rp_id;

    s = '<div class = "report-pop-box" id="'+id+'">';
	s += '<div style="position:absolute;right:10px;top:5px;"><a href="javascript:rp_windowclose(\''+id+'\')"><img src="../img/b_drop.png" /></a></div>';
    s += '<div class="report-pop-box-title" id="'+title_id+'"></div>';
    s += '<div class="report-pop-box-content" id="'+content_id+'"></div>';
    s += '<div class="report-pop-box-foot">';
    s += '<div class="foot-ok foot_ok_'+rp_id+'"><img src="../img/ok.png"/></div>';
    s += '<div class="foot-cancel"><a href="javascript:rp_windowclose(\''+id+'\');void(0);" title="关闭窗口"><img src="../img/cancel.png"/></a></div>';
    s += '</div>';
    s += '</div>';

    $(s).appendTo("body");

    var aw = $(window).width();
    var ah = $(window).height();
	
	if (height > ah) height = ah - 50;

    var l = (aw - width) / 2 - 150;
    var t = (ah - height) / 2 + $(document).scrollTop();

    $("#"+id).css("top", t+'px');
    $("#"+id).css("left", l+'px');
    $("#"+id).css("width", width+"px");
    $("#"+id).css("height", height+"px");
    $("#"+id).css("z-index", z_index++);
    $("#"+content_id).css("height", (height-100)+"px");
    $("#"+content_id).html('');

    $("#"+id).show();

    $("#"+id).draggable({handle:"#"+title_id, delay:0 });

    $("#"+title_id).click(function(){
        $(this).parents("#"+id).css('z-index', ++z_index);
    });
}

function cloud_logout()
{
	$.ajax({
		url:'../logout.php',
		data:{type:'cloud_logout'},
		type:'post',
		dataType:'json',
		success:function(json) {
			location.href="/cloud/index.php"
		}
	});
}

// 窗口关闭
function rp_windowclose(pid)
{
    $("#"+pid).remove();
}

function gotohttps()
{
	$.ajax({
		url: '../httpcheck.php',
		dataType:'json',
		type:'post',
		data:{type:'check'},
		success:function(data){
			if (data.yn == "no") {
				parent.location.href="https://"+data.str+"/index.php";
			}
		}
	});
}

var _ipdata_checked = 0;
function cpumem()
{
	$.ajax({
		url:'../cpu.php',
		data:{type:'cpu', ipdata_checked: _ipdata_checked},
		type:'post',
		dataType:'json',
		success:function(data) {
			_ipdata_checked = 1;
			$("#cpu").html(data.cpu+'% / '+data.ncpu+'核');
			$("#mem").html(data.mem+'% / '+parseInt(data.totalmem)+'G');
			$("#hard").html(data.hard+'% / '+data.hsize);

			if (data.totalmem < 4) {
				$("#showerror").show();
				var err = "重要提醒：系统当前最大内存为"+data.totalmem + 
					"G，与系统所需最小内存4G不相符，可能导致某些服务无法正常启动.为了不影响数据的正常性，请及时添加内存！";
				$("#showerror span").text(err);
			}
			if (data.ipdata && (data.ipdata).indexOf("UTF-8") != -1) {
				$("#showerror").show();
				var err = "重要提醒：系统地址库出现问题，当前地址库文件类型为："+data.ipdata+"，系统所需文件类型为：GB2312.";
				$("#showerror span").text(err);
			}
		}
	});
}

function getdevice()
{
	var devid = "";
	var arr = [];

	var user = $("#gol_user").val();
	var usertype = $("#gol_usertype").val();

	$('[name="device"]').each(function(){
		if ($(this).attr("checked"))
			arr.push($(this).val());
	})

	if (usertype == "hangxin" && arr.length == 0)
		return 0;

	if (user != "admin" && arr.length == 0) {
		$('[name="device"]').each(function(){
			arr.push($(this).val());
		})
	}

	if (arr.length == 0) {
		$('[name="device"]').each(function(){
			if ($(this).attr("checked"))
				arr.push($(this).val());
		})
	}
	
	if (arr.length == 0)
		devid = 0;
	else
		devid = arr.join(',');

	return devid;
}

function getdevname()
{
	var devname = "";
	var arr = [];

	$('[name="device"]').each(function(){
		if ($(this).attr("checked"))
			arr.push($(this).attr("cname"));
	})
	
	if (arr.length == 0)
		devname = "";
	else
		devname = arr.join(',');

	return devname;
}

function showerror(str)
{
	var s, w, h;

	w = $(window).width();
	h = $(window).height();

	var left = (w - 500) / 2 - 50;
	var toppx = (h - 40) / 2;

	if ($(".showerror").length <= 0) {
		s = '<div class="showerror" style="position:absolute; top:'+toppx+'px; left:'+left+'px; width:500px; height:20px; line-height:20px; text-align:center;'+
			'padding:5px 0; font-size:14px; display:none; z-index:100;">';
		s += '<img src="../img/73.png" style="margin-bottom:-3px;" />&nbsp;'+str;
		s += '</div>';
	}
	$(s).appendTo("body");
	$(".showerror").slideDown("slow");
	setTimeout(function(){
		$(".showerror").slideUp("slow");
	}, 3000);
}

function checkaxptable()
{
	$.ajax({
		url:'../checkapp.php',
		data:{type:'checkapp'},
		type:'post',
		dataType:'json',
		success:function(data){
			if (data.yn == "no")
				showerror(data.str);
		}
	});
}

function updateequalcount(count)
{
	if (count != 0) {
		$(".showequalcount").removeClass("show-expire-background1");
		$(".showequalcount").addClass("show-expire-background2");
	}else {
		$(".showequalcount").removeClass("show-expire-background2");
		$(".showequalcount").addClass("show-expire-background1");
	}
	$(".showequalcount").text(count);
}

function getexpirelen(devtype)
{
	var grpid = 0;
	var sch = "";
	
	$.ajax({
		url:'system_handle.php',
		data:{type:'cloud_devstat', grpid: grpid, devtype: devtype},
		dataType:'json',
		type:'post',
		success:function(data) {
			if (devtype == "panabit")
				$(".device-expire").html(data.exp);
			else
			if (devtype == "ixcache")
				$(".ixcache-expire").html(data.exp);

			if (devtype == "panabit")
				updateequalcount(data.equalcount);
		}
	});
}

function cloud_tips_show()
{
	var w = $(window).width();
	var h = $(window).height();
	
	var left = (w - 100) / 2;
	var top = (h - 100) / 2;
	
	$('<div id="tips1" class="cloud-tips1">正在连接...</div>').appendTo("body");
	$("#tips1").css("left", left+"px");
	$("#tips1").css("top", top+"px");
	
	$("#tips1").show();
}

function open_remote(serialno, webenable, sshenable, callback)
{
	var index = layer.load(0, {
		shade: 0
	});

	$.ajax({
		url: 'api.php?r=gateway@sshport_open',
		data: {
			serialno: serialno,
			webenable: webenable,
			sshenable: sshenable
		},
		dataType: 'json',
		type: 'post',
		success: function(d) {
			layer.close(index);
			if (ajax_resultCallBack(d) == false) {
				layer.msg(d.msg, {
					icon: 5
				});
				return;
			}

			if (typeof callback == 'function')
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {
				icon: 2
			});
		}
	});
}

function open_https(serialno, off)
{
	var host = window.document.location.protocol + '//' + window.document.location.hostname;

	// if (off){
	// 	layer.msg('此设备已断开，无法连接。');
	// 	return;
	// }
	open_remote(serialno, 1, 0, function(d) {
		var path = '/login/userverify.cgi?pakey=' + d.md5str + '&username=admin';
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(host + ":" + d.webport + path, "_blank");
				}
			});
		} else
			window.open(host + ":" + d.webport + path, "_blank");
	});
}

function cloud_tips_hide()
{
	$("#tips1").remove();
}

function opendevicelist()
{
	$(".device-list-outer").show();
	$(".device-list-outer-tohide").show();
	$(".device-list-outer-tohide").click(function(){
		$(".device-list-outer").hide();
		$(this).hide();
	});
}

var devicetrees;
function appenddevicetree(json)
{
	var data;
	var devid;
	var s, s2;

	devicetrees = new dTree('devicetrees');

	s = '所有设备 ';
	devicetrees.add(0, -1, s);

	for (var i = 0; i < json.rows.length; i++){
		r = json.rows[i];

		if (r.type == 1) {
			name = '<input type="checkbox" value="'+r.devid+'" name="device">'+r.devname;
			devicetrees.add(r.id, r.parent, name, "javascript:devselect("+r.devid+")");
		}else 
		if (r.type == 0)
			devicetrees.add(r.id, r.parent, r.devname);
	}

	var tree = devicetrees.toString();

	$(".devicetree").html("");
	$(".devicetree").html(tree);
	json.rows.length = 0;
}

function devselect(devid)
{
	$("[name='device']").each(function(){
		if ($(this).val() == devid)
			$(this).attr("checked", true);
	});
}

function showdevicetree()
{
	$.ajax({
		url:'../Maintain/devicetree.php',
		data:{type:"devicetreelist"},
		type:'post',
		dataType:'json',
		success:function(json) {
			if (json.yn && json.yn == "no")
				return;
			if (json.rows.length != 0)
				appenddevicetree(json);
		}
	});
}

function show_totalpage(totalrecord, page)
{
	$("#show_totalpage").text('共' + Math.ceil(totalrecord / page) + '页');
}

function set_content_height(render)
{
		var check_form_h = 35;
       	var pagebar_h = 26;
       	var spacing_h = 15;
       	var content_h = $(window).height() - $(".check-form").height() - check_form_h - pagebar_h - spacing_h;
       	$("#"+render).height(content_h);
}

function set_content_css(render, nav_w, pagebar_w)
{
	var w = $(window).width() - 22;
	var chk_h = $(".check-form").height();
	if (pagebar_w == 0) pagebar_w = 20;
	else pagebar_w = 40;
	if (nav_w) nav_w = 40;
       	var h = $(window).height() - chk_h - nav_w - pagebar_w;
	$(render).css("width", w + 'px');
	$(render).css("height", h + 'px');
}

function getcachefile()
{
	return "logeye_cache_" + ((new Date()).getTime() / 1000);
}

function layui_open(title, width, height, contid)
{
	var index = layer.open({
		type: 1,
		title: title,
		//shade: [0.8, '#393D49'],
		//shadeClose:1,
		shade: 0,
		area:[width, height],
		content: $("#"+contid)
	});

	return index;
}

function createtree()
{
	var data;
	var devid;

	trees = new dTree('trees');
	trees.add(0, -1, '选择协议');

	$.ajax({
		url:'../user_behavior/tree.php',
		type:'get',
		dataType:'json',
		success:function(data){
			for (var i = 0; i < data.result.length; i++){
				r = data.result[i];
				cname = decodeURIComponent(r.cname);
				trees.add(r.id, r.parent, r.cname, 
					"javascript:appselect("+r.id+", '"+r.name+"', '"+cname+"')");
			}

			trees.add(1500, 1044, "自定义协议组", "");
			for (var i = 0; i < data.cusgrp.length; i++) {
				r = data.cusgrp[i];
				cname = decodeURIComponent(r.cname);
				trees.add(r.id, r.parent, r.cname, 
						"javascript:appselect("+r.id+", '"+r.name+"', '"+cname+"')");
			}

			var tree = trees.toString();
			$("#treelist").html(tree);
			data.result.length = 0;
		}
	})
}

var config = {
    zindex:1000,
    curtab:'up',
    iptrendtab:'bpsup',
    trendiv:0,
    loadingstr: "<div style='margin:0 auto;padding-top:100px;'><img src='../img/upload.gif' /></div>",
    my_colors_def: ["#068BC5","#4EB133","#E6561C","#E6EB01","#24C8E3",
	    "#62E172","#F7EE64","#69F5C3","#ACDBFD","#C6C9CA", 
	    "#F68F67","#CDE577","#710000","#5D584B","#4572A7"]
}
