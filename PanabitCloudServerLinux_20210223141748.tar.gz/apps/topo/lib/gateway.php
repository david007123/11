<?php
namespace cloud\apps\topo\gateway;

// /usr/logdata/devops/opssvc/collection/gateway
define ('COLLECTION_DIR', OPSSVC_DIR . '/collection/gateway');
// define ('COLLECTION_DIR', '/usr/logd/www/Maintain/iwan/user');

function select($data)
{
	global $nidb, $user;
	
	$grpidstr = \cloud\apps\work\project\get_curr_work_groupstr(1);
	if($grpidstr === false)
		return false;

	$grpdir = '/usr/logd/www/Maintain/iwan/group';
	if(!is_dir(COLLECTION_DIR))
		return '[]';

	// 将用户管理的设备写到配置文件中
	$gfile = tempnam($grpdir, "group");
	if(($fd = fopen($gfile, "w")) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '创建用户组的临时文件失败。');
		return false;
	}
	
	$cmd = DATAEYE . " device list page=1 limit=2000 grpid=0";
	$cmd.= " usergrp={$grpidstr} sch=";
	$cmd.= " sortname=license_id12 sortdesc=asc";
	$cmd.= " expire=0";

	exec($cmd, $out, $ret);

	$curtm = time();
	foreach($out as $val) {
		$row = explode('|', $val);
		if ($row[0] == "ipaddr") 
			continue;
		if (count($row) < 3) 
			continue;

		// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
		$serialno	= to_utf8($row[4]);
		$istimeout	= (((int)$row[11] + 15) < $curtm ? 0 : 1);

		fwrite($fd, "{$serialno} $istimeout\n");
	}
	fclose($fd);
	$out = null;

	// 获取topo图数据
	$cmd = TOPO . ' -d ' . COLLECTION_DIR . ' 3 -f' . $gfile;

	exec($cmd, $out, $ret);
	unlink($gfile);
	if($ret) 
		set_errmsg(MSG_LEVEL_ARG, __function__, "code={$ret} fail: " . implode(' ', $out));
	else
	if(count($out) > 0)
		return $out[0];

	return '[]';
}

function read_ifcnt($serialno, $zone = "")
{
	$keys = array('name', 'mode', 'zone', 'status', 'driver', 'mac', 'type', 'bpsin', 'bpsout', 'ppsin', 'ppsout', 'bdgname', 'ifspeed', 'ifpeer', 'lagroup');
	$klen = count($keys);

	$dir = COLLECTION_DIR . "/{$serialno}";
	if(($fd = fopen("{$dir}/if.lst", "r")) == false)
		return 0;

	$count = 0;
	while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
		$volume = explode(' ', $line);
		if(count($volume) != $klen) continue;
		if($volume[0] == 'summary') continue;
		$result = array_combine($keys, $volume);
		
		if(empty($zone) == false && $zone != $result['zone'])
			continue;

		$count++;
	}
	fclose($fd);

/*
em0 0 outside up PANAOS 00-e2-69-03-c1-86 I211_COPPER 10.25K 34.92K 11 16 0 100M NULL 0
em1 0 outside up PANAOS 00-e2-69-03-c1-87 I211_COPPER 48 48 0 0 0 1000M NULL 0
em2 0 inside up PANAOS 00-e2-69-03-c1-88 I211_COPPER 39.77K 12.43K 16 8 0 1000M NULL 0
*/
	return $count;
}

function FormatiWANSvcResult($keys, $values)
{
	$result = array();
	
	$cnt = count($keys);
	$nameindex = $cnt - 1;
	
	foreach($values as $volume)
	{
		$volume = explode(' ', $volume);
		if($volume[0] != 'iwansvc') continue;

		$vc = count($volume);

		if($vc > $cnt) {
			for($i = $cnt; $i < $vc; $i++) {
				$volume[$cnt - 1] .= ' ' . $volume[$i];
			}
			$volume = array_slice($volume, 0, $cnt);
			// $volume[$cnt - 1] =  iconv("gbk", "utf-8//translit", $volume[$cnt - 1]);
		}
		else {
			for(;$vc < $cnt; $vc++)
				$volume[] = "";
		}

		array_push($result, array_combine($keys, $volume));
	}
	return $result;
}

function read_iwansvc($serialno)
{
	$dir = COLLECTION_DIR . "/{$serialno}";
	if(($fd = fopen($dir . '/iwansvc.lst', "r")) == false)
		return false;

	
	$data = array(
		"rows" => array(),
		"total" => 0
	);
	$result = array();
	while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
//		$line = iconv("gbk", "utf-8//translit", $line);
		array_push($result, preg_replace('/ +/', ' ', $line));
	}

	fclose($fd);

	if(count($result) <= 0) return $data;

	$keys = array('type', 'id', 'name', 'linkup', 'ifname', 'addr', 'vlan', 'mtu', 'service', 'dns0', 
				  'dns1', 'clntcnt', 'lastinbytes', 'lastoutbytes', 'inbps', 'outbps', 'poolid', 'poolname', 'maxclnt', 'auth',
				  'disabled', 'radsvrid', 'radsvrname');

	$ret = FormatiWANSvcResult($keys, $result);

	$iwanmap = array();
	if(($mfd = fopen($dir . '/iwanmap.lst', "r")) != false) {
		while(!feof($mfd)) {
			$line = str_replace("\n", '', fgets($mfd, 1024));
			if(empty($line)) continue;
			$pxy = explode(' ', $line);
			if(count($pxy) != 2) continue;
			$line = explode(':', $pxy[1]);
			if(count($line) != 2) continue;

			$pxy[0] 	= iconv("gbk", "utf-8//translit", $pxy[0]);
			$line[0] 	= iconv("gbk", "utf-8//translit", $line[0]);

			if(isset($iwanmap[$pxy[0]][$line[0]]))
				array_push($iwanmap[$pxy[0]][$line[0]], intval($line[1]));
			else
				$iwanmap[$pxy[0]] = array($line[0] => array(intval($line[1])));
		}
		fclose($mfd);
	}

	foreach($ret as $row) {
		if(isset($iwanmap[$row['name']]))
			$row['wan'] = $iwanmap[$row['name']];
		else
			$row['wan'] = array();

		$row['clntcnt'] = intval($row['clntcnt']);
		$row['linkup']  = intval($row['linkup']);
		$row['name'] 	= iconv("gbk", "utf-8//translit", $row['name']);
		$row['poolname']= iconv("gbk", "utf-8//translit", $row['poolname']);
		$row['radsvrname']= iconv("gbk", "utf-8//translit", $row['radsvrname']);
		$row['ifname']	= iconv("gbk", "utf-8//translit", $row['ifname']);
//		$data[$row['name']] = $row;
		array_push(
			$data['rows'],
			array(
				'name'		=> $row['name'],
				'addr'		=> $row['addr'],
				'ifname'	=> $row['ifname'],
				'auth'		=> $row['auth'],
				'mtu'		=> $row['mtu'],
				'dns'		=> array($row['dns0'], $row['dns1']),
				'clntcnt'	=> $row['clntcnt'],
				'disabled'	=>($row['disabled'] == 'enable'? 0: 1),
				'inbps'		=> $row['inbps'],
				'outbps'	=> $row['outbps'],
				'linkup'	=> $row['linkup'],
				'poolid'	=> intval($row['poolid']),
				'poolname'	=> $row['poolname'],
				'radsvrname'=> $row['radsvrname'],
				'wan'		=> $row['wan'],
		));
	}
	
	$data['total'] = count($data['rows']);
/*
addr: "10.30.0.1"
auth: "radius"
clntcnt: 135
disabled: "enable"
dns0: "114.114.114.114"
dns1: "8.8.8.8"
id: "4"
ifname: "pa4"
inbps: "9.20M"
lastinbytes: "23251533.77M"
lastoutbytes: "34343463.92M"
linkup: "1"
maxclnt: "0"
mtu: "1450"
name: "iWANGame"
outbps: "10.27M"
poolid: "2"
poolname: "GameCloud"
radsvrid: "1"
radsvrname: "RAAS"
service: "NULL"
type: "iwansvc"
vlan: "0"
*/
	return $data;
}

function info($data)
{
	global $nidb, $user;
	
	ni_app_load('gateway', 'devlist');
	// require_once(ROOT_DIR . "app/gateway/lib/devlist.php");

	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}
	$serialno = $data['serialno'];

	$dev = array(
		'page'		=> 1,
		'limit'		=> 1,
		'sort'		=> 'serialno',
		'g_ascdesc'	=> -1,
		'keyword'	=> $serialno,
		'expire'	=> 0
	);

	if(($result = \cloud\apps\gateway\devlist($dev)) === false)
		return false;

	if(count($result['rows']) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}

	$info = $result['rows'][0];
	$info['grpname'] = "";
	$info['ifcnt']	= 0;
	$info['pop'] = [];

	// 补充所属群组名称
	if($info['grpid'] != "" && $info['grpid'] != 0 && $info['grpid'] != 10000) {

		$sql = "select `grpid`, `grpname` from cloud_grp where `grpid` = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $info['grpid'], \PDO::PARAM_INT);
		$sth->execute();

		if(($data = $sth->fetch(\PDO::FETCH_ASSOC))) {
			$info['grpname'] = iconv("gbk", "utf-8//translit", $data['grpname']);
		}
	}
	else
	if($info['grpid'] == 10000) 
		$info['grpname'] = "空组";

	// 补充网络接口数
	if(($cnt = read_ifcnt($serialno)) !== false) 
		$info['ifcnt'] = $cnt;

	// 补充iwansvc数
	if(($data = read_iwansvc($serialno)) !== false) 
		$info['pop'] = $data;

	return $info;
}


function iwansvc_list($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	return read_iwansvc($data['serialno']);
}

function read_iwansvc_info($serialno, $name)
{
	if(empty($name) == true)
		return false;

	$dir = COLLECTION_DIR . "/{$serialno}";
	if(($fd = fopen($dir . '/iwansvc.lst', "r")) == false)
		return false;

	$result = array();
	while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
		$line = iconv("gbk", "utf-8//translit", $line);
		array_push($result, preg_replace('/ +/', ' ', $line));
	}

	fclose($fd);

	if(count($result) <= 0) return false;

	$keys = array('type', 'id', 'name', 'linkup', 'ifname', 'addr', 'vlan', 'mtu', 'service', 'dns0', 
				  'dns1', 'clntcnt', 'lastinbytes', 'lastoutbytes', 'inbps', 'outbps', 'poolid', 'poolname', 'maxclnt', 'auth',
				  'disabled', 'radsvrid', 'radsvrname');

	$ret = FormatiWANSvcResult($keys, $result);

	$iwanmap = array();
	if(($mfd = fopen($dir . '/iwanmap.lst', "r")) != false) {
		while(!feof($mfd)) {
			$line = str_replace("\n", '', fgets($mfd, 1024));
			if(empty($line)) continue;
			$line = iconv("gbk", "utf-8//translit", $line);
			$pxy = explode(' ', $line);
			if(count($pxy) != 2) continue;
			$line = explode(':', $pxy[1]);
			if(count($line) != 2) continue;

			//$pxy[0] 	= iconv("gbk", "utf-8//translit", $pxy[0]);
			//$line[0] 	= iconv("gbk", "utf-8//translit", $line[0]);

			if(isset($iwanmap[$pxy[0]][$line[0]]))
				array_push($iwanmap[$pxy[0]][$line[0]], intval($line[1]));
			else
				$iwanmap[$pxy[0]] = array($line[0] => array(intval($line[1])));
		}
		fclose($mfd);
	}

	foreach($ret as $row) {
		if($row['name'] != $name) continue;
		
		if(isset($iwanmap[$row['name']]))
			$row['wan'] = $iwanmap[$row['name']];
		else
			$row['wan'] = array();

		$row['clntcnt'] = intval($row['clntcnt']);
		$row['linkup']  = intval($row['linkup']);
//		$row['name'] 	= iconv("gbk", "utf-8//translit", $row['name']);
//		$data[$row['name']] = $row;

		return $row;
	}

	return false;
/*
addr: "10.30.0.1"
auth: "radius"
clntcnt: 135
disabled: "enable"
dns0: "114.114.114.114"
dns1: "8.8.8.8"
id: "4"
ifname: "pa4"
inbps: "9.20M"
lastinbytes: "23251533.77M"
lastoutbytes: "34343463.92M"
linkup: "1"
maxclnt: "0"
mtu: "1450"
name: "iWANGame"
outbps: "10.27M"
poolid: "2"
poolname: "GameCloud"
radsvrid: "1"
radsvrname: "RAAS"
service: "NULL"
type: "iwansvc"
vlan: "0"
*/
}

function iwansvc_info($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}
	
	if(isset($data['name']) == false
	|| empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "POP名称不能为空！");
		return false;
	}
	
	return read_iwansvc_info($data['serialno'], $data['name']);
}

function get_filename($path, $fliter)
{
	$ret = array();

	if ($dh = opendir($path)){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				if(empty($fliter) == false
				&& strpos($file, $fliter) === false)
					continue;
				//if (is_file($path . '/' . $file)) {
					array_push($ret, $file);
				//}
			}
		}
		closedir($dh);
	}

	return $ret;
}

function read_wan($serialno, $type, $name)
{
	$path = COLLECTION_DIR . "/{$serialno}/wan";
	$dnames = get_filename($path, ".dat");

	$data = array(
		"rows" => array(),
		"total" => 0
	);

	foreach($dnames as $file) {

		if(($fd = fopen($path . '/' . $file, "r")) == false)
			continue;

		$result = array();
		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$result[$volume[0]] = $volume[1];
		}
		fclose($fd);
		
		if(empty($type) == false && $type != $result['type'])
			continue;

		$result['name']			= iconv("gbk", "utf-8//translit", $result['name']);
		if(empty($name) == false && $name != $result['name']) 
			continue;

		$result['linkup']		= intval($result['linkup']);
		$result['disable']		= intval($result['disable']);
		$result['bandwidth']	= intval($result['bandwidth']);
		$result['proxyid']		= intval($result['proxyid']);
		$result['ifname']		= iconv("gbk", "utf-8//translit", $result['ifname']);
		
		if($result['type'] == 'iwan') {
			$result['peerip']	= $result['peerip'];
			$result['peerport']	= intval($result['peerport']);
		}
		else
		if($result['type'] == 'l2tpwan') {
			$result['peerip']	= $result['svraddr'];
			$result['peerport']	= intval($result['svrport']);
		}

//		$data[$result['name']] = $result;
		array_push($data['rows'], array(
			'name'		=> $result['name'],
			'ifname'	=> $result['ifname'],
			'proxyid'	=> $result['proxyid'],
			'type'		=> $result['type'],
			'addr'		=> $result['addr'],
			'disabled'	=> $result['disable'],
			'linkup'	=> $result['linkup'],
			'inbps'		=> $result['inbps'],
			'outbps'	=> $result['outbps'],
			'bandwidth'	=> $result['bandwidth'],
			'peerip'	=> $result['peerip'],
			'peerport'	=> $result['peerport']
		));
	}
	
	$data['total'] = count($data['rows']);
/*
addr: "121.201.18.57"
arpttl: "59"
bandwidth: "0"
bigpkts: "0"
clonemac: "00-00-00-00-00-00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "0"
dnsaddr: "223.5.5.5"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/43682997/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "121.201.18.1"
gatewayup: "1"
gottime: "0"
gwmac: "0c-da-41-12-ea-61"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-00"
ifname: "pa0"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "34.27K "
invping: "0"
lastdowntime: ""
linkid: "6"
linkup: "1"
macbase: "b0-98-b2-22"
maxping: "0"
maxping_ms: "0.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
name: "bgp"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "2122"
outbps: "7.89M "
outbytes: "26245.93G "
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
proxyid: "1"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
type: "proxy"
vlan: "1317"
vlan1: "0"
work: 1



addr: "0.0.0.0"
arpttl: "0"
bandwidth: "0"
bigpkts: "0"
cfgmtu: "1500"
clonemac: "00-00-00-00-00-00"
connect_time: ""
cur_delay: "0.00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "1"
dnsaddr: "0.0.0.0"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/0/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "0.0.0.0"
gatewayup: "0"
gottime: "0"
gwmac: "00-00-00-00-00-00"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-c0"
ifname: "fstel"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "0 "
interface_name: "pa3"
invping: "0"
iwansid: "0"
lastdial: "1970-01-01/08:00:00"
lastdowntime: ""
linkid: "18"
linkup: "0"
macbase: "b0-98-b2-22"
max_delay: "0.00"
maxping: "0"
maxping_ms: "0.00"
min_delay: "5000.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
myip: "0.0.0.0"
myport: "1036"
name: "iwanToCN2"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "1"
outbps: "0 "
outbytes: "0 "
peerip: "119.97.160.132"
peermtu: "0"
peerport: "8000"
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
pppoemtu: "1500"
proxyid: "13"
sdwan_dns0: "0.0.0.0"
sdwan_dns1: "0.0.0.0"
sdwan_gateway: "0.0.0.0"
sdwan_ip: "0.0.0.0"
sdwclnt_ltime: "1559609165"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
state: "ALLOC"
svraddr: "119.97.160.132"
svrport: "8000"
token: "0"
type: "iwan"
username: "iwantrans"
vlan: "0"
vlan1: "0"
work: 0
*/
	return $data;
}

function wan_list($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['type']))
		$type = trim($data['type']);
	else
		$type = "";

	if(isset($data['name']))
		$name = trim($data['name']);
	else
		$name = "";

	return read_wan($data['serialno'], $type, $name);
}

function read_waninfo($serialno, $pxyid)
{
	$file = COLLECTION_DIR . "/{$serialno}/wan/{$pxyid}.dat";
	if(file_exists($file)) {

		$data = array();
		if(($fd = fopen($file, "r")) == false)
			return false;

		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$line = iconv("gbk", "utf-8//translit", $line);
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$data[$volume[0]] = $volume[1];
		}
		fclose($fd);

		return $data;
	}

	return false;
/*
addr: "121.201.18.57"
arpttl: "59"
bandwidth: "0"
bigpkts: "0"
clonemac: "00-00-00-00-00-00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "0"
dnsaddr: "223.5.5.5"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/43682997/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "121.201.18.1"
gatewayup: "1"
gottime: "0"
gwmac: "0c-da-41-12-ea-61"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-00"
ifname: "pa0"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "34.27K "
invping: "0"
lastdowntime: ""
linkid: "6"
linkup: "1"
macbase: "b0-98-b2-22"
maxping: "0"
maxping_ms: "0.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
name: "bgp"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "2122"
outbps: "7.89M "
outbytes: "26245.93G "
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
proxyid: "1"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
type: "proxy"
vlan: "1317"
vlan1: "0"
work: 1



addr: "0.0.0.0"
arpttl: "0"
bandwidth: "0"
bigpkts: "0"
cfgmtu: "1500"
clonemac: "00-00-00-00-00-00"
connect_time: ""
cur_delay: "0.00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "1"
dnsaddr: "0.0.0.0"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/0/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "0.0.0.0"
gatewayup: "0"
gottime: "0"
gwmac: "00-00-00-00-00-00"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-c0"
ifname: "fstel"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "0 "
interface_name: "pa3"
invping: "0"
iwansid: "0"
lastdial: "1970-01-01/08:00:00"
lastdowntime: ""
linkid: "18"
linkup: "0"
macbase: "b0-98-b2-22"
max_delay: "0.00"
maxping: "0"
maxping_ms: "0.00"
min_delay: "5000.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
myip: "0.0.0.0"
myport: "1036"
name: "iwanToCN2"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "1"
outbps: "0 "
outbytes: "0 "
peerip: "119.97.160.132"
peermtu: "0"
peerport: "8000"
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
pppoemtu: "1500"
proxyid: "13"
sdwan_dns0: "0.0.0.0"
sdwan_dns1: "0.0.0.0"
sdwan_gateway: "0.0.0.0"
sdwan_ip: "0.0.0.0"
sdwclnt_ltime: "1559609165"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
state: "ALLOC"
svraddr: "119.97.160.132"
svrport: "8000"
token: "0"
type: "iwan"
username: "iwantrans"
vlan: "0"
vlan1: "0"
work: 0
*/
}

function wan_info($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['pxyid']) == false
	|| ($pxyid = intval($data['pxyid'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "线路ID不正确！");
		return false;
	}

	return read_waninfo($data['serialno'], $pxyid);
}

function read_if($serialno, $zone)
{
	$data = array(
		"rows" => array(),
		"total" => 0
	);

	$keys = array('name', 'mode', 'zone', 'status', 'driver', 'mac', 'type', 'bpsin', 'bpsout', 'ppsin', 'ppsout', 'bdgname', 'ifspeed', 'ifpeer', 'lagroup');
	$klen = count($keys);
	
	$dir = COLLECTION_DIR . "/{$serialno}";
	if(($fd = fopen($dir . '/if.lst', "r")) == false)
		return $data;

	while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
		$volume = explode(' ', $line);
		if(count($volume) != $klen) continue;
		if($volume[0] == 'summary') continue;
		$result = array_combine($keys, $volume);
		
		if(empty($zone) == false && $zone != $result['zone'])
			continue;

		$result['bdgname']	= iconv("gbk", "utf-8//translit", $result['bdgname']);
		$result['mode']		= intval($result['mode']);
		$result['ppsin']	= intval($result['ppsin']);
		$result['ppsout']	= intval($result['ppsout']);
		array_push($data['rows'], $result);
	}
	fclose($fd);

	$data['total'] = count($data['rows']);
/*
em0 0 outside up PANAOS 00-e2-69-03-c1-86 I211_COPPER 10.25K 34.92K 11 16 0 100M NULL 0
em1 0 outside up PANAOS 00-e2-69-03-c1-87 I211_COPPER 48 48 0 0 0 1000M NULL 0
em2 0 inside up PANAOS 00-e2-69-03-c1-88 I211_COPPER 39.77K 12.43K 16 8 0 1000M NULL 0
*/
	return $data;
}

function if_list($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['zone']))
		$zone = trim($data['zone']);
	else
		$zone = "";

	return read_if($data['serialno'], $zone);
}

function read_ifinfo($serialno, $name)
{
	$file = COLLECTION_DIR . "/{$serialno}/ncard/{$name}.dat";
	if(file_exists($file)) {

		$data = array();
		if(($fd = fopen($file, "r")) == false)
			return false;

		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$line = iconv("gbk", "utf-8//translit", $line);
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$data[$volume[0]] = $volume[1];
		}
		fclose($fd);

		return $data;
	}

	return false;
/*
addr: "121.201.18.57"
arpttl: "59"
bandwidth: "0"
bigpkts: "0"
clonemac: "00-00-00-00-00-00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "0"
dnsaddr: "223.5.5.5"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/43682997/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "121.201.18.1"
gatewayup: "1"
gottime: "0"
gwmac: "0c-da-41-12-ea-61"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-00"
ifname: "pa0"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "34.27K "
invping: "0"
lastdowntime: ""
linkid: "6"
linkup: "1"
macbase: "b0-98-b2-22"
maxping: "0"
maxping_ms: "0.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
name: "bgp"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "2122"
outbps: "7.89M "
outbytes: "26245.93G "
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
proxyid: "1"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
type: "proxy"
vlan: "1317"
vlan1: "0"
work: 1



addr: "0.0.0.0"
arpttl: "0"
bandwidth: "0"
bigpkts: "0"
cfgmtu: "1500"
clonemac: "00-00-00-00-00-00"
connect_time: ""
cur_delay: "0.00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "1"
dnsaddr: "0.0.0.0"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/0/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "0.0.0.0"
gatewayup: "0"
gottime: "0"
gwmac: "00-00-00-00-00-00"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-c0"
ifname: "fstel"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "0 "
interface_name: "pa3"
invping: "0"
iwansid: "0"
lastdial: "1970-01-01/08:00:00"
lastdowntime: ""
linkid: "18"
linkup: "0"
macbase: "b0-98-b2-22"
max_delay: "0.00"
maxping: "0"
maxping_ms: "0.00"
min_delay: "5000.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
myip: "0.0.0.0"
myport: "1036"
name: "iwanToCN2"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "1"
outbps: "0 "
outbytes: "0 "
peerip: "119.97.160.132"
peermtu: "0"
peerport: "8000"
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
pppoemtu: "1500"
proxyid: "13"
sdwan_dns0: "0.0.0.0"
sdwan_dns1: "0.0.0.0"
sdwan_gateway: "0.0.0.0"
sdwan_ip: "0.0.0.0"
sdwclnt_ltime: "1559609165"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
state: "ALLOC"
svraddr: "119.97.160.132"
svrport: "8000"
token: "0"
type: "iwan"
username: "iwantrans"
vlan: "0"
vlan1: "0"
work: 0
*/
}

function if_info($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}
	
	if(isset($data['name']) == false
	|| empty(($name = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "线路ID不正确！");
		return false;
	}

	return read_ifinfo($data['serialno'], $name);
}

function read_topapp($serialno, $pxyid)
{
	$file = COLLECTION_DIR . "/{$serialno}/wan/{$pxyid}.app";

	if(file_exists($file)) {

		$data = array(
			'rows' => array(),
			'total'=> 0
		);
		$keys = array('name', 'cname', 'bpsout', 'bpsin', 'bps');
		$klen = count($keys);
		
		if(($fd = fopen($file, "r")) == false)
			return false;

		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$line = iconv("gbk", "utf-8//translit", trim($line));
			$volume = explode(' ', $line);

			if(count($volume) == $klen)
				array_push($data['rows'], array_combine($keys, $volume));
		}
		fclose($fd);

		$data['total'] = count($data['rows']);
		return $data;
	}

	return false;
}

function wan_topapp($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['pxyid']) == false
	|| ($pxyid = intval($data['pxyid'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "线路ID不正确！");
		return false;
	}

	return read_topapp($data['serialno'], $pxyid);
}

function FormatResult($keys, $values)
{
	$result = array();
	
	$cnt = count($keys);
	$nameindex = $cnt - 1;
	
	foreach($values as $volume)
	{
		$volume = explode(' ', $volume);
		$vc = count($volume);

		if($vc > $cnt) {
			for($i = $cnt; $i < $vc; $i++) {
				$volume[$cnt - 1] .= ' ' . $volume[$i];
			}
			$volume = array_slice($volume, 0, $cnt);
		}
		else {
			for(;$vc < $cnt; $vc++)
				$volume[] = "";
		}
		
		$ret = array_combine($keys, $volume);
		$ret['pxyname'] =  iconv("gbk", "utf-8//translit", $ret['pxyname']);
		$ret['name'] =  iconv("gbk", "utf-8//translit", $ret['name']);
		array_push($result, $ret);
	}
	return $result;
}

function filterData($iwansvc, $data)
{
	$out = array();

	foreach($data as $key => $val) {
		if($val->pxyname == $iwansvc)
			array_push($out, $val);
	}

	return $out;
}

function cpe_list($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['name']) == false
	|| empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "POP名称不能为空！");
		return false;
	}
	
	$serialno= $data['serialno'];
	$iwansvc = $data['name'];

	$path = COLLECTION_DIR . "/{$serialno}";
	$jsonfile = $path . '/cpe.json';

	if(file_exists($jsonfile)) {
		$data = file_get_contents($jsonfile);
		if($iwansvc != "") 
			$data = filterData($iwansvc, json_decode($data));
		if($data == '')
			return array();
		return $data;
	}

	$file = $path . '/iwanuser.lst';
	if(($fd = fopen($file, "r")) == false) {
		return array();
	}

	$result = array();
    while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
		array_push($result, preg_replace('/ +/', ' ', $line));
    }
	fclose($fd);

	if(count($result) > 0) {
		$keys = array("pxyname", "id", "name", "token", "mtu",
					"ip", "gateway", "dns0", "dns1", "state",
					"myip", "myport", "peerip", "peerport", "inbps",
					"outbps", "flowcnt", "onlinetime", "leftime", "curdelay",
					"mindelay", "maxdelay");
	}

	$ret = FormatResult($keys, $result);
	$json = json_encode($ret);

	file_put_contents($jsonfile, $json);
	if(is_string($iwansvc) && ($iwansvc = trim($iwansvc)) != "")
		$ret = filterData($iwansvc, $ret);

	return $ret;
}

function read_wanip($dir)
{
	$path = $dir . '/wan';
	$dnames = get_filename($path, ".dat");

	$data = array();

	foreach($dnames as $file) {

		if(($fd = fopen($path . '/' . $file, "r")) == false)
			continue;

		$result = array();
		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$result[$volume[0]] = $volume[1];
		}
		fclose($fd);
		
		if($type == 'iwan' || $type == 'l2tpwan')
			continue;

		$result['name']	= iconv("gbk", "utf-8//translit", $result['name']);
		$data[$result['name']]	= $result['addr'];
	}

	return $data;
}

function read_iwansvcX($dir)
{
	$data = array();
	$iwanmap = array();
	if(($mfd = fopen($dir . '/iwanmap.lst', "r")) != false) {
		while(!feof($mfd)) {
			$line = str_replace("\n", '', fgets($mfd, 1024));
			if(empty($line)) continue;
			$pxy = explode(' ', $line);
			if(count($pxy) != 2) continue;
			$line = explode(':', $pxy[1]);
			if(count($line) != 2) continue;

			$pxy[0] 	= iconv("gbk", "utf-8//translit", $pxy[0]);
			$line[0] 	= iconv("gbk", "utf-8//translit", $line[0]);

			if(isset($iwanmap[$line[0]]))
				array_push($iwanmap[$line[0]], intval($line[1]));
			else
				$iwanmap[$line[0]] = array(intval($line[1]));
		}
		fclose($mfd);
	}
	
	$wanip = read_wanip($dir);
	foreach($iwanmap as $name => $ports) {
		if(isset($wanip[$name])) {
			foreach($ports as $port) {
				array_push($data, $wanip[$name] . '_' . $port);
			}
		}
	}
	
	return $data;
}

function read_pathwan($source, $target)
{
	$path = COLLECTION_DIR . "/{$source}/wan";
	$dnames = get_filename($path, "");

	$data = array(
		"rows" => array(),
		"total" => 0
	);

	$targetdir = COLLECTION_DIR . "/{$target}";
	$iwansvcip = read_iwansvcX($targetdir);
	foreach($dnames as $file) {

		if(($fd = fopen($path . '/' . $file, "r")) == false)
			continue;

		$result = array();
		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$result[$volume[0]] = $volume[1];
		}
		fclose($fd);

		if($result['type'] != 'iwan')
			continue;

		if(in_array($result['peerip'] . '_' . $result['peerport'], $iwansvcip) == false)
			continue;

		$result['linkup']		= intval($result['linkup']);
		$result['disable']		= intval($result['disable']);
		$result['bandwidth']	= intval($result['bandwidth']);
		$result['proxyid']		= intval($result['proxyid']);
		$result['name']			= iconv("gbk", "utf-8//translit", $result['name']);
		$result['ifname']		= iconv("gbk", "utf-8//translit", $result['ifname']);
		
		if($result['type'] == 'iwan') {
			$result['peerip']	= $result['peerip'];
			$result['peerport']	= intval($result['peerport']);
		}
		else
		if($result['type'] == 'l2tpwan') {
			$result['peerip']	= $result['svraddr'];
			$result['peerport']	= intval($result['svrport']);
		}

//		$data[$result['name']] = $result;
		array_push($data['rows'], array(
			'name'		=> $result['name'],
			'ifname'	=> $result['ifname'],
			'proxyid'	=> $result['proxyid'],
			'type'		=> $result['type'],
			'addr'		=> $result['addr'],
			'disabled'	=> $result['disable'],
			'linkup'	=> $result['linkup'],
			'inbps'		=> $result['inbps'],
			'outbps'	=> $result['outbps'],
			'bandwidth'	=> $result['bandwidth'],
			'peerip'	=> $result['peerip'],
			'peerport'	=> $result['peerport']
		));
	}
	
	$data['total'] = count($data['rows']);

	return $data;
/*
addr: "121.201.18.57"
arpttl: "59"
bandwidth: "0"
bigpkts: "0"
clonemac: "00-00-00-00-00-00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "0"
dnsaddr: "223.5.5.5"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/43682997/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "121.201.18.1"
gatewayup: "1"
gottime: "0"
gwmac: "0c-da-41-12-ea-61"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-00"
ifname: "pa0"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "34.27K "
invping: "0"
lastdowntime: ""
linkid: "6"
linkup: "1"
macbase: "b0-98-b2-22"
maxping: "0"
maxping_ms: "0.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
name: "bgp"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "2122"
outbps: "7.89M "
outbytes: "26245.93G "
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
proxyid: "1"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
type: "proxy"
vlan: "1317"
vlan1: "0"
work: 1



addr: "0.0.0.0"
arpttl: "0"
bandwidth: "0"
bigpkts: "0"
cfgmtu: "1500"
clonemac: "00-00-00-00-00-00"
connect_time: ""
cur_delay: "0.00"
curping: "0"
curping_ms: "0.00"
datattl: "0"
disable: "1"
dnsaddr: "0.0.0.0"
dnsokper: "0"
dnsreqs: "0"
dnstimeouts: "0"
drop_dummyif: "0"
drop_dummyvlan: "0"
drop_nullvlan: "0"
dummypkt_stat: "0/0/0/0[if/vlan/nullvlan/arp]"
dyniprate: "0"
flowcnt: "0"
gateway: "0.0.0.0"
gatewayup: "0"
gottime: "0"
gwmac: "00-00-00-00-00-00"
gwpxy: "0"
hbfail: "0"
ifmac: "b0-98-b2-22-00-c0"
ifname: "fstel"
ifstatus: "up"
ifup: "1"
inbps: "0 "
inbytes: "0 "
interface_name: "pa3"
invping: "0"
iwansid: "0"
lastdial: "1970-01-01/08:00:00"
lastdowntime: ""
linkid: "18"
linkup: "0"
macbase: "b0-98-b2-22"
max_delay: "0.00"
maxping: "0"
maxping_ms: "0.00"
min_delay: "5000.00"
minping: "2000000"
minping_ms: "0.00"
mtu: "1500"
myip: "0.0.0.0"
myport: "1036"
name: "iwanToCN2"
natip: "0.0.0.0"
natip_count: "0"
natip_deadcnt: "0"
nextipid: "1"
outbps: "0 "
outbytes: "0 "
peerip: "119.97.160.132"
peermtu: "0"
peerport: "8000"
ping_disable: "0"
pingip: "0.0.0.0"
pingip2: "0.0.0.0"
pppoemtu: "1500"
proxyid: "13"
sdwan_dns0: "0.0.0.0"
sdwan_dns1: "0.0.0.0"
sdwan_gateway: "0.0.0.0"
sdwan_ip: "0.0.0.0"
sdwclnt_ltime: "1559609165"
snatdrop: "0"
standby: "NULL"
standby_state: "0"
state: "ALLOC"
svraddr: "119.97.160.132"
svrport: "8000"
token: "0"
type: "iwan"
username: "iwantrans"
vlan: "0"
vlan1: "0"
work: 0
*/
}

function iwan_links($data)
{
	if(isset($data['source']) == false
	|| empty(($data['source'] = trim($data['source'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "源设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['source'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "源设备编号格式不正确！");
		return false;
	}
	if(isset($data['target']) == false
	|| empty(($data['target'] = trim($data['target'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "目标设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['target'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "目标设备编号格式不正确！");
		return false;
	}

	return read_pathwan($data['source'], $data['target']);
}

function read_ifX($dir)
{
	$data = array();

	$keys = array('name', 'mode', 'zone', 'status', 'driver', 'mac', 'type', 'bpsin', 'bpsout', 'ppsin', 'ppsout', 'bdgname', 'ifspeed', 'ifpeer', 'lagroup');
	$klen = count($keys);

	if(($fd = fopen($dir . '/if.lst', "r")) == false)
		return $data;

	while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
		$volume = explode(' ', $line);
		if(count($volume) != $klen) continue;
		if($volume[0] == 'summary') continue;
		$result = array_combine($keys, $volume);

//		$result['bdgname']	= iconv('GB2312', 'UTF-8', $result['bdgname']);
		$result['mode']		= intval($result['mode']);
		$result['zone']		= intval($result['zone']);
//		$result['ppsin']	= intval($result['ppsin']);
//		$result['ppsout']	= intval($result['ppsout']);
		$result['status']	= ($result['status'] == 'up' ? 1 : 0);

		$data[$result['name']] = array(
			'name'		=> $result['name'],
			'mode'		=> $result['mode'],
			'bpsin'		=> $result['bpsin'],
			'bpsout'	=> $result['bpsout'],
			'ifspeed'	=> $result['ifspeed'],
			'linkup'	=> $result['status'],
			'zone'		=> $result['zone']
		);
		
//		array_push($data, $result);
	}
	fclose($fd);
/*
em0 0 outside up PANAOS 00-e2-69-03-c1-86 I211_COPPER 10.25K 34.92K 11 16 0 100M NULL 0
em1 0 outside up PANAOS 00-e2-69-03-c1-87 I211_COPPER 48 48 0 0 0 1000M NULL 0
em2 0 inside up PANAOS 00-e2-69-03-c1-88 I211_COPPER 39.77K 12.43K 16 8 0 1000M NULL 0
*/
	return $data;
}

function read_target(&$data)
{
	$dir = COLLECTION_DIR . "/{$data['id']}";
//	$data['if'] = read_if($dir);
	$iflist = read_ifX($dir);
	if(($fd = fopen($dir . '/iwansvc.lst', "r")) == false)
		return false;

	$result = array();
	while(!feof($fd)) {
		$line = str_replace("\n", '', fgets($fd, 1024));
		if(empty($line)) continue;
		$line = iconv("gbk", "utf-8//translit", preg_replace('/ +/', ' ', $line));
		array_push($result, $line);
	}

	fclose($fd);

	if(count($result) < 1) return true;

	$keys = array('type', 'id', 'name', 'linkup', 'ifname', 'addr', 'vlan', 'mtu', 'service', 'dns0', 
				  'dns1', 'clntcnt', 'lastinbytes', 'lastoutbytes', 'inbps', 'outbps', 'poolid', 'poolname', 'maxclnt', 'auth',
				  'disabled', 'radsvrid', 'radsvrname');
	$kcnt = count($keys);

	$svc = array();
	foreach($result as $row)
	{
		$volume = explode(' ', $row);
		if($volume[0] != 'iwansvc') continue;

		$vc = count($volume);
		if($vc > $kcnt) {
			for($i = $kcnt; $i < $vc; $i++)
				$volume[$kcnt - 1] .= ' ' . $volume[$i];
		}
		else {
			for(;$vc < $kcnt; $vc++)
				$volume[] = "";
		}

		$target = array_combine($keys, $volume);
		$target['disabled'] = ($target['disabled']=='disable'?1:0);
		$target['linkup']	= intval($target['linkup']);

		$svc[$target['name']] = $target;
	}

	$hash = array();
	if(($mfd = fopen($dir . '/iwanmap.lst', "r")) != false) {
		while(!feof($mfd)) {
			$line = str_replace("\n", '', fgets($mfd, 1024));
			if(empty($line)) continue;
			$pxy = explode(' ', $line);
			if(count($pxy) != 2) continue;
			$line = explode(':', $pxy[1]);
			if(count($line) != 2) continue;

			$pxy[0] 	= iconv("gbk", "utf-8//translit", $pxy[0]);
			if(isset($svc[$pxy[0]]) == false)
				continue;

			$line[0] 	= iconv("gbk", "utf-8//translit", $line[0]);
			if(isset($svc[$pxy[0]]['wan'][$line[0]]))
				array_push($svc[$pxy[0]]['wan'][$line[0]]['port'], intval($line[1]));
			else
				$svc[$pxy[0]]['wan'][$line[0]] = array(
					'port'	=> array(intval($line[1]))
				);

			if(isset($hash[$line[0]]) == false)
				$hash[$line[0]] = array($pxy[0] => 1);
			else
				$hash[$line[0]][$pxy[0]]++;
		}
		fclose($mfd);
	}

	$path = $dir . '/wan';
	$dnames = get_filename($path, ".dat");
	$wanlist = array();
	foreach($dnames as $file) {

		if(($fd = fopen($path . '/' . $file, "r")) == false)
			continue;

		$result = array();
		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
			if(empty($line)) continue;
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$result[$volume[0]] = trim($volume[1]);
		}
		fclose($fd);
		
		if($result['type'] == 'iwan' || $result['type'] == 'l2tpwan')
			continue;

		$result['linkup']	= intval($result['linkup']);
		$result['disable']	= intval($result['disable']);
		$result['name']		= iconv("gbk", "utf-8//translit", $result['name']);
		$result['ifname']	= iconv("gbk", "utf-8//translit", $result['ifname']);

		if(isset($hash[$result['name']]) == false)
			continue;
		foreach($hash[$result['name']] as $sid => $cnt) {
			if(isset($svc[$sid]['wan'][$result['name']]) == false)
				continue;

			if(isset($wanlist[$result['name']]) == false) {
				
				$wanlist[$result['name']] = count($data['proxy']);
				array_push($data['proxy'], array(
					'name'		=> $result['name'],
					'ifname'	=> $result['ifname'],
					'linkup'	=> $result['linkup'],
					'disable'	=> $result['disable'],
					'usecnt'	=> 1,
					'bpsin'		=> $result['inbps'],
					'bpsout'	=> $result['outbps'],
					'ip'		=> $result['addr']
				));
				
				
			}
			else
				$data['proxy'][$wanlist[$result['name']]]['usecnt']++;

			$svc[$sid]['wan'][$result['name']]['id'] = $wanlist[$result['name']];
		}
	}

	$ifnames = array();
	foreach($svc as $name => $row) {

		// set ifs
		foreach($data['proxy'] as $id => &$wan) {
			if(gettype($wan['ifname']) == 'string') {
				if(isset($ifnames[$wan['ifname']]) == false) {
					$ifnames[$wan['ifname']] = count($data['ifs']);

					$ifn = $iflist[$wan['ifname']];
					$ifn['usecnt'] = 1;
					array_push($data['ifs'], $ifn);
				}
				else 
					$data['ifs'][$ifnames[$wan['ifname']]]['usecnt']++;
				$wan['ifname'] = $ifnames[$wan['ifname']];
			}
		}

		// set data
		array_push($data['data'], array(
			'name'		=> $name,
			'proxy'		=> $row['wan'],
			'bpsin'		=> $row['inbps'],
			'bpsout'	=> $row['outbps'],
			'disable'	=> $row['disabled'],
			'linkup'	=> $row['linkup'],
			'ip'		=> $row['addr'],
		));
	}

	return true;
}

function read_source(&$data)
{
	$path = COLLECTION_DIR . "/{$data['id']}/wan";
	$dnames = get_filename($path, ".dat");

	$iflist = read_ifX(COLLECTION_DIR . "/{$data['id']}");
	$wanlist = array();
	$iwans	 = array();
	foreach($dnames as $file) {

		if(($fd = fopen($path . '/' . $file, "r")) == false)
			continue;

		$result = array();
		while(!feof($fd)) {
			$line = str_replace("\n", '', fgets($fd, 1024));
//			$line = preg_replace('/ +/', ' ', $line);
			if(empty($line)) continue;
			$volume = explode('=', $line);
			if(count($volume) != 2) continue;
			$result[$volume[0]] = trim($volume[1]);
		}
		fclose($fd);
		
		$result['name']		= iconv("gbk", "utf-8//translit", $result['name']);
		if($result['type'] == 'iwan') {
			array_push($iwans, $result['name']);
		}

		$result['linkup']		= intval($result['linkup']);
		$result['peerport']		= intval($result['peerport']);
		$result['disable']		= intval($result['disable']);
//		$result['bandwidth']	= intval($result['bandwidth']);
//		$result['proxyid']		= intval($result['proxyid']);
		$result['ifname']	= iconv("gbk", "utf-8//translit", $result['ifname']);
		
		$wanlist[$result['name']] = array(
				'name'		=> $result['name'],
				'ifname'	=> $result['ifname'],
				'linkup'	=> $result['linkup'],
				'disable'	=> $result['disable'],
				'bpsin'		=> $result['inbps'],
				'bpsout'	=> $result['outbps'],
				'ip'		=> $result['addr'],
				'peerip'	=> $result['peerip'],
				'peerport'	=> $result['peerport']
		);

	}

	$ifnames = array();
	$proxy = array();
	foreach($iwans as $iwan) {

		if(isset($wanlist[$iwan]) == false) 
			continue;
		
		// set proxy
		$wan = $wanlist[$iwan];
		$pxy = $wan['ifname'];
		if(isset($proxy[$pxy]) == false) {
			
			if(isset($ifnames[$wanlist[$pxy]['ifname']]) == false) {
				$ifnames[$wanlist[$pxy]['ifname']] = count($data['ifs']);

				$ifn = $iflist[$wanlist[$pxy]['ifname']];
				$ifn['usecnt'] = 1;
				array_push($data['ifs'], $ifn);
			}
			else
				$data['ifs'][$ifnames[$wanlist[$pxy]['ifname']]]['usecnt']++;
			
			$proxy[$pxy] = count($data['proxy']);
			array_push($data['proxy'], array(
				'name'		=> $pxy,
				'ifname'	=> $ifnames[$wanlist[$pxy]['ifname']],
				'linkup'	=> $wanlist[$pxy]['linkup'],
				'disable'	=> $wanlist[$pxy]['disable'],
				'usecnt'	=> 1,
				'bpsin'		=> $wanlist[$pxy]['bpsin'],
				'bpsout'	=> $wanlist[$pxy]['bpsout'],
				'ip'		=> $wanlist[$pxy]['ip']
			));
		}
		else
			$data['proxy'][$proxy[$pxy]]['usecnt']++;

		// set data
		array_push($data['data'], array(
			'name'		=> $iwan,
			'proxy'		=> $proxy[$pxy],
			'bpsin'		=> $wan['bpsin'],
			'bpsout'	=> $wan['bpsout'],
			'disable'	=> $wan['disable'],
			'linkup'	=> $wan['linkup'],
			'ip'		=> $wan['ip'],
			'peerip'	=> $wan['peerip'],
			'peerport'	=> $wan['peerport']
		));
	}
}

function iwan_link_info($data)
{
	if(isset($data['source']) == false
	|| empty(($data['source'] = trim($data['source'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "源设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['source'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "源设备编号格式不正确！");
		return false;
	}
	if(isset($data['target']) == false
	|| empty(($data['target'] = trim($data['target'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "目标设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['target'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "目标设备编号格式不正确！");
		return false;
	}

	$ret = array(
		"source" => array(
			"id"	=> $data['source'],
			"ifs"	=> array(),
			"proxy"	=> array(),
			"data"	=> array()
		),
		"target" => array(
			"id"	=> $data['target'],
			"ifs"	=> array(),
			"proxy"	=> array(),
			"data"	=> array()
		)
	);

	read_source($ret['source']);
	read_target($ret['target']);

	return $ret;
}

function position($data)
{
	if(isset($data['serialno']) == false
	|| empty(($data['serialno'] = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号不能为空！");
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}
	$serialno = $data['serialno'];

	$config = "";
	$file = COLLECTION_DIR . "/{$serialno}/position.dat";
	if(isset($data['vx']))
		$config = "vx=" . floatval($data['vx']) . "\n";
	if(isset($data['vy']))
		$config .= "vy=" . floatval($data['vy']) . "\n";

	if($config == "")
		return unlink($file) ? 1 : false;
	else
		return file_put_contents($file, $config) === false ? false : 1;
}
