<?php
define ("ROOT_DIR", dirname(dirname(dirname(__DIR__))));
require_once(ROOT_DIR . '/conf/config.php');
require_once(ROOT_DIR . '/apps/user/lib/login.php');


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

// upgrade
$sql = "alter table palog.cloud_upgrade add upgrade_pro varchar(32) not null default ''";
$x = $nidb->query($sql);

$sql = "alter table palog.cloud_task add status int not null default '0', add upgrade_pro varchar(32) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_task add create_user varchar(32) not null default 'admin'";
$nidb->query($sql);

$sql = "alter table palog.cloud_users add logintime bigint(4) not null default '0'";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add grp varchar(512) not null default '0'";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add grpname varchar(512) not null default '0'";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add remarks varchar(512) not null default '0'";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add ixc_grpids varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add ixc_grpnames varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add log_grpids varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add log_grpnames varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add intool_grpids varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add intool_grpnames varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users modify ixc_grpids varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users modify ixc_grpnames varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users modify log_grpids varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users modify log_grpnames varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users modify intool_grpids varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users modify intool_grpnames varchar(512) not null default ''";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add loginip bigint(4) not null default '0'";
$nidb->query($sql);
$sql = "alter table palog.cloud_log add ipaddr varchar(16) not null default ''";
$nidb->query($sql);


// 2020-02-18
$sql = "alter table palog.cloud_users add column `mobile` varchar(16) not null default '' after `password`";
$nidb->query($sql);


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);  
