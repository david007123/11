// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

layui.use(['element', 'table', 'layer', 'form'], function() {
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var form = layui.form;
	var timer = new taskTimer();

	table.render({
		elem: '#userlist',
		even: true,
		loading: false,
		url: 'api.php?r=user@list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#userlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 35,
					fixed: 'left',
					type: 'numbers'
				},
				{
					field: 'username',
					title: '用户名',
					width: 110,
					templet: function(d) {
						return '<span class="setBtn" lay-event="passwd">' + d.username + '</span>';
					}
				},
				{
					field: 'mobile',
					title: '绑定手机号',
					width: 110,
					templet: function(d) {
						return '<span class="setBtn" lay-event="mobile">' + (d.mobile?d.mobile:"none") + '</span>';
					}
				}, {
					field: 'logintime',
					title: '登录时间',
					width: 130,
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.logintime, true);
					}
					
				}, {
					field: 'loginip',
					title: '登录地址',
					width: 105,
					templet: function(d) {
						return _int2iP(d.loginip);
					}
				},
				{
					field: 'grpname',
					title: '流控管理组',
				}, {
					field: 'ixc_grpnames',
					title: '缓存组',
				}, {
					field: 'log_grpnames',
					title: '日志组'
				}, {
					field: 'intool_grpnames',
					title: '内网访问组',
				}, {
					field: 'remarks',
					title: '备注',
					width: 160
				}, {
					title: '操作',
					width: 75,
					templet: function(d) {
						return '<span class="setBtn" lay-event="edit">编辑</span><span>&nbsp;|&nbsp;</span><span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});

	table.on('tool(userlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'passwd') {
			layer.open({
				type: 1,
				shadeClose: true,
				title: '修改密码 - ' + data.username,
				area: ['370px', '255px'],
				btnAlign: 'c',
				btn: ['确认', '取消'],
				content: $('#user-passwd').html(),
				success: function(layero, index) {
					form.render();
				},
				yes: function(index, layero) {
					var d = form.val('passwd');
					
					if(d.pass == '') {
						layer.msg('密码不能为空！', {icon: 5});
						return;
					}
					if(d.pass != d.repass) {
						layer.msg('两次密码不一致！', {icon: 5});
						return;
					}
					$.ajax({
						url: 'api.php?r=user@passwd',
						data: {
							user: data.username,
							pass: d.pass,
							oldpass: d.oldpass
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							search();
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
		}
		else
		if (event == 'edit') {
			layer.open({
				type: 1,
				shadeClose: true,
				title: '编辑用户组 - ' + data.username,
				area: ['620px', '500px'],
				btnAlign: 'c',
				btn: ['保存', '反选', '全选', '不选'],
				content: $('#user-group').html(),
				statistics: function(type, layero, index) {
					var e, tab = layero.find('[data-group="' + type + '"]');

					if(tab.length == 0) return;
					e = layero.find('.layui-tab-content > .layui-tab-item').eq(tab.index());
					tab.text(tab.attr('title') + '(' + e.find('input[type="checkbox"]:checked').length + ' / ' + e.find('input[type="checkbox"]').length + ')');
				},
				loadgrp: function(type, row, layero, index) {
					var e, data, tab = layero.find('[data-group="' + type + '"]');
					var col = {gateway: 'grp', ixcache: 'ixc_grpids', panalog: 'log_grpids', intranet: 'intool_grpids'};

					if(tab.length == 0) return;
					e = layero.find('.layui-tab-content > .layui-tab-item').eq(tab.index());
					e.children().remove();
					$.ajax({
						url: 'api.php?r=' + type + '@group',
						dataType: 'json',
						success: function(d) {
							var cnt, id, i, selected, data; 
							if (ajax_resultCallBack(d) === false) return;

							data = d.data.rows;
							if(data.length && data[0].grpid == 0)
								data = d.data.rows.splice(1);
							selected = data.length;
							cnt = parseInt(data.length / 2);
							
							if(type == 'intranet') {
								d.data.rows.forEach(function (data, i){
									d.data.rows[i].grpid = data.id;
									d.data.rows[i].grpname = data.name;
								});
							}

							for(i = 0; i < cnt; i++) {
								id = i * 2;
								e.append('<div class="layui-row layui-col-space10"><div class="layui-col-md6"><input type="checkbox" data-grpid="' + data[id].grpid + '" title="' + data[id].grpname + '" lay-skin="primary"></div><div class="layui-col-md6"><input type="checkbox" data-grpid="' + data[id+1].grpid + '" title="' + data[id+1].grpname + '" lay-skin="primary"></div></div>');
							}
							if(data.length % 2) {
								id = i * 2;
								e.append('<div class="layui-row layui-col-space10"><div class="layui-col-md6"><input type="checkbox" data-grpid="' + data[id].grpid + '" title="' + data[id].grpname + '" lay-skin="primary"></div></div>');
							}
							
							cnt = 0;
							data = row[col[type]];
							if(data) {
								data.split(',').forEach(function(grpid, i){
									e.find('input[data-grpid="' + grpid + '"]').prop('checked', true);
									cnt++;
								});
							}
							tab.text(tab.attr('title') + '(' + cnt + ' / ' + selected + ')');
							form.render('checkbox');
						}
					});
				},
				success: function(layero, index) {
					var h, that = this;

					layero.find('input[name="remarks"]').val(data.remarks);
					layero.find('.layui-tab li').each(function(i, e){
						var type = e.getAttribute('data-group');
						that.loadgrp(type, data, layero, index);
					});
					form.on('checkbox()', function(data){
						var tab = layero.find('.layui-tab-title > .layui-this');

						if(tab.length == 0) return;
						that.statistics(tab.attr('data-group'), layero, index);
					});

					h = layero.find('.layui-layer-content').height() - layero.find('.layui-tab-title').prop('offsetHeight') - 40;
					h-= layero.find('.layui-form-item').height();
					layero.find('.layui-tab-content').height(h);
				},
				yes: function(index, layero) {
					var d = form.val('user-group');
					var err = '', success = '';
					
					d.user = data.username;
					d.grp = '';
					
					layero.find('.layui-tab li').each(function(i, e) {
						var grp, e, tab, type = e.getAttribute('data-group');

						tab = layero.find('[data-group="' + type + '"]');
						grp = [];
						if(tab.length) {
							e = layero.find('.layui-tab-content > .layui-tab-item').eq(tab.index());
							e.find('input[data-grpid]:checked').each(function(i, e){
								grp.push(e.getAttribute('data-grpid'));
							});
						}
						d.grp = [type, grp.join(',')].join('|');
						$.ajax({
							url: 'api.php?r=user@save',
							data: d,
							type: 'post',
							async: false,
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									err = d.msg;
									return;
								}
								if (d.msg) 
									success = d.msg;
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					});
					if(err.length) {
						layer.msg(err, {
							icon: 5
						});
						return;
					}
					else
					if(success.length) {
						layer.msg(success, {
							icon: 1
						});
					}
					search();
					layer.close(index);
				},
				btn2: function(index, layero) {
					var type, ckd, e = layero.find('.layui-tab-content > .layui-show');
					
					ckd = e.find('input[type="checkbox"]:checked');
					type = layero.find('.layui-tab-title > .layui-this').attr('data-group');
					
					e.find('input[type="checkbox"]').not(':checked').prop('checked', true);
					ckd.prop('checked', false);
					form.render('checkbox');
					this.statistics(type, layero, index);
					return false;
				},
				btn3: function(index, layero) {
					var type, e = layero.find('.layui-tab-content > .layui-show');
					
					type = layero.find('.layui-tab-title > .layui-this').attr('data-group');
					e.find('input[type="checkbox"]').prop('checked', true);
					form.render('checkbox');
					this.statistics(type, layero, index);
					return false;
				},
				btn4: function(index, layero) {
					var type, e = layero.find('.layui-tab-content > .layui-show');
					
					type = layero.find('.layui-tab-title > .layui-this').attr('data-group');
					e.find('input[type="checkbox"]').prop('checked', false);
					form.render('checkbox');
					this.statistics(type, layero, index);
					return false;
				}
			});
		}
		else
		if(event === 'del') {
			layer.confirm('确认要删除用户' + data.username + '吗?', {
				icon: 0,
				title: '用户删除'
			}, function(index) {
				layer.close(index);
				$.ajax({
					url: 'api.php?r=user@remove',
					data: {
						u: data.username
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						search();
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			});
		}
		else
		if (event == 'mobile') {
			var btn_title = (data.mobile?'解绑':'绑定');
			layer.open({
				type: 1,
				shadeClose: true,
				title: btn_title + '手机号码 - ' + data.username,
				area: ['370px', '230px'],
				btnAlign: 'c',
				btn: [btn_title, '取消'],
				content: $('#tpl-user-mobile-config').html(),
				success: function(layero, index) {
					var sms_timeout;
					var tmid;
					form.val('mobile-config', {username: data.username, phone: data.mobile});

					if(data.mobile) {
						layero.find('input[name="phone"]').prop('disabled', true).css('background-color', '#e9e9e9');
					}
					// .addClass('layui-btn-disabled')
					form.render();
					form.on('submit(send-sms)', function(obj) {
						var d = form.val('mobile-config');
						var that = $(obj.elem);
						var txt = that.children().text();
						if(!data.mobile) d.bind = 1;
						$.ajax({
							url: 'api.php?r=user@sms-send',
							data: d,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});

								// sms set timeout 
								that.prop('disabled', true);
								that.addClass('layui-btn-disabled');
								if(tmid) clearTimeout(tmid); 
								sms_timeout = 59;
								tmid = setInterval(function(){
									if(sms_timeout < 0) {
										clearTimeout(tmid);
										tmid = null;
										that.prop('disabled', false);
										that.children().text(txt);
										that.removeClass('layui-btn-disabled')
									} else {
										that.children().text('' + sms_timeout + '秒后获取');
										sms_timeout--;
									}
								}, 1000); 
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					});
				},
				yes: function(index, layero) {
					var d = form.val('mobile-config');
					
					if(d.mobile == '') {
						layer.msg('手机号码不能为空！', {icon: 5});
						return;
					}
					if(d.code == '') {
						layer.msg('验证码不能为空！', {icon: 5});
						return;
					}

					$.ajax({
						url: 'api.php?r=user@mobile-' + (data.mobile?'un':'') + 'bind',
						data: d,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							search();
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
		}
	});

	//添加用户
	$('.adduserbtn').click(function() {
		layer.open({
			type: 1,
			shadeClose: true,
			title: '添加用户',
			area: ['400px', '278px'],
			btnAlign: 'c',
			btn: ['确认', '取消'],
			content: $('#user-add').html(),
			success: function(layero, index) {
				form.render();
			},
			yes: function(index, layero) {
				var d = form.val('add');
				
				if(d.user == '') {
					layer.msg('用户名不能为空！', {icon: 5});
					return;
				}
				if(d.pass == '') {
					layer.msg('密码不能为空！', {icon: 5});
					return;
				}
				if(d.pass != d.repass) {
					layer.msg('两次密码不一致！', {icon: 5});
					return;
				}
				$.ajax({
					url: 'api.php?r=user@add',
					data: d,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						search();
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});

	//搜索
	function search(page, obj) {
		var table = layui.table;

		var where = {
			keyword: $.trim($('#toptool input[name="keyword"]').val())
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				};
		} else
			page = 0;

		table.reloadExt('userlist', option);
	}
	
	function sms_config() {
		var d = form.val('sms_config');
		$.ajax({
			url: 'api.php?r=user@sms-save',
			data: d,
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
			},
			error: function() {
				layer.msg('获取数据失败，请稍后再试。', {
					icon: 2
				});
			}
		});
	}

	function sms_usesave() {
		var d = form.val('sms_use_option');
		$.ajax({
			url: 'api.php?r=user@sms-usesave',
			data: d,
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
			},
			error: function() {
				layer.msg('获取数据失败，请稍后再试。', {
					icon: 2
				});
			}
		});
	}

	$('#toptool .searchbtn').click(function() {
		search(1);
	});

	$('#sms_config .save').click(function() {
		sms_config();
	});

	$('#sms_use_option .save').click(function() {
		sms_usesave();
	});

	form.on('submit', function(data) {
		var id = $(data.elem).attr('id');
		if(id == 'toptool') {
			search(1);
			return false;
		}
		else 
		if(id == 'sms_config') {
			sms_config();
		}
		else 
		if(id == 'sms_use_option') {
			sms_usesave();
		}
	});

	function sms_useconfig()
	{
		$.ajax({
			url: 'api.php?r=user@sms-useconfig',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
				form.val('sms_use_option', d.data);
			},
			error: function() {
				layer.msg('获取数据失败，请稍后再试。', {
					icon: 2
				});
			}
		});
	}
	
	element.on('tab(user-mgd-tab)', function(data){
		if(data.index == 1) 
			sms_useconfig();
		else
		if(data.index == 2) {
			$.ajax({
				url: 'api.php?r=user@sms-config',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					form.val('sms_config', d.data);
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		}
	});
});
