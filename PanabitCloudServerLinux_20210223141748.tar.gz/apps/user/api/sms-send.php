<?php
namespace cloud\apps\user;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');


// 装载功能 | load function
ni_app_load('user', 'login');


// 执行 | exec function
if(isset($_REQUEST['bind']) && !empty($_REQUEST['bind'])) 
	logged();

$result = send_sms($_REQUEST);
if($result === 302) {
	json_error_exit(302, '', 'index.php');
}

// 结果输出 | printf result
if($result === false)
	json_error_exit(ERR_FAILURE);
else
	json_error_exit(ERR_OK, '', '');
