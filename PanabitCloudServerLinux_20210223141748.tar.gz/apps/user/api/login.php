<?php
namespace cloud\apps\user;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');


// 装载功能 | load function
ni_app_load($appname, $appmethod);


// 执行 | exec function
if(($user = logged()) === false)
	$user = auth($_REQUEST);

// 结果输出 | printf result
if($user === false)
	json_error_exit(ERR_FAILURE, '登陆失败！', (is_needverify()?1:0));
else
	json_error_exit(ERR_OK, '', 'index.php');
