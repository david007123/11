<?php
namespace cloud\apps\user;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

header("Content-type: application/json; charset=" . WEB_CHARSET);

// 支持库装载 | load lib
// ni_library_load('nidb');

// 装载功能 | load function
ni_app_load('user', 'login');

// 执行 | exec function
$verify = new \verify();
$verify->entry ();
