<?php
namespace cloud\apps\user;


function select($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`username` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"username",
		"logintime",
		"grp",
		"grpname",
		"remarks",
		"loginip",
		"ixc_grpids",
		"ixc_grpnames",
		"log_grpids",
		"log_grpnames",
		"intool_grpids",
		"intool_grpnames"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_users $where_str";
	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`username`,
`mobile`,
`logintime`,
`grp`,
`grpname`,
`remarks`,
`loginip`,
`ixc_grpids`,
`ixc_grpnames`,
`log_grpids`,
`log_grpnames`,
`intool_grpids`,
`intool_grpnames`';

	$sql = "select $keys from cloud_users $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$result['rows'] = $rows;

	
	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function add($data, $allow = 0)
{
	global $nidb, $user;
	

	$optional = array();
	if(format_and_push($data, 'user', $optional, 'username', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '用户名不能为空。');
		return false;
	}
	$optional['username'] = strtolower($optional['username']);

	if(!$allow) {
		if(\cloud\apps\work\project\project_enable(array())) {
			if(!\cloud\apps\work\project\in_work_user($optional['username'])) {
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
				return false;
			}
		}
		else
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}
	
	if(format_and_push($data, 'pass', $optional, 'password', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '用户密码不能为空。');
		return false;
	}

	if(format_and_push($data, 'remarks', $optional, '', 'string', false) == false)
		$optional['remarks']	= '';

	$optional['ixc_grpids']		= '';
	$optional['ixc_grpnames']	= '';
	$optional['grp']			= '';
	$optional['grpname']		= '';
	$optional['log_grpids']		= '';
	$optional['log_grpnames']	= '';
	$optional['intool_grpids']	= '';
	$optional['intool_grpnames']= '';
	$optional['password']		= md5($optional['password']);
	
	if(!$allow)
		cloud_insertlog($user->username, "添加用户{$optional['username']}");	

	try {
		$sql = "select * from cloud_users where `username` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['username'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if($row) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该用户已存在！');
			return false;
		}

		if(insert_data('cloud_users', $optional) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}

		return true;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return false;
}

function passwd($data)
{
	global $nidb, $user;
	

	$optional = array();
	$tmp = array();
	if(format_and_push($data, 'user', $optional, 'username', 'string', false) == false)
		$optional['username'] = $user->username;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_user($optional['username'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		if($optional['username'] != $user->username
		|| $optional['username'] == ADMIN_ACCT) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

	if(format_and_push($data, 'oldpass', $tmp, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '原密码不能为空。');
		return false;
	}
	
	if(format_and_push($data, 'pass', $optional, 'password', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '修改的密码不能为空。');
		return false;
	}

	try {
		$sql = "select * from cloud_users where `username` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['username'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if(!$row) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该用户不存在！');
			return false;
		}

		if(!($user->username == ADMIN_ACCT && $optional['username'] != $user->username)) {
			$oldpass = md5($tmp['oldpass']);
			if($oldpass != $row['password']) {
				set_errmsg(MSG_LEVEL_DEF, __function__, '原密码不正确！');
				return false;
			}
		}
		
		$optional['password'] = md5($optional['password']);
		if(update_data('cloud_users', $optional, array('username' => $optional['username'])) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if($optional['username'] != $user->username)
		cloud_insertlog($user->username, "修改密码{$optional['username']}");
	else
		cloud_insertlog($user->username, "修改密码");

	return true;
}

function mobile($data)
{
	global $nidb, $user;

	$optional = array();
	if(format_and_push($data, 'user', $optional, 'username', 'string', false) == false)
		$optional['username'] = $user->username;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		if($optional['username'] != $user->username
		&& $optional['username'] != ADMIN_ACCT) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

//	format_and_push($data, 'oldpass', $optional, '', 'string', false);
	if(format_and_push($data, 'phone', $optional, 'mobile', 'string', false) == false) {
		$optional['mobile'] = '';
		$tag = '解绑';
	}
	else 
		$tag = '绑定';

	try {
		$sql = "select * from cloud_users where `username` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['username'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if(!$row) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该用户不存在！');
			return false;
		}
/*
		// 如果设置了密码，则验证密码。
		if(isset($optional['oldpass'])) {
			if(!($user->username == ADMIN_ACCT && $optional['username'] != $user->username)) {
				if($row['password'] != md5($optional['oldpass'])) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '原密码不正确！');
					return false;
				}
			}
		}
*/
		if(update_data('cloud_users', $optional, array('username' => $optional['username'])) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if($optional['username'] != $user->username)
		cloud_insertlog($user->username, $tag . "手机号{$optional['username']}.{$optional['mobile']}");
	else
		cloud_insertlog($user->username, $tag . "手机号{$optional['mobile']}");

	return true;
}

function get_gateway_group($grpids)
{
	global $nidb;

	
	$result = array(
		'id'	=> array(),
		'name'	=> array()
	);

	$str = "?";
	if(count($grpids) > 1)
		$str.= str_repeat(',?', count($grpids) - 1);

	try {
		$sql = "select `grpid` as `id`, `grpname` as `name` from cloud_grp where `grpid` in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($grpids);

		while ($row = $sth->fetch(\PDO::FETCH_ASSOC)) {
			array_push($result['id'], $row['id']);
			array_push($result['name'], $row['name']);
		}
		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $result;
}

function get_ixcache_group($grpids)
{
	global $nidb;

	
	$result = array(
		'id'	=> array(),
		'name'	=> array()
	);
	
	$str = "?";
	if(count($grpids) > 1)
		$str.= str_repeat(',?', count($grpids) - 1);

	try {
		$sql = "select `grpid` as `id`, `grpname` as `name` from ixcache_grp where `grpid` in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($grpids);

		while ($row = $sth->fetch(\PDO::FETCH_ASSOC)) {
			array_push($result['id'], $row['id']);
			array_push($result['name'], $row['name']);
		}
		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $result;
}

function get_panalog_group($grpids)
{
	global $nidb;

	
	$result = array(
		'id'	=> array(),
		'name'	=> array()
	);
	
	$str = "?";
	if(count($grpids) > 1)
		$str.= str_repeat(',?', count($grpids) - 1);

	try {
		$sql = "select `grpid` as `id`, `grpname` as `name` from logserver_grp where `grpid` in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($grpids);

		while ($row = $sth->fetch(\PDO::FETCH_ASSOC)) {
			array_push($result['id'], $row['id']);
			array_push($result['name'], $row['name']);
		}
		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $result;
}

function get_intool_group($grpids)
{
	global $nidb;


	$result = array(
		'id'	=> array(),
		'name'	=> array()
	);
	
	$str = "?";
	if(count($grpids) > 1)
		$str.= str_repeat(',?', count($grpids) - 1);
	
	try {
		$sql = "select `id`, `name` from intool_grp where `id` in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($grpids);

		while ($row = $sth->fetch(\PDO::FETCH_ASSOC)) {
			array_push($result['id'], $row['id']);
			array_push($result['name'], $row['name']);
		}
		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $result;
}

function save($data)
{
	global $nidb, $user;
	

	$optional = array();
	if(format_and_push($data, 'user', $optional, 'username', 'string', false) == false)
		$optional['username'] = $user->username;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		if($optional['username'] != $user->username
		|| $optional['username'] == ADMIN_ACCT) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}
	
	$pagrp = array();
	$ixgrp = array();
	$loggrp = array();
	$ingrp = array();

	$grplist = array('gateway', 'ixcache', 'panalog', 'intranet');

	if(isset($data['grp']) && is_string($data['grp'])) {
		$str = explode('@', $data['grp']);
		foreach($str as $group) {
			$node = explode('|', $group);
			if(count($node) <= 0)
				continue;
			$grpname = $node[0];
			if(in_array($grpname, $grplist) === false)
				continue;
			if(count($node) == 1)
				$groups = array(0);
			else
				$groups = explode(',', $node[1]);

			if($grpname == 'gateway') {
				foreach($groups as $id) {
					if(($grpid = intval($id)) < 0) {
						set_errmsg(MSG_LEVEL_ARG, __function__, $grpname . '更新组的ID不正确。');
						return false;
					}
					array_push($pagrp, $grpid);
				}
			}
			else
			if($grpname == 'ixcache') {
				foreach($groups as $id) {
					if(($grpid = intval($id)) < 0) {
						set_errmsg(MSG_LEVEL_ARG, __function__, $grpname . '更新组的ID不正确。');
						return false;
					}
					array_push($ixgrp, $grpid);
				}
			}
			else
			if($grpname == 'panalog') {
				foreach($groups as $id) {
					if(($grpid = intval($id)) < 0) {
						set_errmsg(MSG_LEVEL_ARG, __function__, $grpname . '更新组的ID不正确。');
						return false;
					}
					array_push($loggrp, $grpid);
				}
			}
			else
			if($grpname == 'intranet') {
				foreach($groups as $id) {
					if(($grpid = intval($id)) < 0) {
						set_errmsg(MSG_LEVEL_ARG, __function__, $grpname . '更新组的ID不正确。');
						return false;
					}
					array_push($ingrp, $grpid);
				}
			}
		}
	}

	$frmData = array();
	if(count($pagrp)) {
		if(in_array(0, $pagrp)) {
			$frmData['grp']			= '';
			$frmData['grpname']		= '';
		}
		else {
			$grp = get_gateway_group($pagrp);
			if($grp && count($grp)) {
				$frmData['grp']		= implode(',', $grp['id']);
				$frmData['grpname'] = iconv("gbk", "utf-8", implode(',', $grp['name']));
				if(strlen($frmData['grpname']) > 512) {
					$str = substr($frmData['grpname'], 0, 508);
					$tmp = explode(',', $str);
					array_pop($tmp);
					$frmData['grpname'] = implode(',', $tmp) . ',...';
				}
			}
		}
	}
	if(count($ixgrp)) {
		if(in_array(0, $ixgrp)) {
			$frmData['ixc_grpids']			= '';
			$frmData['ixc_grpnames']		= '';
		}
		else {
			$grp = get_ixcache_group($ixgrp);
			if($grp && count($grp)) {
				$frmData['ixc_grpids']		= implode(',', $grp['id']);
				$frmData['ixc_grpnames']	= implode(',', $grp['name']);
				if(strlen($frmData['ixc_grpnames']) > 512) {
					$str = substr($frmData['ixc_grpnames'], 0, 508);
					$tmp = explode(',', $str);
					array_pop($tmp);
					$frmData['ixc_grpnames'] = implode(',', $tmp) . ',...';
				}
			}
		}
	}
	if(count($loggrp)) {
		if(in_array(0, $loggrp)) {
			$frmData['log_grpids']			= '';
			$frmData['log_grpnames'] 		= '';
		}
		else {
			$grp = get_panalog_group($loggrp);
			if($grp && count($grp)) {
				$frmData['log_grpids']		= implode(',', $grp['id']);
				$frmData['log_grpnames']	= implode(',', $grp['name']);
				if(strlen($frmData['log_grpnames']) > 512) {
					$str = substr($frmData['log_grpnames'], 0, 508);
					$tmp = explode(',', $str);
					array_pop($tmp);
					$frmData['log_grpnames'] = implode(',', $tmp) . ',...';
				}
			}
		}
	}
	if(count($ingrp)) {
		if(in_array(0, $ingrp)) {
			$frmData['intool_grpids']		= '';
			$frmData['intool_grpnames']		= '';
		}
		else {
			$grp = get_intool_group($ingrp);
			if($grp && count($grp)) {
				$frmData['intool_grpids']	= implode(',', $grp['id']);
				$frmData['intool_grpnames']	= implode(',', $grp['name']);
				if(strlen($frmData['intool_grpnames']) > 512) {
					$str = substr($frmData['intool_grpnames'], 0, 508);
					$tmp = explode(',', $str);
					array_pop($tmp);
					$frmData['intool_grpnames'] = implode(',', $tmp) . ',...';
				}
			}
		}
	}

	if(isset($data['remarks']))
		format_and_push($data, 'remarks', $frmData, '', 'string', true);

	if(count($frmData) == 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '请指定要保存的内容！');
		return false;
	}

	cloud_insertlog($user->username, "用户修改{$optional['username']}");	

	try {
		$sql = "select * from cloud_users where `username` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['username'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if(!$row) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该用户不存在！');
			return false;
		}

		if(update_data('cloud_users', $frmData, array('username' => $optional['username'])) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return true;
}

function remove($data)
{
	global $nidb, $user;
	

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['u']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的用户不能为空。');
		return false;
	}
	if(is_array($data['u']) === false) {
		if(empty($data['u']) || gettype($data['u']) != 'string') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要删除的用户。');
			return false;
		}

		$users = array($data['u']);
	}
	else
		$users = $data['u'];

	if(count($users) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的用户为空。');
		return false;
	}

	cloud_insertlog($user->username, "删除用户" . implode(',', $users));	

	$str = "?";
	if(count($users) > 1)
		$str.= str_repeat(',?', count($users) - 1);

	try {
		$sql = "delete from cloud_users where `username` in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($users);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return true;
}

