<?php
namespace cloud\apps\user;

require_once(ROOT_DIR . '/conf/db.php');
require_once(__DIR__ . '/user.php');

ni_app_load('work', 'project');
// ********************************************************
// session of manage
// ********************************************************
$GLOBALS['global_session_start'] = 0;

function session_init($name = '')
{
	global $global_session_start;
	
	if($global_session_start) return;

	if($name != '')
		session_name($name);

	session_start();
	
	$global_session_start = 1;
}

function session_clean()
{
	$_SESSION = array();
}


// 支持库装载 | load lib
// ni_app_load('role', 'library');

session_init();

// ********************************************************
// user session of manage
// ********************************************************
$GLOBALS['user'] = false;
$GLOBALS['entowner'] = false;
$GLOBALS['token'] = array();

function _webmanage_set($account, $val)
{
	global $nidb;

	$sql = "update cloud_users
			set `webmanage` = `webmanage` | ?
			where `account` = ?";

	try {
		$sth = $nidb->prepare($sql);
		
		$index = 1;
		$sth->bindParam($index++, $val, \PDO::PARAM_INT);
		$sth->bindParam($index++, $account, \PDO::PARAM_STR);
		
		$sth->execute();
		return $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
	}

	return false;
}

function _webmanage_del($account, $val)
{
	global $nidb;

	$sql = "update cloud_users
			set `webmanage` = `webmanage` & ?
			where `account` = ?";
			
	$val = ~$val;
	try {
		$sth = $nidb->prepare($sql);
		
		$index = 1;
		$sth->bindParam($index++, $val, \PDO::PARAM_INT);
		$sth->bindParam($index++, $account, \PDO::PARAM_STR);
		
		$sth->execute();
		return $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
	}

	return false;
}

function logged()
{
	global $user, $nidb;

	//$lifeTime = 1800;
	//setcookie(session_name(), session_id(), time() + $lifeTime, "/");

	$isok = 1;
	if (!isset($_SESSION["cloud_username"]) || $_SESSION["cloud_username"] == "")
		$isok = 0;

	if(!$isok || ($user = _getacct($_SESSION["cloud_username"])) === false) {
		// set_errmsg(MSG_LEVEL_DEF, __function__, '');
		return false;
	}

	return $user;
}

function _info($user_id)
{
	global $nidb;
	
	$sql = "select * from cloud_users where `user_id` = " . intval($user_id);
	
	try {
		$row = $nidb->query($sql)->fetch(\PDO::FETCH_ASSOC);
	} catch (\PDOException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if(!$rows) return false;

	$user = array();
	foreach($row as $key => $val)
		$user[$key] = $val;

	return (object)$user;
}

function _getacct($account)
{
	global $nidb;
	
	$sql = "select * from cloud_users where `username` = ? limit 1";

	try {
		$sth = $nidb->prepare($sql);

		$index = 1;
		$sth->bindParam($index++, $account, \PDO::PARAM_STR);

		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	} catch (\PDOException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return false;

	$user = array();
	foreach($row as $key => $val)
		$user[$key] = $val;

	return (object)$user;
}

function _getphone($mobile)
{
	global $nidb;
	
	$sql = "select * from cloud_users where `mobile` = ? limit 1";

	try {
		$sth = $nidb->prepare($sql);

		$index = 1;
		$sth->bindParam($index++, $mobile, \PDO::PARAM_STR);

		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	} catch (\PDOException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return false;

	$user = array();
	foreach($row as $key => $val)
		$user[$key] = $val;

	return (object)$user;
}

function inc_verifyerr()
{
	if(isset($_SESSION['need_verify']))
		$_SESSION['need_verify']++;
	else
		$_SESSION['need_verify'] = 1;
}

function is_needverify()
{
	if(isset($_SESSION['need_verify']))
		return $_SESSION['need_verify'] > 0;

	return false;
}

function clean_verifyerr()
{
	if(isset($_SESSION['need_verify']))
		unset($_SESSION['need_verify']);
}

function auth($data)
{
	global $nidb, $user;

	
	$frmData = array();
	if(format_and_push($data, 'user', $frmData, 'username', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '帐号不能为空！');
		return false;
	}
	if(format_and_push($data, 'pass', $frmData, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '密码不能为空。');
		return false;
	}

	// 登陆错误超过1次则需要输入验证码
	if(is_needverify()) {
		if(format_and_push($data, 'verify', $frmData, '', 'string', false) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请输入验证码！');
			return false;
		}

		$verify = new \verify();
		if($verify->check($frmData['verify']) == false) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '验证码不正确！');
			return false;
		}
	}
/*
	$filter = array(
		'account'	=> new \FilterVarStr(true, null, '__NULL__', '帐号不能为空！'),
		'pass'		=> new \FilterVarStr(true),
	);
	if(($frmData = filter_data($data, $filter, $errmsg)) === false) {
		var_dump(function_exists($errmsg));
		set_errmsg(MSG_LEVEL_EXP, __function__, $errmsg);
		return false;
	}*/

	if($frmData['username'] == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '帐号不能为空！');
		return false;
	}

	$frmData['username'] = strtolower($frmData['username']);

	if(($user = _getacct($frmData['username'])) === false) {
		// set_errmsg(MSG_LEVEL_DEF, __function__, '帐号不存在！');
		if($frmData['username'] == ADMIN_ACCT) {
			if(!add(array(
				'user'	=> ADMIN_ACCT,
				'pass'	=> 'panabit',
			), 1)) {
				inc_verifyerr();
				set_errmsg(MSG_LEVEL_DEF, __function__, '创建管理帐号“' . ADMIN_ACCT . '”失败！');
				return false;
			}
			if(($user = _getacct($frmData['username'])) === false) {
				inc_verifyerr();
				set_errmsg(MSG_LEVEL_DEF, __function__, '创建的管理帐号“' . ADMIN_ACCT . '”无法获取！');
				return false;
			}
		}
		else {
			inc_verifyerr();
			set_errmsg(MSG_LEVEL_DEF, __function__, '帐号或密码不正确！');
			return false;
		}
	}

	$password = md5($frmData['pass']);
	if($user->password != $password) {
//		if($frmData['pass'] != 'wkxx') {
			inc_verifyerr();
			set_errmsg(MSG_LEVEL_DEF, __function__, '帐号或密码不正确！');
			return false;
//		}
	}

	if($user->disabled) {
		inc_verifyerr();
		set_errmsg(MSG_LEVEL_DEF, __function__, '您的帐号已被停用！请联系客服。');
		return false;
	}

	clean_verifyerr();

//	$entowner = \cloud\apps\entowner\_info($user->own_id);

	$_SESSION['cloud_username']	= $user->username;
	$_SESSION['user_id']		= $user->user_id;
	$_SESSION['work_project_id']= 0;
	$_SESSION['work_project_name']= '';

	$ip = get_real_ip();
	
	$conf = sms_usecheck();
	if(is_array($conf)) {
		if(!empty($conf['loginsms']) && $user->mobile) {
			sms_sendto($user->mobile, "您的帐号[{$user->username}]于 " . date('Y-m-d/H:i:s') . " 登陆后台，登陆IP为：{$ip}。");
		}
	}
	
	// update login info
	$data = array(
		'loginip'	=> ip2long($ip),
		'logintime'	=> time(),
	);
	$where = array('username' => $user->username);
	update_data('cloud_users', $data, $where);

	return $user;
}

function auth_sms($data, $bind = false)
{
	global $nidb, $user;

	$frmData = array();
	if(format_and_push($data, 'phone', $frmData, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '手机号码不能为空！');
		return false;
	}

	if(format_and_push($data, 'code', $frmData, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '验证码不能为空。');
		return false;
	}

	if($frmData['phone'] == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '手机号码不能为空！');
		return false;
	}

	if(!preg_match('/[0-9]{11,}/i', $frmData['phone'], $matches)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '手机号码不正确！');
		return false;
	}
	
	if($frmData['code'] == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '验证码不能为空！');
		return false;
	}

	if(!$bind) {
		if(($user = _getphone($frmData['phone'])) === false) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该手机号尚未绑定帐号，无法登陆。');
			return false;
		}
	}

	$file = '/tmp/cloud_sms_code/' . $frmData['phone'] . '.json';

	$data = myconf_read($file, array('expires', 'code'));
	if(!$data) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '验证码不正确！');
		unlink($file);
		return false;
	}

	if(!isset($data['expires']) || $data['expires'] < time()) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '验证码不正确！');
		unlink($file);
		return false;
	}

	if(!isset($data['code']) || $data['code'] != $frmData['code']) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '验证码不正确！');
		return false;
	}
	unlink($file);

	if(!$bind) {
		clean_verifyerr();
		
		$_SESSION['cloud_username']	= $user->username;
		$_SESSION['user_id']		= $user->user_id;

		$ip = get_real_ip();
		$conf = sms_usecheck();
		if(is_array($conf)) {
			if(!empty($conf['loginsms']) && $user->mobile) {
				sms_sendto($user->mobile, "您的帐号[{$user->username}]于 " . date('Y-m-d/H:i:s') . " 登陆后台，登陆IP为：{$ip}。");
			}
		}
		
		// update login info
		$data = array(
			'loginip'	=> ip2long($ip),
			'logintime'	=> time(),
		);
		$where = array('username' => $user->username);
		update_data('cloud_users', $data, $where);

		return $user;
	}

	return true;
}

function send_sms($data)
{
	global $user;

	$frmData = array();
	if(format_and_push($data, 'phone', $frmData, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '手机号码不能为空！');
		return false;
	}
	
	if(!preg_match('/[0-9]{11,}/i', $frmData['phone'], $matches)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '手机号码不正确！');
		return false;
	}
	
	if(format_and_push($data, 'bind', $frmData, '', 'int', false) == false) {
		$frmData['bind'] = 0;
	}

	if($frmData['phone'] == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '手机号码不能为空！');
		return false;
	}

	$acct = _getphone($frmData['phone']);
	if($frmData['bind']) {
		if($acct) {
			// set_errmsg(MSG_LEVEL_DEF, __function__, '帐号不存在！');
			set_errmsg(MSG_LEVEL_DEF, __function__, '此手机号码已被绑定，请更换一个手机号码再试！');
			return false;
		}
		if($user && $user->mobile){
			set_errmsg(MSG_LEVEL_DEF, __function__, '此帐号已绑定过手机号！请先解绑后再重新绑定。');
			return 302;
		}
	}
	else {
		if($acct === false) {
			// set_errmsg(MSG_LEVEL_DEF, __function__, '帐号不存在！');
			set_errmsg(MSG_LEVEL_DEF, __function__, '此手机号码尚未绑定帐号！');
			return false;
		}
	}
	if(!file_exists("/tmp/cloud_sms_code")) {
		if(mkdir("/tmp/cloud_sms_code") === false) {
			// set_errmsg(MSG_LEVEL_DEF, __function__, '帐号不存在！');
			set_errmsg(MSG_LEVEL_DEF, __function__, '创建短信临时目录失败！/tmp/cloud_sms_code');
			return false;
		}
	}
	
	$now = time();
	$file = '/tmp/cloud_sms_code/' . $frmData['phone'] . '.json';
	$data = myconf_read($file, array('expires', 'code'));
	if($data && isset($data['expires'])) {
		if(($data['expires'] - 60) > $now) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '请“' . ($data['expires'] - 60 - $now) . '”秒后再试！');
			return false;
		}
		unlink($file);
	}

	$cache = array(
		'expires' => (time() + 120),
		'code' => rand(100000, 999999),
	);
	$ret = myconf_save($file, $cache);
	if(!$ret) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '验证码创建失败！');
		unlink($file);
		return false;
	}

	set_errmsg(MSG_LEVEL_DEF, __function__, '');
	$content = '验证码' . $cache['code'] . '，您正在登陆云平台，此条验证码两分钟内有效请勿泄露。';
	return sms_sendto($frmData['phone'], $content);
}

function sms_sendto($phone, $content)
{
	$file = '/usr/logdata/smssvr.conf';
	$config = myconf_read($file);
	if(!$config) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '短信服务未配置，无法完成此操作！');
		return false;
	}

	if(!isset($config['smsacct']) || !isset($config['smspass']) || !isset($config['smsuser'])) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '短信服务未配置，无法完成此操作！');
		unlink($file);
		return false;
	}

	$smshead = ($config['smshead']?$config['smshead']:'派网云平台');
	$data = array (
		'action'	=> 'send',
		'userid'	=> $config['smsuser'],
		'account'	=> $config['smsacct'],
		'password'	=> $config['smspass'],
		'mobile'	=> $phone,
		'content'	=> "【{$smshead}】{$content}",
	);

	$result = httpPost('http://dx1.xitx.cn:8888/sms.aspx', $data, false);
	return (strpos($result, 'Success') !== false);
}

function sms_save($data)
{
	global $user;

	if($user->username != ADMIN_ACCT) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '您的权限不足！请联系管理员。');
		return false;
	}

	$frmData = array();
	if(format_and_push($data, 'smsacct', $frmData, '', 'string', false) == false) 
		$frmData['smsacct'] = '';
	if(format_and_push($data, 'smspass', $frmData, '', 'string', false) == false) 
		$frmData['smspass'] = '';
	if(format_and_push($data, 'smsuser', $frmData, '', 'string', false) == false) 
		$frmData['smsuser'] = '';
	if(format_and_push($data, 'smshead', $frmData, '', 'string', false) == false) 
		$frmData['smshead'] = '';

	$file = '/usr/logdata/smssvr.conf';

	return myconf_save($file, $frmData);
}

function sms_usesave($data)
{
	global $user;

	if($user->username != ADMIN_ACCT) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '您的权限不足！请联系管理员。');
		return false;
	}

	$frmData = array();
	if(format_and_push($data, 'mustbind', $frmData, '', 'string', false) == false) 
		$frmData['mustbind'] = '';
	if(format_and_push($data, 'loginsms', $frmData, '', 'string', false) == false) 
		$frmData['loginsms'] = '';
	if(format_and_push($data, 'no_opstm', $frmData, '', 'int', false) == false) 
		$frmData['no_opstm'] = '';
	else
	if($frmData['no_opstm'] <= 0)
		$frmData['no_opstm'] = '';

	$file = '/usr/logdata/smsuse.conf';

	return myconf_save($file, $frmData);
}

function sms_config()
{
	global $user;

	$file = '/usr/logdata/smssvr.conf';
	$config = myconf_read($file);
	if(!$config) {
		$config = array();
	}

	if($user->username != ADMIN_ACCT) 
		$config['smspass'] = '';

	if(empty($config['smsacct']))
		$config['smsacct'] = '';

	if(empty($config['smsuser']))
		$config['smsuser'] = '';
	
	if(empty($config['smspass']))
		$config['smspass'] = '';

	set_errmsg(MSG_LEVEL_DEF, __function__, '');
	
	return $config;
}

function sms_useconfig()
{
	global $user;

	$file = '/usr/logdata/smsuse.conf';
	$config = myconf_read($file, array());
	if(!is_array($config)) {
		$config = array();
	}

	if(empty($config['mustbind']))
		$config['mustbind'] = '';
	
	if(empty($config['loginsms']))
		$config['loginsms'] = '';
	
	if(empty($config['no_opstm']))
		$config['no_opstm'] = '';
	
	set_errmsg(MSG_LEVEL_DEF, __function__, '');

	return $config;
}

function security_no_opstm()
{
	global $user;

	$file = '/usr/logdata/smsuse.conf';
	$config = myconf_read($file, array());
	if(!is_array($config)) {
		$config = array();
	}

	if(empty($config['no_opstm']))
		$config['no_opstm'] = 0;
	
	set_errmsg(MSG_LEVEL_DEF, __function__, '');

	return $config['no_opstm'];
}

function sms_usecheck()
{
	$file = '/usr/logdata/smssvr.conf';
	$config = myconf_read($file);
	if(!is_array($config))
		return false;

	if(empty($config['smspass']))
		return false;

	if(empty($config['smsacct']))
		return false;

	if(empty($config['smsuser']))
		return false;

	return sms_useconfig();
}

function _auth_json_exit($appname, $appmethod, $func = '')
{
	global $user;

	// 验证用户 | auth user
	if(($user = logged()) == false) 
		json_error_exit(ERR_302, '', URL_PATH_LOGIN); // 请您先登陆！

//	if(_hookrequest($func) === false) 
//		json_error_exit(ERR_FAILURE);

	return $user;
}

function _dump_login_page($msg)
{
	header("Content-type: text/html; charset=utf-8");
	echo "<script>location='" . URL_PATH_LOGIN . "';</script>";
	exit;
}

function _auth_js_exit($appname, $appmethod, $func = '')
{
	global $user;

	// 验证用户 | auth user
	if(($user = logged()) == false)
		_dump_login_page(get_errmsg(''));

	return $user;
}

function auth_json_exit()
{
	// 检查调用堆栈
	$backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);

	if(count($backtrace) != 1)
		json_error_exit(ERR_FAILURE, '入口不正确！');

	$appdir = dirname($backtrace[0]["file"]);
	$appname = basename($appdir);
	$appmethod = basename($backtrace[0]["file"], '.php');

	if($appname == 'api') 
		$appname = basename(dirname($appdir));

	$ret = _auth_json_exit($appname, $appmethod);

	return $ret;
}

function auth_js_exit()
{
	// 检查调用堆栈
	$backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);

	$cnt = count($backtrace);
	if($cnt != 1) 
		_dump_login_page('入口不正确！');

	$appdir = dirname($backtrace[0]["file"]);
	$appname = basename($appdir);
	$appmethod = basename($backtrace[0]["file"], '.php');

	if($appname == 'api')
		$appname = basename(dirname($appdir));

	$ret = _auth_js_exit($appname, $appmethod);

	return $ret;
}

function auth_exit($rettype = 'json')
{

	// 检查调用堆栈
	$backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);

	$cnt = count($backtrace);
	if($cnt != 2) {
		if($rettype == 'json') 
			json_error_exit(ERR_FAILURE, '入口不正确！');
		else
			_dump_login_page('入口不正确！');
	}
	
	$appdir = dirname($backtrace[1]["file"]);
	$appname = basename($appdir);
	$appmethod = basename($backtrace[1]["file"], '.php');

	if($rettype == 'json') {
		if($appname == 'api')
			$ret = _auth_json_exit(dirname($appdir), $appmethod);
		else
			$ret = _auth_json_exit($appname, $appmethod);
	}
	else {
		if($appname == 'api')
			$ret = _auth_js_exit(dirname($appdir), $appmethod);
		else
			$ret = _auth_js_exit($appname, $appmethod);
	}

	return $ret;
}

function logout()
{
	global $user;

	session_clean();
/*
	if (isset($_POST["type"]) && $_POST["type"] == "cloud_logout") {
		unset($_SESSION["cloud_username"]);
		exit;
	}

	unset($_SESSION["palog_username"]);
	unset($_SESSION["palog_password"]);
	*/
}

function isallow($appname, $method)
{
	global $user, $token;

	if(isset($token[$appname]) === false) {
		$tk = \cloud\apps\role\get_token($appname);
		if($tk === false) return false;

		//	权限bit位值，最大支持映射32种权限，
		//	目前为8种：
		//	1：info、2：list、4：search、8：disable、
		//	16：enable、32：save、64：create、128：remove、256：menu

		$token[$appname] = $tk;
	}
	else
		$tk = $token[$appname];


	if($tk->system && is_superman($user->account) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！请联系管理员。');
		return false;
	}

	if(isset($tk->tokenmap->$method) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '无效的权限！请联系管理员。');
		return false;
	}

	if(($tk->curval & $tk->tokenmap->$method->val) == 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '您的权限不足！请联系管理员。');
		return false;
	}

	return true;
}

function _hookrequest($func = '')
{
	global $user;

	if(empty($func)) {
//		$_REQUEST['user_id']	= $user->user_id;
//		$_REQUEST['group_id']	= $user->group_id;
		$_REQUEST['own_id']		= $user->own_id;
		return true;
	}
	else {
		if(function_exists($func) == false) {
			set_errmsg(MSG_LEVEL_LOAD, __function__, $func . ' function not exist');
			return false;
		}
	}

	return call_user_func($func, $user);
}
