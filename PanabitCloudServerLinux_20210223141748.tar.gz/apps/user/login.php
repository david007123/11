<?php
$appdir = dirname(__FILE__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');


$auto_install_php = ROOT_DIR . '/install/auto_install.php';
if(file_exists($auto_install_php)) {

	exec("/usr/logd/bin/php {$auto_install_php} 2>&1", $output, $ret);
	if($ret) {
		unset($output);
		// unlink($auto_install_php);
		return false;
	}
}

// 装载功能 | load function
// ni_app_load('user', 'login');

// 验证用户 | auth user
//\raas\apps\user\_auth_js_exit($appname, IDENTITY_TOKEN_LIST);

// exec page
//hook_register('get_wallet_hook', '获取库存信息', 'web_body');

//if(is_MobileWeb())
//	require_once(__DIR__  . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . $appmethod . '-m.html');
//else
//	require_once(__DIR__  . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . $appmethod . '.html');

$path = __DIR__  . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR;
if(isset($_REQUEST['T']) && preg_match("/^([a-zA-Z0-9-_]{1,})$/", $_REQUEST['T'], $match)) {
	if(file_exists("{$path}/login/{$_REQUEST['T']}/login.html"))
		$theme = "login/{$_REQUEST['T']}/";
}
else
	$theme = '';

require_once("{$path}/{$theme}login.html");
