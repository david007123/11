<?php
namespace cloud\apps\netoff;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

header("Content-type: application/json; charset=" . WEB_CHARSET);

// 支持库装载 | load lib
// ni_library_load('nidb');

// 装载功能 | load function
ni_app_load('user', 'login');
ni_app_load($appname, 'object');


$content = myconf_read('/usr/logdata/cloud_api_token.conf', array('netoff_ip'));
if(isset($content['netoff_ip']) == false || $content['netoff_ip'] != get_real_ip()) {
	set_errmsg(MSG_LEVEL_ARG, __function__, '');
	// 验证用户 | auth user
	\cloud\apps\user\auth_json_exit();
}

// 执行 | exec function
$result = object\select($_REQUEST);


// 结果输出 | printf result
if($result === false)
	json_error_exit(ERR_FAILURE, '获取失败！');
else
	json_error_exit(ERR_OK, '', $result);
