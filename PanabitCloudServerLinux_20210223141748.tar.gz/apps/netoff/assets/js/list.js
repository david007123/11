// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

layui.use(['element', 'table', 'layer', 'form'], function() {
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var form = layui.form;

	table.render({
		elem: '#objlist',
		even: true,
		loading: false,
		url: 'api.php?r=netoff@obj-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'serialno',
			type: 'asc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#objlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 50,
					fixed: 'left',
					type: 'numbers'
				},
				{
					field: 'event',
					title: '资源对象',
				}, {
					field: 'serialno',
					title: '12位编号',
				}, {
					field: 'name',
					title: '系统名称',
				}, {
					field: 'tips',
					title: '简要说明',
				}, {
					title: '操作',
					width: 50,
					templet: function(d) {
						return '<span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});

	$('.addobjbtn').on('click', function(obj){
		var event = obj.currentTarget.getAttribute('lay-filter');
		if(event === "add"){
			layer.open({
				type: 1,
				title: '添加阻断对象',
				area: ['430px'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['添加'],
				content: $('#add-obj').html(),
				mysubmit: function(index, layero){
					var data = form.val('addobj');
			
					$.ajax({
						url:'api.php?r=netoff@obj-add',
						data: data,
						type:'post',
						dataType:'json',
						success:function(d) {
							if(ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {icon: 5});
								return;
							}
							if(d.msg) layer.msg(d.msg, {icon: 1});
							table.refresh('objlist');
							layer.close(index);
						},
						error: function(){
							layer.msg('添加失败，请稍后再试。', {icon: 2});
						}
					});
				},
				yes: function(index, layero) {
					this.mysubmit(index, layero);
				}
			});
		}
	});
	
	$('.addobjwbtn').on('click', function(obj){
		var event = obj.currentTarget.getAttribute('lay-filter');
		if(event === "add"){
			layer.open({
				type: 1,
				title: '添加放行对象',
				area: ['430px'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['添加'],
				content: $('#add-obj-w').html(),
				mysubmit: function(index, layero){
					var data = form.val('addobj-w');

					data.event = 'W:' + data.event;
					
					$.ajax({
						url:'api.php?r=netoff@obj-add',
						data: data,
						type:'post',
						dataType:'json',
						success:function(d) {
							if(ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {icon: 5});
								return;
							}
							if(d.msg) layer.msg(d.msg, {icon: 1});
							table.refresh('objlist');
							layer.close(index);
						},
						error: function(){
							layer.msg('添加失败，请稍后再试。', {icon: 2});
						}
					});
				},
				yes: function(index, layero) {
					this.mysubmit(index, layero);
				}
			});
		}
	});
	
	table.on('tool(objlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event === 'del') {
			layer.confirm('确认要删除对象吗?', {
				icon: 0,
				title: '删除对象'
			}, function(index) {
				layer.close(index);
				$.ajax({
					url: 'api.php?r=netoff@obj-remove',
					data: {
						id: data.id
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {icon: 1});
						
						table.reloadExt('objlist', {page: {curr: 1}});
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			});
		}
	});
	
	table.render({
		elem: '#loglist',
		even: true,
		loading: false,
		url: 'api.php?r=netoff@logger-login',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'birth',
			type: 'desc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#loglist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 50,
					fixed: 'left',
					type: 'numbers'
				},
				{
					title: '用户头像',
					width: 80,
					templet: function(d) {
						return '<img src="' + d.avatarurl + '" width="30px" />';
					}
				}, {
					field: 'nickname',
					title: '用户昵称',
					width: 150,
				}, {
					field: 'username',
					title: '登录用户',
					width: 150,
				}, {
					field: 'birth',
					title: '登录时间',
					width: 140,
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.birth, 'yyyy/MM/dd HH:mm:ss');
					}
				}, {
					field: 'openid',
					title: 'openid',
				}
			]
		]
	});

	table.render({
		elem: '#operatelist',
		even: true,
		loading: false,
		url: 'api.php?r=netoff@logger-operate',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#operatelist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 50,
					fixed: 'left',
					type: 'numbers'
				},
				{
					title: '用户头像',
					width: 80,
					templet: function(d) {
						return '<img src="' + d.avatarurl + '" width="30px" />';
					}
				}, {
					field: 'nickname',
					title: '用户昵称',
					width: 150,
				}, {
					field: 'birth',
					title: '操作时间',
					width: 140,
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.birth, 'yyyy/MM/dd HH:mm:ss');
					}
				}, {
					title: '内容',
					templet: function(d) {
						var str = (Number(d.status)== 0 ? "联网" : "断网");
						return str + " 设备/" + d.device + " 对象/" + d.object + " 用户/" + d.openid;
					}
				}
			]
		]
	});

	element.on('tab(netoff)', function(data){
		switch(data.index) {
			case 0:
				table.reloadExt('objlist');
				break;
			case 1:
				table.reloadExt('loglist');
				break;
			case 2:
				table.reloadExt('operatelist');
				break;
			default:
				break;
		}
	});
});
