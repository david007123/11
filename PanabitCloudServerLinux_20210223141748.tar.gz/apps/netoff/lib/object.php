<?php
namespace cloud\apps\netoff\object;


function is_utf8($word)   
{
	if (preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$word) == true)
	{
		return true;
	}else{   
		return false;   
	}   
}

function select($data)
{
	global $nidb;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
/*
	if(format_and_push($data, 'disabled', $optional, '', 'int', false))
		$where_str .= "`disabled` = " . $optional['disabled'] . " and ";
	else
		$where_str .= "`disabled` < " . TB_ROW_DEL_VALUE . " and ";
	
	if(format_and_push($data, 'upstartm', $optional, '', 'int', false))
		$where_str .= "`update_time` >= " . $optional['upstartm'] . " and ";

	if(format_and_push($data, 'endtm', $optional, '', 'int', false)) 
		$where_str .= "`update_time` < " . $optional['upendtm']  . " and ";

	if(format_and_push($data, 'startm', $optional, '', 'int', false))
		$where_str .= "`create_time` >= " . $optional['startm'] . " and ";

	if(format_and_push($data, 'endtm', $optional, '', 'int', false))
		$where_str .= "`create_time` < " . $optional['endtm']  . " and ";
*/
	// set custom options
	if(format_and_push($data, 'id', $optional, '', 'int', false))
		$where_str .= "`id` = " . $optional['id']  . " and ";

	if(format_and_push($data, 'serialno', $optional, 'license_id12', 'string', false)) {
		$where_str .= "`license_id12` = ? and ";
		array_push($values, $optional['license_id12']);
	}

	if(format_and_push($data, 'name', $optional, 'sysname', 'string', false)) {
		$where_str .= "`sysname` = ? and ";
		array_push($values, "%" . $optional['sysname'] . "%");
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data['keyword'], 'value', $optional, 'keyword', 'string', false)) {
			$where_str .= "(`license_id12` like ? or `sysname` like ? or `tips` like ? or `myevent` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$order_map = array(
		"id",
		"myevent",
		"openid",
		"license_id12",
		"status",
		"isupdate",
		"sysname",
		"tips",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	$sql = "select count(*) as `total` from weixin_brokennet $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	if(isset($data['simplify'])) {
		$keys = '`myevent` as `event`,
			`license_id12` as `serialno`,
			`status`,
			`sysname` as `name`,
			`tips`';
	}
	else{
		$keys = '`id`,
			`myevent` as `event`,
			`openid`,
			`license_id12` as `serialno`,
			`status`,
			`sysname` as `name`,
			`tips`';
	}

	$sql = "select $keys from weixin_brokennet $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function add($data)
{
	global $nidb;


	$optional = array();
/*
	if(format_and_push($data, 'openid', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, 'openid不能为空。');
		return false;
	}

	if(preg_match("/^([a-zA-Z0-9-_]{20,})$/", $optional['openid'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "OPENID“{$optional['openid']}”不正确！");
		return false;
	}
*/
	if(format_and_push($data, 'serialno', $optional, 'license_id12', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '12位编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['license_id12'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "用户“{$optional['license_id12']}”不正确！");
		return false;
	}

	if(format_and_push($data, 'event', $optional, 'myevent', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '操作对象不能为空。');
		return false;
	}

	format_and_push($data, 'tips', $optional, '', 'string', false);


	$sql = "select id from weixin_brokennet where `license_id12` = ? and `myevent` = ? limit 1";

	try {
		$sth = $nidb->prepare($sql);

		$sth->bindParam(1, $optional['license_id12'], \PDO::PARAM_STR);
		$sth->bindParam(2, $optional['myevent'], \PDO::PARAM_STR);
		$sth->execute($values);

		$row = $sth->fetch(\PDO::FETCH_LAZY);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if($row) {
		set_errmsg(MSG_LEVEL_EXP, __function__, "“{$grpname}”对象已存在。");
		return false;
	}

	$sysname = "";
	if (!empty($optional['license_id12'])) {
		$cmd = DATAEYE . " device get license_id12={$optional['license_id12']}";
		exec($cmd, $out, $ret);
		$license_id12 = "";
		foreach($out as $val) {
			list($tag, $val) = explode('=', $val);
			if ($tag == "name") {
				$sysname = $val;
				$license_id12 = $optional['license_id12'];
			}
		}

		if ($sysname != "") {
			if (!is_utf8($sysname) || json_encode($sysname) == false)
				$sysname = iconv("gbk", "utf-8", $sysname);
		}

		if($license_id12 != $optional['license_id12']) {
			set_errmsg(MSG_LEVEL_EXP, __function__, "“{$optional['license_id12']}”设备不存在。");
			return false;
		}
	}
	

	$optional['birth'] = time();
	// $optional['isupdate'] = 0;
	$optional['sysname'] = $sysname;

	try {
		if(insert_data('weixin_brokennet', $optional) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
		$optional['id'] = $nidb->lastInsertId();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $optional;
}

function deny($data)
{
	global $nidb;


	$values = array();


	if(isset($data['allow']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '操作方法不能为空。');
		return false;
	}
	$allow = intval($data['allow']);
	
	if(isset($data['id']) == false) {

		if(add($data) === false)
			set_errmsg(MSG_LEVEL_ARG, __function__, '');
//			return false;

		if(format_and_push($data, 'serialno', $values, 'license_id12', 'string', false) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '12位编号不能为空。');
			return false;
		}
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $values['license_id12'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "用户“{$values['license_id12']}”不正确！");
			return false;
		}

		if(format_and_push($data, 'event', $values, 'myevent', 'string', false) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '操作对象不能为空。');
			return false;
		}
	
		$sql = "update weixin_brokennet set `status` = ${allow}, `isupdate` = 1";
		$sql.= " where `license_id12` = ? and `myevent` = ? ";

		try {
			$sth = $nidb->prepare($sql);
			$sth->bindParam(1, $values['license_id12'], \PDO::PARAM_STR);
			$sth->bindParam(2, $values['myevent'], \PDO::PARAM_STR);
			$ret = $sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
	}
	else {
		if(is_array($data['id']) == false)
			$data['id'] = explode(',', $data['id']);

		foreach($data['id'] as $val) {
			$id = intval($val);
			if($id <= 0){
				set_errmsg(MSG_LEVEL_ARG, __function__, "删除对象“{$id}”不正确。");
				return false;
			}
			array_push($values, $id);
		}
		
		if(count($values) == 0) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '删除对象不能为空。');
			return false;
		}
		
		$idstr = '?';
		if(count($values) > 1)
			$idstr .= str_repeat(',?' , count($values) - 1);

		$sql = "update weixin_brokennet set `status` = ${allow}, `isupdate` = 1 where id in($idstr)";
		
		try {
			$sth = $nidb->prepare($sql);
			$ret = $sth->execute($values);
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}

	}

	if($ret == false) 
		return false;

	return $sth->rowCount();
}

function remove($data)
{
	global $nidb;


	$values = array();
	
	if(isset($data['id']) == false) {
		if(format_and_push($data, 'serialno', $values, 'license_id12', 'string', false) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '12位编号不能为空。');
			return false;
		}
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $values['license_id12'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "用户“{$values['license_id12']}”不正确！");
			return false;
		}

		if(format_and_push($data, 'event', $values, 'myevent', 'string', false) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '操作对象不能为空。');
			return false;
		}
		
		$sql = "delete from weixin_brokennet where `license_id12` = ? and `myevent` = ? ";
		
		try {
			$sth = $nidb->prepare($sql);
			$sth->bindParam(1, $values['license_id12'], \PDO::PARAM_STR);
			$sth->bindParam(2, $values['myevent'], \PDO::PARAM_STR);
			$ret = $sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
	}
	else {
		if(is_array($data['id']) == false)
			$data['id'] = explode(',', $data['id']);

		foreach($data['id'] as $val) {
			$id = intval($val);
			if($id <= 0){
				set_errmsg(MSG_LEVEL_ARG, __function__, "删除对象“{$id}”不正确。");
				return false;
			}
			array_push($values, $id);
		}
		
		if(count($values) == 0) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '删除对象不能为空。');
			return false;
		}
		
		$idstr = '?';
		if(count($values) > 1)
			$idstr .= str_repeat(',?' , count($values) - 1);

		$sql = "delete from weixin_brokennet where id in($idstr)";

		try {
			$sth = $nidb->prepare($sql);
			$ret = $sth->execute($values);
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
	}


	if($ret == false) 
		return false;

	return true;
}


