<?php
namespace cloud\apps\netoff\logger;


function login($data)
{
	global $nidb;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
/*
	if(format_and_push($data, 'disabled', $optional, '', 'int', false))
		$where_str .= "`disabled` = " . $optional['disabled'] . " and ";
	else
		$where_str .= "`disabled` < " . TB_ROW_DEL_VALUE . " and ";
	
	if(format_and_push($data, 'upstartm', $optional, '', 'int', false))
		$where_str .= "`update_time` >= " . $optional['upstartm'] . " and ";

	if(format_and_push($data, 'endtm', $optional, '', 'int', false)) 
		$where_str .= "`update_time` < " . $optional['upendtm']  . " and ";

	if(format_and_push($data, 'startm', $optional, '', 'int', false))
		$where_str .= "`create_time` >= " . $optional['startm'] . " and ";

	if(format_and_push($data, 'endtm', $optional, '', 'int', false))
		$where_str .= "`create_time` < " . $optional['endtm']  . " and ";
*/
	// set custom options
	if(format_and_push($data, 'id', $optional, '', 'int', false))
		$where_str .= "`id` = " . $optional['id']  . " and ";

	if(format_and_push($data, 'nickname', $optional, '', 'string', false)) {
		$where_str .= "`nickname` = ? and ";
		array_push($values, $optional['nickname']);
//		array_push($values, "%" . $optional['nickname'] . "%");
	}
	
	if(format_and_push($data, 'username', $optional, '', 'string', false)) {
		$where_str .= "`username` = ? and ";
		array_push($values, $optional['username']);
	}
	
	if(isset($data['keyword'])) {
		if(format_and_push($data['keyword'], 'value', $optional, 'keyword', 'string', false)) {
			$where_str .= "(`nickname` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);


	$order_map = array(
		"id",
		"birth",
		"nickname",
		"openid",
		"username",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	$sql = "select count(*) as `total` from weixin_brokennet_login $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`id`,
		`birth`,
		`nickname`,
		`openid`,
		`username`,
		`avatarurl`';

	$sql = "select $keys from weixin_brokennet_login $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}


function operate($data)
{
	global $nidb;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
/*
	if(format_and_push($data, 'disabled', $optional, '', 'int', false))
		$where_str .= "`disabled` = " . $optional['disabled'] . " and ";
	else
		$where_str .= "`disabled` < " . TB_ROW_DEL_VALUE . " and ";
	
	if(format_and_push($data, 'upstartm', $optional, '', 'int', false))
		$where_str .= "`update_time` >= " . $optional['upstartm'] . " and ";

	if(format_and_push($data, 'endtm', $optional, '', 'int', false)) 
		$where_str .= "`update_time` < " . $optional['upendtm']  . " and ";

	if(format_and_push($data, 'startm', $optional, '', 'int', false))
		$where_str .= "`create_time` >= " . $optional['startm'] . " and ";

	if(format_and_push($data, 'endtm', $optional, '', 'int', false))
		$where_str .= "`create_time` < " . $optional['endtm']  . " and ";
*/
	// set custom options
	if(format_and_push($data, 'id', $optional, '', 'int', false))
		$where_str .= "`id` = " . $optional['id']  . " and ";

	if(format_and_push($data, 'nickname', $optional, '', 'string', false)) {
		$where_str .= "`nickname` = ? and ";
		array_push($values, $optional['nickname']);
//		array_push($values, "%" . $optional['nickname'] . "%");
	}
	
	if(format_and_push($data, 'username', $optional, '', 'string', false)) {
		$where_str .= "`username` = ? and ";
		array_push($values, $optional['username']);
	}
	
	if(format_and_push($data, 'openid', $optional, '', 'string', false)) {
		$where_str .= "`openid` = ? and ";
		array_push($values, $optional['openid']);
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data['keyword'], 'value', $optional, 'keyword', 'string', false)) {
			$where_str .= "(`nickname` like ? or `username` like ? or `object` like ? or `openid` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$order_map = array(
		"id",
		"birth",
		"nickname",
		"openid",
		"username",
		"device",
		"object",
		"status",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	$sql = "select count(*) as `total` from weixin_brokennet_operation $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`birth`,
		`device`,
		`nickname`,
		`openid`,
		`object`,
		`status`,
		`avatarurl`';

	$sql = "select $keys from weixin_brokennet_operation $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

