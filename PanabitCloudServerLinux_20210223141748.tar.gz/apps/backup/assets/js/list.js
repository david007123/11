// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

var flag = false;

function operate(d) {
	return '<a target="_blank" href="api.php?r=backup@filedown&file=' + d.filename +
		'" class="setBtn">下载</a>&nbsp;|&nbsp;<span lay-event="deldwn" class="setBtn">删除</span>'
}

var timer = new taskTimer();
layui.use(['form', 'element', 'table', 'layer'], function() {
	var element = layui.element;
	var form = layui.form;
	var table = layui.table;
	var layer = layui.layer;
	var backuptable;

	//所有组
	function maingroup_refresh() {
		timer.add('read_group', 3, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="filter-group"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="filter-group"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
						timer.rmv('read_group');
					}
				});
			}
		}, 1);
		timer.add('getnum', 3, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=backup@currcnt',
					dataType: 'json',
					success: function(d) {
						$('.backupnum').text(d.data);
					}
				});
			}
		}, 1);
	}
	maingroup_refresh();

	timer.add('read_group', 3, {
		fuc: function() {
			var that = this;
			$.ajax({
				url: 'api.php?r=group@group',
				type: 'post',
				success(d) {
					if (ajax_resultCallBack(d) == false) return;
					var i, data = d.data;

					$('select[lay-filter="filter-group"] option').not('[value=-1]').remove();
					for (i = 0; i < data.rows.length; i++)
						$('select[lay-filter="filter-group"]')
						.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

					form.render('select');
					timer.rmv('read_group');
				}
			});
		}
	}, 1);

	backuptable = table.render({
		elem: '#backuplist',
		even: true,
		url: 'api.php?r=backup@list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		loading: false,
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			if(res.ret == 0) {
				res.count = res.data.total;
				res.data = res.data.rows;
			}
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#backuplist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
				}, {
					field: 'serialno',
					title: '编号',
				}, {
					field: 'cname',
					title: '名称',
					width: 200
				}, {
					title: '属组',
					templet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					title: '备份类型',
					templet: function(r) {
						if (r.backup_type == 1) {
							return "定时";
						} else if (r.backup_type == 2) {
							return "取消";
						}
						return '';
					}
				},
				{
					title: '最近备份',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.backup_time, true);
					}
				},
				{
					title: '最近状态',
					templet: function(r) {
						switch (r.errors) {
							case "same":
								return "内容未变化";
							case "timeout":
								return "超时";
							case "ok":
								return "备份成功";
							case "fail":
								return "文件上传失败";
							case "noconf":
								return "配置文件不存在";
							case "wait":
								return "等待备份";
							default:
								break;
						}
						return '';
					}
				},
				{
					title: '距离下次备份',
					templet: function(r) {
						var dt;
						if (r.backup_type == 1) {
							dt = parseInt(((new Date()).getTime()) / 1000);
							return '<span class="off_txt">' + (r.backup_nexttime - dt) + '秒</span>';
						}
						return '';
					}
				},
				{
					field: 'fnum',
					title: '文件数',
				},
				{
					field: 'servertime',
					title: '操作',
					templet: function(r) {
						downstr = '<a lay-event="file" class="setBtn">文件</a>';
						if (r.backup_type == 1) {
							downstr += '&nbsp;|&nbsp;';
							downstr += '<a class="log-tooltips setBtn" title="取消备份" lay-event="close">取消</a>';
						} else if (r.backup_type == 2) {
							downstr += '&nbsp;|&nbsp;';
							downstr += '<a lay-event="open" class="log-tooltips setBtn" title="开启后为定时备份">开启</a>';
						}
						downstr += '&nbsp;|&nbsp;';
						downstr += '<a lay-event="cancel" class="log-tooltips setBtn" title="将会删除这台设备所有的备份文件">删除</a>';
						return downstr;
					}
				}
			]
		]
	});

	//批量删除
	$('.backupdel').click(function() {
		var delarr = [];
		var checkStatus = table.checkStatus(backuptable.config.id);
		checkStatus.data.forEach(function(e, i) {
			delarr.push(e.serialno);
		});
		if (delarr.length <= 0) {
			layer.msg('请先选择要删除的设备。');
			return;
		}
		layer.confirm('确认要删除这些设备吗?', {
			icon: 0,
			title: '设备删除'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=backup@remove',
				data: {
					devs: delarr
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					layer.msg('删除成功！', {
						icon: 1
					});
					search();
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});

	//行内操作
	table.on('tool(backuplist)', function(obj) {
		var checkStatus = table.checkStatus(backuptable.config.id);
		var data = obj.data;
		if (obj.event == 'file') {
			layer.open({
				type: 1,
				title: '下载列表',
				area: ['700px', '500px'],
				resize: false,
				shadeClose: true,
				btnAlign: 'c',
				content: $('#downloadlayer').html(),
				myrefresh: function(index, layero) {
					$.ajax({
						url: 'api.php?r=backup@backupfile',
						dataType: 'json',
						data: {
							serialno: data.serialno
						},
						type: 'post',
						success: function(d) {
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							table.reload('downloadlist', {
								data: d.data.rows,
							});
						}
					});
				},
				success: function(layero, index) {
					var that = this;
					table.init('downloadlist', {done: function(res, curr, count){
						layero.find('[lay-id="downloadlist"]').css('margin-top', '0px');
					}});

					that.myrefresh();

					table.on('tool(downloadlist)', function(obj) {
						var data = obj.data,
							event = obj.event,
							d = obj.rows;
						if (event == 'deldwn') {
							layer.confirm('确认要删除该备份文件吗?', {
								icon: 0,
								title: '备份文件删除'
							}, function(index) {
								$.ajax({
									url: 'api.php?r=backup@rmvfile',
									data: {
										serialno: data.filename.substring(0, 12),
										files: data.filename
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										layer.msg('删除成功！', {
											icon: 1
										});
										that.myrefresh();
									},
									error: function() {
										layer.msg('删除失败，请稍后再试。', {
											icon: 2
										});
									}
								});
								layer.close(index);
							});
						}
					});
				},
				end: function() {
					timer.rmv('downloadlist');
				}
			});
		} else if (obj.event == 'cancel') {
			layer.confirm('该操作将会删除这台设备所有的备份文件，确认要删除这台设备吗?', {
				icon: 0,
				title: '删除备份'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=backup@remove',
					data: {
						devs: data.serialno
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						layer.msg('删除成功', {
							icon: 1
						});
						table.reloadExt('backuplist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (obj.event == 'close') {
			layer.confirm('确认取消这台设备的备份吗?', {
				icon: 0,
				title: '取消备份'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=backup@stop',
					data: {
						devs: data.serialno
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (d.msg) layer.msg(d.msg, {
							// icon: 2
						});
						// if(d.ret == 0)
						// layer.msg('操作成功', {
						// 	icon: 1
						// });
						table.reloadExt('backuplist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('操作失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (obj.event == "open") {
			layer.confirm('确认开启这台设备的备份吗?', {
				icon: 0,
				title: '开启备份'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=backup@start',
					data: {
						devs: data.serialno
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (d.msg) layer.msg(d.msg, {
							// icon: 2
						});
						// if(d.ret == 0)
						// layer.msg('操作成功', {
						// 	icon: 1
						// });
						table.reloadExt('backuplist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('操作失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	form.on('select(auto-backup)', function(data) {
		$.ajax({
			url: 'api.php?r=backup@save',
			data: {
				days: $.trim($('input[name="backup_days"]').val()),
				count: $.trim($('input[name="backup_count"]').val()),
				enable: $('.auto-backup').val()
			},
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
			},
			error: function() {
				layer.msg('获取数据失败，请稍后再试。', {
					icon: 2
				});
			}
		});
		layer.close(index);
	});

	//刷新
	var auto_refresh_hd = 0;

	function auto_refresh() {
		var interval = $('select[lay-filter="auto-refresh"]').val();
		if (auto_refresh_hd) {
			clearInterval(auto_refresh_hd);
			auto_refresh_hd = 0;
		}
		var tm = Number(interval);
		if (tm)
			auto_refresh_hd = setInterval(function() {
				if(isHiddenMyView()) return;
				var checkStatus = table.checkStatus(backuptable.config.id);
				if (!checkStatus.data.length)
					search(-1);
			}, tm * 1000);
	}
	auto_refresh();

	form.on('select(auto-refresh)', function(data) {
		auto_refresh();
	});

	form.on('select(filter-group)', function(data){
		search(1);
	});

	//搜索
	function search(page, obj) {
		var table = layui.table;
		var grpid = Number($('select[lay-filter="filter-group"]').val());
		var where = {
			grpid: 0,
			keyword: $.trim($('#backuptool input[name="keyword"]').val()),
			// sort: 'serialno',
			g_ascdesc: 'asc',
			expire: 0,
		};
		if (grpid) where.grpid = grpid;

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				};
		} else
			page = 0;

		table.reloadExt('backuplist', option);
		if (page >= 0)
			auto_refresh();
	}

	//添加备份搜索
	function search_backup(page, obj) {
		var table = layui.table;
		var grpid = Number($('.pupgrplist').val());
		var version = Number($('.versiongrp').val());
		var txt = $('.backey').val();
		var arr = [];
		if (version == "0" || version == null) version = "";
		if (version != "") arr.push(version);
		if (txt != "")
			arr.push(txt);
		var where = {
			grpid: grpid,
			keyword: arr.join('|'),
			sort: 'serialno',
			g_ascdesc: 'asc',
			expire: 2,
		};
		if (grpid) where.grpid = grpid;
		if (version) where.version = version;

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				};
		} else
			page = 0;

		table.reloadExt('new-backuplist', option);
	}

	$('.searchbackup').click(function() {
		search(1);
	});

	$('.form-group-text').keyup(function(event) {
		if (event.keyCode == 13) {
			search(1);
		}
	});

	$('.addbackup').on('click', function() {
		//添加备份
		layer.open({
			type: 1,
			title: '添加备份',
			shadeClose: true,
			area: ['855px', '550px'],
			content: $('#add-backup').html(),
			success: function(layero, index) {
				$(".bakcup-settime").hide();
				form.render();

				form.on('radio(backuptype)', function(data) {
					var v = data.value;
					if (v == "1") {
						$(".bakcup-settime").show();
						$(".backupbtn").text("稍后备份");
					} else {
						$(".bakcup-settime").hide();
						$(".backupbtn").text("立即备份");
					}
					form.render("radio");
				});

				$('.backupbtn').click(function(data) {
					var devs = [];
					var seg = $('.seg').val();
					var type;
					$(".layui-form-radio").each(function() {
						if ($(this).hasClass("layui-form-radioed"))
							type = $(this).prev().val();
					});
					var checkStatus = table.checkStatus('new-backuplist');
					checkStatus.data.forEach(function(e, i) {
						var obj = {
							s: e.serialno,
							n: e.name,
							g: e.grpid
						}
						devs.push(obj);
					});
					if (devs.length <= 0) {
						layer.msg("请选择要备份的设备");
						return;
					}

					layer.confirm("确定需要备份这些设备吗？", {
						btn: ['确定', '取消']
					}, function(index) {
						$.ajax({
							url: 'api.php?r=backup@create',
							data: {
								type: type,
								seg: seg,
								devs: devs,
							},
							dataType: 'json',
							type: 'post',
							success: function(data) {
								if (data.res == 0) {
									layer.alert('配置成功！');
								} else {
									layer.alert(data.msg);
								}
								table.reloadExt('backuplist', {
									page: {
										curr: 1
									}
								});
							}
						});
					});
				});

				$('.search-list').click(function() {
					search_backup(1);
				});

				$('.backey').keyup(function(event) {
					if (event.keyCode == 13) {
						$('.search-list').click();
					}
				});

				form.on('select(backgrp)', function(data) {
					search_backup(1);
				});

				form.on('select(filter-version)', function(data) {
					search_backup(1);
				});

				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="backgrp"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="backgrp"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
					}
				});

				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="backgrp"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="backgrp"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
					}
				});

				table.render({
					elem: '#new-backuplist',
					url: 'api.php?r=gateway@devlist',
					method: 'post',
					even: true,
					limit: 10,
					skin: 'line',
					success: function() {
						getVgrp();
					},
					where: {
						page: 1,
						limit: 10,
						grpid: -1,
						keyword: '',
						sort: 'serialno',
						g_ascdesc: 'asc',
						expire: 2
					},
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3
					},
					parseData: function(res) {
						var data = res.data.rows;
						if (res.ret == 0) {
							res.count = res.data.total;
							res.data = res.data.rows;
						}
						res.code = res.ret;
						res.msg = res.msg;
					},
					done: function(res, curr, count) {
					},
					cols: [
						[{
								field: 'id',
								title: '序号',
								width: 27,
								fixed: 'left',
								type: 'numbers'
							},
							{
								type: 'checkbox',
								width: 25
							}, {
								field: 'serialno',
								title: '设备编号',
								width: 105
							}, {
								field: 'name',
								title: '设备名称',
								width: 190
							}, {
								title: '所属组',
								width: 98,
								templet: function(d) {
									var grpname;
									if (d.grpid == 0) return '';
									grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
									return grpname;
								}
							}, {
								field: 'version',
								title: '当前版本',
								width: 172
							}
						]
					]
				});
			}
		});

		function getVgrp() {
			$.ajax({
				url: 'api.php?r=gateway@devlist',
				type: 'post',
				success: function(d) {
					var data = d.data.rows;
					var varr = [];
					for (var i = 0; i < data.length; i++) {
						if (varr.indexOf(data[i].version) == -1) {
							varr.push(data[i].version);
						}
					}
					varr.sort(function(a, b) {
						var a1, ax1 = a.split(',');
						var b1, bx1 = b.split(',');
						a1 = ax1.length > 1 ? ax1[1] : ax1[0];
						b1 = bx1.length > 1 ? bx1[1] : bx1[0];
						return (a1 < b1 ? 1 : (a1 == b1 ? 0 : -1));
					});
					$('.versiongrp option').not('[value=0]').remove();
					for (i = 0; i < varr.length; i++)
						$('.versiongrp').append(new Option(varr[i]));
					form.render('select');
				}
			});
		}
		getVgrp();
	});

	//备份配置
	$('.backupcfg').click(function() {
		$.ajax({
			url: 'api.php?r=backup@option',
			type: 'post',
			dataType: 'json',
			success(d) {
				$('input[name="backup_days"]').val(d.data.days);
				$('input[name="backup_count"]').val(d.data.count);
				$('.auto-backup').val(d.data.enable);
				form.render('select');
			}
		});
	});
	
	$('.savebtn').click(function() {
		var days = $('input[name="backup_days"]').val();
		var count = $('input[name="backup_count"]').val();
		layer.confirm('确认要修改备份配置吗?', {
			icon: 0,
			title: '配置修改'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=backup@save',
				data: {
					days: days,
					count: count,
					enable: $('.auto-backup').val()
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});
});
