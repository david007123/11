<?php
namespace cloud\apps\backup;


function select($data)
{
	global $nidb, $user;


	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$keyword = iconv("utf-8", "gbk", $optional['keyword']);
			$where_str .= "(`license_id12` like ? or `cname` like ? or `cname` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $keyword . "%");
		}
	}

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
		if(!empty($optional['grpid']))
			$where_str .= '`grpid` in (' . $optional['grpid'] . ') and ';
	}
	else {
		if (is_supadmin($user->username)) {
			if($optional['grpid'] == 0)
				$where_str .= '(grpid = 0 or grpid = 10000) and ';
			else
			if($optional['grpid'] > 0)
				$where_str .= 'grpid = ' . $optional['grpid'] . ' and ';
		}
		else {
			if($user->grp == '')
				return array(
					'total' => 0,
					'rows'	=> array()
				);
			if($optional['grpid'] <= 0)
				$where_str .= "grpid in ({$user->grp}) and ";
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return array(
						'total' => 0,
						'rows'	=> array()
					);
				}
				$where_str .= "grpid = {$optional['grpid']} and ";
			}
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$order_map = array(
		"license_id12",
		"cname",
		"backup_time",
		"fnum",
		"grpid",
		"errors",
		"backup_type",
		"backup_nexttime",
		"complete",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}
	
	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by backup_time desc';

	$sql = "select count(*) as `total` from cloud_backup $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`license_id12` as `serialno`,
		`cname`,
		`backup_time`,
		`fnum`,
		`grpid`,
		`errors`,
		`backup_type`,
		`backup_nexttime`,
		`complete`';

	$sql = "select $keys from cloud_backup $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$now = time();
	foreach($rows as $key => $val) {
		$rows[$key]->serialno = to_utf8($val->serialno);
		$rows[$key]->cname = to_utf8($val->cname);
//		$rows[$key]->updesc = to_utf8($val->updesc);
//		$rows[$key]->errors = to_utf8($val->errors);
		$rows[$key]->upgrade_start = intval($val->upgrade_start);
		$rows[$key]->now 	= $now;
	}

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function option()
{
	$ret = array("enable"=>0, "days"=>0, "count"=>15);

	$data = myconf_read(CLOUD_CONF, array("backup_auto", "backup_days", "backup_count"));

	if(isset($data['backup_auto']))
		$ret['enable'] = intval($data['backup_auto']);
	if(isset($data['backup_days']))
		$ret['days'] = intval($data['backup_days']);
	if(isset($data['backup_count']))
		$ret['count'] = intval($data['backup_count']);

	return $ret;
}

function save($data)
{
	global $nidb, $user;

	$optional = array();

	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	format_and_push($data, 'enable', $optional, 'backup_auto', 'int', true);
	format_and_push($data, 'days', $optional, 'backup_days', 'int', true);
	format_and_push($data, 'count', $optional, 'backup_count', 'int', true);

	if(count($optional) == 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无修改内容。');
		return false;
	}

	return myconf_save(CLOUD_CONF, $optional);
}

function create($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	$optional = array();
	$backuptype = array('立即备份', '定时备份');

	if(format_and_push($data, 'type', $optional, '', 'int', false) == false) 
		$optional['type'] = 0;
	else
	if(isset($backuptype[$optional['type']]) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择一个有效的备份方式。');
		return false;
	}

	if(format_and_push($data, 'seg', $optional, '', 'int', false) == false)
		$optional['seg'] = 3;

	if(isset($data['devs']) == false || is_array($data['devs']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	$devs = array();
	foreach($data['devs'] as $val) {
		
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $val['s'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$val['s']}”不正确！");
			return false;
		}
		
		if(isset($val['n']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "“{$val['s']}”的设备名称不能为空！");
			return false;
		}
		
		if(isset($val['g']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "“{$val['s']}”的归属组不能为空！");
			return false;
		}
		
		array_push($devs, array(
			'serialno'	=> $val['s'],
			'name'		=> iconv('utf-8', 'gbk', $val['n']),
			'grpid'		=> intval($val['g'])
		));

	}

	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	$nexttime = time() + $optional['seg'] * 86400;

	try {
		foreach($devs as $dev) {

			$sql = "select license_id12 from cloud_backup where license_id12 = ? limit 1";

			$sth = $nidb->prepare($sql);
			$sth->bindParam(1, $dev['serialno'], \PDO::PARAM_STR);
			$sth->execute();
			$row = $sth->fetch(\PDO::FETCH_ASSOC);

			$frmData = array(
				'backup_type'	=> $optional['type'],
				'backup_seg'	=> $optional['seg'],
				'backup_nexttime'=>$nexttime,
				'complete'		=> 0,
				'grpid'			=> $dev['grpid'],
				'errors'		=> 'wait'
			);

			if(!$row) {
				/*
				 * Create task
				 */
				$frmData['cname']			= $dev['name'];
				$frmData['license_id12']	= $dev['serialno'];
				$frmData['backup_time']		= 0;
				$frmData['backup_ctime']	= 0;
				$frmData['fnum']			= 0;
				
				if(insert_data('cloud_backup', $frmData) === false) {
					$errmsg = implode(' ', $nidb->errorInfo());
					set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
					return false;
				}
			}
			else {
				if(update_data('cloud_backup', $frmData, array('license_id12' => $dev['serialno'])) === false) {
					$errmsg = implode(' ', $nidb->errorInfo());
					set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
					return false;
				}
			}
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function remove($data)
{
	global $nidb, $user;
	
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	if(isset($data['devs']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的设备不能为空。');
		return false;
	}
	if(is_array($data['devs']) === false) {
		if(empty($data['devs']) || gettype($data['devs']) != 'string') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要删除的设备。');
			return false;
		}

		$data['devs'] = array($data['devs']);
	}

	$devs = array();
	foreach($data['devs'] as $serialno) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
			return false;
		}
		array_push($devs, $serialno);
	}

	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '删除设备不能为空，请选择要删除的设备。');
		return false;
	}
	
	$str = "?";
	if(count($devs) > 1)
		$str.= str_repeat(',?', count($devs) - 1);

	try {
		$sql = "delete from cloud_backup where license_id12 in ({$str})";
		$sth = $nidb->prepare($sql);
		// $sth->bindParam(1, $serialno, \PDO::PARAM_STR);
		$sth->execute($devs);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if ($dh = opendir(CLOUD_BACKUP_PATH)){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				$filename = CLOUD_BACKUP_PATH . '/' . $file;
				if (is_file($filename)) {
					foreach($devs as $serialno) {
						if(strpos($file, $serialno) === 0) {
							unlink($filename);
						}
					}
				}
			}
		}
		closedir($dh);
	}

	//foreach($devs as $serialno) 
	//	exec('find ' . CLOUD_BACKUP_PATH . ' -depth 1 -type f -name "' . $serialno . '_*.tar.gz" -exec rm -f {} \;');

	return true;
}

function enable($data)
{
	global $nidb, $user;
	

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	if(isset($data['enable']) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '请指定要执行的动作！');
		return false;
	}
	if(intval($data['enable']))
		$enable = 1;
	else
		$enable = 2;

	if(isset($data['devs']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要操作的设备不能为空。');
		return false;
	}
	if(is_array($data['devs']) === false) {
		if(empty($data['devs']) || gettype($data['devs']) != 'string') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要操作的设备。');
			return false;
		}

		$data['devs'] = array($data['devs']);
	}

	$devs = array();
	foreach($data['devs'] as $serialno) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
			return false;
		}
		array_push($devs, $serialno);
	}

	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备不能为空，请选择要操作的设备。');
		return false;
	}
	
	$str = "?";
	if(count($devs) > 1)
		$str.= str_repeat(',?', count($devs) - 1);

	try {
		$sql = "update cloud_backup set backup_type = {$enable} where license_id12 in ({$str})";
		$sth = $nidb->prepare($sql);
		// $sth->bindParam(1, $serialno, \PDO::PARAM_STR);
		$sth->execute($devs);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function backupfile($data)
{
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	if(format_and_push($data, 'serialno', $optional, '', 'string', true) === false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '要查看的设备不能为空！');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}

	if (!file_exists(CLOUD_BACKUP_PATH))
		mkdir(CLOUD_BACKUP_PATH);
	
	$ret = array(
		'total'	=> 0,
		'rows'	=> array()
	);
	$dts = array();

	$dir = opendir(CLOUD_BACKUP_PATH);
	if ($dir) {
		while (($file = readdir($dir)) != false) {
			if (strstr($file, $optional['serialno']) != false) {
				$size = filesize(CLOUD_BACKUP_PATH . "/" . $file);
				
				$i = strpos($file, "_");
				$dt = strtotime(substr($file, $i+1, 14));
				
				array_push($ret['rows'], array(
					"filename"	=> $file,
					"size"		=> $size,
					"dt"		=> $dt
				));
				array_push($dts, $dt);
			}
		}
		closedir($dir);
	}

	array_multisort($dts, SORT_DESC, $ret['rows']);

	$ret['total'] = count($ret['rows']);

	return $ret;
}

function rmvfile($data)
{
	global $nidb, $user;

	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	if(format_and_push($data, 'serialno', $optional, '', 'string', true) === false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '设备编号不能为空！');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}

	if(isset($data['files']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的文件不能为空。');
		return false;
	}
	if(is_array($data['files']) === false) {
		if(empty($data['files']) || gettype($data['files']) != 'string') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要删除的文件。');
			return false;
		}

		$data['files'] = array($data['files']);
	}

	$delcnt = 0;
	foreach($data['files'] as $fname) {
		if (file_exists(CLOUD_BACKUP_PATH . "/" . $fname)) {
			unlink(CLOUD_BACKUP_PATH . "/" . $fname);
			$delcnt++;
		}
	}

	// count backupfile
	$fcnt = 0;
	if ($dh = opendir(CLOUD_BACKUP_PATH)){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				if (is_file($path . '/' . $file) && strpos($file, $optional['serialno']) === 0) 
					$fcnt++;
			}
		}
		closedir($dh);
	}


	try {
		$sql = "update cloud_backup set fnum = ? where license_id12 = ?";
		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $fcnt, \PDO::PARAM_INT);
		$sth->bindParam(2, $optional['serialno'], \PDO::PARAM_STR);
		$sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return $fcnt;
}

function getfile($data)
{
	$optional = array();


	if(format_and_push($data, 'file', $optional, '', 'string', true) === false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的文件不能为空！');
		return false;
	}

	$filename = CLOUD_BACKUP_PATH . "/" . $optional['file'];
	
	if(file_exists($filename) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的文件不存在！');
		return false;
	}

	return $filename;
}

function currcnt($data)
{
	global $nidb, $user;

	
	$values = array();
	$optional = array();

	$where_str = 'complete=0 or backup_type=1 and ';
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false) {
		$optional['grpid'] = -1;
	}

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid']);
		if($optional['grpid'] === false)
			return 0;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return 0;

		if($optional['grpid'])
			$where_str = "`grpid` in ({$optional['grpid']}) and ";
	}
	else {
		if (is_supadmin($user->username)) {
			if($optional['grpid'] == 0)
				$where_str = '(grpid = 0 or grpid = 10000) and ';
			else
			if($optional['grpid'] > 0)
				$where_str = 'grpid = ' . $optional['grpid'] . ' and ';
		}
		else {
			if($user->grp == '')
				return 0;
			if($optional['grpid'] <= 0)
				$where_str .= "grpid in ({$user->grp}) and ";
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return 0;
				}
				$where_str .= "grpid = {$optional['grpid']} and ";
			}
		}
	}
	
	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_backup $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(!$row) return 0;
	
	return $row['total'];
}
