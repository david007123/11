<?php
namespace cloud\apps\backup;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

// header("Content-type: application/json; charset=" . WEB_CHARSET);

// 支持库装载 | load lib
// ni_library_load('nidb');

// 装载功能 | load function
ni_app_load('user', 'login');
ni_app_load($appname, 'backup');


// 验证用户 | auth user
\cloud\apps\user\auth_json_exit();


// 执行 | exec function
$file = getfile($_REQUEST);

// 结果输出 | printf result
if($file === false) {
	$file =  'err.log';
	file_put_contents($file, get_errmsg(''));
}

//	json_error_exit(ERR_FAILURE, '获取失败！');

/* 
简述: ob_end_clean() 清空并关闭输出缓冲, 详见手册 
说明: 关闭输出缓冲, 使文件片段内容读取至内存后即被送出, 减少资源消耗 
*/ 
ob_end_clean(); 
/* 
HTTP头信息: 指示客户机可以接收生存期不大于指定时间（秒）的响应 
*/ 
header('Cache-control: max-age=31536000'); 
/* 
HTTP头信息: 缓存文件过期时间(格林威治标准时) 
*/ 
header('Expires: ' . gmdate('D, d M Y H:i:s', time()+31536000) . ' GMT'); 
/* 
HTTP头信息: 文件在服务期端最后被修改的时间 
Cache-control,Expires,Last-Modified 都是控制浏览器缓存的头信息 
在一些访问量巨大的门户, 合理的设置缓存能够避免过多的服务器请求, 一定程度下缓解服务器的压力 
*/ 
header('Last-Modified: ' . gmdate('D, d M Y H:i:s' , filemtime($file) . ' GMT')); 
/* 
HTTP头信息: 文档的编码(Encode)方法, 因为附件请求的文件多样化, 改变编码方式有可能损坏文件, 故为none 
*/ 
header('Content-Encoding: none'); 
/* 
HTTP头信息: 告诉浏览器当前请求的文件类型. 
1.始终指定为application/octet-stream, 就代表文件是二进制流, 始终提示下载. 
2.指定对应的类型, 如请求的是mp3文件, 对应的MIME类型是audio/mpeg, IE就会自动启动Windows Media Player进行播放. 
*/ 
header('Content-type: application/octet-stream'); 
/* 
HTTP头信息: 如果为attachment, 则告诉浏览器, 在访问时弹出”文件下载”对话框, 并指定保存时文件的默认名称(可以与服务器的文件名不同) 
如果要让浏览器直接显示内容, 则要指定为inline, 如图片, 文本 
*/
$uage = $_SERVER["HTTP_USER_AGENT"];
if (preg_match("/Firefox/", $uage)) 
	header('Content-Disposition: attachment; filename*="utf8\'\'' . basename($file) . '"');
else 
	header('Content-Disposition: attachment; filename="' . basename($file) . '"'); 

/* 
HTTP头信息: 告诉浏览器文件长度 
(IE下载文件的时候不是有文件大小信息么?) 
*/ 
header('Content-Length: ' . filesize($file)); 

if($fp = fopen($file, 'rb')) {
	fpassthru($fp);
	fclose($fd);
}