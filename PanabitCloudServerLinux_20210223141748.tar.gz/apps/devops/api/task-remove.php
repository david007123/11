<?php
namespace cloud\apps\devops;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

header("Content-type: application/json; charset=" . WEB_CHARSET);

// 支持库装载 | load lib
// ni_library_load('nidb');

// 装载功能 | load function
ni_app_load('user', 'login');
ni_app_load($appname, 'task');


// 验证用户 | auth user
\cloud\apps\user\auth_json_exit();


// 执行 | exec function
$result = del($_REQUEST);


// 结果输出 | printf result
if($result === false)
	json_error_exit(ERR_FAILURE);
else
	json_error_exit(ERR_OK, '', $result);
