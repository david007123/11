<?php
/*
 * 该文件来自 task.php?r=fetch 的请求回调
 * 用于响应客户端的任务请求，将对应的客户端任务下发给客户端。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $_REQUEST 附加数据，可从这里取
 *
 */

// 检查最大任务数
if(maxdown_check('task') <= 0) {
	echo "ret_code=1\n";
	echo "ret_msg=NOTASK\n";
	exit;
}

// 数据库加载
require_once(ROOT_DIR . '/ni-core/class/ni_db.php');
require_once(ROOT_DIR . '/conf/db.php');

$sql = "select `task_id`, `stat`, `tool`, `toolver`, `plan_tm`, `param_md5`";
$sql.= " from cloud_platform.devops_process";
$sql.= " where `keyno` = ? and `stat` < 6 order by `failcnt` asc limit 1";

try {
	$sth = $nidb->prepare($sql);
	$sth->bindParam(1, $keyno, PDO::PARAM_STR);
	$sth->execute();

	$row = $sth->fetch(PDO::FETCH_ASSOC);
}
catch (NiDBException $e) {
	echo "ret_code=10000\n";
	echo "ret_msg=ERRSQL\n";
	exit;
}

if(!$row) {
	echo "ret_code=1\n";
	echo "ret_msg=NOTASK\n";
	exec(DATAEYE . " device set license_id12={$keyno} task_signal=0");
	exit;
}

// 检查任务更新是否超
$sql = "select count(*) as `count` from cloud_platform.devops_process";
$sql.= " where `stat` > 0 and `stat` < 6 order by `failcnt` asc limit 1";

try {
	$sth = $nidb->prepare($sql);
	$sth->bindParam(1, $keyno, PDO::PARAM_STR);
	$sth->execute();

	$downcnt = $sth->fetch(PDO::FETCH_ASSOC);
}
catch (NiDBException $e) {
	echo "ret_code=10000\n";
	echo "ret_msg=ERRSQL\n";
	exit;
}
if(!$downcnt) {
	echo "ret_code=1000\n";
	echo "ret_msg=GET_CURRDOWN_ERR\n";
	exit;
}
if($downcnt['count'] >= maxdown_get()) {
	echo "ret_code=1001\n";
	echo "ret_msg=MAXDOWN\n";
	exit;
}

$http = "http";
if(isset($_SERVER['REQUEST_SCHEME'])
&& intval($_SERVER['REQUEST_SCHEME']))
	$http = $_SERVER['REQUEST_SCHEME'];
else
if(isset($_SERVER['HTTP_UPGRADE_INSECURE_REQUESTS'])
	&& intval($_SERVER['HTTP_UPGRADE_INSECURE_REQUESTS'])) {
		$http = "https";
}
else
if(isset($_SERVER['SERVER_PORT'])
	&& intval($_SERVER['SERVER_PORT']) == 443) {
		$http = "https";
}
$url_path = $http . "://" . $_SERVER['HTTP_HOST'];

$tool_url = "{$url_path}/devops/tool/{$row['tool']}/down/{$row['toolver']}.tar.gz";
$param_url = "{$url_path}/devops/task/{$keyno}/{$row['task_id']}/param.dat";

if(($left_time = $row['plan_tm'] - time()) < 0)
	$left_time = 0;

$toolver = $row['toolver'];
if($row['tool'] == $toolver)
	$toolver = '';


// 输出结果
$task_content = "ret_code=0\n";
$task_content.= "ret_msg=\n";
$task_content.= "task_id={$row['task_id']}\n";
$task_content.= "task_type=\n";
$task_content.= "task_tag=\n";
$task_content.= "task_token=\n";
$task_content.= "task_plan={$left_time}\n";
$task_content.= "tool_name={$row['tool']}\n";
$task_content.= "tool_ver={$toolver}\n";
$task_content.= "tool_url={$tool_url}\n";
$task_content.= "param_md5={$row['param_md5']}\n";
$task_content.= "param_url={$param_url}\n";

if($row['stat'] == 0) {

	$ftask = OPSTASK_DIR . "/{$keyno}/{$row['task_id']}/task.conf";
	if(!file_put_contents($ftask, $task_content)) {
		echo "ret_code=1\n";
		echo "ret_msg=WRITE_TASK_FILE_ERR\n";
	}

	// 更新状态任务状态
	// 任务状态；0：等待开始，1：检查任务，2：检查工具：3：检查参数；
	// 			 4：计划等待，5：执行任务，6：任务取消，7：执行失败，8：执行成功。
	$sql = "update cloud_platform.devops_process";
	$sql.= " set `stat` = 1, `stime` = " . time();
	$sql.= " where `keyno` = ? and `task_id` = ?";

	try {
		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $keyno, PDO::PARAM_STR);
		$sth->bindParam(2, $row['task_id'], PDO::PARAM_INT);
		$sth->execute();
	}
	catch (NiDBException $e) {
		exit;
	}
}

echo $task_content;
