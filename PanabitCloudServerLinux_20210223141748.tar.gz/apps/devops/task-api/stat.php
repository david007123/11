<?php
/*
 * 该文件来自 task.php?r=stat 的请求回调
 * 用于响应客户端的任务请求，更新客户端执行任务的状态。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $_REQUEST 附加数据，可从这里取
 *
 */
 
if(!isset($_REQUEST['code'])
|| ($stat = intval($_REQUEST['code'])) < 2 || $stat > 5)
	exit;

if(!isset($_REQUEST['task_id'])
|| ($task_id = intval($_REQUEST['task_id'])) <= 0)
	exit;

// 数据库加载
require_once(ROOT_DIR . '/ni-core/class/ni_db.php');
require_once(ROOT_DIR . '/conf/db.php');

// 更新状态任务状态
// 任务状态；0：等待开始，1：检查任务，2：检查工具：3：检查参数；
// 			 4：计划等待，5：执行任务，6：任务取消，7：执行失败，8：执行成功。
$sql = "update cloud_platform.devops_process";
$sql.= " set `stat` = ?";
$sql.= " where `keyno` = ? and `task_id` = ?";

try {
	$sth = $nidb->prepare($sql);
	$sth->bindParam(1, $stat, PDO::PARAM_INT);
	$sth->bindParam(2, $keyno, PDO::PARAM_STR);
	$sth->bindParam(3, $task_id, PDO::PARAM_INT);
	if($sth->execute())
		echo "OK";
	else
		echo "ERRSQL";
}
catch (NiDBException $e) {
	echo $e->getMessage();
}
