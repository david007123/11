<?php
/*
 * 该文件来自 task.php?r=result 的请求回调
 * 用于响应客户端的任务请求，保存客户端执行任务过程中产生的报告和结果。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $_REQUEST 附加数据，可从这里取
 *
 */
 
// 读取配置文件
function the_conf_read($file, $data = array())
{
	$ret = array();
	
	if(is_array($data) == false)
		$data = array();

	if (!file_exists($file)) 
		return $ret;

	if ($fp = fopen($file, "r")) {
		$cnt = 0;
		$keycnt = count($data);
		while (!feof($fp)) {
			if(empty($buf = trim(fgets($fp))))
				continue;

			$col = explode('=', $buf, 2);
			if(count($col) != 2)
				continue;
			$key = trim($col[0]);
			if(strpos($key, ' ') !== false)
				continue;

			if($keycnt && in_array($key, $data) == false)
				continue;

			$ret[$key] = trim($col[1]);
			$cnt++;
			if($cnt == $keycnt) break;
		}
		fclose($fp);
	}

	return $ret;
}

// 检查是否有文件上传
function check_result_file($keyno, $task_id, $code, &$msg)
{
	if(!isset($_FILES['file']))
		return false;

	$upfile = $_FILES['file'];
	$result_file = $upfile['tmp_name'];
	if(file_exists($result_file) == false) {
		if(!empty($msg)) $msg.=" ";
		$msg .= "找不到上传的文件！error：" . $upfile['error'];
		return false;
	}

	$task = OPSTASK_DIR . "/{$keyno}/{$task_id}/task.conf";
	$info = the_conf_read($task, array('tool_name'));
	if(!isset($info['tool_name']) || empty($info['tool_name']))  {
		if(!empty($msg)) $msg.=" ";
		$msg .= "“task.conf”中未找到运维工具。";
		unlink($result_file);
		return false;
	}
	$page_file = OPSTOOL_DIR . "/{$info['tool_name']}/result.php";
	if(file_exists($page_file)) {
		require_once($page_file);
		if(file_exists($result_file))
			unlink($result_file);
	}
	else {
		$dir = OPSTASK_DIR . "/{$keyno}/{$task_id}";
		move_uploaded_file($result_file, "{$dir}/result.dat");
	}
	
	return true;
}

if(!isset($_REQUEST['code']))
	exit;

$code = intval($_REQUEST['code']);
$stat = ($code? 7 : 8);

if(!isset($_REQUEST['task_id'])
|| ($task_id = intval($_REQUEST['task_id'])) <= 0)
	exit;

if(isset($_REQUEST['msg']))
	$msg = trim($_REQUEST['msg']);
else
	$msg = "";

check_result_file($keyno, $task_id, $code, $msg);
if(strlen($msg) > 255)
	$msg = substr($msg, 0, 255);

// 数据库加载
require_once(ROOT_DIR . '/ni-core/class/ni_db.php');
require_once(ROOT_DIR . '/conf/db.php');

// 更新状态任务状态
// 任务状态；0：等待开始，1：检查任务，2：检查工具：3：检查参数；
// 			 4：计划等待，5：执行任务，6：任务取消，7：执行失败，8：执行成功。
$sql = "update cloud_platform.devops_process";
$sql.= " set `stat` = {$stat}, `code` = {$code}, `msg` = ?, `finishtm` = " . time();
if($code)
	$sql.= ", `failcnt` = `failcnt` + 1";
$sql.= " where `keyno` = ? and `task_id` = ?";

$msg = iconv("gbk", "utf-8//translit", $msg);
try {
	$sth = $nidb->prepare($sql);
	$sth->bindParam(1, $msg, PDO::PARAM_STR);
	$sth->bindParam(2, $keyno, PDO::PARAM_STR);
	$sth->bindParam(3, $task_id, PDO::PARAM_INT);
	if(!$sth->execute()) {
		echo "ERRSQL";
		exit;
	}
}
catch (NiDBException $e) {
	echo $e->getMessage();
	exit;
}

// 更新任务状态
$sql = "update cloud_platform.devops_task as `a`";
$sql.= " inner join (";
$sql.= " select `task_id`, sum(if(`stat` = 7, 1, 0)) as `fail`, sum(if(`stat` = 8, 1, 0)) as `pass`";
$sql.= " from cloud_platform.devops_process where `task_id` = {$task_id}";
$sql.= " ) as b";
$sql.= " on a.`task_id` = b.`task_id`";
$sql.= " set a.`fail` = b.`fail`, a.`pass` = b.`pass`,";
$sql.= " a.`finishtm` = if(a.`devs` <= (b.`fail` + b.`pass`), " . time() . ", 0)";
$sql.= " where a.`task_id` = {$task_id}";

try {
	$sth = $nidb->prepare($sql);
	$sth->bindParam(1, $msg, PDO::PARAM_STR);
	$sth->bindParam(2, $keyno, PDO::PARAM_STR);
	if(!$sth->execute()) {
		echo "ERRSQL";
		exit;
	}
}
catch (NiDBException $e) {
	echo $e->getMessage();
	exit;
}

echo "OK";
