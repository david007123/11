<?php
/*
 * 该文件来自 task.php?r=collection 的请求回调
 * 用于响应客户端的请求转发处理，将请求再转发到目的响应文件上。
 *
 * 已解析的参数有：
 * $apiname 功能名称
 * $keyno 12位授权编号 
 * $_REQUEST 附加数据，可从这里取
 *
 */
defined('DEVOPS_DIR') or exit;

if(!isset($_REQUEST['name'])
|| empty($name = trim($_REQUEST['name'])))
	exit;

if(!isset($_REQUEST['act'])
|| empty($act = trim($_REQUEST['act'])))
	exit;


if(isset($_REQUEST['token'])) {
	$token = trim($_REQUEST['token']);
	if(preg_match("/^([a-zA-Z0-9-_]{1,})$/", $token, $match) == false)
		$token = '';
} else
	$token = '';

$opssvc_page = ROOT_DIR . "/apps/{$name}/collection/{$act}.php";
if(file_exists($opssvc_page) === false)
	exit;

require_once($opssvc_page);
