<?php
/*
 * 该文件来自 task.php?r=report 的请求回调
 * 用于响应客户端的任务请求，保存客户端执行任务过程中产生的报告。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $_REQUEST 附加数据，可从这里取
 *
 */
 
// 读取配置文件
function the_conf_read($file, $data = array())
{
	$ret = array();
	
	if(is_array($data) == false)
		$data = array();

	if (!file_exists($file)) 
		return $ret;

	if ($fp = fopen($file, "r")) {
		$cnt = 0;
		$keycnt = count($data);
		while (!feof($fp)) {
			if(($buf = fgets($fp)) === false)
				break;

			if(empty($buf = trim($buf, " \t\n\r\0\x0B")))
				continue;

			$col = explode('=', $buf, 2);
			if(count($col) != 2)
				continue;
			$key = trim($col[0]);
			if(strpos($key, ' ') !== false)
				continue;

			if($keycnt && in_array($key, $data) == false)
				continue;

			$ret[$key] = trim($col[1]);
			$cnt++;
			if($cnt == $keycnt) break;
		}
		fclose($fp);
	}

	return $ret;
}

// 检查是否有文件上传
function check_report_file($keyno, $task_id, $code, &$msg)
{
	if(!isset($_FILES['report_file']))
		return false;

	$upfile = $_FILES['report_file'];
	$report_file = $upfile['tmp_name'];
	if(file_exists($report_file) == false) {
		if(!empty($msg)) $msg.=" ";
		$msg .= "找不到上传的文件！error：" . $upfile['error'];
		return false;
	}
	
	$task = OPSTASK_DIR . "/{$keyno}/{$task_id}/task.conf";
	$info = the_conf_read($task, array('tool_name'));
	if(!isset($info['tool_name']) || empty($info['tool_name']))  {
		if(!empty($msg)) $msg.=" ";
		$msg .= "“task.conf”中未找到运维工具。";
		unlink($report_file);
		return false;
	}

	$page_file = OPSTOOL_DIR . "/{$info['tool_name']}/report.php";
	if(file_exists($page_file)) {
		require_once($page_file);
		if(file_exists($report_file))
			unlink($report_file);
	}
	else {
		$dir = OPSTASK_DIR . "/{$keyno}/{$task_id}";
		move_uploaded_file($report_file, "{$dir}/result.dat");
	}
	
	return true;
}

if(!isset($_REQUEST['code']))
	exit;

$code = intval($_REQUEST['code']);
// $stat = ($code? 7 : 8);

if(!isset($_REQUEST['task_id'])
|| ($task_id = intval($_REQUEST['task_id'])) <= 0)
	exit;

if(isset($_REQUEST['msg'])
	$msg = trim($_REQUEST['msg']);
else
	$msg = "";

check_report_file($keyno, $task_id, $code, $msg);
