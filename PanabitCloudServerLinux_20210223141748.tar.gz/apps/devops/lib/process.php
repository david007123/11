<?php
namespace cloud\apps\devops\process;


function select($data)
{
	global $nidb, $user;


	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);
	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';

	if(format_and_push($data, 'task_id', $optional, '', 'int', false) === false)
		$optional['task_id'] = 0;
	
	if($optional['task_id'])
		$where_str .= "`task_id` = {$optional['task_id']} and ";

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false)
		$wkpid = \cloud\apps\work\project\project_enable();
	else
		$wkpid = $optional['wkpid'];

//	if($wkpid) 
//		$where_str .= "`wkpid` = {$wkpid} and ";
//	if(!is_supadmin($user->username)) {
//		if($wkpid == 0) {
//			$wkpids = \cloud\apps\work\project\get_work_for_user($user->username);
//			if($wkpids) // return $result;
//				$where_str .= "`wkpid` in ({$wkpids}) and ";
//		}
//	}

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`tool` like ? or `devops` like ? or `operator` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"task_id",
		"tool",
		"keyno",
		"stat",
		"ret",
		"name",
		"finishtm",
		"stime"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.devops_process";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
	}
	
	$key = "`task_id`,`tool`,`keyno`,`stat`,`code`,`name`,`msg`,`finishtm`,`stime`";
	$sql = "select {$key} from cloud_platform.devops_process";
	$sql.= " {$where_str} {$order_by} limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function save($data)
{
	global $nidb, $user;

	
	if(isset($data['keyno']) == false || empty(($data['keyno'] = trim($data['keyno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12,})$/", $data['keyno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['task_id']) == false || ($data['task_id'] = intval($data['task_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无效的任务。');
		return false;
	}
	
	if(isset($data['act']) == false || empty(($data['act'] = trim($data['act'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无效的请求。');
		return false;
	}

	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	try {
		$sql = "select `stat` from cloud_platform.devops_process";
		$sql.= " where keyno = ? and `task_id` = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $data['keyno'], \PDO::PARAM_STR);
		$sth->bindParam(2, $data['task_id'], \PDO::PARAM_INT);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '找不到此设备任务。');
		return false;
	}

	// 任务状态；0：等待开始，1：检查任务，2：检查工具：3：检查参数；
	// 			 4：计划等待，5：执行任务，6：任务取消，7：执行失败，8：执行成功。
	
	if($data['act'] == 'retry') {
		if($row['stat'] <= 5) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '任务进行中，无法完成此操作！');
			return false;
		}
		if($row['stat'] >= 8) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '任务已成功完成，无法完成此操作！');
			return false;
		}
		$stat = 0;
		$otheset = " , `stime` = 0, `finishtm` = 0, `msg` = ''";

		$cmd = DATAEYE . " device set license_id12={$data['keyno']} task_signal=1";
		exec("{$cmd} > /dev/null 2>&1");
	}
	else
	if($data['act'] == 'cancel') {
		if($row['stat'] >= 6) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '任务已结束，无效的请求。');
			return false;
		}
		$stat = 6;
		$otheset = " , `finishtm` = " . time();

		$cmd = DATAEYE . " device set license_id12={$data['keyno']} task_signal=0";
		exec("{$cmd} > /dev/null 2>&1");
	}
	else {
		set_errmsg(MSG_LEVEL_DEF, __function__, '无效的请求。');
		return false;
	}

	try {
		$sql = "update `cloud_platform`.`devops_process` ";
		$sql.= " set `stat` = {$stat}" . $otheset;
		$sql.= " where keyno = ? and `task_id` = {$data['task_id']}";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $data['keyno'], \PDO::PARAM_STR);
		
		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return $ret;
}
