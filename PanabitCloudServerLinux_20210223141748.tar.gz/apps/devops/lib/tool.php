<?php
namespace cloud\apps\devops\tool;


function select($data)
{
	global $nidb, $user;


	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);
	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	
	if(format_and_push($data, 'task_id', $optional, '', 'int', false) === false)
		$optional['task_id'] = 0;
	
	if($optional['task_id'])
		$where_str .= "`task_id` = {$optional['task_id']} and ";

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false)
		$wkpid = \cloud\apps\work\project\project_enable();
	else
		$wkpid = $optional['wkpid'];

	if($wkpid) 
		$where_str .= "`wkpid` = {$wkpid} and ";
	if(!is_supadmin($user->username)) {
		if($wkpid == 0) {
			$wkpids = \cloud\apps\work\project\get_work_for_user($user->username);
			if(!$wkpids) return $result;
			$where_str .= "`wkpid` in ({$wkpids}) and ";
		}
	}
	
	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`tool` like ? or `devops` like ? or `operator` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"task_id",
		"wkpid",
		"tool",
		"devops",
		"devs",
		"pass",
		"fail",
		"operator",
		"finishtm",
		"ctime"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.devops_task";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
	}

	$sql = "select * from cloud_platform.devops_task";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}


	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function add($data)
{
	global $nidb, $user;

	
	if(isset($data['devs']) == false || empty(($data['devs'] = trim($data['devs'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['devs'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['tool']) == false || empty(($data['tool'] = trim($data['tool'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无效的运维工具。');
		return false;
	}
	
	if(isset($data['devops']) == false || empty(($data['devops'] = trim($data['devops'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '运维工具名称为空。');
		return false;
	}
	
	if(isset($data['param']) == false)
		$data['param'] = '';
	else
		$data['param'] = trim($data['param']);

	
	$devs = explode(',', $data['devs']);
	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}

	
	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	$frmData = array(
		'wkpid'		=> $wkpid,
		'tool'		=> $data['tool'],
		'devops'	=> $data['devops'],
		'devs'		=> count($devs),
		'operator'	=> $user->username,
		'ctime'		=> time()
	);

	if(insert_data('cloud_platform`.`devops_task', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}
	$id = $nidb->lastInsertId();


	$frmData = array(
		'task_id'	=> $id,
		'tool'		=> $data['tool'],
		'param'		=> $data['param'],
		'data'		=> ''
	);

	foreach($devs as $dev) {
		$frmData['keyno'] = $dev;
		if(insert_data('cloud_platform`.`devops_process', $frmData) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}

	// 更新名称
	$sql = "select `license_id12`, if(length(trim(sys_name2)), sys_name2, sys_name) as sysname, license_id12 from cloud_device";
	$sql.= " where `license_id12` in ('" . implode("','", $devs) . "')";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return $id;
	}

	foreach($rows as $row) {
		$sql = "update `cloud_platform`.`devops_process`";
		$sql.= " set `name` = '" . to_utf8($row->sysname) . "'";
		$sql.= " where `keyno` = '" . $row->license_id12 . "'";
		$sth = $nidb->prepare($sql);
		$sth->execute();
	}
//	$sql = "update `cloud_platform`.`devops_process` as a";
//	$sql.= " inner join (select if(length(trim(sys_name2)), sys_name2, sys_name) as sysname, license_id12 from cloud_device) as b";
//	$sql.= " on a.keyno = b.license_id12";
//	$sql.= " set a.name = b.sysname";
//	$sth = $nidb->prepare($sql);
//	$sth->execute();

	return $id;
}

function del($data)
{
	global $nidb, $user;

	
	if(isset($data['task_id']) == false || empty(($data['task_id'] = intval($data['task_id'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要删除的任务。');
		return false;
	}

	$wkpids = \cloud\apps\work\project\project_enable();
	if(!$wkpids && !is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	try {
		$sql = "select * from `cloud_platform`.`devops_task`";
		$sql.= " where `task_id` = {$data['task_id']}";
		if($wkpids)
			$sql.= " and `wkpid` in ({$wkpids})";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的任务不存在。');
		return false;
	}

	// 删除进程
	try {
		$sql = "delete from `cloud_platform`.`devops_process` where `task_id` = {$data['task_id']}";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		
		$sql = "delete from `cloud_platform`.`devops_task` where `task_id` = {$data['task_id']}";
		$sth = $nidb->prepare($sql);
		$sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function make($data)
{
	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '运维工具名称不能为空。');
		return false;
	}
	if(isset($data['ver']) == false || empty(($data['ver'] = trim($data['ver'])))) {
		$data['ver'] = $data['name'];
	}
	
	$fname = array();

	$srcdir = OPSTOOL_DIR . "/{$data['name']}/opstool";
	if(!file_exists("{$srcdir}/appctrl")){
		set_errmsg(MSG_LEVEL_ARG, __function__, '缺少启动文件“appctrl”。');
		return false;
	}
	if(!file_exists("{$srcdir}/app.inf")){
		set_errmsg(MSG_LEVEL_ARG, __function__, '缺少配置文件“app.inf”。');
		return false;
	}

	if (($dh = opendir($srcdir))){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				array_push($fname, $file);
			}
		}
		closedir($dh);
	}
	
	if(!count($fname)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '找不到任何运维工具的文件。');
		return false;
	}

	$filelist = implode(' ', $fname);
	$downdir = OPSTOOL_DIR . "/{$data['name']}/down";
	if(!is_dir($downdir)) @mkdir($downdir);

	exec("tar czf {$downdir}/{$data['ver']}.tar.gz -C {$srcdir} {$filelist} 2>&1", $output, $ret);
	if($ret) {
		set_errmsg(MSG_LEVEL_ARG, __function__, implode(',', $output));
		unset($output);
		return false;
	}
	exec("ln -s {$downdir}/{$data['ver']}.tar.gz {$downdir}/{$data['name']}.tar.gz 2>&1", $output, $ret);

	return true;
}