function get_select_node(node) {
	var selected = [];

	function nodeCallback(node) {
		var childs, data = [];

		if (!node.grp) return true;

		childs = node.children;
		for (var i = 0; i < childs.length; i++) {
			if (nodeCallback(childs[i]))
				data.push(childs[i]);
		}

		if (data.length == node.grp)
			return true;

		selected = selected.concat(data);

		return false;
	}

	if (nodeCallback(node))
		selected.push(node);

	return selected;
}

function search_app(win) {
	var names = [];
	var selectNames = [];
	var data = $('#treeWrap .layui-tree-txt');
	var key = $('.appIpt').val();

	data.each(function() {
		var e = $(this);
		var txt = e.text();
		if (txt.indexOf(key) != -1) {
			e.parents('[data-id]').each(function() {
				var ico, e = $(this);
				var id = e.attr('data-id');
				var str = '[data-id="' + id + '"]';
				if (id != 1044 && names.indexOf(str) == -1) {
					names.push(str);
					ico = e.find('.layui-tree-entry .layui-tree-icon');
					if (ico.length && ico.children('.layui-icon-addition').length)
						ico.children('.layui-icon-addition').click();
				}
			});
		}
	});

	if (names.length) {
		win.find('[data-id="1044"] .layui-tree-pack [data-id]').hide();
		win.find('[data-id="1044"] .layui-tree-pack ' + names.join(',')).show();
	} else
		win.find('[data-id="1044"] .layui-tree-pack [data-id]').show();

	return names.length;
}

function setcol_devlist(d) {
	var state = getcol_state(d);
	var html = '';
	if (typeof this.mytemplet == 'function') {
		html = this.mytemplet.call(this, d, state);
	} else
	if (this.field == undefined)
		return html;
	else
		html = d[this.field];

	if (state == '<img src="/cloud/assets/img/expire.png" class="icon" title="License即将到期"/>')
		return '<div class="expire_txt">' + html + '</div>';
	else
	if (state == '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>')
		return '<div class="off_txt">' + html + '</div>';
	else
		return html;
}

// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;

function dump_tb_paga() {
	var tmout = 0,
		paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if (tb_paga) {
		if ((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if (paga <= 0)
				paga = 20;
		}
	}
	return {
		paga: paga,
		tmout: tmout
	};
}

function get_tb_paga() {
	return _tb_paga;
}

function set_tb_paga(paga) {
	if (!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if (_tb_paga != npage) {
		opt = dump_tb_paga();
		if (now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {
				expires: 31
			});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function getcol_state(d) {
	var state = '<img src="/cloud/assets/img/online.png" class="icon" title="当前在线">';

	if (d.release) {
		if (typeof(d.usedays) != 'string' && d.usedays <= 7) {
			if (d.usedays <= 7)
				state = '<img src="/cloud/assets/img/expire.png" class="icon" title="License即将到期"/>';

		}

		d.usedays_desc = d.usedays + '天';
	} else
		d.usedays_desc = '';

	if (d.linkdown) {
		state = '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>';
	}

	return state;
}

function ping_delay_color(delay) {
	if (delay > 1000)
		return 'color: red;';
	if (delay >= 300)
		return 'color: #bdbd6d;';
	if (delay >= 1)
		return 'color: darkgreen;';
	return '';
}

var timer = new taskTimer();

layui.use(['form', 'element', 'table', 'layer', 'tree', 'util', 'transfer'], function() {
	var form = layui.form;
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var tree = layui.tree;
	var util = layui.util;
	var transfer = layui.transfer;
	var isMobile = myDev.isMobile();
	var operateTask_list;
	if (isMobile) {
		$('.getwaytool').css({
			'width': '100%',
			'justify-content': 'space-between',
			'flex-wrap': 'wrap'
		});
	}

	function search(page, obj) {
		var where = {
			keyword: $.trim($('.pa_keyword').val()),
			sort: 'serialno',
			g_ascdesc: 'asc',
			online: 2
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				};
		} else
			page = 0;
		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('cloud_devlist', option);
	}

	tablelns = table.render({
		elem: '#cloud_devlist',
		even: true,
		loading: false,
		url: 'api.php?r=gateway@devlist',
		method: 'post',
		skin: 'line',
		initSort: {
			field: 'serialno',
			type: 'asc'
		},
		where: {
			sort: 'serialno',
			g_ascdesc: 'asc',
			online: 2
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			var d, i;
			if (res.ret == 0) {
				g_sertm = res.data.now;
				res.count = res.data.total;
				res.data = res.data.rows;

				for (i = 0; i < res.data.length; i++) {
					d = res.data[i];
					if ((Number(d.lasttime) + 15) < Number(d.servertime))
						d.linkdown = 1;
					else
						d.linkdown = 0;
				}
			}

			res.code = res.ret;
			res.msg = res.msg;

			var e = $('#cloud_devlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[{
					field: 'id',
					title: '序号',
					width: 30,
					fixed: 'left',
					type: 'numbers',
					templet: setcol_devlist
				},
				{
					type: 'checkbox',
					width: 25
				}, {
					field: 'serialno',
					title: '编号',
					width: 124,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						var dsc = (d.ping_delay >= 1000 ? ' > ' : '') + d.ping_delay + 'ms 时延';
						if (isMobile) {
							return '<div lay-event="info" title="' + dsc + '"><i class="fa fa-desktop table-icon" style="' +
								ping_delay_color(d.linkdown ? 9999 : d.ping_delay) + '"></i><span style="cursor: pointer;">' + d.serialno +
								'</span></div>';
						} else {
							return '<a href="javascript:void(0);" lay-event="info" title="' + dsc +
								'"><i class="fa fa-desktop table-icon" style="' + ping_delay_color(d.linkdown ? 9999 : d.ping_delay) +
								'"></i></a><span>' + d.serialno + '</span>';
						}
					}
				}, {
					field: 'name',
					title: '名称',
					width: 188,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<span style="font-weight: bold">' + (d.name ? d.name : 'none') + '</span>';
					}
				}, {
					field: 'lasttime',
					title: '状态',
					width: 35,
					templet: setcol_devlist,
					mytemplet: function(d, state) {
						return state;
					}
				}, {
					field: 'grpname',
					title: '属组',
					width: 95,
					templet: setcol_devlist,
					mytemplet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'lasttime',
					title: '最后在线',
					sort: true,
					width: 94,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return $.myTime.UnixToStrDate(d.lasttime, 'MM-dd/HH:mm:ss');
					}
				}, {
					field: 'license_end',
					title: '有效期',
					sort: true,
					width: 62,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.usedays_desc;
					}
				}, {
					field: 'users',
					title: '用户(C/M/F)',
					sort: true,
					width: 137,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.users + '/' + d.max_users + '/' + d.max_ipcnt;
					}
				}, {
					field: 'flowcont',
					title: '连接数',
					sort: true,
					width: 110,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.flowcont + '/' + parseInt(d.max_flowcont / 1000) + 'K';
					}
				}, {
					field: 'bpsout',
					title: '上行',
					sort: true,
					width: 60,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-left">' + numberformats(d.bpsout) + '</div>';
					}
				},
				{
					field: 'bpsin',
					title: '下行',
					sort: true,
					width: 60,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-left">' + numberformats(d.bpsin) + '</div>';
					}
				}, {
					field: 'sysrun',
					title: '运行',
					sort: true,
					width: 85,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-align">' + parsesysrun(d.sysrun) + '</div>';
					}
				}, {
					field: 'cpu',
					title: '温度/CPU',
					sort: true,
					width: 79,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.temp + '℃ / ' + d.cpu + '%'
					}
				}, {
					field: 'version',
					title: '当前版本',
					sort: true,
					width: 171,
					templet: setcol_devlist
				}
			]
		]
	});

	//自动刷新
	var auto_refresh_hd = 0;

	function auto_refresh() {
		if (auto_refresh_hd) {
			clearInterval(auto_refresh_hd);
			auto_refresh_hd = 0;
		}
		auto_refresh_hd = setInterval(function() {
			if (isHiddenMyView()) return;
			var checkStatus = table.checkStatus(tablelns.config.id);
			if (!checkStatus.data.length)
				search(-1);
		}, 3000);
	}
	auto_refresh();

	//获取脚本
	function getScript() {
		form.on('select(sel-script)', function(data) {
			var name = data.value;
			$.ajax({
				url: '/devops/tool/shellops/param.php?r=get',
				data: {
					name: name
				},
				success(d) {
					$('.script-txt').val(d.data);
				}
			});
		});
	}

	function getSc() {
		var name = $('#sel-script').val();
		$.ajax({
			url: '/devops/tool/shellops/param.php?r=get',
			data: {
				name: name
			},
			success(d) {
				$('.script-txt').val(d.data);
			}
		});
	}

	$('.search_Btn').click(function() {
		search(1);
	});

	$('.pa_keyword').keyup(function(event) {
		if (event.keyCode == 13) {
			$('.search_Btn').click();
		}
	});

	$('.operate-manage').on('click', function() {
		layer.open({
			type: 1,
			title: '任务中心',
			area: ['700px', '450px'],
			shadeClose: true,
			resize: false,
			content: $('#operate-wrap').html(),
			success: function(d) {
				operateTask_list = table.render({
					elem: '#operateTask_list',
					even: true,
					autoSort: false,
					skin: 'line',
					url: 'api.php?r=devops@task-list',
					method: 'post',
					page: true,
					limits: [10, 20, 30, 40, 50],
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3,
						curr: 1
					},
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					parseData: function(res) {
						var d;
						res.code = res.ret;
						res.msg = res.msg;
						res.count = res.data.total;
						res.data = res.data.rows;
						var data = res.data;
						for (i = 0; i < data.length; i++) {
							d = data[i];
						}
					},
					cols: [
						[{
								title: '序号',
								type: 'numbers'
							}, {
								field: 'name',
								title: '任务名称',
							}, {
								title: '设备数',
								templet: function(d) {
									return '<span class="setBtn" lay-event="count">' + d.devs + '</span>';
								}
							}, {
								title: '创建时间',
								templet: function(d) {
									return $.myTime.UnixToStrDate(d.ctime, 'yyyy/MM-dd HH:mm:ss');
								}
							}, {
								field: 'res',
								title: '进度',
								templet: function(d) {
									var num = (((d.pass + d.fail) / d.devs) * 100);
									num += '%';
									return num;
								}
							},
							{
								title: '操作',
								templet: function(d) {
									return '<span data-id="' + d.task_id + '" class="setBtn" lay-event="del">删除</span>';
								}
							}
						]
					]
				});

				table.on('tool(operateTask_list)', function(obj) {
					var data = obj.data,
						event = obj.event;
					var task_id;
					var msg;
					if (event == 'count') {
						layer.open({
							type: 1,
							title: '任务详情',
							area: ['45%', '55%'],
							shadeClose: true,
							resize: false,
							content: $('#countmore-wrap').html(),
							end: function() {
								timer.rmv('operateTaskmore_listX');
							},
							success: function(d) {
								table.render({
									elem: '#operateTaskmore_list',
									even: true,
									autoSort: false,
									skin: 'line',
									url: 'api.php?r=devops@process-list&task_id=' + data.task_id,
									method: 'post',
									page: {
										layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
										groups: 3
									},
									request: {
										pageName: 'page',
										limitName: 'limit'
									},
									parseData: function(res) {
										return {
											"data": res.data.rows,
											"code": res.ret,
											"msg": res.msg,
											"count": res.data.total
										}
										msg = res;
										var data = res.data.rows;
										var d;
										for (var i = 0; i < data.length; i++) {
											d = data[i];
										}
									},
									cols: [
										[{
											title: '序号',
											width: 35,
											type: 'numbers'
										}, {
											title: '设备名称',
											field: 'name'
										}, {
											title: '设备编号',
											field: 'keyno'
										}, {
											title: '开始时间',
											width: 130,
											templet: function(d) {
												return $.myTime.UnixToStrDate(d.stime, true);
											}
										}, {
											title: '结束时间',
											width: 130,
											templet: function(d) {
												return $.myTime.UnixToStrDate(d.finishtm, true);
											}
										}, {
											title: '执行结果',
											width: 62,
											align: 'center',
											templet: function(d) {
												var stat = ["等待开始", "检查任务", "检查工具", "检查参数", "计划等待", "执行任务", "任务取消", "执行失败", "执行成功"]
												return stat[d.stat];
											}
										}, {
											title: '信息',
											templet: function(d) {
												if (d.ret != 0) {
													return d.msg;
												} else {
													return "";
												}
											}
										}]
									]
								});
								timer.add('operateTaskmore_listX', 3, {
									fuc: function() {
										table.reloadExt('operateTaskmore_list');
									}
								});
							}
						});
					} else if (event == "del") {
						var task_id = $(this).attr('data-id');
						layer.confirm('确认删除此任务吗?', {
							icon: 0,
							title: '任务删除'
						}, function(index) {
							$.ajax({
								url: 'api.php?r=devops@task-remove&task_id=' + task_id,
								type: 'post',
								dataType: 'json',
								success: function() {
									layer.msg('删除成功', {
										icon: 1,
										time: 1000
									});
									table.reloadExt('operateTask_list');
								},
								error: function() {
									layer.msg('删除失败，请稍后再试。', {
										icon: 2,
										time: 1000
									});
								}
							});
							layer.close(index);
						});
					}
				});
			}
		});
	});

	$('.operate-grp').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('operate-type');
		var checkStatus = table.checkStatus('cloud_devlist');
		var devs = [];
		var id;
		checkStatus.data.forEach(function(e, i) {
			devs.push(e.serialno);
		});
		switch (event) {
			case 'node-ignore':
				var names = [];
				if (devs.length <= 0) {
					layer.msg('请先选择要操作的设备。', {
						time: 1000
					});
					return;
				}
				layer.open({
					type: 1,
					title: '选择协议',
					area: ['600px', '600px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认下发'],
					content: $('#proto-tree').html(),
					success: function(layero, index) {
						element.render();
						form.render();
						tree.render();
						var animate = layer.load(1);
						$.ajax({
							url: 'apps/gateway/assets/js/tree.json',
							type: 'get',
							dataType: 'json',
							success: function(d) {
								var html = "";
								for (var i = 0; i < d.length; i++) {
									html += '<li style="padding:3px 2px;" data-name="' + d[i].children.name + '">' + d[i].title +
										'</li>';
								}
								$('.appContent ul').html(html);

								$(document).click(function(e) {
									var _con = $('.appContent');
									if (!_con.is(e.target) && _con.has(e.target).length === 0) {
										_con.css('display', 'none');
									}
								});
							}
						});

						$.ajax({
							url: 'apps/gateway/assets/js/tree.json',
							type: 'get',
							dataType: 'json',
							success: function(d) {
								var searchtree = true;
								var tree_option = {
									elem: '#treeWrap',
									id: "treeWrap",
									data: d,
									showCheckbox: true,
									accordion: true,
									click: function(obj) {
										this.accordion = searchtree;
									}
								};

								element.render();
								form.render();

								tree.render(tree_option);
								$('.appIpt').on('keyup', function() {
									searchtree = false;
									layero.find('[value="512"]').parent().children('.layui-tree-txt').click();
									if (search_app(layero) == 0) {
										searchtree = true;
										layero.find('[value="512"]').parent().children('.layui-tree-txt').click();
									}
								});

								layer.close(animate);
							}
						})

						$('.addRight').click(function(obj) {
							var nodes, names = [],
								data = tree.getChecked('treeWrap');

							if (data.length == 0) {
								$('.selected-app').empty();
								layer.msg('请选择协议。', {
									time: 1000
								});
								return;
							}

							nodes = data[0].children;
							for (i = 0; i < nodes.length; i++)
								names = names.concat(get_select_node(nodes[i]));

							var html = "";
							for (var i = 0; i < names.length; i++) {
								html += '<p data-name="' + names[i].field + '" data-id="' + names[i].id + '">' + names[i].title +
									'</p>';
							}
							$('.selected-app').html(html);

							$('.selected-app p').click(function() {
								var color = $(this).css('background-color');
								if (color == "rgb(255, 255, 255)") {
									$(this).css("background-color", "rgb(206, 206, 206)");
									$(this).addClass('selected');
								} else {
									$(this).css("background-color", "white");
									$(this).removeClass('selected');
								}
							});
						});

						function delapp() {
							var p = $('.selected-app .selected');
							p.remove();
						}

						$('.delRight').click(function() {
							var ids = [];
							$('.selected-app p').each(function() {
								ids.push($(this).attr('data-id'));
							});
							delapp();
							form.render();
							tree.render();
						});
					},
					yes: function(index, layero) {
						var fields = [];
						$('.selected-app p').each(function() {
							fields.push($(this).attr('data-name'));
						});
						if ($('.selected-app').children().length == 0) {
							layer.msg('请选择协议。', {
								time: 1000
							});
							return;
						}

						var ignore = $('input[name="ignore[node]"]').prop("checked") ? 1 : 0;
						$.ajax({
							url: 'api.php?r=devops@task-create',
							data: {
								tool: 'nodeignore',
								devs: devs.join(','),
								apps: fields.join(','),
								ignore: ignore
							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5,
										time: 1000
									});
									return;
								}

								layer.open({
									type: 1,
									title: '忽略节点',
									area: ['45%', '55%'],
									shadeClose: true,
									resize: false,
									content: $('#countmore-wrap').html(),
									end: function() {
										timer.rmv('operateTaskmore_listY');
									},
									success: function(layero, index) {
										table.render({
											elem: '#operateTaskmore_list',
											even: true,
											autoSort: false,
											skin: 'line',
											url: 'api.php?r=devops@process-list&task_id=' + d.data,
											method: 'post',
											page: {
												layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
												groups: 3
											},
											request: {
												pageName: 'page',
												limitName: 'limit'
											},
											parseData: function(res) {
												return {
													"data": res.data.rows,
													"code": res.ret,
													"msg": res.msg,
													"count": res.data.total
												}
												var data = res.data.rows;
												var d;
												for (var i = 0; i < data.length; i++) {
													d = data[i];
												}
											},
											cols: [
												[{
													title: '序号',
													width: 50,
													type: 'numbers'
												}, {
													title: '设备名称',
													field: 'name'
												}, {
													title: '设备编号',
													field: 'keyno'
												}, {
													title: '开始时间',
													templet: function(d) {
														return $.myTime.UnixToStrDate(d.stime, 'MM-dd/HH:mm:ss');
													}
												}, {
													title: '结束时间',
													templet: function(d) {
														return $.myTime.UnixToStrDate(d.finishtm, 'MM-dd/HH:mm:ss');
													}
												}, {
													title: '任务状态',
													align: 'center',
													templet: function(d) {
														var stat = ["等待开始", "下载任务", "下载工具", "下载参数", "计划等待", "执行任务", "任务取消", "执行失败", "执行成功"]
														return stat[d.stat];
													}
												}, {
													field: 'msg',
													title: '信息'
												}, {
													title: '操作',
													templet: function(d) {
														if (d.stat < 6) {
															return '<span class="setBtn" lay-event="cancel">取消任务</span>';
														} else if (d.stat == 6 || d.stat == 7) {
															return '<span class="setBtn" lay-event="retry">重试</span>';
														}
													}
												}]
											]
										});

										timer.add('operateTaskmore_listY', 3, {
											fuc: function() {
												table.reloadExt('operateTaskmore_list');
											}
										});

										//取消任务
										table.on('tool(operateTaskmore_list)', function(obj) {
											var data = obj.data,
												event = obj.event;
											var task_id;
											if (event == 'cancel') {
												layer.confirm('确定要取消此任务吗？', function(index) {
													$.ajax({
														url: 'api.php?r=devops@process-cancel&task_id=' + d.data,
														data: {
															keyno: devs.join(',')
														},
														type: 'post',
														dataType: 'json',
														success: function(d) {
															if (ajax_resultCallBack(d) === false) {
																layer.msg(d.msg, {
																	icon: 5,
																	time: 1000
																});
																return;
															}
															layer.msg('任务已取消', {
																icon: 1,
																time: 1000
															});
															table.reloadExt('operateTaskmore_list');
														},
														error: function() {
															layer.msg('获取数据失败，请稍后再试。', {
																icon: 2,
																time: 1000
															});
														}
													});
												});
											} else if (event == "retry") {
												layer.confirm('确定要重试吗？', function(index) {
													$.ajax({
														url: 'api.php?r=devops@process-retry&task_id=' + d.data,
														data: {
															keyno: devs.join(',')
														},
														type: 'post',
														dataType: 'json',
														success: function(d) {
															if (ajax_resultCallBack(d) === false) {
																layer.msg(d.msg, {
																	icon: 5,
																	time: 1000
																});
																return;
															}
															layer.msg('重试成功', {
																icon: 1,
																time: 1000
															});
															table.reloadExt('operateTaskmore_list');
														},
														error: function() {
															layer.msg('获取数据失败，请稍后再试。', {
																icon: 2,
																time: 1000
															});
														}
													});
												});
											}
										});
										timer.add('operateTaskmore_listX', 3, {
											fuc: function() {
												table.reloadExt('operateTaskmore_list');
											}
										});
									}
								});
								if (d.msg) layer.msg(d.msg, {
									icon: 1,
									time: 1000
								});
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2,
									time: 1000
								});
							}
						});
					}
				});
				break;
			case 'script-operate':
				function open_scriptRes() {
					layer.open({
						type: 1,
						title: '输入脚本',
						area: ['720px', '600px'],
						shadeClose: true,
						resize: true,
						content: $('#scriptWrap').html(),
						btnAlign: 'c',
						btn: ['保存'],
						success: function(layero, index) {
							layero.find('textarea').setTextareaCount();
							//历史列表下拉框
							$.ajax({
								url: '/devops/tool/shellops/param.php?r=list',
								success(d) {
									var html = '';
									for (var i = 0; i < d.data.length; i++) {
										html += '<option value="' + d.data[i] + '">' + d.data[i] + '</option>';
									}
									layero.find('[lay-filter="sel-script"]').append(html);
									form.render('select');
								}
							});
							getScript();

							//删除历史脚本
							$('.del-his').click(function() {
								if ($('#sel-script').val() == "") {
									layer.msg('请选择要删除的脚本。', {
										time: 1500
									});
									return;
								}
								layer.confirm('确认删除此脚本吗?', {
									icon: 0,
									title: '脚本删除'
								}, function(index) {
									$.ajax({
										url: '/devops/tool/shellops/param.php?r=del',
										data: {
											name: $('#sel-script').find("option:selected").text()
										},
										success: function() {
											layer.msg('删除成功', {
												icon: 1,
												time: 1000
											});
											getSc();
											$.ajax({
												url: '/devops/tool/shellops/param.php?r=list',
												success(d) {
													var i, data = d.data;
													var html = '<option value="请选择">请选择</option>';
													for (var i = 0; i < d.data.length; i++) {
														html += '<option value="' + d.data[i] + '">' + d.data[i] + '</option>';
													}
													$('#sel-script').empty();
													$('#sel-script').html(html);
													form.render('select');
												}
											});
										},
										error: function() {
											layer.msg('删除失败，请稍后再试。', {
												icon: 2,
												time: 1000
											});
										}
									});
									layer.close(index);
								});
							});

							//添加脚本
							$('.add-script').click(function() {
								var name = $('#sel-script').find("option:selected").text();
								if (!name) {
									return;
								}
								layer.open({
									type: 1,
									title: '添加运维脚本',
									area: ['300px', '200px'],
									shadeClose: true,
									resize: true,
									btnAlign: 'c',
									btn: ['确认'],
									content: $('#scriptName-wrap').html(),
									yes: function(index, layero) {
										$.ajax({
											url: '/devops/tool/shellops/param.php?r=save',
											data: {
												name: $('.script-name').val(),
												text: $('.script-txt').val()
											},
											type: 'post',
											dataType: 'json',
											success: function(d) {
												if (ajax_resultCallBack(d) === false) {
													layer.msg(d.msg, {
														icon: 5
													});
													return;
												}
												if (d.ret == 0) layer.msg('添加成功', {
													icon: 1
												});
												layer.close(index);

												$('#sel-script').empty();
												$('.script-txt').val(d.data).val('');
												$.ajax({
													url: '/devops/tool/shellops/param.php?r=list',
													success(d) {
														var i, data = d.data;
														var html = '<option value="">请选择</option>';
														for (var i = 0; i < d.data.length; i++) {
															html += '<option value="' + d.data[i] + '">' + d.data[i] + '</option>';
														}
														$('#sel-script').empty();
														$('#sel-script').html(html);
														form.render('select');
													}
												});
											},
											error: function() {
												layer.msg('连接超时，请稍后再试。', {
													icon: 2
												});
											}
										});
									}
								});
							});

							//执行
							$('.carry-script').click(function() {
								var val = $('#sel-script').val();
								if (layero.find('[lay-filter="sel-script"]').val() == '') {
									layer.msg('请选择脚本。', {
										time: 1500
									});
									return;
								}
								$.ajax({
									url: 'api.php?r=devops@task-create',
									data: {
										tool: 'shellops',
										devs: devs.join(','),
										param: $('.script-txt').val(),
										save_history: $('.cfgname').val()
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										var name = $('#sel-script').val();
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5,
												time: 1000
											});
											return;
										}
										layer.close(index);
										layer.open({
											type: 1,
											title: '脚本运维 -- ' + (val == "默认的配对运维（无）" ? "默认的配对运维" : name),
											area: ['45%', '55%'],
											shadeClose: true,
											resize: false,
											content: $('#countmore-wrap').html(),
											end: function() {
												timer.rmv('operateTaskmore_listZ');
											},
											success: function(layero, index) {
												table.render({
													elem: '#operateTaskmore_list',
													even: true,
													autoSort: false,
													skin: 'line',
													url: 'api.php?r=devops@process-list&task_id=' + d.data,
													method: 'post',
													page: {
														layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
														groups: 3
													},
													request: {
														pageName: 'page',
														limitName: 'limit'
													},
													parseData: function(res) {
														return {
															"data": res.data.rows,
															"code": res.ret,
															"msg": res.msg
														}
														var data = res.data.rows;
														var d;
														for (var i = 0; i < data.length; i++) {
															d = data[i];
														}
													},
													cols: [
														[{
															title: '序号',
															width: 50,
															type: 'numbers'
														}, {
															title: '设备名称',
															field: 'name'
														}, {
															title: '设备编号',
															field: 'keyno'
														}, {
															title: '开始时间',
															templet: function(d) {
																return $.myTime.UnixToStrDate(d.stime, 'MM-dd/HH:mm:ss');
															}
														}, {
															title: '结束时间',
															templet: function(d) {
																return $.myTime.UnixToStrDate(d.finishtm, 'MM-dd/HH:mm:ss');
															}
														}, {
															title: '任务状态',
															align: 'center',
															templet: function(d) {
																var stat = ["等待开始", "下载任务", "下载工具", "下载参数", "计划等待", "执行任务", "任务取消", "执行失败",
																	"执行成功"
																]
																return stat[d.stat];
															}
														}, {
															field: 'msg',
															title: '信息'
														}, {
															title: '操作',
															templet: function(d) {
																if (d.stat < 6) {
																	return '<span class="setBtn" lay-event="cancel">取消任务</span>';
																} else if (d.stat == 6 || d.stat == 7) {
																	return '<span class="setBtn" lay-event="retry">重试</span>';
																}
																return '';
															}
														}]
													]
												});

												timer.add('operateTaskmore_listZ', 3, {
													fuc: function() {
														table.reloadExt('operateTaskmore_list');
													}
												});

												table.on('tool(operateTaskmore_list)', function(obj) {
													var data = obj.data,
														event = obj.event;
													var task_id;
													if (event == 'cancel') {
														layer.confirm('确定要取消此任务吗？', function(index) {
															$.ajax({
																url: 'api.php?r=devops@process-cancel&task_id=' + d.data,
																data: {
																	keyno: devs.join(',')
																},
																type: 'post',
																dataType: 'json',
																success: function(d) {
																	if (ajax_resultCallBack(d) === false) {
																		layer.msg(d.msg, {
																			icon: 5,
																			time: 1000
																		});
																		return;
																	}
																	layer.msg('任务已取消', {
																		icon: 1,
																		time: 1000
																	});
																	table.reloadExt('operateTaskmore_list');
																},
																error: function() {
																	layer.msg('获取数据失败，请稍后再试。', {
																		icon: 2,
																		time: 1000
																	});
																}
															});
														});
													} else if (event == "retry") {
														layer.confirm('确定要重试吗？', function(index) {
															$.ajax({
																url: 'api.php?r=devops@process-retry&task_id=' + d.data,
																data: {
																	keyno: devs.join(',')
																},
																type: 'post',
																dataType: 'json',
																success: function(d) {
																	if (ajax_resultCallBack(d) === false) {
																		layer.msg(d.msg, {
																			icon: 5,
																			time: 1000
																		});
																		return;
																	}
																	layer.msg('重试成功', {
																		icon: 1,
																		time: 1000
																	});
																	table.reloadExt('operateTaskmore_list');
																},
																error: function() {
																	layer.msg('获取数据失败，请稍后再试。', {
																		icon: 2,
																		time: 1000
																	});
																}
															});
														});
													}
												});
											}
										});
									},
								});
							});
						},
						yes: function(index, layero) {
							var flag;
							if (layero.find('select[lay-filter="sel-script"]').val() == "默认的配对运维（无）") {
								flag = true;
							}
							$.ajax({
								url: '/devops/tool/shellops/param.php?r=save',
								data: {
									name: $('#sel-script').val(),
									text: $('.script-txt').val()
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (flag) {
										layero.find('select[lay-filter="sel-script"] option[value="默认的配对运维（无）"]').val("默认的配对运维").text(
											"默认的配对运维");
										form.render('select');
									}
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}
									if (d.ret == 0) layer.msg('保存成功', {
										icon: 1
									});
								},
								error: function() {
									layer.msg('连接超时，请稍后再试。', {
										icon: 2
									});
								}
							});
						}
					});
				}

				if (devs.length <= 0) {
					open_scriptRes();
					$('.carry-script').hide();
				} else {
					open_scriptRes();
				}
		}
	});
});
