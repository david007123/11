<?php
define ("ROOT_DIR", dirname(dirname(dirname(__DIR__))));
require_once(ROOT_DIR . '/conf/config.php');
require_once(ROOT_DIR . '/apps/user/lib/login.php');


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

// upgrade
$sql = "show columns from cloud_platform.devops_task where `Field` = 'name'";
$sth = $nidb->prepare($sql);
$sth->execute();
$row = $sth->fetch(\PDO::FETCH_ASSOC);
if(!$row) {
	$sql = "drop table if exists cloud_platform.devops_task";
	$nidb->query($sql);
}

$sql = "show columns from cloud_platform.devops_process where `Field` = 'task_id'";
$sth = $nidb->prepare($sql);
$sth->execute();
$row = $sth->fetch(\PDO::FETCH_ASSOC);
if(!$row) {
	$sql = "drop table if exists cloud_platform.devops_process";
	$nidb->query($sql);
}

// 创建任务表
$sql = "create table if not exists cloud_platform.devops_task (";
$sql.= "`task_id` bigint NOT NULL auto_increment primary key COMMENT '任务ID' ,";
$sql.= "`wkpid` bigint NOT NULL DEFAULT 0 COMMENT '项目ID' ,";
$sql.= "`tool` char(128) NOT NULL DEFAULT '' COMMENT '运维工具' ,";
$sql.= "`name` char(128) NOT NULL DEFAULT '' COMMENT '运维工具中文名' ,";
$sql.= "`devs` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '设备数' ,";
$sql.= "`pass` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '已成功' ,";
$sql.= "`fail` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '已失败' ,";
$sql.= "`msg` char(255) NOT NULL DEFAULT '' COMMENT '消息' ,";
$sql.= "`operator` char(64) NOT NULL DEFAULT '' COMMENT '操作员',";
$sql.= "`finishtm` bigint NOT NULL DEFAULT 0 COMMENT '完成时间',";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);


// 创建设备进程列表
$sql = "create table if not exists cloud_platform.devops_process (";
$sql.= "`task_id` bigint NOT NULL DEFAULT 0 COMMENT '任务ID' ,";
$sql.= "`tool` char(128) NOT NULL DEFAULT '' COMMENT '运维工具' ,";
$sql.= "`toolver` char(16) NOT NULL DEFAULT '' COMMENT '运维工具版本号' ,";
$sql.= "`keyno` char(16) NOT NULL DEFAULT '' COMMENT '设备' ,";
$sql.= "`stat` smallint UNSIGNED NOT NULL DEFAULT 0 COMMENT '执行状态；0：等待开始，1：检查任务，2：检查工具：3：检查参数；4：计划等待，5：执行任务，6：任务取消，7：执行失败，8：执行成功。' ,";
$sql.= "`code` smallint UNSIGNED NOT NULL DEFAULT 0 COMMENT '错误代码' ,";
$sql.= "`failcnt` smallint UNSIGNED NOT NULL DEFAULT 0 COMMENT '失败次数' ,";
$sql.= "`name` varchar(255) NOT NULL DEFAULT '' COMMENT '设备名称' ,";
$sql.= "`msg` varchar(255) NOT NULL DEFAULT '' COMMENT '消息' ,";
$sql.= "`finishtm` bigint NOT NULL DEFAULT 0 COMMENT '完成时间',";
$sql.= "`stime` bigint NOT NULL DEFAULT 0 COMMENT '开始时间',";
$sql.= "`plan_tm` bigint NOT NULL DEFAULT 0 COMMENT '计划开始时间',";
$sql.= "`param_md5` varchar(32) NOT NULL DEFAULT '' COMMENT '参数的MD5值' ,";
$sql.= "PRIMARY KEY (`task_id`, `keyno`)";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);  
