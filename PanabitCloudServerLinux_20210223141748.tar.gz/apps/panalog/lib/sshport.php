<?php
namespace cloud\apps\panalog;


function sshport_open($data)
{
	global $nidb, $user;
	
	$optional = array();


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	// set custom options
	if(format_and_push($data, 'serialno', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '操作设备不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}

	/* get dev info */
	$serialno = strtolower($optional['serialno']);
	$cmd = DATAEYE . " logserver list sch='{$serialno}'";
	$cmd.= " format=1";	// 增加 freeend 可升级时间
	exec($cmd, $out, $ret);
	$sysname = '';
	if($ret == 0) {
		foreach($out as $val) {
			$row = explode(' ', $val);
			if (count($row) < 3) {
				continue;
			}
			// $row[3]: Panalog 上配置的名称，$row[14]：云平台上配置的名称
			if(empty($row[14]))
				$name = $row[3];
			else
				$name = $row[14];

			$sysname		= '|' . to_utf8($name);
			break;
		}
	}

	/* Update log */
	cloud_insertlog($user->username, "查看日志设备：{$optional['serialno']}{$sysname}");

	$cmd = DATAEYE . " logserver set license_id12={$optional['serialno']} mapping=1";
	exec($cmd);

	try {
		$sql = "select `webport`, `sshport` from logserver_list where license_id12 = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['serialno'], \PDO::PARAM_STR);

		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_LAZY);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if($row) {

		$localip = $_SERVER['HTTP_HOST'];
		if (strchr($localip, ':') != false) {
			$ds = explode(':', $localip);
			$localip = $ds[0];
		}

		return array(
			'hostip'	=> gethostbyname($localip),
			'webport'	=> $row->webport,
			'sshport'	=> $row->sshport
		);
	}
	else
		set_errmsg(MSG_LEVEL_EXP, __function__, '映射失败！');

	return false;
}

