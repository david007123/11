<?php
namespace cloud\apps\panalog;


function devlist($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
		'fail'		=> 0,
		'exp'		=> 0,
		'page'		=> 0,
		'limit'		=> 0
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
		$optional['keyword'] = strtolower($optional['keyword']);
		$optional['keyword'] = shell_filter($optional['keyword']);
	}
	else
		$optional['keyword'] = '';
	
	if(format_and_push($data, 'sort', $optional, '', 'string', false) == false)
		$optional['sort'] = 'serialno';

	if(format_and_push($data, 'expire', $optional, '', 'int', false) == false)
		$optional['expire'] = 0;
	
	if(format_and_push($data, 'page', $result, '', 'int', false) == false)
		$result['page'] = 1;
	
	if(format_and_push($data, 'limit', $result, '', 'int', false) == false)
		$result['limit'] = 20;
	else
		if($result['limit'] <= 0) $result['limit'] = 20;

	if(format_and_push($data, 'g_ascdesc', $optional, '', 'string', false)) {
		if ($optional['g_ascdesc'] != 'desc')
			$optional['g_ascdesc'] = 0;
		else
			$optional['g_ascdesc'] = 1;
	}
	else
		$optional['g_ascdesc'] = 0;

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(2, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->log_grpids == '')
				return $result;
			if($optional['grpid'] <= 0)
				$optional['grpid'] = $user->log_grpids;
			else {
				$grpids = explode(',', $user->log_grpids);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
		else
		if($optional['grpid'] == 0)
			$optional['grpid'] = '10000,0';
		else 
		if($optional['grpid'] < 0)
			$optional['grpid'] = '';
	}

	switch($optional['sort']) {
		case "serialno":
		$sort_name = 1;break;
		case "lasttime":
		$sort_name = 2;break;
		case "license_start":
		$sort_name = 3;break;
		case "license_end":
		$sort_name = 4;break;
		case "bps":
		$sort_name = 7;break;
		case "sysrun":
		$sort_name = 9;break;
		case "version":
		$sort_name=10;break;
		case "name":
		$sort_name=12;break;
		default:
		$sort_name=1;break;
	}

	$cmd = DATAEYE . " logserver list page={$result['page']}";
	$cmd.= " limit={$result['limit']}";
	$cmd.= " usergrp={$optional['grpid']} sch='{$optional['keyword']}'";
	$cmd.= " sortname={$sort_name} sortdesc={$optional['g_ascdesc']}";
	$cmd.= " expire={$optional['expire']}";

	exec($cmd, $out, $ret);

	foreach($out as $val) {
		$row = explode(' ', $val);
		if (count($row) < 3) {
			if(($pos = strpos($row[0], 'total=')) === 0)
				$result['total'] = intval(substr($row[0], 6));
			else
			if(($pos = strpos($row[0], 'fail=')) === 0)
				$result['fail'] = intval(substr($row[0], 5));
			else
			if(($pos = strpos($row[0], 'exp=')) === 0)
				$result['exp'] = intval(substr($row[0], 4));
			continue;
		}

		$grpid = intval($row[1]);

        $map_address = to_utf8($row[11]);

		// $row[3]: Panalog 上配置的名称，$row[14]：云平台上配置的名称
		$sysname = $row[3];
		if(empty($row[14]))
			$name = $sysname;
		else
			$name = $row[14];

		$name		= to_utf8($name);
		$sysname	= to_utf8($sysname);
		$serialno	= to_utf8($row[0]);
		
		$license_end= intval($row[6]);
		$boot		= intval($row[2]);

		array_push($result['rows'], array(
			"name"			=> $name,
			"sysname"		=> $sysname,
			"license_start"	=> intval($row[5]),
			"license_end"	=> $license_end,
			"usedays"		=> ($license_end == 0 ? '' : intval(($license_end - $now) / 86400)),
			"serialno"		=> $serialno,
			"bps"			=> intval($row[7]),
			"lasttime"		=> intval($row[10]),
			"servertime"	=> $now,
			"grpid"			=> $grpid,
//			"machineno"		=> $row[14], 
			"sysrun"		=> ($now - intval($boot)),
			"outip"			=> long2ip($row[8]),
			"outport"		=> intval($row[9]),
			"map_address"	=> $map_address,
			"version"		=> $row[4]
		));
	}

	return $result;
}
