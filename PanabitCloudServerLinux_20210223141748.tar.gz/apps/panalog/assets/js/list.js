// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function open_remote(serialno, webenable, sshenable, callback) {
	var index = layer.load(0, {
		shade: 0
	});

	$.ajax({
		url: 'api.php?r=panalog@sshport_open',
		data: {
			serialno: serialno
		},
		dataType: 'json',
		type: 'post',
		success: function(d) {
			layer.close(index);
			if (ajax_resultCallBack(d) == false) {
				layer.msg(d.msg, {
					icon: 5
				});
				return;
			}
			if (typeof callback == 'function')
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {
				icon: 2
			});
		}
	});
}

function open_https(serialno, off) 
{
	var protocol = window.document.location.protocol + '//';

	if (off) {
		layer.msg('此设备已断开，无法连接。');
		return;
	}
	open_remote(serialno, 1, 0, function(d) {
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(protocol + d.hostip + ":" + d.webport, "_blank");
				}
			});
		} else
			window.open(protocol + d.hostip + ":" + d.webport, "_blank");
	});
}

function getcol_state(d) {
	var state = '当前在线';

	if (d.usedays != '') {
		if (d.usedays <= 7)
			state = "即将到期";

		d.usedays += '天';
	}

	if (d.linkdown) {
		state = "断开连接";
	}

	return state;
}

function setcol_devlist(d) {
	var state = getcol_state(d);
	var html = '';
	if (typeof this.mytemplet == 'function') {
		html = this.mytemplet.call(this, d, state);
	} else
	if (this.field == undefined)
		return html;
	else
		html = d[this.field];

	if (state == '即将到期')
		return '<div class="expire_txt">' + html + '</div>';
	else
	if (state == '断开连接')
		return '<div class="off_txt">' + html + '</div>';
	else
		return html;
}

function nameOpen(tips, serialno, name, grpid, map_address, linkdown) {
	var off = "";
	if(linkdown) {
		off = 'style="color: #909090;"';
	}
	layer.tips('<p><a href="javascript:void(0);" onclick="open_https(\'' + serialno +
		'\', ' + linkdown + ');" ' + off + '>HTTPS</a></p>\
		<p><a href="javascript:void(0);" onclick="set_gateway(\'' + serialno + '\', \'' + name +
		'\', \'' + grpid + '\',\'' + map_address + '\')">设置</a></p>',
		$(tips).parents('td'), {
			// tipsMore: true,
			tips: 4,
			success: function(layero, index){
				layero.on('mouseout', function(even) {
					var p = $(even.relatedTarget).parents('.layui-layer');
					if (p.is(layero)  || $(even.relatedTarget).hasClass('layui-layer-move')) return;
					layer.close(index);
				});
			}
		});
}

function set_gateway(serialno, name, grpid, map_address) {
	var form = layui.form;
	var layer = layui.layer;
	var table = layui.table;
	layer.open({
		type: 1,
		title: '设备配置',
		area: ['560px'],
		shadeClose: true,
		resize: false,
		btnAlign: 'c',
		btn: ['确认'],
		content: $('#tpl-devconfig').html(),
		mysubmit: function(index, layero) {
			var data = form.val('devconfig');
			$.ajax({
				url: 'api.php?r=panalog@devconfig',
				data: data,
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					// table.refresh('devlist');
					table.reloadExt('devlist');
					layer.close(index);
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		success: function(layero, index) {
			var data = form.val('devconfig');
			var that = this;
			var tab,
				dev = {
					serialno: serialno,
					grpid: Number(data.grpid),
					name: data.name,
					address: (data.map_address && data.map_address != '' && data.map_address != 'none' ? map_address : '')
				};

			if (dev.grpid == 10000)
				dev.grpid = 0;

			tab = layero.find('form[lay-filter="devconfig"] select[name="grpid"]');
			$('select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
				tab.append($(e).clone());
			});

			tab.parents('.layui-layer-content').css('overflow', 'inherit');
			tab.children('[value="' + dev.grpid + '"]').prop('selected', true);
			form.val('devconfig', {
				'serialno': serialno,
				'name': name,
				'grpid': grpid,
				'address': (map_address && map_address != '' && map_address != 'none' ? map_address : '')
			});
			form.render(null, 'devconfig');
			form.on('submit', function(data) {
				that.mysubmit(index, layero);
				return false;
			});
		},
		yes: function(index, layero) {
			this.mysubmit(index, layero);
		}
	});
}

layui.use(['form', 'table', 'element'], function() {
	var form = layui.form;
	var table = layui.table;
	var element = layui.element;
	var timer = new taskTimer();
	var tablelns;
	var isMobile = myDev.isMobile();

	$('.form-group-text').keyup(function(event) {
		if (event.keyCode == 13) {
			$('.searchBtn').click();
		}
	});

	function maingroup_refresh() {
		timer.add('read_group', 3, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=panalog@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="filter-group"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="filter-group"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
						timer.rmv('read_group');
					}
				});
			}
		}, 1);
	}
	maingroup_refresh();

	tablelns = table.render({
		elem: '#devlist',
		even: true,
		autoSort: false,
		loading: false,
		url: 'api.php?r=panalog@devlist',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'serialno',
			type: 'asc'
		},
		where: {
			sort: 'serialno',
			g_ascdesc: 'asc',
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			var d, i;
			if (res.ret == 0) {
				res.count = res.data.total;
				res.data = res.data.rows;
				
				for(i = 0; i < res.data.length; i++) {
					d = res.data[i];
					if ((Number(d.lasttime) + 15) < Number(d.servertime))
						d.linkdown = 1;
					else
						d.linkdown = 0;
				}
			}

			res.code = res.ret;
			res.msg = res.msg;

			var e = $('#devlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[{
					field: 'id',
					title: '序号',
					width: 25,
					fixed: 'left',
					type: 'numbers',
					templet: setcol_devlist
				},
				{
					type: 'checkbox',
					width: 25
				}, {
					field: 'serialno',
					title: '编号',
					width: 123,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						if (isMobile) {
							return '<div lay-event="info"><i class="fa fa-desktop table-icon"></i><span style="cursor: pointer;">' + d.serialno + '</span></div>';
						} else {
							return '<a href="javascript:void(0);" lay-event="info"><i class="fa fa-desktop table-icon"></i></a><span>' + d.serialno + '</span>';
						}
					}
				}, {
					field: 'name',
					title: '名称',
					width: 230,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<span class="setBtn" lay-event="open" onmouseover="nameOpen(this, \'' + $.trim(d.serialno) +
							'\', \'' + $.trim(d.name) + '\', \'' + $.trim(d.grpid) + '\', \'' + $.trim(d.map_address) + '\', ' + d.linkdown + ')">' + (d.name?d.name:'none') +
							'</span>';
					}
				}, {
					field: 'state',
					title: '状态',
					width: 35,
					templet: setcol_devlist,
					mytemplet: function(d, state) {
						if (state == '当前在线')
							return '<img src="/cloud/assets/img/online.png" class="icon" title="当前在线">';

						if (state == '即将到期')
							return '<img src="/cloud/assets/img/expire.png" class="icon" title="License即将到期"/>';
						return '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>';

					},
				},
				{
					field: 'grpname',
					title: '属组',
					width: 120,
					templet: setcol_devlist,
					mytemplet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				},
				{
					field: 'lasttime',
					title: '最后在线',
					width: 120,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return $.myTime.UnixToStrDate(d.lasttime, 'MM-dd/HH:mm:ss');
					}
				},
				{
					field: 'license_end',
					title: '有效期',
					sort: true,
					width: 70,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.usedays;
					}
				},
				{
					field: 'bps',
					title: '接收速率',
					sort: true,
					width: 75,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return numberformats(d.bps);
					}
				},
				{
					field: 'sysrun',
					title: '运行',
					sort: true,
					width: 85,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-left">' + parsesysrun(d.sysrun) + '</div>';
					}
				},
				{
					field: 'version',
					title: '当前版本',
					sort: true,
					width: 150,
					templet: setcol_devlist
				}
			]
		]
	});

	table.on('sort(devlist)', function(obj) {
		search(0, obj);
	});

	table.on('tool(devlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'open') {
			open_https(data.serialno, data.linkdown);
		}
		else
		if (event == 'info') {
			layer.open({
				type: 1,
				title: '设备信息',
				area: ['400px'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['关闭'],
				content: $('#tpl-devinfo').html(),
				success: function(layero, index) {
					$('[lay-filter="devinfo"] [name]').each(function(i, e) {
						var elem = $(e);
						var name = elem.attr('name');

						if (data[name]) {
							elem.text(data[elem.attr('name')]);
						} else {
							if (name == 'license_time')
								elem.text($.myTime.UnixToStrDate(data.license_start, false) + ' 至 ' + $.myTime.UnixToStrDate(data.license_end,
									false));
							if (name == 'openhttps')
								elem.html('<a class="setBtn" href="javascript:open_https(\'' + data.serialno + '\', ' + data.linkdown + ');">' + elem.attr(
									'title') + '</a>');
						}
					});

					$('[lay-filter="devinfo"]').css('font-size', '12px');
					form.render(null, 'devinfo');
					form.on('submit', function(data) {
						return false;
					});
				},
				yes: function(index, layero) {
					layer.close(index);
				}
			});
		}
	});

	// 搜索
	function search(page, obj) {
		var grpid = Number($('select[lay-filter="filter-group"]').val());
		var filterX = Number($('select[lay-filter="filter-x"]').val());

		var where = {
			grpid: 0,
			keyword: $.trim($('#tb_toolbar input[name="keyword"]').val()),
			sort: 'serialno',
			g_ascdesc: 'asc',
			expire: 0
		};
		if (filterX == 1) where.expire = 1;
		if (filterX == 2) where.sort = 'time';
		if (grpid) where.grpid = grpid;

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;

		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('devlist', option);
		if (page >= 0)
			auto_refresh();
	}

	form.on('select(filter-group)', function(data) {
		search(1);
	});

	form.on('select(filter-x)', function(data) {
		search(1);
	});

	$('#tb_toolbar button').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('lay-filter');
		var checkStatus = table.checkStatus(tablelns.config.id);
		var devs = [];
		checkStatus.data.forEach(function(e, i) {
			devs.push(e.serialno);
		});
		switch (event) {
			case 'search':
				search(1);
				break;
			case 'del':
				if (devs.length <= 0) {
					layer.msg('请先选择要删除的设备。');
					return;
				}

				layer.confirm('确认要删除这些设备吗?', {
					icon: 0,
					title: '设备删除'
				}, function(index) {
					$.ajax({
						url: '/Maintain/system_handle_ex.php',
						data: {
							type: 'logserver_delete',
							idstr: devs.join('|')
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							/*
							if(ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {icon: 5});
								return;
							}
							*/
							if (d.str) layer.msg(d.msg, {
								icon: (d.yn == "no") ? 5 : 1
							});
							search();
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
					layer.close(index);
				});
				break;
			case 'grpchg':
				if (devs.length <= 0) {
					layer.msg('请先选择要操作的设备。');
					return;
				}

				layer.open({
					type: 1,
					title: '设备分组修改 / 已选 ' + devs.length,
					area: ['300px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#tpl-grpchg').html(),
					mysubmit: function(index, layero) {
						var data = form.val('grpchg');
						$.ajax({
							url: 'api.php?r=panalog@grpchg',
							data: {
								dev: devs,
								grpid: data.grpid
							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								// table.refresh('devlist');
								table.reloadExt('devlist');
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					},
					success: function(layero, index) {
						var data = form.val('grpchg');
						var that = this;
						var tab;

						tab = layero.find('form[lay-filter="grpchg"] select[name="grpid"]');
						$('select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
							tab.append($(e).clone());
						});

						tab.parents('.layui-layer-content').css('overflow', 'inherit');
						form.render(null, 'grpchg');
						form.on('submit', function(data) {
							that.mysubmit(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						this.mysubmit(index, layero);
					}
				});
				
				break;
			case 'group':
				layer.open({
					type: 1,
					title: '设备组管理',
					area: ['600px', '400px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					content: $('#tpl-groupmgd').html(),
					cancel: function(index, layero) {
						maingroup_refresh();
					},
					success: function(layero, index) {
						var that = this;
						form.on('submit', function(data) {
							return false;
						});

						var grouplns = table.render({
							elem: '#grouplist',
							even: true,
							autoSort: false,
							height: 345,
							width: 600,
							url: 'api.php?r=panalog@group', //数据接口
							method: 'post',
							limit: 20,
							skin: 'line',
							initSort: {
								field: 'grpname',
								type: 'asc'
							},
							request: {
								pageName: 'page',
								limitName: 'limit'
							},
							toolbar: true,
							defaultToolbar: [{
								title: '添加新设备组', //标题
								layEvent: 'LAYTABLE_ADDGROUP', //事件名，用于 toolbar 事件中使用
								icon: 'layui-icon-add-circle' //图标类名
							}],
							page: false,
							parseData: function(res) {
								var rows = []
								if (res.ret == 0) {
									res.data.rows.forEach(function(item, index) {
										rows.push(item);
									});
								}

								this.mydefgrp = res.data.defgrp;
								if (this.mydefgrp == 10000)
									this.mydefgrp = 0;

								res.count = rows.length;
								res.data = rows;
								res.code = res.ret;
								res.msg = res.msg;;
							},
							cols: [
								[ //表头
									{
										field: 'id',
										title: '序号',
										minWidth: 50,
										fixed: 'left',
										type: 'numbers'
									}, {
										field: 'grpname',
										title: '组名称',
										edit: 'text',
										sort: false
									}, {
										field: 'operate',
										title: '操作',
										width: 60,
										templet: function(d) {
											return '<span class="setBtn" lay-event="del">删除</span>'
										}
									}
								]
							]
						});

						$(grouplns.config.elem).parent().find('.layui-table-tool').css('background-color', 'white');
						table.on('tool(grouplist)', function(obj) {
							var data = obj.data,
								event = obj.event;

							if (event === 'del') {
								layer.confirm('确定要删除该设备组吗？', function(index) {
									$.ajax({
										url: 'api.php?r=panalog@group_del',
										data: {
											grpid: data.grpid
										},
										type: 'post',
										dataType: 'json',
										success: function(d) {
											if (ajax_resultCallBack(d) === false) {
												layer.msg(d.msg, {
													icon: 5
												});
												return;
											}
											if (d.msg) layer.msg(d.msg, {
												icon: 1
											});

											obj.del();
											layer.close(index);
										},
										error: function() {
											layer.msg('获取数据失败，请稍后再试。', {
												icon: 2
											});
										}
									});
								});
							}
						});
						table.on('toolbar(grouplist)', function(obj) {
							var checkStatus = table.checkStatus(obj.config.id),
								data = checkStatus.data;

							switch (obj.event) {
								case 'LAYTABLE_ADDGROUP':
									layer.prompt({
										formType: 0,
										value: '',
										maxlength: 32,
										title: '请输入设备组名称',
										area: ['300px', '120px']
									}, function(value, index, elem) {
										value = $.trim(value);
										if (value == '') {
											layer.msg('设备组名称不能为空！', {
												icon: 5
											});
											return;
										}
										$.ajax({
											url: 'api.php?r=panalog@group_add',
											data: {
												name: value
											},
											type: 'post',
											dataType: 'json',
											success: function(d) {
												if (ajax_resultCallBack(d) === false) {
													layer.msg(d.msg, {
														icon: 5
													});
													return;
												}
												if (d.msg) layer.msg(d.msg, {
													icon: 1
												});
												layer.close(index);
												table.refresh('grouplist');
											},
											error: function() {
												layer.msg('获取数据失败，请稍后再试。', {
													icon: 2
												});
											}
										});
									});
									break;
							}
						});
						table.on('edit(grouplist)', function(obj) {
							var value = obj.value,
								data = obj.data,
								field = obj.field;

							$.ajax({
								url: 'api.php?r=panalog@group_save',
								data: {
									grpid: data.grpid,
									grpname: value
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										table.refresh('grouplist');
										return;
									}
									if (d.msg) layer.msg(d.msg, {
										icon: 1
									});
								},
								error: function() {
									layer.msg('获取数据失败，请稍后再试。', {
										icon: 2
									});
								}
							});
						});
					}
				});
				break;
		};
	});

	// 自动刷新
	var auto_refresh_hd = 0;

	function auto_refresh() {
		var interval = $('select[lay-filter="auto-refresh"]').val();
		if (auto_refresh_hd) {
			clearInterval(auto_refresh_hd);
			auto_refresh_hd = 0;
		}
		var tm = Number(interval);
		if (tm)
			auto_refresh_hd = setInterval(function() {
				if(isHiddenMyView()) return;
				var checkStatus = table.checkStatus(tablelns.config.id);
				if (!checkStatus.data.length)
					search(-1);
			}, tm * 1000);
	}
	form.on('select(auto-refresh)', function(data) {
		auto_refresh();
	});
	auto_refresh();
});
