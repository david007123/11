// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

/** layuiAdmin.std-v1.2.1 LPPL License By http://www.layui.com/admin/ */
var echartsTheme = {
        color: ["#009688", "#1E9FFF", "#5FB878", "#FFB980", "#D87A80", "#8d98b3", "#e5cf0d", "#97b552", "#95706d", "#dc69aa", "#07a2a4", "#9a7fd1", "#588dd5", "#f5994e", "#c05050", "#59678c", "#c9ab00", "#7eb00a", "#6f5553", "#c14089"],
        title: {
            textStyle: {
                fontWeight: "normal",
                color: "#666"
            }
        },
        dataRange: {
            itemWidth: 15,
            color: ["#009688", "#e0ffff"]
        },
        toolbox: {
            color: ["#1e90ff", "#1e90ff", "#1e90ff", "#1e90ff"],
            effectiveColor: "#ff4500"
        },
        tooltip: {
            backgroundColor: "rgba(50,50,50,0.5)",
            axisPointer: {
                type: "line",
                lineStyle: {
                    color: "#009688"
                },
                crossStyle: {
                    color: "#008acd"
                },
                shadowStyle: {
                    color: "rgba(200,200,200,0.2)"
                }
            }
        },
        dataZoom: {
            dataBackgroundColor: "#efefff",
            fillerColor: "rgba(182,162,222,0.2)",
            handleColor: "#008acd"
        },
        grid: {
            borderColor: "#eee",
			top: '40px',
			left: '2%',
			right: '2%',
			bottom: '6px',
			containLabel: true
        },
        categoryAxis: {
            axisLine: {
                lineStyle: {
                    color: "#009688"
                }
            },
            axisTick: {
                show: !1
            },
            splitLine: {
                lineStyle: {
                    color: ["#eee"]
                }
            }
        },
        valueAxis: {
            axisLine: {
                lineStyle: {
                    color: "#009688"
                }
            },
            splitArea: {
                show: !0,
                areaStyle: {
                    color: ["rgba(250,250,250,0.1)", "rgba(200,200,200,0.1)"]
                }
            },
            splitLine: {
                lineStyle: {
                    color: ["#eee"]
                }
            }
        },
        polar: {
            axisLine: {
                lineStyle: {
                    color: "#ddd"
                }
            },
            splitArea: {
                show: !0,
                areaStyle: {
                    color: ["rgba(250,250,250,0.2)", "rgba(200,200,200,0.2)"]
                }
            },
            splitLine: {
                lineStyle: {
                    color: "#ddd"
                }
            }
        },
        timeline: {
            lineStyle: {
                color: "#009688"
            },
            controlStyle: {
                normal: {
                    color: "#009688"
                },
                emphasis: {
                    color: "#009688"
                }
            },
            symbol: "emptyCircle",
            symbolSize: 3
        },
        bar: {
            itemStyle: {
                normal: {
                    barBorderRadius: 2
                },
                emphasis: {
                    barBorderRadius: 2
                }
            }
        },
        line: {
            smooth: !0,
            symbol: "emptyCircle",
            symbolSize: 3
        },
        k: {
            itemStyle: {
                normal: {
                    color: "#d87a80",
                    color0: "#2ec7c9",
                    lineStyle: {
                        color: "#d87a80",
                        color0: "#2ec7c9"
                    }
                }
            }
        },
        scatter: {
            symbol: "circle",
            symbolSize: 4
        },
        radar: {
            symbol: "emptyCircle",
            symbolSize: 3
        },
        map: {
            itemStyle: {
                normal: {
                    areaStyle: {
                        color: "#ddd"
                    },
                    label: {
                        textStyle: {
                            color: "#d87a80"
                        }
                    }
                },
                emphasis: {
                    areaStyle: {
                        color: "#fe994e"
                    }
                }
            }
        },
        force: {
            itemStyle: {
                normal: {
                    linkStyle: {
                        color: "#1e90ff"
                    }
                }
            }
        },
        chord: {
            itemStyle: {
                normal: {
                    borderWidth: 1,
                    borderColor: "rgba(128, 128, 128, 0.5)",
                    chordStyle: {
                        lineStyle: {
                            color: "rgba(128, 128, 128, 0.5)"
                        }
                    }
                },
                emphasis: {
                    borderWidth: 1,
                    borderColor: "rgba(128, 128, 128, 0.5)",
                    chordStyle: {
                        lineStyle: {
                            color: "rgba(128, 128, 128, 0.5)"
                        }
                    }
                }
            }
        },
        gauge: {
            axisLine: {
                lineStyle: {
                    color: [[.2, "#2ec7c9"], [.8, "#5ab1ef"], [1, "#d87a80"]],
                    width: 10
                }
            },
            axisTick: {
                splitNumber: 10,
                length: 15,
                lineStyle: {
                    color: "auto"
                }
            },
            splitLine: {
                length: 22,
                lineStyle: {
                    color: "auto"
                }
            },
            pointer: {
                width: 5
            }
        },
        textStyle: {
            fontFamily: "微软雅黑, Arial, Verdana, sans-serif"
        }
    };
	
var ap_bwidth = ['20','20','20','20',
		 '20', '40', '20','40',
		 '20','40', '80','160'];

var ap_pmode = ['AUTO','11A','11B','11G',
	'11NG_HT20', '11NG_HT40',
	'11NA_HT20','11NA_HT40',
	'11AC_VHT20','11AC_VHT40',
	'11AC_VHT80','11AC_VHT160'];

var ap_mode_str = ['OPEN','WPA_PSK','WPA2_PSK','WPAMIXED_PSK',
	'WEP', '8021X', 'WAPI','UNKNOWN'];

function noise_to_str(rssi)
{
	var html;

	if(rssi > -65)
		html = '<span style="color: #00a65a;">' + rssi + '</span>';
	else
	if(rssi > -70)
		html = '<span style="color: #00c0ef;">' + rssi + '</span>';
	else
		html = '<span style="color: #dd4b39;">' + rssi + '</span>';
	
	return html;
}

function col_aplist(d)
{
	var name, html = '';
	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'name') {
			html = '<span class="setBtn" lay-event="ap-option">' + d[this.field] + '</span>';
		}
		else
		if(this.field == 'group') {
			name = $('.layui-show [lay-filter="filter-group"] option[value="'+d.grpid+'"]').text();
			html = '<span class="setBtn" lay-event="ap-group-set">' + name + '</span>';
		}
		else
		if(this.field == 'mac') {
			html = '<span class="setBtn" lay-event="ap-ssid-set">' + d[this.field] + '</span>';
		}
		else
		if(this.field == 'online') {
			if(!d.online)
				html = '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>';
			else
				html = '<img src="/cloud/assets/img/online.png" class="icon" title="当前在线"/>';
		}
		else 
		if(this.field == 'cfgmagic') {
			if(!d.cfgmagic)
				html = '未配置';
			else
				html = $.myTime.UnixToStrDate(d[this.field], 'MM-dd/HH:mm:ss');
		}
		else
		if(this.field == 'pmode') {
			html = ap_pmode[d.rd0_phymode] + ' / ' + ap_pmode[d.rd1_phymode];
		}
		else
		if(this.field == 'channel') {
			html = '<span class="setBtn" lay-event="ap-option-channel">' + d.rd0_channel + ' / ' + d.rd1_channel + '</span>';
		}
		else 
		if(this.field == 'noise') {
			return noise_to_str(d.rd0_noise) + ' / ' + noise_to_str(d.rd1_noise); 
		}
		else
		if(this.field == 'chanuse') {
			html = d.rd0_chanuse + '% / ' + d.rd1_chanuse + '%';
		}
		else
		if(this.field == 'ltime') {
			html = $.myTime.UnixToStrDate(d[this.field], 'MM-dd/HH:mm:ss');
		}
		else
		if(this.field == 'usrcnt') {
			html = '<span class="setBtn" lay-event="ap-user-show">' + d.rd0_usercurr + ' / ' + d.rd1_usercurr + '</span>'; 
		}
		else
		if(this.field == 'pwr') {
			html = d.rd0_txpwr + ' / ' + d.rd1_txpwr; 
		}
		else
			html = d[this.field];
	}

	if(!d.online) 
		html = '<div class="off_txt">' + html + '</div>';

	return html;
}

var user_pmode = ['AUTO','11A','11B','11G',
		     '11NG_HT20', '11NG_HT40',
		     '11NA_HT20','11NA_HT40',
		     '11AC_VHT20','11AC_VHT40',
		     '11AC_VHT80','11AC_VHT160'];

function col_userlist(d)
{
	var name, html = '';
	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'rssi') {
			html = noise_to_str(d.st_rssi);
		}
		else
		if(this.field == 'rate') {
			html = d.st_txrate + ' / ' + d.st_rxrate;
		}
		else
		if(this.field == 'jump') {
			html = d.st_jumpap + ' / ' + d.st_jumpwlan;
		}
		else
		if(this.field == 'st_phymode') {
			html = user_pmode[d[this.field]];
		}
		else
		if(this.field == 'outbps' || this.field == 'inbps'
		|| this.field == 'outbytes' || this.field == 'inbytes') {
			html = numberformats(d[this.field]);
		}
		else
		if(this.field == 'ipname') {
			name = $('.layui-show [lay-filter="filter-group"] option[value="'+d.grpid+'"]').text();
			if(name && d.name)
				html = name + ' / ' + d.name;
			else
			if(name)
				html = name + ' / none';
			else
			if(d.name)
				html = d.name;
			else
				html = 'none';
			html = '<span class="setBtn" lay-event="mdesc">' + html + '</span>';
		}
		else
			html = d[this.field];
	}

	return html;
}

function col_ap_upgrade(d)
{
	var html = '';

	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'desc') {
			html = '<div data-apid="' + d.apid + '" data-mytype="' + d.devtype + '">' + (d.vdesc?d.vdesc:'检测中...') + '</div>';
		}
		else
		if(this.field == 'operate') {
			html = '<span class="setBtn" lay-event="del">移除</span>';
		}
		else
			html = d[this.field];
	}

	return html;
}

function col_ssidlist(d)
{
	var html = '';
	
	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'mode') {
			html = ap_mode_str[d[this.field]];
		}
		else
		if(this.field == 'operate') {
			html = '<span class="setBtn" lay-event="edit">编辑</span>'; 
			html+= ' | <span class="setBtn" style="color: red;" lay-event="del">删除</span>'; 
		}
		else
			html = d[this.field];
	}

	return html;
}

function col_sac_group_operate(d)
{
	if(d.grpid == 0)
		return '<span style="color: darkgray;">删除</span>';

	return '<span class="setBtn" lay-event="del">删除</span>';
}

function col_tasklist(d)
{
	var html = '';

	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'cmdstr') {
			html = '<span class="setBtn" lay-event="show">' + d[this.field] + '</span>';
		}
		else
		if(this.field == 'birth') {
			html = $.myTime.UnixToStrDate(d[this.field], 'HH:mm:ss');
		}
		else
		if(this.field == 'state') {
			html = task_stat[d[this.field]]; // task_stat
		}
		else
			html = d[this.field];
	}

	return html;
}

var task_stat = ['等待执行', '正在执行', '任务结束'];
var stat_desc = ['任务闲置', '等待AP获取命令','等待解析任务','任务执行中','解析命令失败', '执行成功','执行失败','执行超时'];
var reply_desc_cn = [
			'字符串超长', 
			'该SSID已经存在，故忽略当前配置指令', 
			'无可用WLAN', 
			'指定的WLAN已被占用', 
			'参数不正确', 
			'没有找到该SSID，故忽略当前配置指令', 
			'没有找到该SSID', 
			'参数错误:没有newverstr或cloud地址', 
			'仅支持HTTP或HTTPS链接', 
			'设备类型不匹配', 
			'参数错误:2G和5G配置请至少勾选一个', 
			'没有找到指定的AP', 
			'参数错误:没有找到指定的频道',
			'该SSID为加密模式，但未设置密码，请先设置。'
];
/*
		if (reply_msg.search("ERROR:") != -1) {
			reply_msg = reply_desc_cn[reply_msg.split('ERROR:')[1]];
		}
*/
function col_currtasklist(d)
{
	var html = '';
	var havErr = d.reply.search("ERROR:");
	
	if(havErr == -1)
		havErr = d.reply.search("FAILED:");

	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'birth') {
			html = $.myTime.UnixToStrDate(d[this.field], 'HH:mm:ss');
		}
		else
		if(this.field == 'state') {
			html = stat_desc[d[this.field]]; // task_stat
		}
		else
		if(this.field == 'ttl') {
			html = d[this.field] + 's';
		}
		else
		if(this.field == 'reply'){
			if(d.reply.search("ERROR:") != -1)
				html = reply_desc_cn[d.reply.split('ERROR:')[1]]; 
			else
			if(d.reply.search("FAILED:") != -1)
				html = d.reply.substr(7);
		}
		else
			html = d[this.field];
	}

	if (havErr != -1) 
		html = '<div class="off_txt">' + html + '</div>';

	return html;
}

function col_ssid_configlist(d)
{
	var html = '';

	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'radio') {
			html = d[this.field] ? '5G': '2G';
		}
		else
		if(this.field == 'name') {
			html = '<span class="setBtn" lay-event="name">' + d[this.field] + '</span>';
		}
		else
		if(this.field == 'stanum') {
			html = '<span class="setBtn" lay-event="ap-user-show">' + d[this.field] + '</span>'; 
		}
		else
		if(this.field == 'mode') {
			html = ap_mode_str[d[this.field]];
		}
		else
		if(this.field == 'operate') {
			if(d.hide) 
				html = '<span style="color: #aaaaaa;">隐藏</span> | <span class="setBtn" lay-event="show">显示</span>';
			else
				html = '<span class="setBtn" lay-event="hide">隐藏</span> | <span style="color: #aaaaaa;">显示</span>';

			html+= ' | <span class="setBtn" lay-event="del">删除</span>';
		}
		else
			html = d[this.field];
	}

	return html;
}

var event_str = ['', '添加网络', '删除网络', '修改网络',
				 '修改射频', '升级', '重启', '重置', '关灯', '开灯',
				 '未知', '上线', '超时离线' ];
var level_str = ['提示', '警告', '错误', '调试' ];
function col_loggerlist(d)
{
	var html = '';
	
	if (this.field == undefined)
		return html;
	else {
		if(this.field == 'birth') {
			html = $.myTime.UnixToStrDate(d[this.field], true);
		}
		else
		if(this.field == 'event') {
			html = event_str[d[this.field]];
		}
		else
		if(this.field == 'grpid') {
			html = $('.layui-show [lay-filter="filter-group"] option[value="'+d[this.field]+'"]').text();
		}
		else
		if(this.field == 'level') {
			html = level_str[d[this.field]];
		}
		else
			html = d[this.field];
	}

	return html;
}

window.onresize = function () {
	for(i in echarts_pool)
		echarts_pool[i].resize();
};

var echarts_pool = [];

layui.use(['element', 'form', 'table', "carousel"], function() {
	var element = layui.element;
	var form = layui.form;
	var table = layui.table;
	var timer = new taskTimer();
	var carousel = layui.carousel,
		opt = [{
			title: {
				text: "最近24小时用户趋势",
				x: "center",
				textStyle: {
					fontSize: 14
				}
			},
			tooltip: {
				trigger: "axis"
			},
			legend: {
				data: [""]
			},
			xAxis: [{
				type: "category",
				boundaryGap: !1,
				data: []
			}],
			yAxis: [{
				type: "value"
			}],
			series: [{
				symbol: "none",
				name: "用户",
				type: "line",
				smooth: !0,
				itemStyle: {
					normal: {
						areaStyle: {
							type: "default"
						}
					}
				},
				data: []
			}]
		}, {
			title: {
				text: "最近24小时速率趋势",
				x: "center",
				textStyle: {
					fontSize: 14
				}
			},
			tooltip: {
				trigger: "axis",  
				formatter:function(params)  
				{  
				   var relVal = params[0].name;  
				   for (var i = 0, l = params.length; i < l; i++) {  
						relVal += '<br/>' + params[i].marker + params[i].seriesName + ' : ' + numberformats(params[i].value);  
					}  
				   return relVal;  
				}
			},
			legend: {
				data: ['上行', '下行'],
				right: 20,
			},
			xAxis: [{
				type: "category",
				boundaryGap: !1,
				data: []
			}],
			yAxis: [{
				type: "value",
				axisLabel: {
					formatter: numberformats
				}
			},
			{
				type: "value",
				axisLabel: {
					formatter: numberformats
				}
			}],
			series: [{
				symbol: "none",
				name: "上行",
				type: "line",
				smooth: !0,
				itemStyle: {
					normal: {
						areaStyle: {
							type: "default"
						}
					}
				},
				data: []
			}, {
				symbol: "none",
				name: "下行",
				type: "line",
				smooth: !0,
				itemStyle: {
					normal: {
						areaStyle: {
							type: "default"
						}
					}
				},
				data: []
			}]
		}, {
			title: {
				text: "最近24小时PPS趋势",
				x: "center",
				textStyle: {
					fontSize: 14
				}
			},
			tooltip: {
				trigger: "axis",  
				formatter:function(params)  
				{  
				   var relVal = params[0].name;  
				   for (var i = 0, l = params.length; i < l; i++) {  
						relVal += '<br/>' + params[i].marker + params[i].seriesName + ' : ' + numberformats(params[i].value);  
					}  
				   return relVal;  
				}
			},
			legend: {
				data: ['上行', '下行'],
				right: 20,
			},
			xAxis: [{
				type: "category",
				boundaryGap: !1,
				data: []
			}],
			yAxis: [{
				type: "value",
				axisLabel: {
					formatter: numberformats
				}
			},
			{
				type: "value",
				axisLabel: {
					formatter: numberformats
				}
			}],
			series: [{
				symbol: "none",
				name: "上行",
				type: "line",
				smooth: !0,
				itemStyle: {
					normal: {
						areaStyle: {
							type: "default"
						}
					}
				},
				data: []
			}, {
				symbol: "none",
				name: "下行",
				type: "line",
				smooth: !0,
				itemStyle: {
					normal: {
						areaStyle: {
							type: "default"
						}
					}
				},
				data: []
			}]
		}];

	var dataview = $('#sac-user-dataview, #sac-bps-dataview, #sac-pps-dataview').children("div");
	dataview.each(function(index, e) {
		var id = e.parentElement.getAttribute('id');
		echarts_pool[id] = echarts.init(e, echartsTheme),
		echarts_pool[id].setOption(opt[index]),
		echarts_pool[id].resize();
	});

	window.onresize();
	
	var table_option = {
		even: true,
		loading: false,
		limit: get_tb_paga(),
		skin: 'line',
		method: 'post',
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			var d, i, data, patt;
			if (res.ret == 0) {
				if(typeof(res.data) == 'string') {
					patt = new RegExp("^(\\[.*.\\]|\\[\\]|\\{\\}|\\{.*.\\})$");
					if(patt.test(res.data)) {
						try{
							res.data = eval('(' + res.data + ')');
							res.count = res.data.total;
							res.data = res.data.rows;
						}
						catch(err) {
							res.data = [];
							res.count= 0;
						}
					}
				}
				else {
					res.count = res.data.total;
					res.data = res.data.rows;
					if(res.data.total == undefined)
						res.count = res.data.length;
				}
			}

			res.code = res.ret;
			res.msg = res.msg;
			
		},
	};

	table.init('sac-ap-mgd', $.extend(true, {}, table_option, {
		done: function(res, curr, count) {
			var e = $('#sac-ap-mgd').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		}
	}));
	table.init('sac-user-mgd', $.extend(true, {}, table_option, {
		done: function(res, curr, count) {
			var e = $('#sac-user-mgd').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		}
	}));
	table.init('sac-ssid-mgd', $.extend(true, {}, table_option, {
		done: function(res, curr, count) {
			var currssid = $('#user-toptool select[name="ssid"] option').val();
			
			$('#user-toptool select[name="ssid"] option').not('[value=""]').remove();
			for (i = 0; i < res.data.length; i++)
				$('select[name="ssid"]')
				.append(new Option(res.data[i].name + ' [' + res.data[i].apcnt + ']', res.data[i].name));

			$('#user-toptool select[name="ssid"] option[value="' + currssid + '"]').prop('selected', true);
			form.render('select');
			
			var e = $('#sac-ssid-mgd').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		}
	}));
	table.init('sac-logger-mgd', $.extend(true, {}, table_option, {
		done: function(res, curr, count) {
			var e = $('#sac-logger-mgd').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		}
	}));
	
	var tb_index = 0;
	element.on('tab(sac-tab)', function(data) {
		var tbid = this.getAttribute('data-tbid');
		tb_index = data.index;
		if(tbid) {
			if(tbid == 'sac-ap-mgd') {
				ap_search(1);
			}
			else
			if(tbid == 'sac-user-mgd') {
				user_search(1);
				auto_ap_refresh();
			}
			else
			if(tbid == 'sac-ssid-mgd') {
				ssid_search(1);
			}
			else
			if(tbid == 'sac-logger-mgd') {
				logger_search(1);
			}
		}
		else 
			window.onresize();
	});
	
	table.on('tool(sac-ap-mgd)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'ap-option') {
			layer.open({
				type: 1,
				shadeClose: true,
				resize: false,
				title: '设备命名 / ' + data.name,
				btnAlign: 'c',
				btn: ['确定'],
				content: $('#tpl-sac-ap-name-set').html(),
				success: function(layero, index) {
					layero.find('.layui-layer-content').css('overflow', 'inherit');

					form.val('ap-name-set-form', data);
					form.render();
				},
				yes: function(index, layero) {
					var d = form.val('ap-name-set-form');

					if(d.name == "") {
						layer.msg('设备名称不能为空！', {
							icon: 5
						});
						return ;
					}

					$.ajax({
						url: 'api.php?r=sac@ap-name',
						data: d,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							ap_search();
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
		}
		else
		if (event == 'ap-option-channel') {
			ap_rdnconfig(data);
		}
		else
		if (event == 'ap-user-show') {
			$('#user-toptool select[lay-filter="filter-group"]').val(-1);
			$('#user-toptool select[lay-filter="filter-apid"]').val(data.apid);
			$('#user-toptool select[lay-filter="filter-ssid"]').val('');
			form.render('select');
			element.tabChange('sac-tab', 'sac-user-mgd');
		}
		else
		if(event == 'ap-group-set') {
			layer.open({
				type: 1,
				shadeClose: true,
				resize: false,
				title: '网络组配置 / ' + data.name,
				btnAlign: 'c',
				btn: ['保存'],
				content: $('#tpl-ap-group-set').html(),
				success: function(layero, index) {
					layero.find('.layui-layer-content').css('overflow', 'inherit');

					var tab = layero.find('select[name="grpid"]');
					$('#ap-toptool select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
						tab.append($(e).clone());
					});

					form.val('ap-group-set-form', data);
					
					form.render('select');
				},
				yes: function(index, layero) {
					var d = form.val('ap-group-set-form');

					d.ridx = 0;
					d.dev = data.apid;
					
					$.ajax({
						url: 'api.php?r=sac@task-modrd-config',
						data: d,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							ap_search();
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
		}
		else
		if(event == 'ap-ssid-set') {
			layer.open({
				type: 1,
				shadeClose: true,
				resize: false,
				area: ['680px', '383px'],
				title: 'SSID管理 / ' + data.name + ' [' + data.ip + ']',
				content: $('#tpl-ap-ssid-config').html(),
				success: function(layero, index) {
					layero.find('.layui-layer-content').css('overflow', 'inherit');

					table.init('ap-ssid-config-tb', $.extend(true, {}, table_option, {
						page: false,
						url: 'api.php?r=sac@ap-list&retfmt=3&apid=' + data.apid,
						done: function(res, curr, count) {
							layero.find('.layui-table-view').css('margin-top', '0px');
						}
					}));

					table.on('tool(ap-ssid-config-tb)', function(obj) {
						var data = obj.data,
							event = obj.event;

						if (event == 'name') {
							ssid_edit(data);
						}
						else
						if (event == 'ap-user-show') {
							$('#user-toptool select[lay-filter="filter-group"]').val(-1);
							$('#user-toptool select[lay-filter="filter-apid"]').val(data.apid);
							$('#user-toptool select[lay-filter="filter-ssid"]').val(data.name);
							form.render('select');
							element.tabChange('sac-tab', 'sac-user-mgd');
						}
						else
						if (event == 'hide') {
							layer.confirm('确定要在无线网络中隐藏此SSID吗？', function(index){
								$.ajax({
									url: 'api.php?r=sac@task-wlan-hide',
									data: {
										dev: data.apid,
										ssid: data.name,
										rdidx: data.radio + 1
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});

										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
						}
						else
						if (event == 'show') {
							layer.confirm('确定要让此SSID可以在无线网络中被发现吗？', function(index){
								$.ajax({
									url: 'api.php?r=sac@task-wlan-show',
									data: {
										dev: data.apid,
										ssid: data.name,
										rdidx: data.radio + 1
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});

										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
						}
						else
						if (event == 'del') {
							layer.confirm('确定要删除此SSID吗？', function(index){
								$.ajax({
									url: 'api.php?r=sac@task-wlan-remove',
									data: {
										dev: data.apid,
										ssid: data.name,
										rdidx: data.radio + 1
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});

										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
						}
					});

					timer.add('ap-ssid-config-tb', 3, {
						fuc: function() {
							var that = this;
							if(tb_index != 1) return;

							var option = {
								method: 'post',
								wherecb: function(w) {
									var op = {};
									if (w.sort && w.g_ascdesc) {
										op.sort = w.sort;
										op.g_ascdesc = w.g_ascdesc;
									}
									return op;
								}
							}
							table.reloadExt('ap-ssid-config-tb', option);
						}
					});
				},
				end: function() {
					timer.rmv('ap-ssid-config-tb');
				}
			});
		}
	});

	function auto_group_refresh(selected)
	{
		if(arguments.length == 0) 
			selected = $('.getwaytool select[lay-filter="filter-group"]').val();

		timer.add('sac_group_refresh', 1, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=sac@group-list',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						
						$('.getwaytool select[lay-filter="filter-group"] option').not('[value=-1]').remove();
						for (i = 0; i < data.length; i++)
							$('.getwaytool select[lay-filter="filter-group"]')
							.append(new Option(data[i].grpname, data[i].grpid));

						if(selected != undefined) 
							$('.getwaytool select[lay-filter="filter-group"] option[value="' + selected + '"]').prop('selected', true);

						form.render('select');
						timer.rmv('sac_group_refresh');
					}
				});
			}
		}, 1);
	}
	
	function auto_ap_refresh(selected)
	{
		if(arguments.length == 0) 
			selected = $('.getwaytool select[lay-filter="filter-apid"]').val();

		timer.add('sac_ap_refresh', 1, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=sac@ap-list&retfmt=1',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						var patt = new RegExp("^(\\[.*.\\]|\\[\\]|\\{\\}|\\{.*.\\})$");
						if(patt.test(data)) {
							try{
								data = eval('(' + data + ')');
							}
							catch(err) {
								data.rows = [];
							}
						}
						
						$('.getwaytool select[lay-filter="filter-apid"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('.getwaytool select[lay-filter="filter-apid"]')
							.append(new Option(data.rows[i].name, data.rows[i].apid));

						if(selected != undefined) 
							$('.getwaytool select[lay-filter="filter-apid"] option[value="' + selected + '"]').prop('selected', true);

						form.render('select');
						timer.rmv('sac_ap_refresh');
					}
				});
			}
		}, 1);
	}
	
	function auto_refresh() {
		auto_group_refresh();
		
		timer.add('sac_survey_stat', 1, {
			fuc: function() {
				var that = this;
				if(tb_index) return;
				$.ajax({
					url: 'api.php?r=sac@ap-stat',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var data = d.data;

						$("#ap-user-curr cite").text(data.sta_cnt);
						$("#ap-user-max cite").text(data.sta_max);
						$("#ap-user-2g cite").text(data.sta_cnt2g);
						$("#ap-user-5g cite").text(data.sta_cnt5g);
						
						$("#ap-devcnt-curr cite").text(data.ap_cnt);
						$("#ap-devcnt-max cite").text(data.ap_max);
						$("#ap-devbps-in cite").text(numberformats(data.allinbps));
						$("#ap-devbps-out cite").text(numberformats(data.alloutbps));
					}
				});
			}
		}, 1);
		
		timer.add('sac_ap_chart', 360, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=sac@chart',
					data: {type: 7},
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, row, times = [], data = d.data;
						var patt = new RegExp("^(\\[.*.\\]|\\[\\]|\\{\\}|\\{.*.\\})$");
						if(patt.test(data.rows)) {
							try{
								data = eval('(' + data.rows + ')');
							}
							catch(err) {
								data = [];
							}
						}
						
						var opt = {
							xAxis: {
								data: []
							},
							series: [{
								name: "用户",
								data: []
							}]
						}
						
						var bps = {
							xAxis: {
								data: []
							},
							series: [{
								name: "上行",
								data: []
							},
							{
								name: "下行",
								data: []
							}]
						}
						
						for(i = 0; i < data.length; i++) {
							row = data[i];
							times.push($.myTime.UnixToStrDate(row.time, 'HH:mm'));
							opt.series[0].data.push(row.apcnt);
							
							bps.series[1].data.push(row.inbps);
							bps.series[0].data.push(row.outbps);
						}
 
						opt.xAxis.data = times;
						echarts_pool['sac-user-dataview'].setOption(opt);

						bps.xAxis.data = times;
						echarts_pool['sac-bps-dataview'].setOption(bps);
					}
				});
				
				/*
				$.ajax({
					url: 'api.php?r=sac@bps-chart',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, row, data = d.data;

						opt = {
							xAxis: [{
								data: []
							}],
							series: [{
								name: "下行",
								data: []
							},
							{
								name: "上行",
								data: []
							}]
						}
						
						for(i = 0; i < data.bpsin.length; i++) {
							row = data.bpsin[i];
							opt.xAxis[0].data.push($.myTime.UnixToStrDate(row.x, 'HH:mm'));
							opt.series[0].data.push(row.y);
							opt.series[1].data.push(data.bpsout[i].y);
						}
 
						echarts_pool['sac-bps-dataview'].setOption(opt);
					}
				});
				*/
			}
		}, 1);
	}
	auto_refresh();

	// ap 
	function ap_search(page, obj) {
		var where = {
			grpid: Number($('#ap-toptool [name="grpid"]').val()),
			keyword: $.trim($('#ap-toptool input[name="keyword"]').val()),
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;
		if (obj) {
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('sac-ap-mgd', option);
	}
	
	function ap_config(devs)
	{
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: 'AP配置',
			area: ['400px', '460px'],
			btnAlign: 'c',
			btn: ['保存'],
			content: $('#tpl-ap-config').html(),
			success: function(layero, index) {
				layero.find('.layui-layer-content').css('overflow', 'inherit');

				var tab = layero.find('select[name="grpid"]');
				$('#ap-toptool select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
					tab.append($(e).clone());
				});

				form.render('checkbox');
				form.render('select');
			},
			yes: function(index, layero) {
				var d = form.val('ap-config');

				d.ridx = (layero.find('[data-ridx="2G"]').prop('checked') ? 1:0);
				d.ridx|= (layero.find('[data-ridx="5G"]').prop('checked') ? 2:0);

				d.dev = devs;
				
				d.rd0_enable = (d.rd0_enable == 'on' ? 1: 0);
				d.rd1_enable = (d.rd1_enable == 'on' ? 1: 0);
				
				$.ajax({
					url: 'api.php?r=sac@task-modrd-config',
					data: d,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if(d.data >= 0)
							show_currtasks(d.data);

						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						
						ap_search();
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	}

	function ap_rdnconfig(data)
	{
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: 'AP网络配置' + (data.name ? ' / ' + data.name : ''),
			area: ['340px', '330px'],
			btnAlign: 'c',
			btn: ['保存'],
			content: $('#tpl-ap-config-channel').html(),
			success: function(layero, index) {
				layero.find('.layui-layer-content').css('overflow', 'inherit');

				form.val('ap-2Gchain', data);
				form.val('ap-5Gchain', data);

				form.render('checkbox');
				form.render('select');
			},
			yes: function(index, layero) {
				var d = $.extend(true, {}, form.val('ap-2Gchain'), form.val('ap-5Gchain'));

				d.ridx = 3;
				d.rd0_enable = (d.rd0_enable == 'on' ? 1: 0);
				d.rd1_enable = (d.rd1_enable == 'on' ? 1: 0);

				d.dev = data.apid;
				$.ajax({
					url: 'api.php?r=sac@task-modrd-change',
					data: d,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						show_currtasks(d.data);
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						layer.close(index);
						ap_search();
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	}

	function ap_toptoolbar()
	{
		var checkStatus = table.checkStatus('sac-ap-mgd');
		var devs = [];

		checkStatus.data.forEach(function(e, i) {
			devs.push(e.apid);
		});
		if (devs.length <= 0) 
			layer.msg('请先选择要操作的AP设备。');

		return devs;
	}
	
	function led_light(devs, on)
	{
		$.ajax({
			url: 'api.php?r=sac@task-led',
			data: {
				dev: devs,
				led: on
			},
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				show_currtasks(d.data);
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
			},
			error: function() {
				layer.msg('获取数据失败，请稍后再试。', {
					icon: 2
				});
			}
		});
	}
	
	function show_currtasks(id)
	{
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '当前任务 - ' + id,
			area: ['600px', '400px'],
			btnAlign: 'c',
			content: $('#tpl-sac-task-runing').html(),
			end: function(){
				timer.rmv('task-table-update' + id);
			},
			success: function(layero, index) {
				var code = 0, data = [];
				
				layero.find('.layui-layer-content').css('overflow', 'inherit');
				table.init('task-tb-runing', $.extend(true, {}, table_option, {
					page: false,
					url: 'api.php?r=sac@task-get&taskid=' + id,
					parseData: function(res) {
						code = res.ret;

						if (res.ret == 0) {
							data = res.data.rows;
							var patt = new RegExp("^(\\[.*.\\]|\\[\\]|\\{\\}|\\{.*.\\})$");
							if(patt.test(data)) {
								try{
									res.data = eval('(' + data + ')');
									res.count = res.data.rows.length;
									res.task = res.data.task;
								}
								catch(err) {
									res.data = [];
									res.count= 0;
								}
							}
							res.count = res.data.total;
							res.data = res.data.rows;
							res.code = res.ret;
						}
						else {
							res.data = data;
							res.count= data.length;
							res.code = 0;
						}

						res.msg = res.msg;
					},
					done: function(res, curr, count) {
						layero.find('.layui-table-tool').css('background-color', 'white');
					}
				}));

				timer.add('task-table-update' + id, 2, {
					fuc: function() {
						if(code) {
							timer.rmv('task-table-update' + id);
							return;
						}
						table.refresh('task-tb-runing');
					}
				});
			}
		});
	}

	$('#ap-toptool button.search').on('click', function(obj) {
		ap_search(1);
	});

	$('#ap-toptool input[name="keyword"]').keyup(function(event) {
		if (event.keyCode == 13) {
			ap_search(1);
		}
	});

	$('#ap-toptool button.add').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if (devs.length <= 0) return;

		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '请选择要添加的SSID - 已选中 ' + devs.length,
			btnAlign: 'c',
			btn: ['确定'],
			content: $('#tpl-sac-ssid-select-add').html(),
			success: function(layero, index) {
				layero.find('.layui-layer-content').css('overflow', 'inherit');
				form.render();
				
				timer.add('sac_ap_ssid_select', 1, {
					fuc: function() {
						var that = this;
						$.ajax({
							url: 'api.php?r=sac@ssid-list&limit=256',
							type: 'post',
							success(d) {
								if (ajax_resultCallBack(d) == false) return;
								var i, data = d.data;
								var patt = new RegExp("^(\\[.*.\\]|\\[\\]|\\{\\}|\\{.*.\\})$");
								if(patt.test(data)) {
									try{
										data = eval('(' + data + ')');
									}
									catch(err) {
										data = [];
									}
								}
								layero.find('select[name="ssid"] option').not('[value=""]').remove();
								var html = '<option value="请选择">请选择</option>';
								for (var i = 0; i < data.rows.length; i++) {
									html += '<option value="' + data.rows[i].name +'">' + data.rows[i].name + ' [' + data.rows[i].apcnt + ']' + '</option>';
								}
								layero.find('select[name="ssid"]').empty();
								layero.find('select[name="ssid"]').html(html);
								form.render('select');
								timer.rmv('sac_ap_ssid_select');
							}
						});
					}
				}, 1);
			},
			yes: function(pindex, layero) {
				var d = form.val('ssid-select-form');

				var ridx = (d['like[2G]'] == 'on' ? 1:0);
				ridx|= (d['like[5G]'] == 'on' ? 2:0);
				
				var hide = (d['hide[2G]'] == 'on' ? 1:0);
				hide|= (d['hide[5G]'] == 'on' ? 2:0);
				
				if(d.ssid == "") {
					layer.msg('请选SSID！', {
						icon: 5
					});
					return ;
				}

				if(ridx == 0) {
					layer.msg('请选生效射频！', {
						icon: 5
					});
					return ;
				}
				
				layer.confirm('确认要为选中的AP设备添加“<span style="color: red;">' + d.ssid + '</span>”SSID吗?', {
					icon: 0,
					title: 'AP设备SSID添加'
				}, function(index) {
					layer.close(index);

					$.ajax({
						url: 'api.php?r=sac@task-wlan-add',
						data: {
							dev: devs.join(','),
							ssid: d.ssid,
							hide: hide,
							ridx: ridx,
							widx: d.widx
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							show_currtasks(d.data);
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							layer.close(pindex);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				});
			}
		});
	});
	
	$('#ap-toptool button.del').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if (devs.length <= 0) return;

		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '请选择要删除的SSID - 已选中 ' + devs.length,
			btnAlign: 'c',
			btn: ['确定'],
			content: $('#tpl-sac-ssid-select-del').html(),
			success: function(layero, index) {
				layero.find('.layui-layer-content').css('overflow', 'inherit');
				form.render();
				
				timer.add('sac_ap_ssid_select', 1, {
					fuc: function() {
						var that = this;
						$.ajax({
							url: 'api.php?r=sac@ssid-list',
							type: 'post',
							data: {apcnt: 1},
							success(d) {
								if (ajax_resultCallBack(d) == false) return;
								var i, data = d.data;
								var patt = new RegExp("^(\\[.*.\\]|\\[\\]|\\{\\}|\\{.*.\\})$");
								if(patt.test(data)) {
									try{
										data = eval('(' + data + ')');
									}
									catch(err) {
										data.rows = [];
									}
								}
								layero.find('select[name="ssid"] option').not('[value=""]').remove();
								for (i = 0; i < data.rows.length; i++)
									layero.find('select[name="ssid"]')
									.append(new Option(data.rows[i].name + ' [' + data.rows[i].apcnt + ']', data.rows[i].name));

								form.render('select');
								timer.rmv('sac_ap_ssid_select');
							}
						});
					}
				}, 1);
			},
			yes: function(pindex, layero) {
				var d = form.val('ssid-select-form');

				if(d.ssid == "") {
					layer.msg('请选择SSID！', {
						icon: 5
					});
					return ;
				}

				layer.confirm('确认要从选中的AP设备中删除“<span style="color: red;">' + d.ssid + '</span>”SSID吗?', {
					icon: 0,
					title: 'AP设备SSID删除'
				}, function(index) {
					layer.close(index);
					$.ajax({
						url: 'api.php?r=sac@task-wlan-remove',
						data: {
							dev: devs.join(','),
							ssid: d.ssid
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							show_currtasks(d.data);
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							layer.close(pindex);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				});
			}
		});
	});

	$('#ap-toptool button.task-mgd').on('click', function(obj) {
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '任务列表',
			area: ['600px', '400px'],
			btnAlign: 'c',
			content: $('#tpl-sac-task').html(),
			end: function() {
				timer.rmv('sac_task_refresh');
			},
			success: function(layero, index) {
				table.init('sac-task-tb', $.extend(true, {}, table_option, {
					page: false,
					done: function(res, curr, count) {
						layero.find('.layui-table-tool').css('background-color', 'white');
					}
				}));

				timer.add('sac_task_refresh', 2, {
					fuc: function() {
						table.refresh('sac-task-tb');
					}
				});
	
				table.on('tool(sac-task-tb)', function(obj) {
					var data = obj.data,
						event = obj.event;

					if (event === 'show') {
						show_currtasks(data.taskid);
					}
				});
			}
		});
	});
	
	$('#ap-toptool button.upgrade-mgd').on('click', function(obj) {
		var checkStatus = table.checkStatus('sac-ap-mgd');

		if (checkStatus.data.length <= 0) {
			layer.msg('请先选择要操作的AP设备。');
			return;
		}

		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: 'AP设备升级',
			area: ['600px', '430px'],
			btnAlign: 'c',
			btn: ['开始升级'],
			content: $('#tpl-ap-upgrade-mgd').html(),
			end: function() {
			},
			success: function(layero, index) {
				table.init('ap-upgrade-tb', $.extend(true, {}, table_option, {
					page: false,
					/*
					toolbar: true,
					defaultToolbar: [{
						title: '升级设备',
						layEvent: 'LAYTABLE_UPGRADE',
						icon: 'layui-icon-add-circle'
					}],
					*/
					data: checkStatus.data,
					done: function(res, curr, count) {
						var types = [];
						res.data.forEach(function(e, i) {
							types.push(e.devtype);
						});
						timer.add('ap-upgrade-tb', 3, {
							fuc: function() {
								var that = this;
								$.ajax({
									url: 'api.php?r=sac@ap-verinfo',
									data: {types: types.join(',')},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) 
											return;
										timer.rmv('ap-upgrade-tb');
										
										desc = '<span style="color: red;">检测失败！</span>';
										res.data.forEach(function(e, i) {
											res.data[i].vdesc = desc;
										});
										layero.find('[data-mytype]').html(desc);
										for(i in d.data) {
											e = d.data[i];
											var ver = e.SFT_VER + '_' + e.SFT_DATE;
											var desc, j, x = layero.find('[data-mytype="' + e.DEV_TYPE + '"]');

											x.each(function(i, v) {
												var x = $(v);
												if(ver == x.parents('tr').children('[data-field="ver"]').attr('data-content')) {
													desc = '<span style="color: green;">已是最新。</span>';
													x.html(desc);
													for(j in res.data) {
														if(ver == res.data[j].ver)
															res.data[j].vdesc = desc;
													}
												}
												else 
												if(e.SFT_VER != '') {
													desc = '<span style="color: green;" title="可升级">' + ver + ' [UP]</span>';
													x.html(desc);
													x.attr('data-pkname', e.FILE_NAME);
													for(j in res.data) {
														if(ver == res.data[j].ver)
															res.data[j].vdesc = desc;
													}
												}
											});
										}
									}
								});
							}
						}, 1);
					}
				}));

				table.on('tool(ap-upgrade-tb)', function(obj) {
					var data = obj.data,
						event = obj.event;

					if (event === 'del') {
						layer.confirm('确定要从升级列表中移除此AP吗？', function(index){
							obj.del();
							layer.close(index);
						});
					}
				});
			},
			yes: function(index, layero){
				var i, l = [], d = {};

				layero.find('[data-pkname]').each(function(i, e){
					var apid = e.getAttribute('data-apid');
					var type = e.getAttribute('data-mytype');
					var pk = e.getAttribute('data-pkname');
					if(type && pk) {
						if(!d[type])
							d[type] = {d: [apid], pk: pk};

						d[type].d.push(apid);
					}
				});

				for(i in d) {
					l.push({
						d: d[i].d.join(','),
						pk: d[i].pk
					});
				}

				if(l.length == 0) {
					layer.msg('暂无需要升级的AP设备。');
					return;
				}

				$.ajax({
					url: 'api.php?r=sac@task-upgrade',
					data: {d: l},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});

	$('#ap-toptool button.group-mgd').on('click', function(obj) {
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '网络组管理',
			area: ['600px', '400px'],
			btnAlign: 'c',
			content: $('#tpl-sac-group').html(),
			end: function() {
				auto_group_refresh();
			},
			success: function(layero, index) {
				table.init('sac-group-tb', $.extend(true, {}, table_option, {
					page: false,
					toolbar: true,
					defaultToolbar: [{
						title: '添加主机组',
						layEvent: 'LAYTABLE_ADDGROUP',
						icon: 'layui-icon-add-circle'
					}],
					parseData: function(res) {
						var d, i, data, patt;
						if (res.ret == 0) 
							res.count = res.data.length;

						res.code = res.ret;
						res.msg = res.msg;
						
					},
					done: function(res, curr, count) {
						layero.find('.layui-table-tool').css('background-color', 'white');
					}
				}));

				table.on('tool(sac-group-tb)', function(obj) {
					var data = obj.data,
						event = obj.event;

					if (event === 'del') {
						layer.confirm('确定要删除该组吗？', function(index){
							$.ajax({
								url: 'api.php?r=sac@group-remove',
								data: {
									grpid: data.grpid
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}
									if (d.msg) layer.msg(d.msg, {
										icon: 1
									});

									obj.del();
									layer.close(index);
								},
								error: function() {
									layer.msg('获取数据失败，请稍后再试。', {
										icon: 2
									});
								}
							});
						});
					}
				});

				table.on('toolbar(sac-group-tb)', function(obj) {
					var checkStatus = table.checkStatus(obj.config.id),
						data = checkStatus.data;

					switch (obj.event) {
						case 'LAYTABLE_ADDGROUP':
							layer.prompt({
								formType: 0,
								value: '',
								maxlength: 31,
								title: '请输入组名称',
								area: ['300px', '120px']
							}, function(value, index, elem) {
								value = $.trim(value);
								if (value == '') {
									layer.msg('组名称不能为空！', {
										icon: 5
									});
									return;
								}
								$.ajax({
									url: 'api.php?r=sac@group-add',
									data: {
										name: value
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});
										layer.close(index);
										table.refresh('sac-group-tb');
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
							break;
					}
				});
			}
		});
	});
	
	$('#ap-toptool button.open').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if(devs.length <= 0) return;

		layer.confirm('确认要打开选中AP设备的灯吗?', {
			icon: 0,
			title: '打开AP灯'
		}, function(index) {
			layer.close(index);
			led_light(devs.join(','), 1);
		});
	});
	$('#ap-toptool button.close').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if(devs.length <= 0) return;

		layer.confirm('确认要关闭选中AP设备的灯吗?', {
			icon: 0,
			title: '关闭AP灯'
		}, function(index) {
			layer.close(index);
			led_light(devs.join(','), 0);
		});
	});
	$('#ap-toptool button.reboot').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if(devs.length <= 0) return;

		layer.confirm('确认要重启选中的AP设备吗?', {
			icon: 0,
			title: '重启AP设备'
		}, function(index) {
			layer.close(index);
			$.ajax({
				url: 'api.php?r=sac@task-reboot',
				data: {
					dev: devs.join(',')
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					show_currtasks(d.data);
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		});
	});

	$('#ap-toptool button.reset').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if(devs.length <= 0) return;

		layer.confirm('确认要重置选中的AP设备吗?', {
			icon: 0,
			title: '重置AP设备'
		}, function(index) {
			layer.close(index);
			$.ajax({
				url: 'api.php?r=sac@task-reset',
				data: {
					dev: devs.join(',')
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					show_currtasks(d.data);
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		});
	});
	
	$('#ap-toptool button.config').on('click', function(obj) {
		var devs = ap_toptoolbar();

		if(devs.length <= 0) return;
		
		ap_config.call(this, devs.join(','));
	});
	
	// user
	function user_search(page, obj) {
		var where = {
			grpid: Number($('#user-toptool [name="grpid"]').val()),
			apid: Number($('#user-toptool [name="apid"]').val()),
			ssid: $.trim($('#user-toptool [name="ssid"]').val()),
			keyword: $.trim($('#user-toptool input[name="keyword"]').val()),
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;
		if (obj) {
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('sac-user-mgd', option);
	}
	
	table.on('tool(sac-user-mgd)', function(obj) {
		var data = obj.data,
			str = '',
			event = obj.event;

		if (event == 'mdesc') {
			if(data.group && data.name)
				str = data.group + ' / ' + data.name;
			else
			if(data.group)
				str = data.group + ' / none';
			else
			if(data.name)
				str = data.name;

			layer.prompt({
				formType: 0,
				value: str,
				title: '请输入备注',
				maxlength: 26,
				area: ['300px', '120px'],
				yes: function(index, layero){
					var value = $.trim(layero.find('.layui-layer-input').val());
					$.ajax({
						url: 'api.php?r=sac@user-set',
						data: {
							mac: data.mac,
							name: value
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							layer.close(index);
							user_search();
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
		}
	});
	
	$('#user-toptool button.search').on('click', function(obj) {
		user_search(1);
	});

	$('#user-toptool input[name="keyword"]').keyup(function(event) {
		if (event.keyCode == 13) {
			user_search(1);
		}
	});

	// ssid
	function ssid_search(page, obj) {
		var where = {
			keyword: $.trim($('#ssid-toptool input[name="keyword"]').val())
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;
		if (obj) {
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('sac-ssid-mgd', option);
	}

	function ssid_del(devs)
	{
		$.ajax({
			url: 'api.php?r=sac@ssid-remove',
			data: {
				name: devs
			},
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
				ssid_search();
			},
			error: function() {
				layer.msg('获取数据失败，请稍后再试。', {
					icon: 2
				});
			}
		});
	}
	
	function ssid_edit(data)
	{
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '编辑SSID',
			area: ['350px', '290px'],
			btnAlign: 'c',
			btn: ['确定'],
			content: $('#tpl-ssid-add').html(),
			success: function(layero, index) {
				layero.find('.layui-layer-content').css('overflow', 'inherit');
				layero.find('[name="name"]').css('background-color', '#eeeeee').prop('disabled', true);
				form.val('ssid-add', data);

				form.render('checkbox');
				form.render('select');
			},
			yes: function(index, layero) {
				var d = form.val('ssid-add');

				d.rdidx = (layero.find('[data-rdidx="2G"]').prop('checked') ? 1 : 0);
				d.rdidx|= (layero.find('[data-rdidx="5G"]').prop('checked') ? 2 : 0);

				$.ajax({
					url: 'api.php?r=sac@ssid-save',
					data: d,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						ssid_search();
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	}

	form.on('select(filter-group)', function(data){
		var id = data.othis.parents('.getwaytool').attr('id');
		if(id == 'ap-toptool') {
			ap_search(1);
		}
		else
		if(id == 'user-toptool') {
			user_search(1);
		}
		else
		if(id == 'logger-toptool') {
			logger_search(1);
		}
	});

	form.on('select(filter-apid)', function(data){
		var id = data.othis.parents('.getwaytool').attr('id');
		if(id == 'user-toptool') {
			user_search(1);
		}
	});
	
	form.on('select(filter-ssid)', function(data){
		var id = data.othis.parents('.getwaytool').attr('id');
		if(id == 'user-toptool') {
			user_search(1);
		}
	});
	
	table.on('tool(sac-ssid-mgd)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'edit') {
			ssid_edit(data);
		}
		else
		if (event == 'del') {
			layer.confirm('确认要删除SSID“' + data.name + '”吗?', {
				icon: 0,
				title: 'SSID 删除'
			}, function(index) {
				ssid_del(data.name);
				layer.close(index);
			});
		}
	});
	
	$('#ssid-toptool button.search').on('click', function(obj) {
		ssid_search(1);
	});
	
	$('#ssid-toptool input[name="keyword"]').keyup(function(event) {
		if (event.keyCode == 13) {
			ssid_search(1);
		}
	});
	
	$('#ssid-toptool button.del').on('click', function(obj) {
		var checkStatus = table.checkStatus('sac-ssid-mgd');
		var devs = [];

		checkStatus.data.forEach(function(e, i) {
			devs.push(e.name);
		});

		if (devs.length <= 0) {
			layer.msg('请先选择要删除的SSID。');
			return;
		}

		layer.confirm('确认要删除选中的SSID吗?', {
			icon: 0,
			title: 'SSID 删除'
		}, function(index) {
			ssid_del(devs);
			layer.close(index);
		});
	});

	$('#ssid-toptool button.add').on('click', function(obj) {
		layer.open({
			type: 1,
			shadeClose: true,
			resize: false,
			title: '添加SSID',
			area: ['350px', '290px'],
			btnAlign: 'c',
			btn: ['确定'],
			content: $('#tpl-ssid-add').html(),
			success: function(layero, index) {
				layero.find('.layui-layer-content').css('overflow', 'inherit');

				form.render('checkbox');
				form.render('select');
			},
			yes: function(index, layero) {
				var d = form.val('ssid-add');

				$.ajax({
					url: 'api.php?r=sac@ssid-add',
					data: d,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						ssid_search();
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});
	
	// logger
	function logger_search(page, obj) {
		var where = {
			grpid: Number($('#logger-toptool [name="grpid"]').val()),
			keyword: $.trim($('#logger-toptool input[name="keyword"]').val())
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;
		if (obj) {
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('sac-logger-mgd', option);
	}

	$('#logger-toptool button.search').on('click', function(obj) {
		logger_search(1);
	});

	$('#logger-toptool input[name="keyword"]').keyup(function(event) {
		if (event.keyCode == 13) {
			logger_search(1);
		}
	});
});
