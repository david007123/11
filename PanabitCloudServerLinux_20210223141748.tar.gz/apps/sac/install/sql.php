<?php
define ("ROOT_DIR", dirname(dirname(dirname(__DIR__))));
require_once(ROOT_DIR . '/conf/config.php');
require_once(ROOT_DIR . '/apps/user/lib/login.php');

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

// 2020-02-18
$sql = "alter table palog.cloud_users add column `ap_grpids` varchar(512) not null default '' after `password`";
$nidb->query($sql);
$sql = "alter table palog.cloud_users add column `ap_grpnames` varchar(512) not null default '' after `ap_grpids`";
$nidb->query($sql);

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);  
