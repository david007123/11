<?php
namespace cloud\apps\sac\ap;


function select($data)
{
	global $user;

	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'apid', $optional, '', 'int', false) == false)
		$optional['apid'] = -1;

	if(format_and_push($data, 'retfmt', $optional, '', 'int', false) == false)
		$optional['retfmt'] = 0;
	
	format_and_push($data, 'keyword', $optional, '', 'string', true);

	
	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " sac list retfmt={$optional['retfmt']}";
	$cmd.= " apid={$optional['apid']} grpid={$optional['grpid']}";
	$cmd.= " name={$optional['keyword']}";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);

	return implode('', $out);
//	$result['rows'] = implode('', $out);

//	return $result;
}

function apssid_list($data)
{
	global $user;

	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	format_and_push($data, 'ssid', $optional, '', 'string', true);
	format_and_push($data, 'keyword', $optional, '', 'string', true);

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}
	
	$cmd = SACEYE . " sac list retfmt=2"; // get ap ssid list
	$cmd.= " name='{$optional['keyword']}'";
	$cmd.= " ssid='{$optional['ssid']}'";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);

	if(count($out) > 1) {
		$keys = array("name", "i", "rd0_wlan", "rd1_wlan");
		$keycnt = count($keys);
		foreach($out as $row) {
			$col = explode(' ', $row);
			if(count($col) != $keycnt) 
				continue;
			array_push($result['rows'], array_combine($keys, $col));
		}
	}
	
	$result['total'] = count($result['rows']);
	return $result;
}

function stats($data)
{
	global $user;
	
	$optional = array();
	$result = array();

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == 0)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	$cmd = SACEYE . " sac stat";
	exec($cmd, $out, $ret);

	$mapkey = array(
		'allinbps',
		'alloutbps',
		'sta_alloc',
		'sta_alloc2g',
		'sta_alloc5g',
		'sta_max',
		'ap_alloc',
		'ap_max',
	);
	foreach($out as $row) {
		$col = explode('=', $row);
		if(in_array($col[0], $mapkey)) {
			$key = str_replace("alloc", "cnt", $col[0]);
			$result[$key] = $col[1];
		}
	}

	return $result;
}



function name($data)
{
	global $user;
	
	$optional = array();
	$result = array();

	// set custom options
	if(format_and_push($data, 'name', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '设备名称不能为空！');
		return false;
	}
	if(format_and_push($data, 'mac', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '设备MAC地址不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}
	
	$cmd = SACEYE . " sacapdesc add grpid={$optional['grpid']}";
	$cmd.= " apmac={$optional['mac']} apname={$optional['name']}";
	
	exec($cmd, $out, $ret);

	$error = implode(' ', trim($out, " \n\r"));
	if($error != '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, $error);
		return false;
	}

	return true;
}

function get_verinfo($data)
{
	global $user;


	$optional = array();

	// set custom options
	// 要操作ID
	if(isset($data['types']) == false
	|| ($typestr = trim($data['types'])) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	$result = array();
	$url="https://47.93.89.56:10443/appbags/PanabitAP/PanabitAP_1_";
	$types = explode(',', $typestr);
	foreach($types as $type) {
		$data = httpPost("{$url}{$type}.txt");
		$content = explode("\n", $data);
		$ret = array();
		foreach($content as $row) {
			if(($pos = strpos($row, '=')) === false)
				continue;
			$key = trim(substr($row, 0, $pos));
			$val = trim(substr($row, $pos + 1), " \n\r\"'");

			if($key == 'VER_DESC')
				$ret[$key] = iconv('GB2312', 'UTF-8', $val);
			else
				$ret[$key] = $val;
		}
		if(isset($ret['VER_DESC']))
			$result[$type] = $ret;
	}

	return $result;
	
/*
		$typesdef[$type] = array();
	// ,{PAP-X2260|PanabitAP_PAP-X2260_V1.2_R1P4_20191216.tar.gz}
	

        DEVTYPES=`floweye sac list listdevtype=1 | sed 's/"//g'`
        URI='https://47.93.89.56:10443/appbags/PanabitAP/'
        WEBDIR='/usr/ramdisk/admin/cgi-bin/App/sac/'
        VERDIR="${WEBDIR}newver"
        mkdir -p ${VERDIR}
        echo "${DEVTYPES}" | while read type;
        do
                #check new version
                fname="PanabitAP_1_${type}.txt"
                fetchurl="${URI}${fname}"

                fetch -q -o /tmp/ "${fetchurl}"
                mv /tmp/${fname} ${VERDIR}
        done

		
        AP_RELEASE=""
        DEV_TYPE=""
        FILE_MD5=""
        FILE_NAME=""
        FILE_SIZE=""
        SFT_DATE=""
        SFT_VER=""
        VER_DESC=""

        VERFILE=`ls ${VERDIR} | grep "${CGI_devtype}.txt"`
        [ "${VERFILE}" != "" -a -f ${VERDIR}/${VERFILE} ] && . ${VERDIR}/${VERFILE}

        printf "{"
        printf "\"AP_RELEASE\":\"${AP_RELEASE}\","
        printf "\"DEV_TYPE\":\"${DEV_TYPE}\","
        printf "\"FILE_MD5\":\"${FILE_MD5}\","
        printf "\"FILE_NAME\":\"${FILE_NAME}\","
        printf "\"FILE_SIZE\":\"${FILE_SIZE}\","
        printf "\"SFT_DATE\":\"${SFT_DATE}\","
        printf "\"SFT_VER\":\"${SFT_VER}\","
        printf "\"VER_DESC\":\"%s\"" `echo ${VER_DESC} | tr " " "/"`
        printf "}"

DEV_TYPE="PAP-X2260"
SFT_VER="V1.2_R1P4"
SFT_DATE="20191216"
AP_RELEASE="1"
FILE_SIZE="9665284"
FILE_NAME="PanabitAP_PAP-X2260_V1.2_R1P4_20191216.tar.gz"
FILE_MD5="e85fc320a45368ed7cbc64863a6c656b"
VER_DESC="1.优化PAP-X2260 LED状态指示。2.优化状态上送性能。3.解决VLAN配置问题。4.解决部分交换机下138未及时获取问题。"
*/
}
