<?php
namespace cloud\apps\sac\logger;


function select($data)
{
	global $user;

	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
	);

	// set custom options
	if(format_and_push($data, 'apid', $optional, '', 'int', false) == false)
		$optional['apid'] = -1;
	if(format_and_push($data, 'level', $optional, '', 'int', false) == false)
		$optional['level'] = -1;
	if(format_and_push($data, 'event', $optional, '', 'int', false) == false)
		$optional['event'] = -1;

	if(format_and_push($data, 'retfmt', $optional, '', 'int', false) == false)
		$optional['retfmt'] = 0;
	
	format_and_push($data, 'keyword', $optional, '', 'string', true);

	
	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = '';
	else
	if($optional['grpid'] <= -1)
		$optional['grpid'] = '';
		

	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " saclog list retfmt=1";
	$cmd.= " apid={$optional['apid']} level={$optional['level']}";
	$cmd.= " name={$optional['keyword']} event={$optional['event']}";
	$cmd.= " grpid={$optional['grpid']}";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);
	
	return implode('', $out);

//	$result['rows'] = implode('', $out);

//	return $result;
}
