<?php
namespace cloud\apps\sac\user;


function select($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> '[]',
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'retfmt', $optional, '', 'int', false) == false)
		$optional['retfmt'] = 0;

	format_and_push($data, 'apid', $optional, '', 'int', false);
	format_and_push($data, 'ssid', $optional, '', 'string', false);
	format_and_push($data, 'keyword', $optional, '', 'string', true);


	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(is_supadmin($user->username)) {
			if($optional['grpid'] <= -1)
				$optional['grpid'] = '';
		}
		else {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}
	
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " ipobj list liststa=1 retfmt={$optional['retfmt']}";
	$cmd.= " apid={$optional['apid']} grpid={$optional['grpid']}";
	$cmd.= " name='{$optional['keyword']}' ssid={$optional['ssid']}";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);
	
	return implode('', $out);

//	$result['rows'] = implode('', $out);

// 	return $result;
}

function set($data)
{
	global $user;
	
	$optional = array();

	// set custom options
	if(format_and_push($data, 'mac', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '用户MAC地址不能为空！');
		return false;
	}
	if(format_and_push($data, 'name', $optional, '', 'string', false) == false)
		$optional['name'] = '';
	
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	if($optional['name'] == '') 
		$cmd = SACEYE . " sacstadesc remove mac={$optional['mac']}";
	else
		$cmd = SACEYE . " sacstadesc add mac={$optional['mac']}";
	$cmd.= " name={$optional['name']}";
	

	exec($cmd, $out, $ret);

	if($ret) {
		set_errmsg(MSG_LEVEL_DEF, __function__, implode('', $out));
		return false;
	}

	return true;
}
