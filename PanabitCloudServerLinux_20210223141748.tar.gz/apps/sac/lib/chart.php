<?php
namespace cloud\apps\sac\chart;


function chart($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> '',
	);

	// set custom options
	if(format_and_push($data, 'type', $optional, '', 'int', false) == false)
		$optional['type'] = 7;

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else 
	if(!is_supadmin($user->username)) {
		if($user->grp == '')
			return $result;
		if($optional['grpid'] == -1)
			$optional['grpid'] = $user->grp;
		else {
			$grpids = explode(',', $user->grp);
			if(in_array($optional['grpid'], $grpids) == false) {
				return $result;
			}
		}
	}
	
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " chart list type={$optional['type']}";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);

	$result['rows'] = implode('', $out);

	return $result;
}
