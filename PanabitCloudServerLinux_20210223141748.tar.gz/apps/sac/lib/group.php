<?php
namespace cloud\apps\sac\group;


function dump_group()
{
	global $nidb, $user;
	
	
	$sql = "select `grpid`, `grpname` from sac_grp";
	if(\cloud\apps\work\project\project_enable(array())) {
		
		$grpidstr = \cloud\apps\work\project\get_curr_work_groupstr(4);
		if(!empty($grpidstr))
			$sql.= " where `grpid` in ($grpidstr)";
		else
		if(($wkp = \cloud\apps\work\project\get_curr_work_project(ROLE_GUEST, 4)) && $wkp['wkpid'])
			return array();
	}
	
	try {

		$sth = $nidb->prepare($sql);
		$sth->execute();
		$data = $sth->fetchAll(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$sorts = array();
	foreach($data as $key => $row) {
		array_push($sorts, $row['grpname']);
	}
	array_multisort($sorts, SORT_ASC, SORT_STRING, $data);
	
	return $data;
}

function get_user_group($account)
{
	global $nidb;


	if(\cloud\apps\work\project\project_enable(array())) {
		
		$grpidstr = \cloud\apps\work\project\get_curr_work_groupstr(4);
		if(empty($grpidstr))
			return array();
	}
	else {
		try {
			$sql = "select `grp` from cloud_users where `username` = ? limit 1";

			$sth = $nidb->prepare($sql);
			$sth->bindParam(1, $account, \PDO::PARAM_STR);
			$sth->execute();

			$row = $sth->fetch(\PDO::FETCH_ASSOC);
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}

		if(!$row) {
			return array();
		}

		$group = array();
		$grp = explode(',', $row['grp']);
		foreach($grp as $val) {
			if($val && ($id = intval($val)) > 0) 
				array_push($group, $id);
		}
		
		if(count($group) == 0)
			return array();

		$grpidstr = implode(',', $group);
	}
	
	try {
		$sql = "select `grpid`, `grpname` from sac_grp where `grpid` in ({$grpidstr})";

		$sth = $nidb->prepare($sql);
		$sth->execute();

		$data = $sth->fetchAll(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$sorts = array();
	foreach($data as $key => $row) {
		array_push($sorts, $row['grpname']);
	}
	array_multisort($sorts, SORT_ASC, SORT_STRING, $data);
	
	return $data;
}

function group_save($data)
{
	global $user;

	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
		return false;
	}
	
	if(isset($data['grpid']) == false || ($grpid = intval($data['grpid'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备组ID不正确！');
		return false;
	}

	if(isset($data['grpname']) == false || empty(($data['grpname'] = trim($data['grpname'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备组的新名称不能为空！');
		return false;
	}
	
	$frmData = array(
		'grpname' => $data['grpname']
	);
	try {
		if(update_data('sac_grp', $frmData, array('grpid' => $grpid)) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return true;
}

function group_add($data)
{
	global $nidb, $user;

	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
		return false;
	}
	
	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备组名称不能为空！');
		return false;
	}
	$grpname = $data['name'];

	try {
		$sql = "select * from sac_grp where `grpname` = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $grpname, \PDO::PARAM_STR);
		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_LAZY);
		if($row) {
			set_errmsg(MSG_LEVEL_EXP, __function__, "“{$grpname}”设备组已存在。");
			return false;
		}

		$frmData = array(
			'grpname' => $grpname
		);
		if(insert_data('sac_grp', $frmData) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
		$id = $nidb->lastInsertId();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return $id;
}

function group_del($data)
{
	global $nidb, $user;


	if(isset($data['grpid']) == false || ($grpid = intval($data['grpid'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备组ID不正确！');
		return false;
	}
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$grpid = \cloud\apps\work\project\in_work_grpidstr(4, $grpid);
		if($grpid === false) return false;
		if($grpid == '') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '指定的归属组不存在。');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
		return false;
	}
	
	try {
		$sql = "select * from sac_grp where grpid = ?";
		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $grpid, \PDO::PARAM_INT);
		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_LAZY);
		if(!$row) {
			set_errmsg(MSG_LEVEL_EXP, __function__, "设备组不存在！");
			return false;
		}
		
		$sql = "DELETE FROM sac_grp WHERE grpid = ?";
		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $grpid, \PDO::PARAM_INT);
		if($sth->execute() === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return $row->grpname;
}

function group($data)
{
	global $user;

	if(is_supadmin($user->username)) {
		$result = dump_group();
		array_unshift($result, (object)array('grpid' => 0, 'grpname' => '空组'));
	} else
		$result = get_user_group($user->username);

	return $result;
}

