<?php
namespace cloud\apps\sac\ssid;


function select($data)
{
	global $user;

	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'apcnt', $optional, '', 'int', false) == false)
		$optional['apcnt'] = 0;

	format_and_push($data, 'keyword', $optional, '', 'string', true);

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}
	
	$cmd = SACEYE . " sacssid list retfmt=1";
	$cmd.= " name='{$optional['keyword']}' apcnt={$optional['apcnt']}";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);

	return implode('', $out);
	
//	$result['rows'] = implode('', $out);

//	return $result;
}

function add($data)
{
	global $user;
	
	$optional = array();

	// set custom options
	if(format_and_push($data, 'name', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, 'SSID名称不能为空！');
		return false;
	}

	if(format_and_push($data, 'vlan', $optional, '', 'int', false) == false)
		$optional['vlan'] = 0;

	if(format_and_push($data, 'mode', $optional, '', 'int', false) == false)
		$optional['mode'] = 0;

	if(format_and_push($data, 'pwd', $optional, '', 'string', false) == false)
		$optional['pwd'] = '';
	
	if($optional['mode'] 
	&&(strlen($optional['pwd']) < 8 || strlen($optional['pwd']) > 15)) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '密码不能小于8位，大于15位！');
		return false;
	}
	
	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " sacssid add name={$optional['name']} vlan={$optional['vlan']} mode={$optional['mode']} pwd={$optional['pwd']}";
	exec($cmd, $out, $ret);

	if(!$ret) return true;

	set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $out));
	return false;
}

function save($data)
{
	global $user;
	
	$optional = array();

	// set custom options
	if(format_and_push($data, 'name', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, 'SSID名称不能为空！');
		return false;
	}

	if(format_and_push($data, 'vlan', $optional, '', 'int', false) == false)
		$optional['vlan'] = 0;

	if(format_and_push($data, 'mode', $optional, '', 'int', false) == false)
		$optional['mode'] = 0;

	if(format_and_push($data, 'pwd', $optional, '', 'string', false) == false)
		$optional['pwd'] = '';
	
	if($optional['mode'] 
	&&(strlen($optional['pwd']) < 8 || strlen($optional['pwd']) > 15)) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '密码不能小于8位，大于15位！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " sacssid set name={$optional['name']} vlan={$optional['vlan']} mode={$optional['mode']} pwd={$optional['pwd']}";
	exec($cmd, $out, $ret);

	if(!$ret) {
		$cmd = SACEYE . " sactask add apidstr=-1 \"cmdstr=op=modwlan&ssid={$optional['name']}\"";
		exec($cmd, $out, $ret);
		return true;
	}

	set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $out));
	return false;
}

function remove($data)
{
	global $user;

	$optional = array();

	// set custom options
	if(isset($data['name']) == false) {
//		set_errmsg(MSG_LEVEL_DEF, __function__, 'SSID名称不能为空！');
//		return false;
		$data['name'] = '';
	}
	
	$optional['name'] = array();
	if(is_array($data['name'])) {
		foreach($data['name'] as $val) {
			$name = shell_filter(trim($val));
			if($name == '') continue;
			array_push($optional['name'], $name);
		}
	}
	else {
		$name = shell_filter(trim($data['name']));
		if($name != '')
			array_push($optional['name'], $name);
	}
	if(count($optional['name']) == 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, 'SSID名称不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if ($user->username != ADMIN_ACCT) {
		if($user->grp == '')
			return $result;
		if($optional['grpid'] == -1)
			$optional['grpid'] = $user->grp;
		else {
			$grpids = explode(',', $user->grp);
			if(in_array($optional['grpid'], $grpids) == false) {
				return $result;
			}
		}
	}

	$count = 0;
	foreach($optional['name'] as $name) {
		$cmd = SACEYE . " sacssid remove name={$name}";
		exec($cmd, $out, $ret);

		if(!$ret) {
			$cmd = SACEYE . " sactask add apidstr=-1 \"cmdstr=op=delwlan&ssidstr={$name}\"";
			exec($cmd, $out, $ret);
			$count++;
			continue;
		}
	}

	if($count == 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $out));
		return false;
	}
	
	return $count;
}
