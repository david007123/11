<?php
namespace cloud\apps\sac\task;


function getTaskDataRow($data) 
{
	$ret = array();
	
	// taskid=0 apcnt=0 birth=1577694088 state=2 cmdstr=op=modrd
	foreach($data as $col) {
		$pos = strpos($col, '=');
		if(count($pos) === false)
			return false;

		$ret[substr($col, 0, $pos)] = substr($col, $pos + 1);
	}

	return $ret;
}

function select($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	format_and_push($data, 'keyword', $optional, '', 'string', true);

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}
	
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " sactask list retfmt=1";
	$cmd.= " grpid={$optional['grpid']}";

	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);
	
	return implode('', $out);
/*
	foreach($out as $row) { 
		$col = explode(' ', trim($row, " \t\n\r"));

		if(($ret = getTaskDataRow($col)) === false) continue;

		array_push($result['rows'], $ret);
	}
*/
//	$result['rows'] = implode('', $out);

//	return $result;
}


function get_task($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'taskid', $optional, '', 'int', false) == false
	|| $optional['taskid'] < 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '任务ID不能为空。');
		return false;
	}

	format_and_push($data, 'keyword', $optional, '', 'string', true);

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
		
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}
	
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$optional[$key] = shell_filter($val);
	}

	$cmd = SACEYE . " sactask list taskid={$optional['taskid']} retfmt=2";


	$page_arg = get_query_page($data);
	$cmd.= " page={$page_arg['page']} limit={$page_arg['limit']}";
	$cmd.= " sort={$page_arg['sort']} sortdesc={$page_arg['sortdesc']}";

	exec($cmd, $out, $ret);
/*
	if(count($out) > 1) {
		$keys = explode('taskid', 'birth', 'state', 'cmdstr', 'apidx', 'apname', 'cmdbirth', 'usetime', 'cmdstat', 'reply');
		$keycnt = count($keys);
		foreach($out as $row) {
			$row = trim($row, " \t\n\r");
			$col = explode(' ', $row);
			if(count($col) != $keycnt) 
				continue;

			array_push($result['rows'], array_combine($keys, $col));
		}
	}
	else {
		if(count($out) > 0) {
			set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $out));
			return false;
		}
	}
*/
	foreach($out as $row) {
		$result['rows'] = $row;
		break;
	}
	
	$result['total'] = count($result['rows']);

	return $result;
}

function addX($data)
{
	global $user;
	
	$optional = array();

	$arg = "";
	$apidstr = "";
	foreach($data as $key => $val) {
		if($key == 'r') continue;
		if($key == 'apidstr') {
			$apidstr = shell_filter($val);
		}
		$arg .= "&{$key}=" . shell_filter($val);
	}
	
	if($arg == "") {
		set_errmsg(MSG_LEVEL_DEF, __function__, '配置参数不能为空。');
		return false;
	}
	
	$arg = substr($arg, 1);

	$cmd = SACEYE . " sactask add apidstr={$apidstr} cmdstr={$arg}";
	exec($cmd, $out, $ret);

	foreach($out as $row) {
		if(strpos($row, 'TASKID=') !== false) {
			return substr($row, 7);
		}
	}

	set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $out));
	return false;
}

function add($apidstr, $cmdstr)
{
	global $user;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '您的权限不足！');
			return false;
		}
	}
	
	$cmd = SACEYE . " sactask add apidstr={$apidstr} \"cmdstr={$cmdstr}\"";
	exec($cmd, $out, $ret);

	foreach($out as $row) {
		if(strpos($row, 'TASKID=') !== false) {
			return substr($row, 7);
		}
	}

	set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $out));
	return false;
}

function reboot($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		/*
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
		*/
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	return add($apidstr, "op=reboot");
}

function reset_conf($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}
	
	return add($apidstr, "op=reset");
}

function led_light($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}
	
	if(format_and_push($data, 'led', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, 'LED配置状态不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	return add($apidstr, "op=led" . ($optional['led'] ? 'on' : 'off'));
}

function del_wlan($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}
	
	if(format_and_push($data, 'ssid', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '请选择一个要删除的SSID！');
		return false;
	}

	if(format_and_push($data, 'rdidx', $optional, '', 'int', false) == false)
		$optional['rdidx'] = 0; // 表示指定射频（2G/5G）：1：2G；2：5G

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	$optional['ssid'] = shell_filter($optional['ssid']);
	
	$cmdstr = "op=delwlan&ssidstr=" . $optional['ssid'] . "&ridx=" . $optional['rdidx'];

	return add($apidstr, $cmdstr);
}

function add_wlan($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(format_and_push($data, 'ssid', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, 'SSID不能为空！');
		return false;
	}
	if(format_and_push($data, 'widx', $optional, '', 'int', false) == false)
		$optional['widx'] = -1; // 自动

	if(format_and_push($data, 'ridx', $optional, '', 'int', false) == false)
		$optional['ridx'] = 3; // 表示绑定所有射频（2G/5G）：1：2G；2：5G

	// 是否隐藏
	format_and_push($data, 'hide', $optional, '', 'int', true);

	$cmdstr = "op=addwlan";
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$cmdstr .= "&{$key}=" . shell_filter($val);
		else
			$cmdstr .= "&{$key}={$val}";
	}

	// 要操作ID
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	return add($apidstr, $cmdstr);
}

function modrd_change($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(format_and_push($data, 'ridx', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '请选择要配置的网络！');
		return false;
	}

	format_and_push($data, 'rd0_txpwr', $optional, '', 'int', false);
	format_and_push($data, 'rd0_phymode', $optional, '', 'int', false);
	format_and_push($data, 'rd0_enable', $optional, '', 'int', false);
	format_and_push($data, 'rd0_channel', $optional, 'rd0_chan', 'int', false);

	format_and_push($data, 'rd1_txpwr', $optional, '', 'int', false);
	format_and_push($data, 'rd1_phymode', $optional, '', 'int', false);
	format_and_push($data, 'rd1_enable', $optional, '', 'int', false);
	format_and_push($data, 'rd1_channel', $optional, 'rd1_chan', 'int', false);

	$cmdstr = "op=modrd";
	foreach($optional as $key => $val) {
		if(gettype($key) == 'string')
			$cmdstr .= "&{$key}=" . shell_filter($val);
		else
			$cmdstr .= "&{$key}={$val}";
	}
	
	// 要操作ID
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	return add($apidstr, $cmdstr);
}

function hide_wlan($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(format_and_push($data, 'ssid', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, 'SSID不能为空！');
		return false;
	}

	if(format_and_push($data, 'rdidx', $optional, '', 'int', false) == false)
		$optional['rdidx'] = 0; // 表示指定射频（2G/5G）：1：2G；2：5G

	// 是否隐藏
	format_and_push($data, 'hide', $optional, '', 'int', true);

	$cmdstr = "op=modwlan";
	foreach($optional as $key => $val) {
		if(gettype($val) == 'string')
			$cmdstr .= "&{$key}=" . shell_filter($val);
		else
			$cmdstr .= "&{$key}={$val}";
	}

	// 要操作ID
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	return add($apidstr, $cmdstr);
}

function modrd_config($data)
{
	global $user;


	$optional = array();

	// set custom options
	if(format_and_push($data, 'ridx', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '请选择要设备的网络！');
		return false;
	}

	format_and_push($data, 'rd0_txpwr', $optional, '', 'int', false);
	format_and_push($data, 'rd0_phymode', $optional, '', 'int', false);
	format_and_push($data, 'rd0_enable', $optional, '', 'int', false);
	format_and_push($data, 'rd0_channel', $optional, 'rd0_chan', 'int', false);

	format_and_push($data, 'rd1_txpwr', $optional, '', 'int', false);
	format_and_push($data, 'rd1_phymode', $optional, '', 'int', false);
	format_and_push($data, 'rd1_enable', $optional, '', 'int', false);
	format_and_push($data, 'rd1_channel', $optional, 'rd1_chan', 'int', false);

	format_and_push($data, 'hide', $optional, '', 'int', false);
	format_and_push($data, 'name', $optional, '', 'string', false);
	format_and_push($data, 'mac', $optional, '', 'string', false);
	
	$cmdstr = "op=modrd";

	foreach($optional as $key => $val) {
		if(gettype($key) == 'string')
			$cmdstr .= "&{$key}=" . shell_filter($val);
		else
			$cmdstr .= "&{$key}={$val}";
	}
	
	// 要操作ID
	if(isset($data['dev']) == false
	|| ($apidstr = shell_filter(trim($data['dev']))) == '') {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(4, $optional['grpid']);
		if($optional['grpid'] === false) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '分组不存在！');
			return false;
		}
		if(empty($optional['grpid'])) {
			//if(!is_supadmin($user->username))
			//	return $result;
			set_errmsg(MSG_LEVEL_DEF, __function__, '分组不存在！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '') {
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}
	
	if($optional['grpid'] > -1) {
		$apids = explode(',', $apidstr);
		foreach($apids as $id) {
			$cmd = SACEYE . " sac set apid={$id} grpid={$optional['grpid']}";
			exec($cmd, $out, $ret);

			$error = implode(' ', trim($out, " \n\r"));
			if($error != '') {
				set_errmsg(MSG_LEVEL_DEF, __function__, $error);
				return false;
			}
		}
	}

	if(isset($optional['name']) && $optional['name'] != ''
	&& isset($optional['mac']) && $optional['mac'] != '') {
		if(strpos($apidstr, ',') === false) {
			$cmd = SACEYE . " sacapdesc add apid={$apidstr} grpid={$optional['grpid']}";
			$cmd.= " apmac={$optional['mac']} apname={$optional['name']}";
			
			exec($cmd, $out, $ret);

			$error = implode(' ', trim($out, " \n\r"));
			if($error != '') {
				set_errmsg(MSG_LEVEL_DEF, __function__, $error);
				return false;
			}
		}
	}
	
	if($optional['ridx'] == 0) 
		return -1;
	
	return add($apidstr, $cmdstr);
}

function upgrade($data)
{
	global $user;


	$upgrade = array();
	$optional = array();

	// set custom options
	// 要操作ID
	if(isset($data['d']) == false
	|| is_array($data['d']) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
		return false;
	}

	// 设置用户组
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == ''){
				set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
				return false;
			}
			if($optional['grpid'] == -1)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					set_errmsg(MSG_LEVEL_DEF, __function__, '操作权限不足！');
					return false;
				}
			}
		}
	}

	foreach($data['d'] as $row) {
		// 要操作ID
		if(isset($row['d']) == false
		|| ($dev = shell_filter(trim($row['d']))) == '') {
			set_errmsg(MSG_LEVEL_DEF, __function__, '操作设备不能为空！');
			return false;
		}

		$ret = array(
			'apidstr'	=> $row['d'],
			'cmdstr'	=> ''
		);
		if(isset($row['url']) && empty(($row['url'] = trim($row['url']))) == false) {
			$ret['cmdstr'] = 'pkurl=' . str_replace(array('>', '<', '\\'), '', $row['url']);
			array_push($upgrade, $ret);
		}
		else
		if(isset($row['pk']) && empty(($row['pk'] = trim($row['pk']))) == false) {
			$ret['cmdstr'] = "pkurl=https://47.93.89.56:10443/appbags/PanabitAP/{$row['pk']}";
			array_push($upgrade, $ret);
		}
	}

	foreach($upgrade as $row) {
		add($row['apidstr'], 'op=upgrade&' . $row['cmdstr']);
	}

	return true;
}
