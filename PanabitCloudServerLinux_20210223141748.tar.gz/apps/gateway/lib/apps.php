<?php
namespace cloud\apps\gateway;


function apps_usergrp($data)
{
	if(isset($data['serialno']) == false || empty(($serialno = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "无效的操作设备！");
		return false;
	}

	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
		return false;
	}

	$rows = array();

	$cmd = DATAEYE . " usragp list license_id12={$serialno}";
	exec($cmd, $out, $ret);
	if($ret != 0) 
		return $rows;

	foreach($out as $val) {
		if (trim($val) == "")
			continue;

		list($id12, $cname, $son_name) = explode(' ', $val);

		$cname = iconv("gbk", "utf-8", $cname);

		list($grpname, $grpcname, $others) = explode(',', $cname);
		if(empty($grpname) || empty($grpcname)) continue;
		$str = stristr($cname, ',');
		$str = substr($str, 1);
		$son_cname = stristr($str, ',');
		if ($son_cname != "" && $son_cname != ",")
			$son_cname = substr($son_cname, 1);
		else
			$son_cname = "";

		if ($son_name == ",")
			$son_name = "";

		array_push($rows, array(
			"name"		=> $grpname,
			"cname"		=> $grpcname,
			"son_cname"	=> $son_cname,
			"son_name"	=> $son_name
		));
	}

	return $rows;
}

function apps_userapp($data)
{
	if(isset($data['serialno']) == false || empty(($serialno = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "无效的操作设备！");
		return false;
	}

	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
		return false;
	}

	$rows = array();

	$cmd = DATAEYE . " usragp list license_id12={$serialno} showapp=1";
	exec($cmd, $out, $ret);
	if($ret != 0) 
		return $rows;

	foreach($out as $val) {
		if (trim($val) == "")
			continue;

		list($id12, $name, $cname, $nodettl, $tports, $uports) = explode(' ', $val);
		if(empty($name) || empty($cname)) continue;

		$cname = iconv("gbk", "utf-8", $cname);

		array_push($rows, array(
			"name"		=> $name,
			"cname"		=> $cname,
			"nodettl"	=> $nodettl,
			"tports"	=> $tports,
			"uports"	=> $uports
		));
	}

	return $rows;
}

function apps_sync($data)
{
	global $user;

	if(isset($data['dev']) == false || is_array($data['dev']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '同步到的目标设备不正确。');
		return false;
	}

	if(isset($data['grp']) && is_array($data['grp']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要同步的协议组不正确。');
		return false;
	}

	if(isset($data['app']) && is_array($data['app']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要同步的协议不正确。');
		return false;
	}
	
	$devs = array();
	foreach($data['dev'] as $key => $val) {
		if(preg_match("/^([a-zA-Z0-9-_]{12,})$/", $val, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '“' + $val + '”设备编号不正确。');
			return false;
		}
		array_push($devs, $val);
	}
	
	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择需要同步的目标设备。');
		return false;
	}

	// 检查自定义协议组对象
	$syndata = array();
	foreach($data['grp'] as $key => $val) {
		if(isset($val['name']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议组的英文名称不能为空。');
			return false;
		}
		if(isset($val['cname']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议组的中文名称不能为空。');
			return false;
		}
		if(isset($val['son_name']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议组的子协议英文名不能为空。');
			return false;
		}

		$row = $val['name'] . ',' . $val['cname'] . ',' . $val['son_name'];
		array_push($syndata, $row);
	}

	$usragp_group = iconv("utf-8", "gbk", implode(';', $syndata));
	
	// 检查自定义协议对象
	$syndata = array();
	foreach($data['data'] as $key => $val) {
		if(isset($val['name']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议的英文名称不能为空。');
			return false;
		}
		if(isset($val['cname']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议的中文名称不能为空。');
			return false;
		}
		if(isset($val['nodettl']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议的TTL不能为空。');
			return false;
		}
		if(isset($val['tports']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议的TCP端口不能为空。');
			return false;
		}
		if(isset($val['uports']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '第“' + $key + '”个协议的UDP端口不能为空。');
			return false;
		}
		
		$row = $val['name'] . '|' . $val['cname'] . '|' . $val['nodettl'] . '|' . $val['tports'] . '|' . $val['uports'];
		array_push($syndata, $row);
	}

	$usrapp_info = iconv("utf-8", "gbk", implode(';', $syndata));
	
	$device = implode(';', $devs);

	$cmd = DATAEYE." usragp config 'device={$device}'";
	if ($usragp_group != "")
		$cmd .= " 'agp_name={$usragp_group}'";
	if ($usrapp_info != "") 
		$cmd .= " 'app={$usrapp_info}'";

	exec($cmd, $out, $ret);
	if($ret) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '同步失败！' . $out);
		return false;
	}

	return true;
}

function apps_showsync()
{
	$rows = array();

	$cmd = DATAEYE . " usragp list showdevice=1";
	exec($cmd, $out, $ret);
	if($ret) {
		set_errmsg(MSG_LEVEL_ARG, __function__, ' ' . $out);
		return false;
	}

	foreach($out as $val) {
		if (trim($val) == "")
			continue;
		
		list($serialno, $status, $sysname, $error) = explode(' ', $val);
		$error = iconv("gbk", "utf-8", $error);
		$sysname = iconv("gbk", "utf-8", $sysname);

		array_push($rows, array(
			"serialno"	=> $serialno,
			"code"		=> (int)$status,
			"name"		=> $sysname,
			"error"		=> $error
		));
	}

	return $rows;
}

function apps_fetch($data)
{
	if(isset($data['serialno']) == false || empty(($serialno = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "无效的操作设备！");
		return false;
	}

	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
		return false;
	}

	$cmd = DATAEYE . " usragp request license_id12={$serialno}";
	exec($cmd, $out, $ret);
	if($ret) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '发送同步协议指令失败！' . $out);
		return false;
	}

	return $ret;
}
