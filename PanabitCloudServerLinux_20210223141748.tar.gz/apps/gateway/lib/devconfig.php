<?php
namespace cloud\apps\gateway;


function devconfig($data)
{
	global $user;
	
	if(isset($data['serialno']) == false || empty(($serialno = trim($data['serialno'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
		return false;
	}

	if(isset($data['name']) && empty(($name = trim($data['name']))) == false)
		$name = iconv("utf-8", "gbk", $name);

	if(isset($data['address']))
		$address = trim($data['address']);
	else
		$address = '';

	if(isset($data['grpid']) == false || ($grpid = intval($data['grpid'])) < 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的归属组不正确。');
		return false;
	}
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$grpid = \cloud\apps\work\project\in_work_grpidstr(1, $grpid, ROLE_ADMIN);
		if($grpid === false)
			return false;
		if(empty($grpid) && !is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}
	else {
		if ($user->username != ADMIN_ACCT) {
			$grpids = explode(',', $user->grp);
			if(in_array($grpid, $grpids) == false) {
				set_errmsg(MSG_LEVEL_ARG, __function__, '指定的归属组不存在。');
				return false;
			}
		}
	}
	
	$lng = $lat = 0;
	if (empty($address) == false && $address != "none") {
		/* 根据地址信息获取经纬度 */
		if(($geo = amap_geo($address)) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '获取“{$address}”地址经纬度失败！');
			return false;
		}

		$lng = $geo['lng'];
		$lat = $geo['lat'];
		$address = iconv("utf-8", "gbk", $address);
	}

	$name = shell_filter($name);
	$address = shell_filter($address);
	
	if(empty($name)) {
		$keyno = strtolower($serialno);

		$cmd = DATAEYE . " device list page=1 limit=1 sch='{$keyno}'";
		exec($cmd, $out, $ret);
		foreach($out as $val) {
			$row = explode('|', $val);
			if ($row[0] == "ipaddr") 
				continue;
			if (count($row) < 3)
				continue;
			$name = $row[1];
			break;
		}
		unset($out);
	}
	
	/* $cmd = CLOUDEYE." setgrpid $licenseid $grpid '$sysname' '$map_address' $lng $lat"; */
	$cmd = DATAEYE . " device set license_id12={$serialno} ".
		"grpid={$grpid} sysname={$name} address={$address} ".
		"lng={$lng} lat={$lat}";
	exec($cmd, $out, $ret);

	return true;
}

function grpchg($data)
{
	global $nidb, $user;

	if(isset($data['dev']) == false || empty($data['dev'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '被操作的设备不能为空。');
		return false;
	}
	
	if(is_string($data['dev']))
		$devs = array($data['dev']);
	else
	if(is_array($data['dev']))
		$devs = $data['dev'];
	else {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的设备不正确。');
		return false;
	}
	
	if(isset($data['grpid']) == false || ($grpid = intval($data['grpid'])) < 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的归属组不正确。');
		return false;
	}

	if(\cloud\apps\work\project\project_enable(array())) {
		$grpid = \cloud\apps\work\project\in_work_grpidstr(1, $grpid, ROLE_ADMIN);
		if($grpid === false)
			return false;
		if(empty($grpid) && !is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			$grpids = explode(',', $user->grp);
			if(in_array($grpid, $grpids) == false) {
				set_errmsg(MSG_LEVEL_ARG, __function__, '指定的归属组不存在。');
				return false;
			}
		}
	}

	$count = 0;
	foreach($devs as $dev) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $dev, $match) == false)
			continue;
		
		$serialno = addslashes($dev);
		$serialno = strtolower($serialno);

		$cmd = DATAEYE . " device list page=1 limit=1 sch='$serialno'";
		exec($cmd, $out, $ret);

		foreach($out as $val) {
			$row = explode('|', $val);
			if ($row[0] == "ipaddr") 
				continue;
			if (count($row) < 3)
				continue;

			$sysname	= $row[15];
			$lng		= $row[19];
			$lat		= $row[20];
			$address	= $row[21];

			if(empty($sysname))
				$sysname = $row[1];
			
			$cmd = DATAEYE . " device set license_id12={$dev}";
			$cmd.= " grpid={$grpid} sysname={$sysname} address={$address}";
			$cmd.= " lng={$lng} lat={$lat} ";

			exec($cmd, $out2, $ret2);

			unset($out2);
			$count++;
			break;
		}
		unset($out);
	}

	return $count;
}
