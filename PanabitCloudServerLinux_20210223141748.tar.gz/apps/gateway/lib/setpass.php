<?php
namespace cloud\apps\gateway;


function setpass($data)
{
	global $user;
	

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['dev']) == false || empty($data['dev'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择需要修改密码的设备。');
		return false;
	}
	if(isset($data['pass']) == false || empty($data['pass'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '新的密码不能为空。');
		return false;
	}
	if($data['pass'] != shell_filter($data['pass'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '新的密码不能有特殊字符串。');
		return false;
	}

	if(isset($data['mdfpass']) == false) 
		$mdfpass = 0;
	else
		$mdfpass = intval($data['mdfpass']);

	if(is_string($data['dev']))
		$devs = array($data['dev']);
	else
	if(is_array($data['dev']))
		$devs = $data['dev'];
	else {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的设备不正确。');
		return false;
	}

	cloud_insertlog($user->username, "修改root密码: " . implode('|', $devs));
	
	$cmd = DATAEYE . " device list clearpassreset";
	exec($cmd, $out, $ret);
	unset($out);

	$count = 0;
	foreach($devs as $dev) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $dev, $match) == false)
			continue;

		$cmd = DATAEYE." device set license_id12={$dev} rootpass='{$data['pass']}' mdfpass={$mdfpass}";
		exec($cmd, $out, $ret);
		if ($out[0] != "ok") {
			set_errmsg(MSG_LEVEL_ARG, __function__, "修改“{$dev}”设备密码失败！");
			return false;
		}

		$count++;
	}

	
	return $count;
}

