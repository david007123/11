<?php
namespace cloud\apps\gateway;


function overflow_ip($data)
{
	global $user;

	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
		'fail'		=> 0,
		'exp'		=> 0,
	);

	if(\cloud\apps\work\project\project_enable(array())) {
		
		$usergrp = \cloud\apps\work\project\get_curr_work_groupstr(1);
		if(empty($usergrp))
			return array();
	}
	else {
		if(!is_supadmin($user->username))
			$usergrp = "";
		else {
			if(empty($user->grp))
				return $result['rows'];

			$usergrp = $user->grp;
		}
	}

	/* expire=2 show all device */	
	$cmd = DATAEYE . " device list usergrp={$usergrp} showequal=1 expire=2";
	exec($cmd, $out, $ret);

	if ($ret != 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, $out);
		return $result['rows'];
	}


	foreach($out as $val) {
		$row = explode('|', $val);
		if ($row[0] == "ipaddr" || count($row) < 10) 
			continue;
		if (count($row) < 10) {
			if(($pos = strpos($val, 'device_total=')) == 0)
				$result["total"] = intval(substr($row[0], 13));
			else
			if(($pos = strpos($row[0], 'device_fail=')) == 0)
				$result["fail"] = intval(substr($row[0], 12));
			else
			if(($pos = strpos($row[0], 'device_exp=')) == 0)
				$result["exp"] = intval(substr($row[0], 11));
			//else
			//if(($pos = strpos($row[0], 'equalcount=')) == 0)
				// $result["equ"] = intval(substr($row[0], 11));
			continue;
		}
		
		// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
		$name = iconv("gbk", "utf-8", (empty($row[15]) ? $row[1] : $row[15]));

		array_push($result['rows'], array(
			'serialno'	=> $row[4],
			'ipaddr'	=> long2ip($row[0]),
			'name'		=> $name,
			'grpid'		=> (int)$row[13],
			'equtime'	=> date('Y/m/d H:i:s', $row[28]),
			'logger'	=> $row[27],
		));
	}

	return $result['rows'];
}
