<?php
namespace cloud\apps\gateway;


function transfer($data)
{
	if(isset($data['dev']) == false || empty($data['dev'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的转移设备不能为空。');
		return false;
	}
	if(isset($data['cloudip']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '新的云平台地址不能为空。');
		return false;
	}
/*
	if(is_ipaddr($data['cloudip']) == false && $data['cloudip'] == '') {
		set_errmsg(MSG_LEVEL_ARG, __function__, '新的云平台地址不正确。');
		return false;
	}
*/
	if($data['cloudip'] == '' || $data['cloudip'] == '0.0.0.0') {
		set_errmsg(MSG_LEVEL_ARG, __function__, '新的云平台地址不正确。');
		return false;
	}

	if(is_string($data['dev']))
		$devs = array(trim($data['dev']));
	else
	if(is_array($data['dev']))
		$devs = $data['dev'];
	else {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定要转移的设备不正确。');
		return false;
	}

	$count = 0;
	foreach($devs as $dev) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $dev, $match) == false)
			continue;
		
		$cmd = DATAEYE." device set license_id12={$dev} newcloudip=" . $data['cloudip'];

		exec($cmd, $out, $ret);
/*
		if ($out[0] != "ok") {
			set_errmsg(MSG_LEVEL_ARG, __function__, "转移“{$dev}”设备时失败！");
			return false;
		}
*/
		$count++;
	}

	return $count;
}

