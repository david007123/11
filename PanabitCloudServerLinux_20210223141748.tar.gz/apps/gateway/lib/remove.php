<?php
namespace cloud\apps\gateway;


function remove($data)
{
	global $nidb;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['dev']) == false || empty($data['dev'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '被删除的设备不能为空。');
		return false;
	}
	
	if(is_string($data['dev']))
		$devs = array($data['dev']);
	else
	if(is_array($data['dev']))
		$devs = $data['dev'];
	else {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定删除设备不正确。');
		return false;
	}
	
	$count = 0;
	foreach($devs as $dev) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $dev, $match) == false)
			continue;

		$cmd = DATAEYE." device remove license_id12={$dev}";

		exec($cmd, $out, $ret);
		if ($out[0] != "ok") {
			set_errmsg(MSG_LEVEL_ARG, __function__, "删除“{$dev}”设备失败！");
			return false;
		}

		$count++;
	}

	return $count;
}

