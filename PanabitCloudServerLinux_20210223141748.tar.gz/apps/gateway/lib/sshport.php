<?php
namespace cloud\apps\gateway;


function sshport_close($data)
{
	global $user;

	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['dev']) == false || empty($data['dev'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '需断开的对象不能为空。');
		return false;
	}

	if(is_array($data['dev']))
		$devs = $data['dev'];
	else {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定要断开的对象不正确。');
		return false;
	}

	$err = array();
	$count = 0;
	foreach($devs as $key => $dev) {
		if(isset($dev['serialno']) == false || empty(($serialno = trim($dev['serialno'])))) {
			/*
			set_errmsg(MSG_LEVEL_ARG, __function__, '需断开的对象不能为空。');
			return false;
			*/
			continue;
		}
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $serialno, $match) == false) {
			/*
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$serialno}”不正确！");
			return false;
			*/
			continue;
		}

		if(isset($dev['cliip']) == false || empty(($cliip = trim($dev['cliip'])))) {
			/*
			set_errmsg(MSG_LEVEL_ARG, __function__, '需断开的对象不能为空。');
			return false;
			*/
			continue;
		}
		if($cliip != 'localhost' && is_ipaddr($cliip) == false)
			continue;

		if(isset($dev['bigport']) == false || (($bigport = intval($dev['bigport'])) <= 0)) {
			/*
			set_errmsg(MSG_LEVEL_ARG, __function__, '需断开的对象不能为空。');
			return false;
			*/
			continue;
		}

		if(isset($dev['minport']) == false || (($minport = intval($dev['minport'])) <= 0)) {
			/*
			set_errmsg(MSG_LEVEL_ARG, __function__, '需断开的对象不能为空。');
			return false;
			*/
			continue;
		}
		
		$cmd = DATAEYE." sshport remove license_id12={$serialno} cliip={$cliip} bigport={$bigport} minport={$minport} ";
		exec($cmd, $out, $ret);
		if ($out[0] != "ok") {
			/*
			set_errmsg(MSG_LEVEL_ARG, __function__, "断开“{$serialno}”设备失败！");
			return false;
			*/
			//if(count($err) < 4)
			//	array_push($err, $serialno);
			continue;
		}

		$count++;
	}

//	$ret = array('count' => $count, );
	
	return $count;
}

function sshport_list($data)
{
	global $nidb, $user;
	

	try {
		$sql = "select `hostname`, `hostip`, `centercode` from intool_list";

		$sth = $nidb->prepare($sql);
		$sth->execute();

		$intools = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$result = array();
//	if(!$intools) 
//		return $result;

//	if(count($intools) <= 0) 
//		return $result;

	$cmd = DATAEYE . " sshport list usergrp=" . $user->grp;
	exec($cmd, $out, $ret);
	foreach($out as $val) {
		$ds = explode(' ', $val);

		$hostname = "";
		foreach($intools as $dd) {
			if ($dd->hostip == $ds[5] && $dd->centercode == $ds[0]) {
				$hostname = $dd->hostname;
				break;
			}
		}

		$bigport = $ds[3];
		if ($bigport == 0)
			continue;

		array_push($result, array(
			"hostname"		=> $hostname,
			"serialno"		=> to_utf8($ds[0]),
			"sysname"		=> to_utf8($ds[1]),
			"grpid"			=> $ds[2],
			"bigport"		=> $bigport,
			"minport"		=> $ds[4],
			"cliip"			=> $ds[5],
			"borntime"		=> date("d/H:i:s", $ds[6]),
			"uptime"		=> $ds[7],
			"usetime"		=> time() - $ds[6]
		));
		array_push($sorts, $hostname);
	}
	array_multisort($sorts, SORT_ASC, SORT_STRING, $result);

	return $result;
}

function sshport_open($data)
{
	global $nidb, $user;
	

	$optional = array();

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	// set custom options
	if(format_and_push($data, 'serialno', $optional, '', 'string', false) == false) {
		//set_errmsg(MSG_LEVEL_ARG, __function__, '操作设备不能为空。');
		//return false;
		$optional['serialno'] = '';
	}
	if(empty($optional['serialno']) == false 
	&& preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}
	
	if(format_and_push($data, 'webenable', $optional, '', 'int', false) == false) 
		$optional['webenable'] = 0;
	if(format_and_push($data, 'sshenable', $optional, '', 'int', false) == false) 
		$optional['sshenable'] = 0;

	if(format_and_push($data, 'hostport', $optional, '', 'int', false) == false) 
		$optional['hostport'] = 0;
	if(format_and_push($data, 'maphost', $optional, '', 'string', false) == false) 
		$optional['maphost'] = '';
	
	/* 判断是内网访问的映射还是网关设备的映射 */
	if(format_and_push($data, 'inacc', $optional, '', 'int', false) == false) 
		$optional['inacc'] = 0;

	if(isset($data['rdpenable']) == false || (($rdpenable = intval($data['rdpenable'])) < 0))
		$rdpenable = 0;

	if ($rdpenable) {
		/* 远程桌面映射利用web映射 */
		$optional['webenable'] = 1;
	}

	$now = time();
	if ($optional['inacc'] > 0) {
		try {
			$sql = "update `intool_list` set `acctimes` = `acctimes` + 1";
			$sql.= ", `lasttime` = {$now}";
			$sql.=" where `id` = {$optional['inacc']}";

			$nidb->prepare($sql)->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
	}

	/* get dev info */
	$serialno = strtolower($optional['serialno']);
	$cmd = DATAEYE . " device list sch='{$serialno}'";
	$cmd.= " format=1";	// 增加 freeend 可升级时间
	exec($cmd, $out, $ret);
	$sysname = '';
	if($ret == 0) {
		foreach($out as $val) {
			$row = explode('|', $val);
			if ($row[0] == "ipaddr") 
				continue;
			if (count($row) < 3) {
				continue;
			}
			// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
			if(empty($row[15]))
				$name = $row[1];
			else
				$name = $row[15];
			$sysname		= '|' . to_utf8($name);
			break;
		}
	}

	/* Update log */
	if ($optional['maphost'] == "")
		cloud_insertlog($user->username, "查看流控设备：{$optional['serialno']}{$sysname}");
	else
		cloud_insertlog($user->username, "查看内网运维设备：{$optional['maphost']}{$sysname}");

	try {
		$frmData = array(
			'md5str'	=> ''
		);
		$where = array(
			'license_id12'	=> $optional['serialno']
		);
		if(update_data('cloud_device', $frmData, $where) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if ($optional['webenable'] == 0 && $optional['sshenable'] == 0) {
		set_errmsg(MSG_LEVEL_DEF, __function__, "系统有更新，请重新登录！");
		return false;
	}
	$cmd = DATAEYE . " device mapping license_id12={$optional['serialno']}";
	$cmd.= " maphost={$optional['maphost']} hostport={$optional['hostport']}";
	$cmd.= " webenable={$optional['webenable']} sshenable={$optional['sshenable']}";
	exec($cmd);

	try {
		$sql = "select `web_port` as `webport`, `ssh_port` as `sshport`, `md5str` from cloud_device where license_id12 = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['serialno'], \PDO::PARAM_STR);

		$sth->execute();

		$data = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$data) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '映射失败！');
		return false;
	}

	if ($data['md5str'] == "none")
		$data['md5str'] = "";

	$localip = $_SERVER['HTTP_HOST'];
	if (strchr($localip, ':') != false) {
		$ds = explode(':', $localip);
		$localip = $ds[0];
	}
	if ($rdpenable) {
		file_put_contents(dirname(ROOT_DIR) . "/download/mstsc_{$data['webport']}.bat", "start mstsc /v:{$localip}:{$data['webport']}");
	}

	$data['hostip'] = gethostbyname($localip);
	return $data;
}

