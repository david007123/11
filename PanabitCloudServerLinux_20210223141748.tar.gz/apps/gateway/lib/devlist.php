<?php
namespace cloud\apps\gateway;


function devlist($data)
{
	global $user;
	
	$optional = array(
		'hasempty_ent'	=> 0,
		'ent_id'		=> 0,
	);
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
		'fail'		=> 0,
		'exp'		=> 0,
		'page'		=> 0,
		'limit'		=> 0,
		'equalcount'=> 0
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	format_and_push($data, 'hasempty_ent', $optional, '', 'int', false);
	format_and_push($data, 'ent_id', $optional, '', 'int', false);

	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		$optional['keyword'] = strtolower($optional['keyword']);
		$optional['keyword'] = shell_filter($optional['keyword']);
	}
	else
		$optional['keyword'] = '';
	
	if(format_and_push($data, 'sort', $optional, '', 'string', false) == false)
		$optional['sort'] = 'serialno';

	if(format_and_push($data, 'expire', $optional, '', 'int', false) == false)
		$optional['expire'] = 0;
	
	if(format_and_push($data, 'page', $result, '', 'int', false) == false)
		$result['page'] = 1;
	
	if(format_and_push($data, 'limit', $result, '', 'int', false) == false)
		$result['limit'] = 20;
	else
		if($result['limit'] <= 0) $result['limit'] = 20;

	if(format_and_push($data, 'g_ascdesc', $optional, '', 'string', false)) {
		if ($optional['g_ascdesc'] != 'desc')
			$optional['g_ascdesc'] = 0;
		else
			$optional['g_ascdesc'] = 1;
	}
	else
		$optional['g_ascdesc'] = 0;

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
		else 
		if($optional['grpid'] == 0)
			$optional['grpid'] = '10000,0';
		else 
		if($optional['grpid'] < 0)
			$optional['grpid'] = '';
	}
	
	switch($optional['sort']) {
		case "serialno":
		$sort_name = 1;break;
		case "lasttime":
		$sort_name = 2;break;
		case "license_start":
		$sort_name = 3;break;
		case "license_end":
		$sort_name = 4;break;
		case "users":
		$sort_name = 5;break;
		case "flowcont":
		$sort_name = 6;break;
		case "bpsout":
		$sort_name = 7;break;
		case "bpsin":
		$sort_name = 8;break;
		case "sysrun":
		$sort_name = 9;break;
		case "version":
		$sort_name=10;break;
		case "temp":
		$sort_name=11;break;
		case "cpu":
		$sort_name=12;break;
		case "name":
		$sort_name=13;break;
		default:
		$sort_name=1;break;
	}

	$cmd = DATAEYE . " device list page={$result['page']}";
	$cmd.= " limit={$result['limit']}";
	$cmd.= " usergrp={$optional['grpid']} sch='{$optional['keyword']}'";
	$cmd.= " sortname={$sort_name} sortdesc={$optional['g_ascdesc']}";
	$cmd.= " expire={$optional['expire']}";
	$cmd.= " hasempty_ent={$optional['hasempty_ent']}";
	$cmd.= " ent_id={$optional['ent_id']}";
	$cmd.= " format=1";	// 增加 freeend 可升级时间

	exec($cmd, $out, $ret);

	foreach($out as $val) {
		$row = explode('|', $val);
		if ($row[0] == "ipaddr") 
			continue;
		if (count($row) < 3) {
			if(($pos = strpos($row[0], 'device_total=')) === 0)
				$result['total'] = intval(substr($row[0], 13));
			else
			if(($pos = strpos($row[0], 'device_fail=')) === 0)
				$result['fail'] = intval(substr($row[0], 12));
			else
			if(($pos = strpos($row[0], 'device_exp=')) === 0)
				$result['exp'] = intval(substr($row[0], 11));
			else
			if(($pos = strpos($row[0], 'equalcount=')) === 0)
				$result['equalcount'] = intval(substr($row[0], 11));
			continue;
		}

		$grpid = (int)$row[13];

		$pos = stripos($row[22], '(');
		$ver = substr($row[22], $pos);
		$ver	= to_utf8($ver);

		// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
		$sysname = $row[1];
		if(empty($row[15]))
			$name = $sysname;
		else
			$name = $row[15];

		$name		= to_utf8($name);
		$sysname	= to_utf8($sysname);
		$machineno	= to_utf8($row[14]);
		$serialno	= to_utf8($row[4]);
		$map_address= to_utf8($row[21]);

		array_push($result['rows'], array(
			"ipaddr"		=> long2ip($row[0]),
			"name"			=> $name,
			"sysname"		=> $sysname,
			"license_start"	=> (int)$row[2],
			"license_end"	=> (int)$row[3],
			"license_upgrade"=> (int)$row[32],
			"usedays"		=> ($row[3] == 0 ? '' : intval(($row[3] - $now) / 86400)),
			"serialno"		=> $serialno,
			"max_flowcont"	=> (int)$row[5],
			"max_ipcnt"		=> (int)$row[6],
			"users"			=> (int)$row[7],
			"flowcont"		=> (int)$row[8],
			"bpsout"		=> (int)$row[9],	
			"bpsin"			=> (int)$row[10],
			"lasttime"		=> (int)$row[11],
			"servertime"	=> $now,
			"webport"		=> (int)$row[12],
			"grpid"			=> $grpid,
//			"grpname"		=> $grpname,
			"machineno"		=> $machineno, 
			"sysrun"		=> ($now - (int)$row[16]),
			"sshport"		=> (int)$row[17],
			"outip"			=> long2ip($row[18]),
			"longitude"		=> $row[19],
			"latitude"		=> $row[20],
			"map_address"	=> $map_address,
			"version"		=> $ver,
			"temp"			=> (int)$row[23],
			"cpu"			=> (int)$row[25],
			"max_users"		=> (int)$row[29],
			"release"		=> (int)$row[33],
			"os"			=> (int)$row[34],
			"ping_delay"	=> (int)$row[35],
			"ent_id"		=> (int)$row[37]
		));
	}

	return $result;
}


function amaplist($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'page'		=> 0,
		'limit'		=> 0
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
		$optional['keyword'] = strtolower($optional['keyword']);
	}
	else
		$optional['keyword'] = '';
	
	if(format_and_push($data, 'sort', $optional, '', 'string', false) == false)
		$optional['sort'] = 'serialno';

	if(format_and_push($data, 'expire', $optional, '', 'int', false) == false)
		$optional['expire'] = 0;
/*
	if(format_and_push($data, 'page', $result, '', 'int', false) == false)
		$result['page'] = 1;

	if(format_and_push($data, 'limit', $result, '', 'int', false))
		$result['limit'] = 20;
	else
		if($result['limit'] <= 0) $result['limit'] = 20;
*/
	if(format_and_push($data, 'g_ascdesc', $optional, '', 'string', false)) {
		if ($optional['g_ascdesc'] != 'desc')
			$optional['g_ascdesc'] = 0;
		else
			$optional['g_ascdesc'] = 1;
	}
	else
		$optional['g_ascdesc'] = 0;

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
		else 
		if($optional['grpid'] == 0)
			$optional['grpid'] = '0,10000';
		else 
		if($optional['grpid'] < 0)
			$optional['grpid'] = '';
	}
	
	switch($optional['sort']) {
		case "serialno":
		$sort_name = 1;break;
		case "lasttime":
		$sort_name = 2;break;
		case "license_start":
		$sort_name = 3;break;
		case "license_end":
		$sort_name = 4;break;
		case "users":
		$sort_name = 5;break;
		case "flowcont":
		$sort_name = 6;break;
		case "bpsout":
		$sort_name = 7;break;
		case "bpsin":
		$sort_name = 8;break;
		case "sysrun":
		$sort_name = 9;break;
		case "version":
		$sort_name=10;break;
		case "temp":
		$sort_name=11;break;
		case "cpu":
		$sort_name=12;break;
		case "name":
		$sort_name=13;break;
		default:
		$sort_name=1;break;
	}

	$optional['expire'] = 2;

	$cmd = DATAEYE . " device list page={$result['page']}";
	$cmd.= " limit={$result['limit']}";
	$cmd.= " usergrp={$optional['grpid']} sch='{$optional['keyword']}'";
	$cmd.= " sortname={$sort_name} sortdesc={$optional['g_ascdesc']}";
	$cmd.= " expire={$optional['expire']}";

	exec($cmd, $out, $ret);

	$ttl = strtotime("now") - 15;
	foreach($out as $val) {
		$row = explode('|', $val);
		if ($row[0] == "ipaddr") 
			continue;
		if (count($row) < 3) 
			continue;
		if($row[21] == "" || $row[22] == "")
			continue;

		$grpid = (int)$row[13];

		$pos = stripos($row[22], '(');
		$ver = substr($row[22], $pos);

        $ver = to_utf8($ver);
        $map_address = to_utf8($row[21]);

		// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
		$name = to_utf8((empty($row[15]) ? $row[1]: $row[15]));

		array_push($result['rows'], array(
			"name"			=> $name,
			"serialno"		=> $row[4],
			"grpid"			=> $grpid,
			"license_start"	=> (int)$row[2],
			"license_end"	=> (int)$row[3],
			"usedays"		=> ($row[3] == 0 ? '' : intval(($row[3] - $now) / 86400)),
			"users"			=> (int)$row[7],
			"bpsout"		=> (int)$row[9],	
			"bpsin"			=> (int)$row[10],
			"lasttime"		=> (int)$row[11],
			"longitude"		=> $row[19],
			"latitude"		=> $row[20],
			"map_address"	=> $map_address,
			"version"		=> $ver,
			"linkdown"		=> (intval($row[11]) < $ttl ? 1 : 0), // 1 离线；0：在线
			"lnglat"		=> array($row[19], $row[20])
		));
	}

	return $result;
}

