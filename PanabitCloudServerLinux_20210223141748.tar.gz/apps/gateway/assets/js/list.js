// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga()
{
	return _tb_paga;
}
function set_tb_paga(paga)
{
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function open_remote(serialno, webenable, sshenable, callback)
{
	var index = layer.load(0, {
		shade: 0
	});

	$.ajax({
		url: 'api.php?r=gateway@sshport_open',
		data: {
			serialno: serialno,
			webenable: webenable,
			sshenable: sshenable
		},
		dataType: 'json',
		type: 'post',
		success: function(d) {
			layer.close(index);
			if (ajax_resultCallBack(d) == false) {
				layer.msg(d.msg, {
					icon: 5
				});
				return;
			}

			if (typeof callback == 'function')
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {
				icon: 2
			});
		}
	});
}

function open_https(serialno, off)
{
	var protocol = window.document.location.protocol + '//';

	if (off){
		layer.msg('此设备已断开，无法连接。');
		return;
	}
	open_remote(serialno, 1, 0, function(d) {
		var path = '/login/userverify.cgi?pakey=' + d.md5str + '&username=admin';
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(protocol + d.hostip + ":" + d.webport + path, "_blank");
				}
			});
		} else 
			window.open(protocol + d.hostip + ":" + d.webport + path, "_blank");
	});
}

function open_ssh(serialno, off)
{	
	if (off){
		layer.msg('此设备已断开，无法连接。');
		return;
	}
	open_remote(serialno, 0, 1, function(d) {
		window.open("ssh://root@" + window.document.location.hostname + ":" + d.sshport, "_blank");
	});
}

function open_scp(serialno, off)
{	
	if (off){
		layer.msg('此设备已断开，无法连接。');
		return;
	}
	open_remote(serialno, 0, 1, function(d) {
		window.open("scp://root@" + window.document.location.hostname + ":" + d.sshport, "_blank");
	});
}

function setcol_devapp_ports(d)
{
	if (d[this.field] == "NONE") return "";
	return d[this.field];
}

function ping_delay_color(delay)
{
	if(delay > 1000)
		return 'color: red;';
	if(delay >= 300)
		return 'color: #bdbd6d;';
	if(delay >= 1)
		return 'color: darkgreen;';
	return '';
}

function getcol_state(d)
{
	var state = '<img src="/cloud/assets/img/online.png" class="icon" title="当前在线">';

	if(d.release) {
		if (typeof(d.usedays) != 'string' && d.usedays <= 7) {
			if (d.usedays <= 7)
				state = '<img src="/cloud/assets/img/expire.png" class="icon" title="License即将到期"/>';

		}

		d.usedays_desc = d.usedays + '天';
	}
	else
		d.usedays_desc = '';
	
	if (d.linkdown) {
		state = '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>';
	}

	return state;
}

function setcol_devlist(d)
{
	var state = getcol_state(d);
	var html = '';
	if (typeof this.mytemplet == 'function') {
		html = this.mytemplet.call(this, d, state);
	} else
	if (this.field == undefined)
		return html;
	else
		html = d[this.field];

	if (state == '<img src="/cloud/assets/img/expire.png" class="icon" title="License即将到期"/>')
		return '<div class="expire_txt">' + html + '</div>';
	else
	if (state == '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>')
		return '<div class="off_txt">' + html + '</div>';
	else
		return html;
}

function setcol_showsync(d)
{
	if (d.error == '')
		return '准备同步，请稍后！';

	switch (d.code) {
		case 0:
		case 1:
			return '<span style="color: #5FB878;">[正在同步] ' + d.error + '</span>';
		case 2:
			return '<span style="color: #009688;">[同步完成] ' + d.error + '</span>';
		case 3:
			return '<span class="off_txt">[同步失败] ' + d.error + '</span>';
	}

	return '[' + d.code + '] ' + d.error;
}

var timer = new taskTimer();
layui.use(['form', 'element', 'table', 'layer'], function() {
	var ua = navigator.userAgent;
	var isMobile = myDev.isMobile();

	//判断
	if (isMobile) {
		$('.getwaytool').css({
			'width': '100%',
			'justify-content': 'space-between',
			'flex-wrap': 'wrap'
		});
	}



	var form = layui.form;
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var tablelns;

	$('.searchBtn').click(function() {
		search(1);
	});

	$('.form-group-text').keyup(function(event) {
		if (event.keyCode == 13) {
			$('.searchBtn').click();
		}
	});


	function maingroup_refresh() {
		timer.add('read_group', 3, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="filter-group"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="filter-group"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
						timer.rmv('read_group');
					}
				});
			}
		}, 1);
	}
	maingroup_refresh();

	var g_sertm = 0;
	tablelns = table.render({
		elem: '#cloud_devlist',
		even: true,
		loading: false,
		url: 'api.php?r=gateway@devlist',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'serialno',
			type: 'asc'
		},
		where: {
			sort: 'serialno',
			g_ascdesc: 'asc',
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			var d, i;
			if (res.ret == 0) {
				g_sertm = res.data.now;
				res.count = res.data.total;
				res.data = res.data.rows;

				for(i = 0; i < res.data.length; i++) {
					d = res.data[i];
					if ((Number(d.lasttime) + 15) < Number(d.servertime))
						d.linkdown = 1;
					else
						d.linkdown = 0;
				}
			}

			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#cloud_devlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[ //表头
				{
					field: 'id',
					title: '序号',
					width: 30,
					fixed: 'left',
					type: 'numbers',
					templet: setcol_devlist
				},
				{
					type: 'checkbox',
					width: 25
				}, {
					field: 'serialno',
					title: '编号',
					width: 130,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						var dsc = (d.ping_delay>=1000?' > ':'') + d.ping_delay + 'ms 时延';
						if (isMobile) {
							return '<div lay-event="info" title="' + dsc + '"><i class="fa fa-desktop table-icon" style="' + ping_delay_color(d.linkdown?9999:d.ping_delay) + '"></i><span style="cursor: pointer;">' + d.serialno + '</span></div>';
						} else {
							return '<a href="javascript:void(0);" lay-event="info" title="' + dsc + '"><i class="fa fa-desktop table-icon" style="' + ping_delay_color(d.linkdown?9999:d.ping_delay) + '"></i></a><span>' + d.serialno + '</span>';
						}
					}
				}, {
					field: 'name',
					title: '名称',
					width: 190,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<span class="setBtn" lay-event="open" onmouseover="nameOpen(this, \'' + $.trim(d.serialno) +
							'\', \'' + $.trim(d.name) + '\', \'' + $.trim(d.grpid) + '\', \'' + $.trim(d.map_address) + '\', ' + d.linkdown + ')">' + (d.name?d.name:'none') +
							'</span>';
					}
				}, {
					field: 'lasttime',
					title: '状态',
					width: 35,
					templet: setcol_devlist,
					mytemplet: function(d, state) {
						return state;
					}
				}, {
					field: 'grpname',
					title: '属组',
					width: 100,
					templet: setcol_devlist,
					mytemplet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'lasttime',
					title: '最后在线',
					sort: true,
					width: 94,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return $.myTime.UnixToStrDate(d.lasttime, 'MM-dd/HH:mm:ss');
					}
				}, {
					field: 'license_end',
					title: '有效期',
					sort: true,
					width: 62,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.usedays_desc;
					}
				}, {
					field: 'users',
					title: '用户(C/M/F)',
					sort: true,
					width: 136,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.users + '/' + d.max_users + '/' + d.max_ipcnt;
					}
				}, {
					field: 'flowcont',
					title: '连接数',
					sort: true,
					width: 100,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.flowcont + '/' + parseInt(d.max_flowcont / 1000) + 'K';
					}
				}, {
					field: 'bpsout',
					title: '上行',
					sort: true,
					width: 60,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-left">' + numberformats(d.bpsout) + '</div>';
					}
				},
				{
					field: 'bpsin',
					title: '下行',
					sort: true,
					width: 60,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-left">' + numberformats(d.bpsin) + '</div>';
					}
				}, {
					field: 'sysrun',
					title: '运行',
					sort: true,
					width: 85,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<div class="cell-align">' + parsesysrun(d.sysrun) + '</div>';
					}
				}, {
					field: 'cpu',
					title: '温度/CPU',
					sort: true,
					width: 78,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.temp + '℃ / ' + d.cpu + '%'
					}
				}, {
					field: 'version',
					title: '当前版本',
					sort: true,
					width: 171,
					templet: setcol_devlist
				},
				// {
				// 	title: '操作',
				// 	width: 35,
				// 	templet: setcol_devlist,
				// 	mytemplet: function(d) {
				// 		return '<span class="setBtn" lay-event="edit">设置</span>'
				// 	}
				// }
			]
		]
	});

	table.on('sort(devlist)', function(obj) {
		search(0, obj);
	});

	table.on('tool(devlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'open') {
			open_https(data.serialno, data.linkdown);
		}
		else
		if (event == 'info') {
			layer.open({
				type: 1,
				title: '设备信息',
				area: ['700px'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['关闭'],
				content: $('#tpl-devinfo').html(),
				success: function(layero, index) {
					$('[lay-filter="devinfo"] [name]').each(function(i, e) {
						var elem = $(e);
						var str, name = elem.attr('name');

						function release_dsc(dev) {
							var str = ["标准版","专业版","网吧版","","","SMB"];
							var os = ["FreeBSD","Linux"];
							var dsc = str[dev.release];

							os = os[dev.os]?' [<span style="color: red">'+os[dev.os]+'</span>]':'';
							if(dsc) {
								if(dev.release == 1 && dev.serialno.substr(0, 2).toLocaleUpperCase() == 'PN')
									dsc = '租赁版';
								return ' [<span style="color: red">' + dsc + '</span>]' + os;
							}
							return os;
						}
						
						if (data[name]) {
							elem.text(data[elem.attr('name')]);
						} else {
							if (name == 'license_time') {
								if (data.usedays === '' && data.serialno.indexOf('F') === 0) {
									elem.text('这是标准版，支持256用户，完全免费，无任何时间限制');
									elem.css('color', 'red');
								}
								else {
									str = $.myTime.UnixToStrDate(data.license_start, false) + ' 至 ' + $.myTime.UnixToStrDate(data.license_end,
										false)
									if (data.usedays <= 0) {
										str += '（已到期）';
										elem.css('color', 'red');
									} else
										elem.css('color', 'darkgreen');
									elem.text(str);
								}
								elem.css('font-weight', 'bold');
							}
							else
							if (name == 'license_upgrade_time') {
								if (data.usedays === '' && data.serialno.indexOf('F') === 0) {
									elem.text('无任何时间限制');
									elem.css('color', 'red');
								}
								else
								if(data.license_upgrade && g_sertm) {
									str = $.myTime.UnixToStrDate(data.license_start, false) + ' 至 ' + $.myTime.UnixToStrDate(data.license_upgrade,
										false)
									if ((data.license_upgrade - g_sertm) <= 0) {
										str += '（已到期）';
										elem.css('color', 'red');
									} else
										elem.css('color', 'darkgreen');
									elem.text(str);
								}
								elem.css('font-weight', 'bold');
							}
							else
							if(name == 'version_str')
								elem.html(data.version + release_dsc(data));
							else
							if (name == 'openhttps')
								elem.html('<a class="setBtn" href="javascript:open_https(\'' + data.serialno + '\', ' + data.linkdown + ');">' + elem.attr(
									'title') + '</a>');
							else
							if (name == 'openssh')
								elem.html('<a class="setBtn" href="javascript:open_ssh(\'' + data.serialno + '\', ' + data.linkdown + ');">' + elem.attr(
									'title') + '</a>');
							else
							if (name == 'openscp')
								elem.html('<a class="setBtn" href="javascript:open_scp(\'' + data.serialno + '\', ' + data.linkdown + ');">' + elem.attr(
									'title') + '</a>');
							else
							if (name == 'outip_dsc') {
								elem.html(data.outip + ' [ <span style="'+ping_delay_color(data.linkdown?9999:data.ping_delay)+'" >' + (data.ping_delay>=4000?' > ':'') + data.ping_delay + 'ms 时延</span> ]'); 
							}
						}
					});

					$('[lay-filter="devinfo"]').css('font-size', '12px');
					form.render(null, 'devinfo');
					form.on('submit', function(data) {
						return false;
					});
				},
				yes: function(index, layero) {
					layer.close(index);
				}
			});
		}
	});

	$('.toolleft2 button').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('lay-filter');
		var checkStatus = table.checkStatus(tablelns.config.id);
		var devs = [];
		checkStatus.data.forEach(function(e, i) {
			devs.push(e.serialno);
		});
		switch (event) {
			case 'move':
				if (devs.length <= 0) {
					layer.msg('请先选择要转移的设备。');
					return;
				}
				var my_cloudip = $.cookie("my_cloudip");
				if(!my_cloudip) my_cloudip = '';
				layer.prompt({
					formType: 0,
					value: my_cloudip,
					maxlength: 32,
					title: '请输入新的云平台地址',
					area: ['300px', '120px'] //自定义文本域宽高
				}, function(value, index, elem) {
					$.cookie("my_cloudip", value, {expires: 31});
					$.ajax({
						url: 'api.php?r=gateway@transfer',
						data: {
							dev: devs,
							cloudip: value
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				});
				break;
			case 'del':
				if (devs.length <= 0) {
					layer.msg('请先选择要删除的设备。');
					return;
				}

				layer.confirm('确定要删除这些设备吗?', {
					icon: 0,
					title: '设备删除'
				}, function(index) {
					$.ajax({
						url: 'api.php?r=gateway@remove',
						data: {
							dev: devs
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							search();
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
					layer.close(index);
				});
				break;
			case 'passwd':
				if (devs.length <= 0) {
					layer.msg('请先选择需要操作的设备。');
					return;
				}

				layer.open({
					type: 1,
					title: '修改设备管理密码',
					area: ['400px', '245px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#tpl-setpass').html(),
					mysubmit: function(index, layero) {
						var data = form.val('setpass');
						data.dev = devs;
						data.mdfpass = 0;
						if (data['like1[mdfweb]'] == 'on') data.mdfpass = 1;
						if (data['like1[mdfroot]'] == 'on') data.mdfpass |= 2;
						if(data.mdfpass == 0) {
							layer.msg('请至少选择一个WEB或者SSH的root密码修改。', {
								icon: 2
							});
							return;
						}
						$.ajax({
							url: 'api.php?r=gateway@setpass',
							data: data,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					},
					success: function(layero, index) {
						var that = this;
						form.render(null, 'setpass');
						form.on('submit', function(data) {
							that.mysubmit(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						this.mysubmit(index, layero);
					}
				});
				break;
			case 'grpchg':
				if (devs.length <= 0) {
					layer.msg('请先选择要操作的设备。');
					return;
				}

				layer.open({
					type: 1,
					title: '设备分组修改 / 已选 ' + devs.length,
					area: ['300px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#tpl-grpchg').html(),
					mysubmit: function(index, layero) {
						var data = form.val('grpchg');
						$.ajax({
							url: 'api.php?r=gateway@grpchg',
							data: {
								dev: devs,
								grpid: data.grpid
							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								// table.refresh('devlist');
								search();
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					},
					success: function(layero, index) {
						var data = form.val('grpchg');
						var that = this;
						var tab;

						tab = layero.find('form[lay-filter="grpchg"] select[name="grpid"]');
						$('select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
							tab.append($(e).clone());
						});

						tab.parents('.layui-layer-content').css('overflow', 'inherit');
						form.render(null, 'grpchg');
						form.on('submit', function(data) {
							that.mysubmit(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						this.mysubmit(index, layero);
					}
				});
				break;

			case 'group':
				layer.open({
					type: 1,
					title: '设备组管理',
					area: ['600px', '400px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					content: $('#tpl-groupmgd').html(),
					cancel: function(index, layero) {
						maingroup_refresh();
					},
					mysubmit: function(index, layero) {
						var data = form.val('setpass');
						data.dev = devs;
						if (data['like1[syncweb]'] == 'on') data.syncweb = 1;
						$.ajax({
							url: 'api.php?r=gateway@setpass',
							data: data,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					},
					success: function(layero, index) {
						var that = this;
						form.render(null, 'setpass');
						form.on('submit', function(data) {
							return false;
						});

						var grouplns = table.render({
							elem: '#grouplist',
							even: true,
							autoSort: false,
							height: 345,
							width: 600,
							url: 'api.php?r=gateway@group', //数据接口
							method: 'post',
							limit: 20,
							skin: 'line',
							//		size: 'sm',
							initSort: {
								field: 'grpname',
								type: 'asc'
							},
							request: {
								pageName: 'page',
								limitName: 'limit'
							},
							toolbar: true,
							defaultToolbar: [{
								title: '添加新设备组', //标题
								layEvent: 'LAYTABLE_ADDGROUP', //事件名，用于 toolbar 事件中使用
								icon: 'layui-icon-add-circle' //图标类名
							}],
							page: false, //开启分页
							parseData: function(res) {
								var rows = []
								if (res.ret == 0) {
									res.data.rows.forEach(function(item, index) {
										rows.push(item);
									});
								}

								this.mydefgrp = res.data.defgrp;
								if (this.mydefgrp == 10000)
									this.mydefgrp = 0;

								res.count = rows.length;
								res.data = rows;
								res.code = res.ret;
								res.msg = res.msg;;
							},
							done: function(res, curr, count) {
								var defgrp = this.mydefgrp;
								var data = res.data;

								// $("[data-field='id']").css('display', 'none');
								for (var i = 0; i < data.length; i++) {
									if (defgrp == data[i].grpid) {
										var index = data[i]['LAY_TABLE_INDEX'];
										if (index == undefined) index = i;
										var row = $('#grouplist').parent().find('tr[data-index=' + index + '] input[type="radio"]');
										row.prop('checked', true);
										row.next().addClass('layui-form-checked');
										break;
									}
								}
								form.render();
							},
							cols: [
								[ //表头
									{
										field: 'id',
										title: '序号',
										minWidth: 50,
										fixed: 'left',
										type: 'numbers'
									}, {
										field: 'grpname',
										title: '组名称',
										edit: 'text',
										sort: false
									}, {
										title: '默认组',
										type: 'radio',
										minWidth: 60
									}, {
										field: 'operate',
										title: '操作',
										width: 60,
										templet: function(d) {
											return '<span class="setBtn" lay-event="del">删除</span>'
										}
									}
								]
							]
						});

						$(grouplns.config.elem).parent().find('.layui-table-tool').css('background-color', 'white');
						table.on('tool(grouplist)', function(obj) {
							var data = obj.data,
								event = obj.event;

							if (event === 'del') {
								layer.confirm('确定要删除该设备组吗？', function(index) {
									$.ajax({
										url: 'api.php?r=gateway@group_del',
										data: {
											grpid: data.grpid
										},
										type: 'post',
										dataType: 'json',
										success: function(d) {
											if (ajax_resultCallBack(d) === false) {
												layer.msg(d.msg, {
													icon: 5
												});
												return;
											}
											if (d.msg) layer.msg(d.msg, {
												icon: 1
											});

											obj.del();
											layer.close(index);
										},
										error: function() {
											layer.msg('获取数据失败，请稍后再试。', {
												icon: 2
											});
										}
									});
								});
							}
						});
						table.on('toolbar(grouplist)', function(obj) {
							var checkStatus = table.checkStatus(obj.config.id),
								data = checkStatus.data;

							switch (obj.event) {
								case 'LAYTABLE_ADDGROUP':
									layer.prompt({
										formType: 0,
										value: '',
										maxlength: 32,
										title: '请输入设备组名称',
										area: ['300px', '120px']
									}, function(value, index, elem) {
										value = $.trim(value);
										if (value == '') {
											layer.msg('设备组名称不能为空！', {
												icon: 5
											});
											return;
										}
										$.ajax({
											url: 'api.php?r=gateway@group_add',
											data: {
												name: value
											},
											type: 'post',
											dataType: 'json',
											success: function(d) {
												if (ajax_resultCallBack(d) === false) {
													layer.msg(d.msg, {
														icon: 5
													});
													return;
												}
												if (d.msg) layer.msg(d.msg, {
													icon: 1
												});
												layer.close(index);
												table.refresh('grouplist');
											},
											error: function() {
												layer.msg('获取数据失败，请稍后再试。', {
													icon: 2
												});
											}
										});
									});
									break;
							}
						});
						table.on('radio(grouplist)', function(obj) {
							$.ajax({
								url: 'api.php?r=gateway@group_setdef',
								data: {
									grpid: obj.data.grpid
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										table.refresh('grouplist');
										return;
									}
									if (d.msg) layer.msg(d.msg, {
										icon: 1
									});
								},
								error: function() {
									layer.msg('获取数据失败，请稍后再试。', {
										icon: 2
									});
								}
							});
						});
						table.on('edit(grouplist)', function(obj) {
							var value = obj.value,
								data = obj.data,
								field = obj.field;
							//var oldname = $(obj.tr[0]).find('[data-field="grpname"] .layui-table-cell').text();
							//layer.confirm('确定要修改该设备组名称吗？', function(index){
							$.ajax({
								url: 'api.php?r=gateway@group_save',
								data: {
									grpid: data.grpid,
									grpname: value
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										table.refresh('grouplist');
										return;
									}
									if (d.msg) layer.msg(d.msg, {
										icon: 1
									});
								},
								error: function() {
									layer.msg('获取数据失败，请稍后再试。', {
										icon: 2
									});
								}
							});
							//}, function(index){
							//obj.data.grpname = obj.value = oldname;
							//layer.msg(oldname, {icon: 2});
							//	table.refresh('grouplist');
							//});
						});
					}
				});
				break;
			case 'remote':
				var fullandrestore = function(layero) {
						var h = layero.height() - 45;
						layero.find('.layui-layer-content').height(h + 'px');
						table.resize('remotelist');
				};
				layer.open({
					type: 1,
					title: '远程中设备',
					area: ['800px', '600px'],
					shadeClose: true,
					resize: true,
					maxmin: true,
					btnAlign: 'c',
					content: $('#tpl-remote').html(),
					full: fullandrestore,
					restore: fullandrestore,
					resizing: fullandrestore,
					myrefresh: function(index, layero) {
						$.ajax({
							url: 'api.php?r=gateway@sshport_list',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								d.data.forEach(function(row, index) {
									if (row.hostname)
										d.data[index].name = row.hostname;
									else
										d.data[index].name = row.sysname;
									d.data[index].onlinetime = row.usetime + 's';
								});
								table.reload('remotelist', {
									data: d.data,
									done: function(res, curr, count) {
										$('[lay-id="remotelist"]').css('margin-top', '0px');
										$('[lay-id="remotelist"] .layui-table-tool').css('background-color', 'white');
									}
								});
							}
						});
					},
					success: function(layero, index) {
						var that = this;
						table.init('remotelist');

						$('[lay-id="remotelist"]').css('margin-top', '0px');
						$('[lay-id="remotelist"] .layui-table-tool').css('background-color', 'white');
						table.on('toolbar(remotelist)', function(obj) {
							var checkStatus = table.checkStatus(obj.config.id),
								devs = [];

							switch (obj.event) {
								case 'LAYTABLE_REFRESH':
									that.myrefresh();
									break;
								case 'LAYTABLE_DEL':
									checkStatus.data.forEach(function(e, i) {
										devs.push({
											serialno: e.serialno,
											cliip: e.cliip,
											bigport: e.bigport,
											minport: e.minport,
										});
									});
									if (devs.length <= 0) return;
									layer.confirm('确定要断开这些设备连接吗？', function(index) {
										$.ajax({
											url: 'api.php?r=gateway@sshport_close',
											data: {
												dev: devs
											},
											type: 'post',
											dataType: 'json',
											success: function(d) {
												if (ajax_resultCallBack(d) === false) {
													layer.msg(d.msg, {
														icon: 5
													});
													return;
												}
												if (d.msg) layer.msg(d.msg, {
													icon: 1
												});
												that.myrefresh();
												layer.close(index);
											},
											error: function() {
												layer.msg('获取数据失败，请稍后再试。', {
													icon: 2
												});
											}
										});
									});
									break;
							}
						});
						/*
												timer.add('sshport_refresh', 5, {fuc: function(){
													var that = this;
													$.ajax({
														url: 'api.php?r=gateway@group',
														type: 'post',
														success(d) {
															if(ajax_resultCallBack(d) == false) return;
															var i, data = d.data;
															
															$('select[lay-filter="filter-group"] option').not('[value=0]').remove();
															for(i = 0; i < data.rows.length; i++) 
																$('select[lay-filter="filter-group"]')
																.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

															form.render('select');
															timer.rmv('read_group');
														}
													});
												}}, 1);
												api.php?r=gateway@overflow_ip
						*/
						that.myrefresh();
					}
				});
				break;
			case 'overflow-ip':
				var fullandrestore = function(layero) {
						var h = layero.height() - 45;
						layero.find('.layui-layer-content').height(h + 'px');
						table.resize('overflow-ip');
				};
				layer.open({
					type: 1,
					title: 'License授权溢出',
					area: ['600px', '400px'],
					shadeClose: true,
					resize: true,
					maxmin: true,
					btnAlign: 'c',
					content: $('#tpl-overflow-ip').html(),
					full: fullandrestore,
					restore: fullandrestore,
					resizing: fullandrestore,
					myrefresh: function(index, layero) {
						$.ajax({
							url: 'api.php?r=gateway@overflow_ip',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								table.reload('overflow-ip', {
									data: d.data,
									done: function(res, curr, count) {
										$('[lay-id="overflow-ip"]').css('margin-top', '0px');
										$('[lay-id="overflow-ip"] .layui-table-tool').css('background-color', 'white');
									}
								});
							}
						});
					},
					success: function(layero, index) {
						var that = this;
						table.init('overflow-ip');

						$('[lay-id="overflow-ip"]').css('margin-top', '0px');
						$('[lay-id="overflow-ip"] .layui-table-tool').css('background-color', 'white');
						table.on('toolbar(overflow-ip)', function(obj) {
							var checkStatus = table.checkStatus(obj.config.id),
								devs = [];

							switch (obj.event) {
								case 'LAYTABLE_REFRESH':
									that.myrefresh();
									break;
							}
						});
						that.myrefresh();
					}
				});
				break;
			case 'search':
				search(1);
				break;
		};
	});

	$('.maintain-grp').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('maintain-type');
		var checkStatus = table.checkStatus(tablelns.config.id);
		var devs = [];
		checkStatus.data.forEach(function(e, i) {
			devs.push(e.serialno);
		});
		switch (event) {
			case 'move':
				if (devs.length <= 0) {
					layer.msg('请先选择要转移的设备。', {
						time: 1000
					});
					return;
				}
				var my_cloudip = $.cookie("my_cloudip");
				if (!my_cloudip) my_cloudip = '';
				layer.prompt({
					formType: 0,
					value: my_cloudip,
					maxlength: 32,
					title: '请输入新的云平台地址',
					area: ['300px', '120px'] //自定义文本域宽高
				}, function(value, index, elem) {
					$.cookie("my_cloudip", value, {
						expires: 31
					});
					$.ajax({
						url: 'api.php?r=gateway@transfer',
						data: {
							dev: devs,
							cloudip: value
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				});
				break;
			case 'del':
				if (devs.length <= 0) {
					layer.msg('请先选择要删除的设备。');
					return;
				}

				layer.confirm('确定要删除这些设备吗?', {
					icon: 0,
					title: '设备删除'
				}, function(index) {
					$.ajax({
						url: 'api.php?r=gateway@remove',
						data: {
							dev: devs
						},
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							search();
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
					layer.close(index);
				});
				break;
			case 'passwd':
				if (devs.length <= 0) {
					layer.msg('请先选择需要操作的设备。');
					return;
				}

				layer.open({
					type: 1,
					title: '修改设备管理密码',
					area: ['400px', '245px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#tpl-setpass').html(),
					mysubmit: function(index, layero) {
						var data = form.val('setpass');
						data.dev = devs;
						data.mdfpass = 0;
						if (data['like1[mdfweb]'] == 'on') data.mdfpass = 1;
						if (data['like1[mdfroot]'] == 'on') data.mdfpass |= 2;
						if(data.mdfpass == 0) {
							layer.msg('请至少选择一个WEB或者SSH的root密码修改。', {
								icon: 2
							});
							return;
						}
						$.ajax({
							url: 'api.php?r=gateway@setpass',
							data: data,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					},
					success: function(layero, index) {
						var that = this;
						form.render(null, 'setpass');
						form.on('submit', function(data) {
							that.mysubmit(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						this.mysubmit(index, layero);
					}
				});
				break;
			case 'grpchg':
				if (devs.length <= 0) {
					layer.msg('请先选择要操作的设备。');
					return;
				}

				layer.open({
					type: 1,
					title: '设备分组修改 / 已选 ' + devs.length,
					area: ['300px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认'],
					content: $('#tpl-grpchg').html(),
					mysubmit: function(index, layero) {
						var data = form.val('grpchg');
						$.ajax({
							url: 'api.php?r=gateway@grpchg',
							data: {
								dev: devs,
								grpid: data.grpid
							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								// table.refresh('devlist');
								search();
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2
								});
							}
						});
					},
					success: function(layero, index) {
						var data = form.val('grpchg');
						var that = this;
						var tab;

						tab = layero.find('form[lay-filter="grpchg"] select[name="grpid"]');
						$('select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
							tab.append($(e).clone());
						});

						tab.parents('.layui-layer-content').css('overflow', 'inherit');
						form.render(null, 'grpchg');
						form.on('submit', function(data) {
							that.mysubmit(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						this.mysubmit(index, layero);
					}
				});


		};
	});

	// 搜索
	function search(page, obj) {
		var grpid = Number($('select[lay-filter="filter-group"]').val());
		var filterX = Number($('select[lay-filter="filter-x"]').val());

		var where = {
			grpid: 0,
			keyword: $.trim($('#tb_toolbar input[name="keyword"]').val()),
			sort: 'serialno',
			g_ascdesc: 'asc',
			expire: 0
		};
		if (filterX == 1) where.expire = 1;
		if (filterX == 2) where.expire = 3;
		if (grpid) where.grpid = grpid;

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;
		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt('cloud_devlist', option);
		if (page >= 0)
			auto_refresh();
	}

	form.on('select(filter-group)', function(data) {
		search(1);
	});

	form.on('select(filter-x)', function(data) {
		search(1);
	});

	// 自动刷新
	var auto_refresh_hd = 0;

	function auto_refresh() {
		var interval = $('select[lay-filter="auto-refresh"]').val();
		if (auto_refresh_hd) {
			clearInterval(auto_refresh_hd);
			auto_refresh_hd = 0;
		}
		var tm = Number(interval);
		if (tm)
			auto_refresh_hd = setInterval(function() {
				if(isHiddenMyView()) return;
				var checkStatus = table.checkStatus(tablelns.config.id);
				if (!checkStatus.data.length)
					search(-1);
			}, tm * 1000);
	}
	form.on('select(auto-refresh)', function(data) {
		auto_refresh();
	});
	auto_refresh();
});

function nameOpen(tips, serialno, name, grpid, map_address, linkdown) {
	var off = "";
	if(linkdown) {
		off = 'style="color: #909090;"';
	}
	layer.tips('<p><a href="javascript:void(0);" onclick="open_https(\'' + serialno + '\', ' + linkdown + ');" ' + off + '>HTTPS</a></p>\
		<p><a href="javascript:void(0);" onclick="open_ssh(\'' + serialno + '\', ' + linkdown + ');" ' + off + '>SSH</a></p>\
		<p><a href="javascript:void(0);" onclick="open_scp(\'' + serialno + '\', ' + linkdown + ');" ' + off + '>SCP</a></p>\
		<p><a href="javascript:void(0);" onclick="sync_devapp(\'' + serialno +
		'\');">协议同步</a></p>\
		<p><a href="javascript:void(0);" onclick="device_myrecord(\'' + serialno + '\', \'' + name +
		'\');">运维日志</a></p>\
		<p><a href="javascript:void(0);" onclick="set_gateway(\'' + serialno + '\', \'' + name +
		'\', \'' + grpid + '\',\'' + map_address + '\')">设置</a></p>',
		$(tips).parents('td'), {
			// tipsMore: true,
			tips: 4,
			// time: 0
			success: function(layero, index){
				layero.on('mouseout', function(even) {
					var p = $(even.relatedTarget).parents('.layui-layer');
					if (p.is(layero)  || $(even.relatedTarget).hasClass('layui-layer-move')) return;
					layer.close(index);
				});
			}
		});
}

function set_gateway(serialno, name, grpid, map_address) {
	var form = layui.form;
	var layer = layui.layer;
	var table = layui.table;
	layer.open({
		type: 1,
		title: '设备配置',
		area: ['560px'],
		shadeClose: true,
		resize: false,
		btnAlign: 'c',
		btn: ['确认'],
		content: $('#tpl-devconfig').html(),
		mysubmit: function(index, layero) {
			var data = form.val('devconfig');
			$.ajax({
				url: 'api.php?r=gateway@devconfig',
				data: data,
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					// table.refresh('devlist');
					table.reloadExt('cloud_devlist');
					layer.close(index);
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		success: function(layero, index) {
			var form_data = form.val('devconfig');
			var that = this;
			var tab,
				dev = {
					serialno: serialno,
					grpid: Number(form_data.grpid),
					name: form_data.name,
					address: (form_data.map_address && form_data.map_address != '' && form_data.map_address != 'none' ? map_address :
						'')
				};

			if (dev.grpid == 10000)
				dev.grpid = 0;

			tab = layero.find('form[lay-filter="devconfig"] select[name="grpid"]');
			$('select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
				tab.append($(e).clone());
			});

			tab.parents('.layui-layer-content').css('overflow', 'inherit');
			tab.children('[value="' + dev.grpid + '"]').prop('selected', true);
			form.val('devconfig', {
				'serialno': serialno,
				'name': name,
				'grpid': grpid,
				'address': (map_address && map_address != '' && map_address != 'none' ? map_address : '')
			});
			form.render(null, 'devconfig');
			form.on('submit', function(data) {
				that.mysubmit(index, layero);
				return false;
			});
		},
		yes: function(index, layero) {
			this.mysubmit(index, layero);
		}
	});
}

function device_myrecord(serialno, name) {
	var width = 900;
	var height = $(window).height();
	var top = 0;
	var left = ($(window).width() - width) / 2;
	window.open("/Maintain/device_myrecord.php?license_id12=" + serialno + "&sys_name=" + encodeURIComponent(name),
		"_blank", "width=" + width + "px,height=" + height + "px,left=" + left + "px,top=" + top + "px,resizable=no");
}

function sync_devapp(serialno) {
	var layer = layui.layer;
	var table = layui.table;
	var element = layui.element;

	layer.open({
		type: 1,
		title: '同步自己的应用协议至其它设备上' + ' from ' + serialno,
		area: ['720px', '520px'],
		shadeClose: true,
		resize: false,
		btnAlign: 'c',
		btn: ['选择目标设备', '刷新数据'],
		content: $('#tpl-devapp-sync').html(),
		usergrp_list: function(index, layero) {
			$.ajax({
				url: 'api.php?r=gateway@usergrp',
				data: {
					serialno: serialno
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});

					table.reload('usergrp', {
						data: d.data,
						done: function(res, curr, count) {}
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		userapp_list: function(index, layero) {
			$.ajax({
				url: 'api.php?r=gateway@userapp',
				data: {
					serialno: serialno
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});

					table.reload('userapp', {
						data: d.data,
						done: function(res, curr, count) {}
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		success: function(layero, index) {
			var that = this;

			layero.find('[lay-filter="devapp-sync"]').css('font-size', '12px');
			table.init('usergrp');
			table.init('userapp');

			element.on('tab(devapp-sync)', function(data) {
				if (data.index == 0)
					that.usergrp_list(index, layero);
				else
					that.userapp_list(index, layero);
				element.on('tab(devapp-sync)', function(data) {});
			});

			$.ajax({
				url: 'api.php?r=gateway@appsfetch',
				data: {
					serialno: serialno
				},
				type: 'post',
				dataType: 'json'
			});

			setTimeout(function() {
				that.usergrp_list(index, layero);
			}, 1000);
			setTimeout(function() {
				that.usergrp_list(index, layero);
			}, 2000);
		},
		yes: function(index, layero) {
			var ndata = {
				grp: [],
				app: []
			};
			table.checkStatus('usergrp').data.forEach(function(e, i) {
				ndata.grp.push({
					name: e.name,
					cname: e.cname,
					son_name: e.son_name
				});
			});
			ndata.app = table.checkStatus('userapp').data;

			if (ndata.grp.length <= 0 && ndata.app.length <= 0) {
				layer.msg('请先选择要同步的项目！', {
					icon: 5
				});
				return;
			}

			sync_devapp_go(serialno, ndata);
		},
		btn2: function(index, layero) {
			var that = this;
			var index = layero.find('.layui-tab-content>.layui-show').index();

			if (index == 0)
				that.usergrp_list(index, layero);
			else
				that.userapp_list(index, layero);
			return false;
		}
	});
}

function sync_devapp_go(serialno, data) {
	var layer = layui.layer;
	var table = layui.table;
	var form = layui.form;

	layer.open({
		type: 1,
		title: '请选择要同步到的目标设备 来自 ' + serialno,
		area: ['720px', '520px'],
		shadeClose: true,
		resize: false,
		btnAlign: 'c',
		btn: ['关闭'],
		content: $('#tpl-devapp-sync-go').html(),
		mysubmit: function(index, layero) {
			var devs = table.checkStatus('devapp-sync-go').data;
			var dev = [];
			if (devs.length <= 0) {
				layer.msg('请先选择目标同步设备！', {
					icon: 5
				});
				return;
			}

			devs.forEach(function(e, i) {
				dev.push(e.serialno);
			});

			$.ajax({
				url: 'api.php?r=gateway@userappsync',
				data: $.extend({
					serialno: serialno,
					dev: dev
				}, data),
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});

					openwin_syncappsmoniter();
					layer.close(index);
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		fetchdevlist: function(index, layero) {
			var data = form.val('devapp-sync-go-toolbar');

			data.sort = 'license_end';
			data.g_ascdesc = 'desc';
			data.expire = 2;
			data.page = 1;
			data.limit = 0;

			$.ajax({
				url: 'api.php?r=gateway@devlist',
				data: data,
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});

					d.data.rows.forEach(function(e, i) {
						if (d.grpid == 0)
							d.data.rows[i].grpname = '';
						else
							d.data.rows[i].grpname = $('select[lay-filter="filter-group"] option[value="' + e.grpid + '"]').text();
					});
					table.reload('devapp-sync-go', {
						data: d.data.rows,
						done: function(res, curr, count) {}
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		success: function(layero, index) {
			var that = this;
			var tab = layero.find('select[name="grpid"]');

			$('select[lay-filter="filter-group"] option').not('[value=-1]').each(function(i, e) {
				tab.append($(e).clone());
			});

			$('[lay-filter="devapp-sync-go"]').css('font-size', '12px');
			table.init('devapp-sync-go');
			that.fetchdevlist(index, layero);

			layero.find('button[lay-filter="search"]').click(function() {
				that.fetchdevlist(index, layero);
			});
			layero.find('button[lay-filter="syncbgo"]').click(function() {
				that.mysubmit(index, layero);
			});

			form.render(null, 'devapp-sync-go-toolbar');
			form.on('submit', function(data) {
				that.mysubmit(index, layero);
				return false;
			});
		},
		yes: function(index, layero) {
			layer.close(index);
		}
	});
}

function openwin_syncappsmoniter() {
	var layer = layui.layer;
	var table = layui.table;
	var form = layui.form;

	layer.open({
		type: 1,
		title: '当前的协议同步设备',
		area: ['720px', '520px'],
		shadeClose: true,
		resize: false,
		btnAlign: 'c',
		btn: ['关闭'],
		content: $('#tpl-devapp-showsync').html(),
		fetchdevlist: function(index, layero) {
			var that = this;

			if (layero.find('[lay-id="devapp-showsync"]').length <= 0) {
				timer.rmv('devapp-showsync');
				return;
			}

			$.ajax({
				url: 'api.php?r=gateway@appshowsync',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false)
						return;

					table.reload('devapp-showsync', {
						data: d.data,
						done: function(res, curr, count) {}
					});
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		},
		success: function(layero, index) {
			var that = this;

			$('[lay-filter="devapp-showsync"]').css('font-size', '12px');
			table.init('devapp-showsync');

			timer.add('devapp-showsync', 3, {
				fuc: function() {
					that.fetchdevlist.call(that, index, layero);
				}
			}, 1);

		},
		yes: function(index, layero) {
			layer.close(index);
		}
	});
}
