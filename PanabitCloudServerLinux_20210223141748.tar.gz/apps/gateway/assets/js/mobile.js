
function open_https(serialno, off)
{
	var protocol = window.document.location.protocol + '//';

	if (off){
		layer.msg('此设备已断开，无法连接。');
		return;
	}
	open_remote(serialno, 1, 0, function(d) {
		var path = '/login/userverify.cgi?pakey=' + d.md5str + '&username=admin';
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(protocol + d.hostip + ":" + d.webport + path, "_blank");
				}
			});
		} else
			window.open(protocol + d.hostip + ":" + d.webport + path, "_blank");
	});
}

function open_remote(serialno, webenable, sshenable, callback) {
	var index = layer.load(0, {
		shade: 0
	});

	$.ajax({
		url: 'api.php?r=gateway@sshport_open',
		data: {
			serialno: serialno,
			webenable: webenable,
			sshenable: sshenable
		},
		dataType: 'json',
		type: 'post',
		success: function(d) {
			layer.close(index);
			if (ajax_resultCallBack(d) == false) {
				layer.msg(d.msg, {
					icon: 5
				});
				return;
			}

			if (typeof callback == 'function')
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {
				icon: 2
			});
		}
	});
}

function getcol_state(d) {
	var state = '<img src="/cloud/assets/img/online.png" class="icon" title="当前在线">';

	if (d.usedays != '') {
		if (d.usedays <= 7)
			state = '<img src="/cloud/assets/img/expire.png" class="icon" title="License即将到期"/>';

		d.usedays_desc = d.usedays + '天';
	} else
		d.usedays_desc = d.usedays;

	if ((Number(d.lasttime) + 15) < Number(d.servertime))
		state = '<img src="/cloud/assets/img/off.png" class="icon" title="断开连接"/>';

	return state;
}

function release_dsc(dev) {
	var str = ["标准版","专业版","网吧版","","","SMB"];
	var dsc = str[dev.release];

	if(dsc) {
		if(dev.release == 1 && dev.serialno.substr(0, 2).toLocaleUpperCase() == 'PN')
			dsc = '租赁版';
		return ' [<span style="color: red">' + dsc + '</span>]';
	}
	return '';
}

function ping_delay_color(delay)
{
	if(delay > 1000)
		return 'color: red;';
	if(delay >= 300)
		return 'color: #bdbd6d;';
	if(delay >= 1)
		return 'color: darkgreen;';
	return '';
}

function getMore(index) {
	var row = g_tbData[index];
	var state = getcol_state(row);
	var outip;
	var lictime, upgradetime, expire = parseFloat(row.usedays);
	if (row.usedays === '' && row.serialno.indexOf('F') === 0)
		lictime = '这是标准版，支持256用户，完全免费，无任何时间限制';
	else
		lictime = $.myTime.UnixToStrDate(row.license_start, false) + ' 至 ' + $.myTime.UnixToStrDate(row.license_end, false) +
		(expire > 0 ? '' : '&nbsp;（已到期）');
		
	if (row.usedays === '' && row.serialno.indexOf('F') === 0)
		upgradetime = '无任何时间限制';
	else 
	if(row.license_upgrade && g_sertm) {
		upgradetime = $.myTime.UnixToStrDate(row.license_start, false) + ' 至 ' + $.myTime.UnixToStrDate(row.license_upgrade, false);
		((row.license_upgrade - g_sertm) >= 0 ? '' : '&nbsp;（已到期）');
	}
	else
		upgradetime = '';
	
	var os = ["FreeBSD","Linux"];
	os = os[row.os]?'<span style="color: red">'+os[row.os]+'</span>':'';
	
	outip = row.outip + ' [ <span style="'+ping_delay_color(row.linkdown?9999:row.ping_delay)+'" >' + (row.ping_delay>=4000?' > ':'') + row.ping_delay + 'ms 时延</span> ]';
	
	var moreContent = '<div class="moreContent">' +
		'<div onclick="closeMore()" class="closebox"><img class="closeIcon" src="/cloud/assets/img/close.svg"></i></div>' +
		'<div class="infoContainer">' +
		'<p class="infotitle">' + state + row.name + '</p>' +
		'<table class="infotable">' +
		'<tr><td>系统名称</td><td>' + row.sysname + '</td></tr>' +
		'<tr><td>管理口地址</td><td>' + row.ipaddr + '</td></tr>' +
		'<tr><td>公司地址</td><td>' + outip + '</td></tr>' +
		'<tr><td>软件编号</td><td>' + row.serialno + '</td></tr>' +
		'<tr><td>机器码</td><td>' + row.machineno + '</td></tr>' +
		'<tr><td>许可使用时间</td><td class="date' + (expire <= 0 ? ' red' : ' green') + '">' + lictime + '</td></tr>' +
		'<tr><td>许可升级时间</td><td class="date' + ((row.license_upgrade - g_sertm) <= 0 ? ' red' : ' green') + '">' + upgradetime + '</td></tr>' +
		'<tr><td>最大连接数</td><td>' + row.max_flowcont + '</td></tr>' +
		'<tr><td>最大用户数</td><td>' + row.max_ipcnt + '</td></tr>' +
		'<tr><td>系统版本</td><td>' + row.version + release_dsc(row) + '</td></tr>' +
		'<tr><td>操作系统</td><td>' + os + '</td></tr>' +
		'<tr><td>Web登录</td><td><a class="setBtn" href="javascript:void(0)" onclick="open_https(\'' + row.serialno +
		'\', ' + row.linkdown + ')">登录Web页面</a></td></tr>' +
		'</table>' +
		'</div>' +
		'</div>';

	$('body').prepend(moreContent);
	$('body').css('overflow', 'hidden');
}

function closeMore() {
	$('.moreContent').remove();
	$('.container').show();
	$('body').css('overflow', '');
}

function sortattr(name)
{
	if(g_sort == name)
		return 'style="color: mediumseagreen;"';

	return '';
}

function sorttat(name)
{
	if(g_sort != name) return '&nbsp;&nbsp;';
	if(g_ascdesc == 'asc')
		return '⇂';
	if(g_ascdesc == 'desc')
		return '↾';
	return '';
}

var g_page = 1;
var g_maxpage = 1;
var g_tbData = [];
var g_sertm = 0;
var g_total = 0;
var g_sort = 'serialno';
var g_ascdesc = 'asc';

function getData() {
	var content = '';
	var grpid = Number($('select[lay-filter="filter-group"]').val());
	var key = $.trim($('.keyword input[name="keyword"]').val());

	$.ajax({
		url: 'api.php?r=gateway@devlist',
		type: 'post',
		dataType: 'json',
		data: {
			limit: 10,
			page: g_page,
			grpid: grpid,
			keyword: key,
			sort: g_sort,
			g_ascdesc: g_ascdesc,
			expire: 0
		},
		success(d) {
			var row, cnt,
				content = '',
				data = d.data.rows;

			g_total = parseInt(d.data.total);

			function cardhtml(row, index) {
				var state = getcol_state(row);
				return '<div class="card">' +
					'<div class="title">' +
					'<p class="title-left">' + state + '<span onclick="open_https(\'' + row.serialno + '\', ' + row.linkdown + ')">' + 
					(row.name?row.name:'none') + '</span>' +
					'<a class="linkicon" href="javascript:void(0)" onclick="getMore(\'' + index + '\')"><i class="fa fa-desktop" style="' + ping_delay_color(row.linkdown?9999:row.ping_delay) + '"></i></a></p>' +
					'</div>' +
					'<a class="infos">' +
					'<div class="datas">' +
					'<p onclick="orderby(this, \'bpsout\')"' + (sortattr('bpsout')) + '>上行速率'+(sorttat('bpsout'))+'</p>' +
					'<p>' + numberformats(row.bpsout) + '</p>' +
					'</div><div class="datas">' +
					'<p onclick="orderby(this, \'users\')"' + (sortattr('users')) + '>用户数'+(sorttat('users'))+'</p>' +
					'<p>' + row.users + '</p>' +
					'</div><div class="datas">' +
					'<p onclick="orderby(this, \'flowcont\')"' + (sortattr('flowcont')) + '>连接数'+(sorttat('flowcont'))+'</p>' +
					'<p>' + row.flowcont + '</p>' +
					'</div><div class="datas">' +
					'<p onclick="orderby(this, \'bpsin\')"' + (sortattr('bpsin')) + '>下行速率'+(sorttat('bpsin'))+'</p>' +
					'<p>' + numberformats(row.bpsin) + '</p>' +
					'</div><div class="datas">' +
					'<p onclick="orderby(this, \'temp\')"' + (sortattr('temp')) + '>温度'+(sorttat('temp'))+'</p>' +
					'<p>' + row.temp + '℃</p>' +
					'</div><div class="datas">' +
					'<p onclick="orderby(this, \'license_end\')"' + (sortattr('license_end')) + '>有效期'+(sorttat('license_end'))+'</p>' +
					'<p>' + row.usedays_desc + '</p>' +
					'</div>' +
					'</a>' +
					'</div>';
			}

			g_sertm = d.data.now;
			g_tbData = data;
			for (var i = 0; i < data.length; i++) {
				row = data[i];
				content += cardhtml(row, i);
			}
			$('.card-list').html(content);

			$('.pagecontent .currentpage').text(g_page);
			var page = g_total / parseInt(d.data.limit);
			g_maxpage = parseInt(page);
			if(g_maxpage > page ) g_maxpage++;
			$('#maxpage').text(g_maxpage);
			$('#devtotal').text(g_total);
			$('#qlimit').text(d.data.limit);
		}
	});
}
getData();

function orderby(e, orderby)
{
	if(g_sort != orderby) 
		g_sort = orderby;
	else {
		if(g_ascdesc == 'asc')
			g_ascdesc = 'desc';
		else
		if(g_ascdesc == 'desc') {
			g_sort = 'serialno';
			g_ascdesc = 'asc';
		}
		else
			g_ascdesc = 'asc';
	}

	getData();
}

function pagePrev()
{
	g_page--;
	if (g_page < 1) g_page = 1;
	getData();
}

function pageNext()
{
	g_page++;
	if (g_page > g_maxpage) g_page = g_maxpage;
	getData();
}

layui.use(['form', 'element', 'table', 'layer'], function() {
	var layer = layui.layer;

	function getGrp() {
		$.ajax({
			url: 'api.php?r=gateway@group',
			type: 'post',
			dataType: 'json',
			success(d) {
				var i, data = d.data;
				$('select[lay-filter="filter-group"] option').not('[value=0]').remove();
				for (i = 0; i < data.rows.length; i++)
					$('select[lay-filter="filter-group"]')
					.append(new Option(data.rows[i].grpname, data.rows[i].grpid));
			}
		});
	}
	getGrp()

	$('.grpsel select').change(function(data) {
		g_page = 1;
		getData();
	});
	$('.searchTxt').on('keyup', function() {
		g_page = 1;
		getData();
	});
});
