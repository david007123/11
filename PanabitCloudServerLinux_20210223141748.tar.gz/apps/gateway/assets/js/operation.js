function search_app(win) {
	var names = [];
	var selectNames = [];
	var data = $('#treeWrap .layui-tree-txt');
	var key = $('.appIpt').val();

	data.each(function() {
		var e = $(this);
		var txt = e.text();
		if (txt.indexOf(key) != -1) {
			e.parents('[data-id]').each(function() {
				var ico, e = $(this);
				var id = e.attr('data-id');
				var str = '[data-id="' + id + '"]';
				if (id != 1044 && names.indexOf(str) == -1) {
					names.push(str);
					ico = e.find('.layui-tree-entry .layui-tree-icon');
					if (ico.length && ico.children('.layui-icon-addition').length)
						ico.children('.layui-icon-addition').click();
				}
			});
		}
	});

	if (names.length) {
		win.find('[data-id="1044"] .layui-tree-pack [data-id]').hide();
		win.find('[data-id="1044"] .layui-tree-pack ' + names.join(',')).show();
	} else
		win.find('[data-id="1044"] .layui-tree-pack [data-id]').show();

	return names.length;
}

function get_select_node(node) {
	var selected = [];

	function nodeCallback(node) {
		var childs, data = [];

		if (!node.grp) return true;

		childs = node.children;
		for (var i = 0; i < childs.length; i++) {
			if (nodeCallback(childs[i]))
				data.push(childs[i]);
		}

		if (data.length == node.grp)
			return true;

		selected = selected.concat(data);

		return false;
	}

	if (nodeCallback(node))
		selected.push(node);

	return selected;
}

layui.use(['form', 'element', 'table', 'layer', 'tree', 'util', 'transfer'], function() {
	var form = layui.form;
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var tree = layui.tree;
	var util = layui.util;
	var transfer = layui.transfer;
	var tablelns;
	var operateTask_list;

	function getScript(layero) {
		form.on('select(sel-script)', function(data) {
			var name = data.value;
			$.ajax({
				url: '/devops/tool/shellops/param.php?r=get',
				data: {
					name: name
				},
				success(d) {
					layero.find('.script-txt').val(d.data);
				}
			});
		});
	}

	function getSc(layero) {
		var name = layero.find('.sel-script').val();
		$.ajax({
			url: '/devops/tool/shellops/param.php?r=get',
			data: {
				name: name
			},
			success(d) {
				$('.script-txt').val(d.data);
			}
		});
	}

	$('.operate-manage').on('click', function() {
		layer.open({
			type: 1,
			title: '任务中心',
			area: ['600px', '400px'],
			shadeClose: true,
			resize: false,
			content: $('#operate-wrap').html(),
			success: function(d) {
				operateTask_list = table.render({
					elem: '#operateTask_list',
					even: true,
					autoSort: false,
					skin: 'line',
					url: 'api.php?r=devops@task-list',
					method: 'post',
					page: true,
					limits: [10, 20, 30, 40, 50],
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3,
						curr: 1
					},
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					parseData: function(res) {
						var d;
						res.code = res.ret;
						res.msg = res.msg;
						res.count = res.data.total;
						res.data = res.data.rows;
						var data = res.data;
						for (i = 0; i < data.length; i++) {
							d = data[i];
						}
					},
					cols: [
						[ //表头
							{
								title: '序号',
								width: 35,
								type: 'numbers'
							}, {
								field: 'name',
								width: 130,
								title: '任务名称',
							}, {
								title: '设备数',
								width: 60,
								templet: function(d) {
									return '<span class="setBtn" lay-event="count">' + d.devs + '</span>';
								}
							}, {
								title: '创建时间',
								width: 130,
								templet: function(d) {
									return $.myTime.UnixToStrDate(d.ctime, 'yyyy/MM-dd HH:mm:ss');
								}
							}, {
								field: 'res',
								title: '进度',
								templet: function(d) {
									var num = (((d.pass + d.fail) / d.devs) * 100);
									num += '%';
									return num;
								}
							},
							{
								title: '操作',
								templet: function(d) {
									return '<span data-id="' + d.task_id + '" class="setBtn" lay-event="del">删除</span>';
								}
							}
						]
					]
				});

				table.on('tool(operateTask_list)', function(obj) {
					var data = obj.data,
						event = obj.event;
					var msg;
					if (event == 'count') {
						layer.open({
							type: 1,
							title: '任务详情',
							area: ['800px', '600px'],
							shadeClose: true,
							resize: false,
							content: $('#countmore-wrap').html(),
							end: function() {
								timer.rmv('operateTaskmore_listX');
							},
							success: function(d) {
								table.render({
									elem: '#operateTaskmore_list',
									even: true,
									autoSort: false,
									loading: false,
									skin: 'line',
									url: 'api.php?r=devops@process-list&task_id=' + data.task_id,
									method: 'post',
									page: {
										layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
										groups: 3
									},
									request: {
										pageName: 'page',
										limitName: 'limit'
									},
									parseData: function(res) {
										return {
											"data": res.data.rows,
											"code": res.ret,
											"msg": res.msg,
											"count": res.data.total
										}
										msg = res;
										var data = res.data.rows;
										var d;
										for (var i = 0; i < data.length; i++) {
											d = data[i];
										}
									},
									cols: [
										[ //表头
											{
												title: '序号',
												width: 35,
												type: 'numbers'
											}, {
												title: '设备名称',
												field: 'name'
											}, {
												title: '设备编号',
												field: 'keyno'
											}, {
												title: '开始时间',
												width: 130,
												templet: function(d) {
													return $.myTime.UnixToStrDate(d.stime, true);
												}
											}, {
												title: '结束时间',
												width: 130,
												templet: function(d) {
													return $.myTime.UnixToStrDate(d.finishtm, true);
												}
											}, {
												title: '任务状态',
												width: 70,
												align: 'center',
												templet: function(d) {
													var stat = ["等待开始", "检查任务", "检查工具", "检查参数", "计划等待", "执行任务", "任务取消", "执行失败", "执行成功"]
													return stat[d.stat];
												}
											}, {
												title: '信息',
												templet: function(d) {
													if (d.msg) {
														return '<span class="setBtn" lay-event="result">' + d.msg + '</span>';
													} else {
														return '<span class="setBtn" lay-event="result">查看更多</span>';
													}
												}
											}, {
												title: '操作',
												templet: function(d) {
													if (d.stat < 6) {
														return '<span class="setBtn" lay-event="cancel">取消任务</span>';
													} else if (d.stat == 6 || d.stat == 7) {
														return '<span class="setBtn" lay-event="retry">重试</span>';
													}
													return '';
												}
											}
										]
									]
								});


								//取消任务 #operateTaskmore_list
								table.on('tool(operateTaskmore_list)', function(obj) {
									var data = obj.data,
										event = obj.event;
									var task_id;
									if (event == 'cancel') {
										layer.confirm('确定要取消此任务吗？', function(index) {
											$.ajax({
												url: 'api.php?r=devops@process-cancel&task_id=' + data.task_id,
												data: {
													keyno: data.keyno
												},
												type: 'post',
												dataType: 'json',
												success: function(d) {
													if (ajax_resultCallBack(d) === false) {
														layer.msg(d.msg, {
															icon: 5,
															time: 1000
														});
														return;
													}
													layer.msg('任务已取消', {
														icon: 1,
														time: 1000
													});
													table.reloadExt('operateTaskmore_list');
													table.reloadExt('operateTask_list');
												},
												error: function() {
													layer.msg('获取数据失败，请稍后再试。', {
														icon: 2,
														time: 1000
													});
												}
											});
										});
									} else if (event == "result") {
										layer.open({
											type: 1,
											title: '运维结果',
											area: ['720px', '600px'],
											shadeClose: true,
											resize: true,
											content: $('#history-log').html(),
											success: function(layero, index) {
												layero.find(".operate-log").setTextareaCount();
												$.ajax({
													url: '/devops/tool/shellops/param.php?r=logger',
													data: {
														task_id: data.task_id,
														keyno: data.keyno
													},
													success(d) {
														layero.find('.operate-log').val(d.data);
													}
												});
											}
										});
									} else if (event == "retry") {
										layer.confirm('确定要重试吗？', function(index) {
											$.ajax({
												url: 'api.php?r=devops@process-retry&task_id=' + data.task_id,
												data: {
													keyno: data.keyno
												},
												type: 'post',
												dataType: 'json',
												success: function(d) {
													if (ajax_resultCallBack(d) === false) {
														layer.msg(d.msg, {
															icon: 5,
															time: 1000
														});
														return;
													}
													layer.msg('重试成功', {
														icon: 1,
														time: 1000
													});
													table.reloadExt('operateTaskmore_list');
													table.reloadExt('operateTask_list');
												},
												error: function() {
													layer.msg('获取数据失败，请稍后再试。', {
														icon: 2,
														time: 1000
													});
												}
											});
										});
									}
								});

								timer.add('operateTaskmore_listX', 3, {
									fuc: function() {
										table.reloadExt('operateTaskmore_list');
									}
								});
							}
						});
					} else if (event == "del") {
						layer.confirm('确认删除此任务吗?', {
							icon: 0,
							title: '任务删除'
						}, function(index) {
							$.ajax({
								url: 'api.php?r=devops@task-remove&task_id=' + data.task_id,
								type: 'post',
								dataType: 'json',
								success: function() {
									layer.msg('删除成功', {
										icon: 1,
										time: 1000
									});
									table.reloadExt('operateTask_list');
								},
								error: function() {
									layer.msg('删除失败，请稍后再试。', {
										icon: 2,
										time: 1000
									});
								}
							});
							layer.close(index);
						});
					}
				});
			}
		});
	});

	$('.operate-grp').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('operate-type');
		var checkStatus = table.checkStatus('cloud_devlist');
		var devs = [];
		var id;
		checkStatus.data.forEach(function(e, i) {
			devs.push(e.serialno);
		});
		switch (event) {
			case 'node-ignore':
				var names = [];
				if (devs.length <= 0) {
					layer.msg('请先选择要操作的设备。', {
						time: 1000
					});
					return;
				}
				layer.open({
					type: 1,
					title: '选择协议',
					area: ['600px', '600px'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['确认下发'],
					content: $('#proto-tree').html(),
					success: function(layero, index) {
						element.render();
						form.render();
						tree.render();
						var animate = layer.load(1);
						$.ajax({
							url: 'apps/gateway/assets/js/tree.json',
							type: 'get',
							dataType: 'json',
							success: function(d) {
								var html = "";
								for (var i = 0; i < d.length; i++) {
									html += '<li style="padding:3px 2px;" data-name="' + d[i].children.name + '">' + d[i].title +
										'</li>';
								}
								$('.appContent ul').html(html);

								$(document).click(function(e) {
									var _con = $('.appContent');
									if (!_con.is(e.target) && _con.has(e.target).length === 0) {
										_con.css('display', 'none');
									}
								});
							}
						});

						$.ajax({
							url: 'apps/gateway/assets/js/tree.json',
							type: 'get',
							dataType: 'json',
							success: function(d) {
								var searchtree = true;
								var tree_option = {
									elem: '#treeWrap',
									id: "treeWrap",
									data: d,
									showCheckbox: true,
									accordion: true,
									click: function(obj) {
										this.accordion = searchtree;
									}
								};

								element.render();
								form.render();

								tree.render(tree_option);
								$('.appIpt').on('keyup', function() {
									searchtree = false;
									layero.find('[value="512"]').parent().children('.layui-tree-txt').click();
									if (search_app(layero) == 0) {
										searchtree = true;
										layero.find('[value="512"]').parent().children('.layui-tree-txt').click();
									}
								});

								layer.close(animate);
							}
						})

						$('.addRight').click(function(obj) {
							var nodes, names = [],
								data = tree.getChecked('treeWrap');

							if (data.length == 0) {
								$('.selected-app').empty();
								layer.msg('请选择协议。', {
									time: 1000
								});
								return;
							}

							nodes = data[0].children;
							for (i = 0; i < nodes.length; i++)
								names = names.concat(get_select_node(nodes[i]));

							var html = "";
							for (var i = 0; i < names.length; i++) {
								html += '<p data-name="' + names[i].field + '" data-id="' + names[i].id + '">' + names[i].title +
									'</p>';
							}
							$('.selected-app').html(html);

							$('.selected-app p').click(function() {
								var color = $(this).css('background-color');
								if (color == "rgb(255, 255, 255)") {
									$(this).css("background-color", "rgb(206, 206, 206)");
									$(this).addClass('selected');
								} else {
									$(this).css("background-color", "white");
									$(this).removeClass('selected');
								}
							});
						});

						function delapp() {
							var p = $('.selected-app .selected');
							p.remove();
						}

						$('.delRight').click(function() {
							var ids = [];
							$('.selected-app p').each(function() {
								ids.push($(this).attr('data-id'));
							});
							delapp();
							form.render();
							tree.render();
						});
					},
					yes: function(index, layero) {
						var fields = [];
						var ignore = 0;
						$('.selected-app p').each(function() {
							fields.push($(this).attr('data-name'));
						});
						if ($('.selected-app').children().length == 0) {
							layer.msg('请选择协议。', {
								time: 1000
							});
							return;
						}

						ignore = layero.find('input[name="ignore"]').prop('checked') ? 1 : 0;

						$.ajax({
							url: 'api.php?r=devops@task-create',
							data: {
								tool: 'nodeignore',
								devs: devs.join(','),
								apps: fields.join(','),
								ignore: ignore
							},
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5,
										time: 1000
									});
									return;
								}

								layer.open({
									type: 1,
									title: '忽略节点',
									area: ['45%', '55%'],
									shadeClose: true,
									resize: false,
									loading: false,
									content: $('#countmore-wrap').html(),
									end: function() {
										timer.rmv('operateTaskmore_listY');
									},
									success: function(layero, index) {
										table.render({
											elem: '#operateTaskmore_list',
											even: true,
											autoSort: false,
											skin: 'line',
											url: 'api.php?r=devops@process-list&task_id=' + d.data,
											method: 'post',
											page: {
												layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
												groups: 3
											},
											request: {
												pageName: 'page',
												limitName: 'limit'
											},
											parseData: function(res) {
												return {
													"data": res.data.rows,
													"code": res.ret,
													"msg": res.msg,
													"count": res.data.total
												}
												var data = res.data.rows;
												var d;
												for (var i = 0; i < data.length; i++) {
													d = data[i];
												}
											},
											cols: [
												[{
													title: '序号',
													width: 50,
													type: 'numbers'
												}, {
													title: '设备名称',
													field: 'name'
												}, {
													title: '设备编号',
													field: 'keyno'
												}, {
													title: '开始时间',
													templet: function(d) {
														return $.myTime.UnixToStrDate(d.stime, 'MM-dd/HH:mm:ss');
													}
												}, {
													title: '结束时间',
													templet: function(d) {
														return $.myTime.UnixToStrDate(d.finishtm, 'MM-dd/HH:mm:ss');
													}
												}, {
													title: '任务状态',
													align: 'center',
													templet: function(d) {
														var stat = ["等待开始", "下载任务", "下载工具", "下载参数", "计划等待", "执行任务", "任务取消", "执行失败", "执行成功"]
														return stat[d.stat];
													}
												}, {
													field: 'msg',
													title: '信息'
												}, {
													title: '操作',
													templet: function(d) {
														if (d.stat < 6) {
															return '<span class="setBtn" lay-event="cancel">取消任务</span>';
														} else if (d.stat == 6 || d.stat == 7) {
															return '<span class="setBtn" lay-event="retry">重试</span>';
														}
														return '';
													}
												}]
											]
										});

										timer.add('operateTaskmore_listY', 3, {
											fuc: function() {
												table.reloadExt('operateTaskmore_list');
											}
										});

										//取消任务
										table.on('tool(operateTaskmore_list)', function(obj) {
											var data = obj.data,
												event = obj.event;
											var task_id;
											if (event == 'cancel') {
												layer.confirm('确定要取消此任务吗？', function(index) {
													$.ajax({
														url: 'api.php?r=devops@process-cancel&task_id=' + d.data,
														data: {
															keyno: devs.join(',')
														},
														type: 'post',
														dataType: 'json',
														success: function(d) {
															if (ajax_resultCallBack(d) === false) {
																layer.msg(d.msg, {
																	icon: 5,
																	time: 1000
																});
																return;
															}
															layer.msg('任务已取消', {
																icon: 1,
																time: 1000
															});
															table.reloadExt('operateTaskmore_list');
														},
														error: function() {
															layer.msg('获取数据失败，请稍后再试。', {
																icon: 2,
																time: 1000
															});
														}
													});
												});
											} else if (event == "retry") {
												layer.confirm('确定要重试吗？', function(index) {
													$.ajax({
														url: 'api.php?r=devops@process-retry&task_id=' + d.data,
														data: {
															keyno: devs.join(',')
														},
														type: 'post',
														dataType: 'json',
														success: function(d) {
															if (ajax_resultCallBack(d) === false) {
																layer.msg(d.msg, {
																	icon: 5,
																	time: 1000
																});
																return;
															}
															layer.msg('重试成功', {
																icon: 1,
																time: 1000
															});
															table.reloadExt('operateTaskmore_list');
														},
														error: function() {
															layer.msg('获取数据失败，请稍后再试。', {
																icon: 2,
																time: 1000
															});
														}
													});
												});
											}
										});

									}
								});
								if (d.msg) layer.msg(d.msg, {
									icon: 1,
									time: 1000
								});
								layer.close(index);
							},
							error: function() {
								layer.msg('获取数据失败，请稍后再试。', {
									icon: 2,
									time: 1000
								});
							}
						});
					}
				});
				break;
			case 'script-operate':
				function open_script() {
					var flag;
					if ($('select[lay-filter="sel-script"]').val() == "默认的配对运维（无）") {
						flag = true;
					}
					layer.open({
						type: 1,
						title: '输入脚本',
						area: ['720px', '600px'],
						shadeClose: true,
						resize: true,
						content: $('#scriptWrap').html(),
						btnAlign: 'c',
						btn: ['保存'],
						success: function(layero, index) {
							layero.find(".script-txt").setTextareaCount();
							//历史列表下拉框
							$.ajax({
								url: '/devops/tool/shellops/param.php?r=list',
								success(d) {
									var html = '';
									for (var i = 0; i < d.data.length; i++) {
										html += '<option value="' + d.data[i] + '">' + d.data[i] + '</option>';
									}
									layero.find('.sel-script').append(html);
									form.render('select');
									if (flag) {
										index.find('select[lay-filter="sel-script"] option[value="默认的配对运维（无）"]').val("默认的配对运维").text(
											"默认的配对运维");
										form.render('select');
									}
								}
							});
							getScript(layero);

							//删除历史脚本
							layero.find('.del-his').click(function() {
								if (layero.find('.sel-script').val() == "") {
									layer.msg('请选择要删除的脚本。', {
										time: 1500
									});
									return;
								}
								layer.confirm('确认删除此脚本吗?', {
									icon: 0,
									title: '脚本删除'
								}, function(index) {
									$.ajax({
										url: '/devops/tool/shellops/param.php?r=del',
										data: {
											name: layero.find('.sel-script option:selected').text()
										},
										success: function() {
											layer.msg('删除成功', {
												icon: 1,
												time: 1000
											});
											getSc(layero);
											$.ajax({
												url: '/devops/tool/shellops/param.php?r=list',
												success(d) {
													var i, data = d.data;
													var html = '<option value="请选择">请选择</option>';
													for (var i = 0; i < d.data.length; i++) {
														html += '<option value="' + d.data[i] + '">' + d.data[i] + '</option>';
													}
													layero.find('.sel-script').html(html);
													form.render('select');
												}
											});
										},
										error: function() {
											layer.msg('删除失败，请稍后再试。', {
												icon: 2,
												time: 1000
											});
										}
									});
									layer.close(index);
								});
							});

							//添加脚本
							layero.find('.add-script').click(function() {
								var thatlayero = layero;
								var name = layero.find('.sel-script').find("option:selected").text();
								if (!name) {
									return;
								}
								layer.open({
									type: 1,
									title: '添加运维脚本',
									area: ['300px', '200px'],
									shadeClose: true,
									resize: true,
									btnAlign: 'c',
									btn: ['确认'],
									content: $('#scriptName-wrap').html(),
									yes: function(index, layero) {
										$.ajax({
											url: '/devops/tool/shellops/param.php?r=save',
											data: {
												name: layero.find('.script-name').val(),
												text: thatlayero.find('.script-txt').val()
											},
											type: 'post',
											dataType: 'json',
											success: function(d) {
												if (ajax_resultCallBack(d) === false) {
													layer.msg(d.msg, {
														icon: 5
													});
													return;
												}
												if (d.ret == 0) layer.msg('添加成功', {
													icon: 1
												});
												layer.close(index);

												thatlayero.find('.sel-script').empty();
												thatlayero.find('.script-txt').val(d.data).val('');
												$.ajax({
													url: '/devops/tool/shellops/param.php?r=list',
													success(d) {
														var i, data = d.data;
														var html = '<option value="">请选择</option>';
														for (var i = 0; i < d.data.length; i++) {
															html += '<option value="' + d.data[i] + '">' + d.data[i] + '</option>';
														}
														thatlayero.find('.sel-script').html(html);
														form.render('select');
													}
												});
											},
											error: function() {
												layer.msg('连接超时，请稍后再试。', {
													icon: 2
												});
											}
										});
									}
								});
							});

							//执行
							layero.find('.carry-script').click(function() {
								var name = $.trim(layero.find('[lay-filter="sel-script"]').val());
								if (name == '') {
									layer.msg('请选择脚本。', {
										time: 1500
									});
									return;
								}
								name = (name == "默认的配对运维（无）" ? "默认的配对运维" : name)
								$.ajax({
									url: 'api.php?r=devops@task-create',
									data: {
										tool: 'shellops',
										devs: devs.join(','),
										param: layero.find('.script-txt').val(),
										save_history: name
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5,
												time: 1000
											});
											return;
										}
										layer.close(index);
										layer.open({
											type: 1,
											title: '脚本运维 -- ' + name,
											area: ['800px', '600px'],
											shadeClose: true,
											resize: false,
											content: $('#countmore-wrap').html(),
											end: function() {
												timer.rmv('operateTaskmore_listZ');
											},
											success: function(layero, index) {
												table.render({
													elem: '#operateTaskmore_list',
													even: true,
													autoSort: false,
													loading: false,
													skin: 'line',
													url: 'api.php?r=devops@process-list&task_id=' + d.data,
													method: 'post',
													page: {
														layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
														groups: 3
													},
													request: {
														pageName: 'page',
														limitName: 'limit'
													},
													parseData: function(res) {
														return {
															"data": res.data.rows,
															"code": res.ret,
															"msg": res.msg
														}
														var data = res.data.rows;
														var d;
														for (var i = 0; i < data.length; i++) {
															d = data[i];
														}
													},
													cols: [
														[{
															title: '序号',
															width: 35,
															type: 'numbers'
														}, {
															title: '设备名称',
															field: 'name'
														}, {
															title: '设备编号',
															field: 'keyno'
														}, {
															title: '开始时间',
															width: 130,
															templet: function(d) {
																return $.myTime.UnixToStrDate(d.stime, true);
															}
														}, {
															title: '结束时间',
															width: 130,
															templet: function(d) {
																return $.myTime.UnixToStrDate(d.finishtm, true);
															}
														}, {
															title: '任务状态',
															width: 70,
															align: 'center',
															templet: function(d) {
																var stat = ["等待开始", "下载任务", "下载工具", "下载参数", "计划等待", "执行任务", "任务取消", "执行失败",
																	"执行成功"
																]
																return stat[d.stat];
															}
														}, {
															title: '信息',
															templet: function(d) {
																if (d.msg) {
																	return '<span class="setBtn" lay-event="result">' + d.msg + '</span>';
																} else {
																	return '<span class="setBtn" lay-event="result">查看更多</span>';
																}
															}
														}, {
															title: '操作',
															templet: function(d) {
																if (d.stat < 6) {
																	return '<span class="setBtn" lay-event="cancel">取消任务</span>';
																} else if (d.stat == 6 || d.stat == 7) {
																	return '<span class="setBtn" lay-event="retry">重试</span>';
																}
																return '';
															}
														}]
													]
												});
							
												timer.add('operateTaskmore_listZ', 3, {
													fuc: function() {
														table.reloadExt('operateTaskmore_list');
													}
												});
							
												table.on('tool(operateTaskmore_list)', function(obj) {
													var data = obj.data,
														event = obj.event;
													var task_id;
													if (event == 'cancel') {
														layer.confirm('确定要取消此任务吗？', function(index) {
															$.ajax({
																url: 'api.php?r=devops@process-cancel&task_id=' + d.data,
																data: {
																	keyno: devs.join(',')
																},
																type: 'post',
																dataType: 'json',
																success: function(d) {
																	if (ajax_resultCallBack(d) === false) {
																		layer.msg(d.msg, {
																			icon: 5,
																			time: 1000
																		});
																		return;
																	}
																	layer.msg('任务已取消', {
																		icon: 1,
																		time: 1000
																	});
																	table.reloadExt('operateTaskmore_list');
																},
																error: function() {
																	layer.msg('获取数据失败，请稍后再试。', {
																		icon: 2,
																		time: 1000
																	});
																}
															});
														});
													} else if (event == "result") {
														layer.open({
															type: 1,
															title: '运维结果',
															area: ['720px', '600px'],
															shadeClose: true,
															resize: true,
															content: $('#history-log').html(),
															success: function(layero, index) {
																layero.find(".operate-log").setTextareaCount();
																$.ajax({
																	url: '/devops/tool/shellops/param.php?r=logger',
																	data: {
																		task_id: data.task_id,
																		keyno: data.keyno
																	},
																	success(d) {
																		layero.find('.operate-log').val(d.data);
																	}
																});
															}
														});
													} else if (event == "retry") {
														layer.confirm('确定要重试吗？', function(index) {
															$.ajax({
																url: 'api.php?r=devops@process-retry&task_id=' + d.data,
																data: {
																	keyno: devs.join(',')
																},
																type: 'post',
																dataType: 'json',
																success: function(d) {
																	if (ajax_resultCallBack(d) === false) {
																		layer.msg(d.msg, {
																			icon: 5,
																			time: 1000
																		});
																		return;
																	}
																	layer.msg('重试成功', {
																		icon: 1,
																		time: 1000
																	});
																	table.reloadExt('operateTaskmore_list');
																},
																error: function() {
																	layer.msg('获取数据失败，请稍后再试。', {
																		icon: 2,
																		time: 1000
																	});
																}
															});
														});
													}
												});
											}
										});
									},
								});
							});
						},
						yes: function(index, layero) {
							var flag;
							if (layero.find('select[lay-filter="sel-script"]').val() == "默认的配对运维（无）") {
								flag = true;
							}
							$.ajax({
								url: '/devops/tool/shellops/param.php?r=save',
								data: {
									name: layero.find('.sel-script').val(),
									text: $('.script-txt').val()
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}
									if (d.ret == 0) layer.msg('保存成功', {
										icon: 1
									});
									if (flag) {
										layero.find('select[lay-filter="sel-script"] option[value="默认的配对运维（无）"]').val("默认的配对运维").text(
											"默认的配对运维");
										form.render('select');
									}
								},
								error: function() {
									layer.msg('连接超时，请稍后再试。', {
										icon: 2
									});
								}
							});
						}
					});
				}
				if (devs.length <= 0) {
					open_script();
					$('.carry-script').hide();
				} else {
					open_script();
				}
				break;
		}
	});
});
