<?php
/*
 * 该文件来自 task.php?r=collection&name=gateway&act=report
 *				> apps/devops/task-api/collection.php 的请求回调
 * 用于响应客户端的任务请求，更新客户端执行任务的状态。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $token 客户端唯一编码，服务令牌 token
 * $name 服务名称 
 * $act 服务功能 
 * $_REQUEST 附加数据，可从这里取
 *
 */

if(!(isset($_FILES['file']) && $_FILES["file"]["tmp_name"] !== ''))
	exit;

$file = '/tmp/collection_report_' . basename($_FILES["file"]["tmp_name"]);
if(move_uploaded_file($_FILES["file"]["tmp_name"], $file) === false) {
	echo "ERR: move upfile.";
	exit;
}

if(!defined('OPSSVC_DIR')) {
	unlink($file);
	exit;
}

// /usr/logdata/devops/opssvc/collection/gateway
define ('COLLECTION_DIR', OPSSVC_DIR . '/collection/gateway');
if(!is_dir(COLLECTION_DIR)) {
	exec("mkdir -p " . COLLECTION_DIR . " 2>&1", $data, $ret);
	$data = null;
}

exec("tar tf " . $file, $data, $ret);

if($ret != 0 || count($data) <= 0) {
	echo "ERR: pack err.";
	unlink($file);
	exit;
}

$serialno = '';
foreach($data as $key => $row) {
	if(preg_match("/^([a-zA-Z0-9-_]{12}).inf$/", $row, $match)) {
		$serialno = $match[1];
		$device = $row;
		break;
	}
}

if($serialno == '') {
	echo "ERR: serialno is empty.";
	unlink($file);
	exit;
}

if($keyno != $serialno) {
	echo "ERR: serialno.";
	unlink($file);
	exit;
}

$dir = COLLECTION_DIR . "/{$serialno}";
if(!is_dir($dir)) {
	if(mkdir($dir) == false) {
		echo "ERR: create user dir fail.";
		unlink($file);
		exit;
	}
}

exec("rm -rf {$dir}/ping {$dir}/wan {$dir}/wangroup {$dir}/ncard", $data, $ret);
/*
exec("rm -rf {$dir}/ping", $data, $ret);
exec("rm -rf {$dir}/wan", $data, $ret);
exec("rm -rf {$dir}/wangroup", $data, $ret);
exec("rm -rf {$dir}/ncard", $data, $ret);
*/
$cmd = "tar zxf " . $file . " -C {$dir}";
exec($cmd, $data, $ret);

rename("{$dir}/{$device}",  "{$dir}/key.inf");

file_put_contents("{$dir}/ok.log", time());

if(file_exists(($jsofile = "{$dir}/data.json")))
	unlink($jsofile);
if(file_exists(($jsofile = "{$dir}/cpe.json")))
	unlink($jsofile);

unlink($file);

$fpath = OPSWEB_DIR . "/processes/collection/{$keyno}";
if(file_exists($fpath))
	unlink($fpath);
