<?php
/*
 * 该文件来自 task.php?r=collection&name=gateway&act=fetch
 *				> apps/devops/task-api/collection.php 的请求回调
 * 用于响应客户端的任务请求，更新客户端执行任务的状态。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $name 服务名称 
 * $act 服务功能 
 * $token 客户端唯一编码，服务令牌 token
 * $_REQUEST 附加数据，可从这里取
 *
 */
defined('OPSSVC_DIR') or exit;
// if(empty($token)) exit;

// 检查任务是否已经上限
if(($maxdown = maxdown_check('collection')) <= 0)
	exit;

$fpath = OPSWEB_DIR . "/processes/collection/{$keyno}";
file_put_contents($fpath, time());

echo "OK {$maxdown}";
