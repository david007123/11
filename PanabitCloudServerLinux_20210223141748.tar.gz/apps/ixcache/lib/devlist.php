<?php
namespace cloud\apps\ixcache;


function devlist($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
		'fail'		=> 0,
		'exp'		=> 0,
		'page'		=> 0,
		'limit'		=> 0
	);

	$now = strtotime("now");
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
		$optional['keyword'] = strtolower($optional['keyword']);
		$optional['keyword'] = shell_filter($optional['keyword']);
	}
	else
		$optional['keyword'] = '';
	
	if(format_and_push($data, 'sort', $optional, '', 'string', false) == false)
		$optional['sort'] = 'serialno';

	if(format_and_push($data, 'expire', $optional, '', 'int', false) == false)
		$optional['expire'] = 0;
	
	if(format_and_push($data, 'page', $result, '', 'int', false) == false)
		$result['page'] = 1;
	
	if(format_and_push($data, 'limit', $result, '', 'int', false) == false)
		$result['limit'] = 20;
	else
		if($result['limit'] <= 0) $result['limit'] = 20;

	if(format_and_push($data, 'g_ascdesc', $optional, '', 'string', false)) {
		if ($optional['g_ascdesc'] != 'desc')
			$optional['g_ascdesc'] = 0;
		else
			$optional['g_ascdesc'] = 1;
	}
	else
		$optional['g_ascdesc'] = 0;
	
	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(3, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->ixc_grpids == '')
				return $result;
			if($optional['grpid'] <= 0)
				$optional['grpid'] = $user->ixc_grpids;
			else {
				$grpids = explode(',', $user->ixc_grpids);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
		else 
		if($optional['grpid'] == 0)
			$optional['grpid'] = '10000,0';
		else 
		if($optional['grpid'] < 0)
			$optional['grpid'] = '';
	}
	
	switch($optional['sort']) {
		case "serialno":
		$sort_name = 1;break;
		case "lasttime":
		$sort_name = 2;break;
		case "license_start":
		$sort_name = 3;break;
		case "license_end":
		$sort_name = 4;break;
		case "bdw":
		$sort_name = 5;break;
		case "flowcont":
		$sort_name = 6;break;
		case "bpsout":
		$sort_name = 7;break;
		case "bpsin":
		$sort_name = 8;break;
		case "sysrun":
		$sort_name = 9;break;
		case "version":
		$sort_name=10;break;
		case "cpurate":
		$sort_name=11;break;
		case "name":
		$sort_name=12;break;
		default:
		$sort_name=1;break;
	}

	$cmd = DATAEYE . " ixcache list page={$result['page']}";
	$cmd.= " limit={$result['limit']}";
	$cmd.= " usergrp={$optional['grpid']} sch='{$optional['keyword']}'";
	$cmd.= " sortname={$sort_name} sortdesc={$optional['g_ascdesc']}";
	$cmd.= " expire={$optional['expire']}";

	exec($cmd, $out, $ret);

	foreach($out as $val) {
		$row = explode(' ', $val);
		if ($row[0] == "ipaddr") 
			continue;
		if (count($row) < 3) {
			if(($pos = strpos($row[0], 'total=')) === 0)
				$result['total'] = intval(substr($row[0], 6));
			else
			if(($pos = strpos($row[0], 'fail=')) === 0)
				$result['fail'] = intval(substr($row[0], 5));
			else
			if(($pos = strpos($row[0], 'exp=')) === 0)
				$result['exp'] = intval(substr($row[0], 4));
			continue;
		}

		$grpid = (int)$row[1];

        $map_address = to_utf8($row[20]);

		// $row[7]: iXCache 上配置的名称，$row[23]：云平台上配置的名称
		$sysname = $row[7];
		if(empty($row[23]))
			$name = $sysname;
		else
			$name = $row[23];

		$name		= to_utf8($name);
		$sysname	= to_utf8($sysname);
		$serialno	= to_utf8($row[0]);
		
//		$machineno = $row[14];
//		if (json_encode($machineno) == false)
//			$machineno = iconv("gbk", "utf-8", $machineno);

		array_push($result['rows'], array(
			"name"			=> $name,
			"sysname"		=> $sysname,
			"license_start"	=> (int)$row[10],
			"license_end"	=> (int)$row[11],
			"board"			=> $row[4],
			"bdw"			=> (int)$row[9],
			"flowcont"		=> (int)$row[14],
			"usedays"		=> ($row[11] == 0 ? '' : intval(($row[11] - $now) / 86400)),
			"serialno"		=> $serialno,
			"bpsout"		=> (int)$row[13],	
			"bpsin"			=> (int)$row[12],
			"lasttime"		=> (int)$row[19],
			"servertime"	=> $now,
			"grpid"			=> $grpid,
//			"machineno"		=> $row[14], 
			"sysrun"		=> ($now - (int)$row[6]),
			"outip"			=> long2ip($row[17]),
			"longitude"		=> $row[21],
			"latitude"		=> $row[22],
			"map_address"	=> $map_address,
			"version"		=> $row[8],
			"diskio"		=> $row[15],
			"pused"			=> $row[16],
			"cpudesc"		=> $row[3],
			"cpurate"		=> $row[2]
		));
	}

	return $result;
}

function amaplist($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'page'		=> 0,
		'limit'		=> 0
	);

	$now = time();
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = 0;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
		$optional['keyword'] = strtolower($optional['keyword']);
	}
	else
		$optional['keyword'] = '';
	
	if(format_and_push($data, 'sort', $optional, '', 'string', false) == false)
		$optional['sort'] = 'serialno';

	if(format_and_push($data, 'expire', $optional, '', 'int', false) == false)
		$optional['expire'] = 0;
/*
	if(format_and_push($data, 'page', $result, '', 'int', false) == false)
		$result['page'] = 1;

	if(format_and_push($data, 'limit', $result, '', 'int', false))
		$result['limit'] = 20;
	else
		if($result['limit'] <= 0) $result['limit'] = 20;
*/
	if(format_and_push($data, 'g_ascdesc', $optional, '', 'string', false)) {
		if ($optional['g_ascdesc'] != 'desc')
			$optional['g_ascdesc'] = 0;
		else
			$optional['g_ascdesc'] = 1;
	}
	else
		$optional['g_ascdesc'] = 0;

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(3, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->ixc_grpids == '')
				return $result;
			if($optional['grpid'] == 0)
				$optional['grpid'] = $user->ixc_grpids;
			else {
				$grpids = explode(',', $user->ixc_grpids);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
	}

	switch($optional['sort']) {
		case "serialno":
		$sort_name = 1;break;
		case "lasttime":
		$sort_name = 2;break;
		case "license_start":
		$sort_name = 3;break;
		case "license_end":
		$sort_name = 4;break;
		case "bdw":
		$sort_name = 5;break;
		case "flowcont":
		$sort_name = 6;break;
		case "bpsout":
		$sort_name = 7;break;
		case "bpsin":
		$sort_name = 8;break;
		case "sysrun":
		$sort_name = 9;break;
		case "version":
		$sort_name=10;break;
		case "cpurate":
		$sort_name=11;break;
		case "name":
		$sort_name=12;break;
		default:
		$sort_name=1;break;
	}

	$optional['expire'] = 2;

	$cmd = DATAEYE . " ixcache list page={$result['page']}";
	$cmd.= " limit={$result['limit']}";
	$cmd.= " usergrp={$optional['grpid']} sch='{$optional['keyword']}'";
	$cmd.= " sortname={$sort_name} sortdesc={$optional['g_ascdesc']}";
	$cmd.= " expire={$optional['expire']}";

	exec($cmd, $out, $ret);

	foreach($out as $val) {
		$row = explode(' ', $val);
		if ($row[0] == "ipaddr") 
			continue;
		if (count($row) < 3) 
			continue;
		if($row[21] == "" || $row[22] == "")
			continue;

		$grpid = (int)$row[13];

        $map_address = to_utf8($row[20]);

		// $row[7]: iXCache 上配置的名称，$row[23]：云平台上配置的名称
		$name = to_utf8($row[7]);

		array_push($result['rows'], array(
			"name"			=> $name,
			"serialno"		=> $row[0],
			"license_start"	=> (int)$row[10],
			"license_end"	=> (int)$row[11],
			"usedays"		=> ($row[11] == 0 ? '' : intval(($row[11] - $now) / 86400)),
			"flowcont"		=> (int)$row[14],
			"users"			=> 0,
			"bpsout"		=> (int)$row[13],	
			"bpsin"			=> (int)$row[12],
			"lasttime"		=> (int)$row[19],
			"longitude"		=> $row[21],
			"latitude"		=> $row[22],
			"map_address"	=> $map_address,
			"version"		=> $row[8]
		));
	}

	return $result;
}