<?php
namespace cloud\apps\ixcache;


function sshport_open($data)
{
	global $nidb, $user;
	
	$optional = array();


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	// set custom options
	if(format_and_push($data, 'serialno', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '操作设备不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}
	

	/* get dev info */
	$serialno = strtolower($optional['serialno']);
	$cmd = DATAEYE . " ixcache list sch='{$serialno}'";
	$cmd.= " format=1";	// 增加 freeend 可升级时间
	exec($cmd, $out, $ret);
	$sysname = '';
	if($ret == 0) {
		foreach($out as $val) {
			$row = explode(' ', $val);
			if ($row[0] == "ipaddr") 
				continue;
			if (count($row) < 3) {
				continue;
			}
			// $row[7]: iXCache 上配置的名称，$row[23]：云平台上配置的名称
			if(empty($row[23]))
				$name = $row[7];
			else
				$name = $row[23];

			$sysname		= '|' . to_utf8($name);
			break;
		}
	}
	
	/* Update log */
	cloud_insertlog($user->username, "查看缓存设备：{$optional['serialno']}{$sysname}");

	$cmd = DATAEYE . " ixcache set license_id12={$optional['serialno']} mapping=1";
	exec($cmd);

	$result = array(
		'webport'	=> 0,
		'sshport'	=> 0,
		'verify'	=> ''
	);
	$cmd = DATAEYE . " ixcache list page=1 limit=1 grpid=-1 sch=".strtolower($optional['serialno'])." usergrp=";
	exec($cmd, $out, $ret);

	if($ret)
		set_errmsg(MSG_LEVEL_EXP, __function__, '映射失败！' . $out);

	foreach($out as $val) {
		$ds = explode(' ', $val);
		if (strstr($ds[0], "total") != false)
			continue;
		if (strstr($ds[0], "fail") != false)
			continue;
		if (strstr($ds[0], "exp") != false)
			continue;

		$result['verify'] = $ds[24];
		$result['webport'] = $ds[25];
		$result['sshport'] = $ds[26];
	}

	$localip = $_SERVER['HTTP_HOST'];
	if (strchr($localip, ':') != false) {
		$ds = explode(':', $localip);
		$localip = $ds[0];
	}

	$result['hostip'] = gethostbyname($localip);
	return $result;
}
