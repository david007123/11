// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function open_remote(serialno, webenable, sshenable, callback)
{
	var index = layer.load(0, {shade: 0});

	$.ajax({
		url:'api.php?r=gateway@sshport_open',
		data: {
			serialno: serialno, 
			webenable: webenable, 
			sshenable: sshenable
		},
		dataType: 'json',
		type:'post',
		success:function(d){
			layer.close(index);
			if(ajax_resultCallBack(d) == false)  {
				layer.msg(d.msg, {icon: 5});
				return;
			}
			
			if(typeof callback == 'function') 
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {icon: 2});
		}
	});
}

function open_https(serialno, off)
{
	var protocol = window.document.location.protocol + '//';

	if (off){
		layer.msg('此设备已断开，无法连接。');
		return;
	}
	open_remote(serialno, 1, 0, function(d) {
		var path = '/login/userverify.cgi?pakey=' + d.md5str + '&username=admin';
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(protocol + d.hostip + ":" + d.webport + path, "_blank");
				}
			});
		} else
			window.open(protocol + d.hostip + ":" + d.webport + path, "_blank");
	});
}

function getcol_state(d)
{
	var state = '<img src="/cloud/assets/img/online.png" class="icon" title="心跳正常">';

	if ((d.lasttime + 30) < Number(d.servertime)) {
		state = '<img src="/cloud/assets/img/off.png" class="icon" title="心跳断开"/>';
	}

	return state;
}

function setcol_devlist(d)
{
	var state = getcol_state(d);
	var html = '';
	if(typeof this.mytemplet == 'function') {
		html = this.mytemplet.call(this, d, state);
	}
	else
	if(this.field == undefined)
		return html;
	else
		html = d[this.field];

	if(state == '即将到期')
		return '<div class="expire_txt">' + html + '</div>';
	else
	if(d.enabled == 0 || state == '<img src="/cloud/assets/img/off.png" class="icon" title="心跳断开"/>')
		return '<div class="off_txt">' + html + '</div>';
	else
		return html;
}

layui.use(['form', 'table', 'element'], function() {
	var form = layui.form;
	var table = layui.table;
	var element = layui.element;
	var timer = new taskTimer();
	var tablelns;

	function maingroup_refresh (){
		timer.add('read_group', 3, {fuc: function(){
			var that = this;
			$.ajax({
				url: 'api.php?r=gateway@group',
				type: 'post',
				success(d) {
					if(ajax_resultCallBack(d) == false) return;
					var i, data = d.data;
					
					$('select[lay-filter="filter-group"] option').not('[value=0]').remove();
					for(i = 0; i < data.rows.length; i++) 
						$('select[lay-filter="filter-group"]')
						.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

					form.render('select');
					timer.rmv('read_group');
				}
			});
		}}, 1);
	}
	maingroup_refresh();
	
	tablelns = table.render({
		elem: '#devlist',
		even: true,
		autoSort: false,
		loading: false,
		url: 'api.php?r=gamecloud@devlist',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'enabled',
			type: 'desc'
		},
		where: {
			sort: 'enabled',
			g_ascdesc: 'desc',
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			if(res.ret == 0) {
				res.count = res.data.total;
				res.data = res.data.rows;
			}

			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#devlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 30,
					fixed: 'left',
					type: 'numbers',
					templet: setcol_devlist
				},
				{
					type: 'checkbox',
					width: 30
				}, {
					field: 'serialno',
					title: '编号',
					width: 110,
					sort: true,
					templet: setcol_devlist
				}, {
					field: 'name',
					title: '名称',
					width: 210,
					sort: true,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return '<span class="setBtn" lay-event="info">' + d.name + '</span>'
					}
				}, {
					field: 'enabled',
					title: '状态',
					width: 35,
					templet: setcol_devlist,
					mytemplet: function(d, state) {
						return state;
					}
				}, {
					field: 'grpname',
					title: '属组',
					width: 90,
					templet: setcol_devlist,
					mytemplet: function(d){
						var grpname;
						if(d.grpid == 0) return '';
						grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'lasttime',
					title: '最后在线',
					sort: true,
					width: 92,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return $.myTime.UnixToStrDate(d.lasttime, 'MM-dd/HH:mm:ss');
					}
				}, {
					title: '许可时间',
					width: 165,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return $.myTime.UnixToStrDate(d.license_start, 'yyyy-MM-dd') + ' - ' +
								$.myTime.UnixToStrDate(d.license_end, 'yyyy-MM-dd');
					}
				}, {
					title: '快线服务',
					width: 90,
					templet: setcol_devlist,
					mytemplet: function(d) {
						var state = '';
						if (d.enabled == 0)
							return '<span class="off_txt">服务停止</span>';
						else
						if(d.l2tp_state == 'DATA')
							return '<span style="color: #5FB878;">服务中</span>';
						else {
							switch(d.l2tp_state) {
							case "INIT":
								state = "初始化";
								break;
							case "WAITIDLE":
								state = d.waitetime_left + "后重拔";
								break;
							case "START":
								state = "开始连接";
								break;
							case "SCCRQ":
								state = "创建隧道";
								break;
							case "SCCN":
								state = "隧道创建成功";
								break;
							case "ICCN":
								state = "会话创建成功";
								break;
							case "PPP":
								state = "PPP协商";
								break;
							}
							state = '<span class="off_txt">' + state + '</span>';
						}
						return state;
					}
				}, {
					field: 'ipcnt',
					title: '人数(当前/最大/规格)',
					sort: true,
					width: 145,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.ipcnt + '/' + d.maxipcnt + '/' + d.license_ipcnt;
					}
				}, {
					field: 'delay',
					title: '延迟ms(当前/最小/最大)',
					sort: true,
					width: 170,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.delay_cur + '/' + d.delay_min+'/' + d.delay_max;
					}
				}, {
					title: '上行/下行(bps)',
					width: 100,
					templet: setcol_devlist,
					mytemplet: function(d) {
						return d.bpsout + '/' + d.bpsin;
					}
				}
			]
		]
	});

	table.on('sort(devlist)', function(obj){
		search(0, obj);
	});
	
	table.on('tool(devlist)', function(obj){
		var data = obj.data,
			event = obj.event;

		if(event == 'info') {
			open_https(data.serialno, 0);
		}
	});

	// 搜索
	function search(page, obj) 
	{
		var grpid = Number($('select[lay-filter="filter-group"]').val());
		
		var where = {
			grpid: 0,
			keyword: $.trim($('#tb_toolbar input[name="keyword"]').val()),
			sort: 'enabled',
			g_ascdesc: 'desc',
			expire: 0
		};
		if(grpid) where.grpid = grpid;

		var option = {
				method: 'post',
				where: where
		};
		if(typeof page == "number") {
			if(page > 0)
				option.page = {curr: page}; //重新从第 1 页开始
		}
		else
			page = 0;

		if(obj) {
			option.initSort = obj;
			if(obj.field) where.sort = obj.field;
			if(obj.type) where.g_ascdesc = obj.type;
		}
		else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op; 
			}
		}

		table.reloadExt('devlist', option);
		if(page >= 0)
			auto_refresh();
	}

	form.on('select(filter-group)', function(data) {
		search(1);
	});

	form.on('select(filter-x)', function(data) {
		search(1);
	});

	$('#tb_toolbar button').on('click', function(obj){
		var event = obj.currentTarget.getAttribute('lay-filter');
		var checkStatus = table.checkStatus(tablelns.config.id);
		var devs = [];
		checkStatus.data.forEach(function(e, i){
			devs.push(e.serialno);
		});
		switch(event){
			case 'search':
				search(1);
				break;
			case 'del':
				if(devs.length <= 0) {
					layer.msg('请先选择要删除的设备。');
					return;
				}
				
				layer.confirm('确认要删除这些设备吗?', {icon: 0, title: '设备删除'}, function(index){
					$.ajax({
						url:'/Maintain/system_handle_ex.php',
						data: {type: 'gamecloud_delete', idstr: devs.join('|')},
						type:'post',
						dataType:'json',
						success:function(d) {
							/*
							if(ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {icon: 5});
								return;
							}
							*/
							if(d.str) layer.msg(d.msg, {icon: (d.yn == "no")? 5: 1});
							search();
						},
						error: function(){
							layer.msg('获取数据失败，请稍后再试。', {icon: 2});
						}
					});
					layer.close(index);
				});
				break;
		};
	});

	// 自动刷新
	var auto_refresh_hd = 0;
	function auto_refresh() 
	{
		var interval = $('select[lay-filter="auto-refresh"]').val();
		if(auto_refresh_hd) {
			clearInterval(auto_refresh_hd);
			auto_refresh_hd = 0;
		}
		var tm = Number(interval);
		if(tm)
			auto_refresh_hd = setInterval(function(){
				if(isHiddenMyView()) return;
				var checkStatus = table.checkStatus(tablelns.config.id);
				if(!checkStatus.data.length)
					search(-1);
			}, tm * 1000);
	}
	form.on('select(auto-refresh)', function(data) {
		auto_refresh();
	});
	auto_refresh();
});
