<?php
/*
 * 该文件来自 task.php?r=opssvc&name=zeropen&act=report
 *				> apps/devops/task-api/opssvc.php 的请求回调
 * 用于响应客户端的任务请求，更新客户端执行任务的状态。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $token 客户端唯一编码，服务令牌 token
 * $name 服务名称 
 * $act 服务功能 
 * $_REQUEST 附加数据，可从这里取
 *
 */

function get_report_filedata()
{
	if(!isset($_FILES['file']))
		return '';

	$upfile = $_FILES['file'];
	if(file_exists($upfile['tmp_name']) == false)
		return "找不到上传的报告文件！";

	if($upfile['error'] > 0){
		unlink($upfile['tmp_name']);
		return "PA配置文件上传失败！error：" . $upfile['error'];
	}

	$text = file_get_contents($upfile['tmp_name']);
	unlink($upfile['tmp_name']);
	if($text === false) 
		return "读取上传的报告文件失败！";
	return $text;
}

if(empty($token)) exit;
if(isset($_REQUEST['obj']) == false || empty($obj = trim($_REQUEST['obj']))) 
	exit;
if(isset($_REQUEST['code']) == false)
	exit;
if(isset($_REQUEST['msg']) == false)
	exit;
if(isset($_REQUEST['id']) == false)
	exit;
$id = intval($_REQUEST['id']);
if($id <= 0)
	exit;

$objtable = array(
	'CPE'		=> 'iWAN客户端',
	'POP'		=> 'iWAN服务端'
);

if(!isset($objtable[$obj]))
	exit;

$objname = $objtable[$obj];

defined('OPSSVC_DIR') or exit;
defined('OPSZEROPEN_DIR') or define('OPSZEROPEN_DIR', OPSSVC_DIR . "/zeropen");
defined('OPSZEROPEN_TOKEN_DIR') or define('OPSZEROPEN_TOKEN_DIR', OPSTOKEN_DIR . "/zeropen");

$tokendir = OPSZEROPEN_TOKEN_DIR . "/{$token}";
if(!file_exists($tokendir))
	exit;

if($obj == 'CPE') {
	$cfgdir = "{$tokendir}/sdwan/cpe/{$id}";
}
else
if($obj == 'POP') {
	$cfgdir = "{$tokendir}/sdwan/pop/{$id}";
}
else
	exit;

if(!is_dir($cfgdir))
	exit;

$code = intval($_REQUEST['code']);
$msg = iconv("gbk", "utf-8//translit", trim($_REQUEST['msg']));


if(!is_dir("{$tokendir}/logger"))
	exec("mkdir -p {$tokendir}/logger 2>&1", $output, $ret);

$now = time();
$reportime = date("Y-m-d", $now);
$freport = "{$tokendir}/logger/{$reportime}";
$reportmsg = '[' . date("H:i:s", $now) . "] {$objname} code: {$code} msg: {$msg}\n";
if(($fp = fopen($freport, 'a'))) {
	fwrite($fp, $reportmsg);
	fclose($fp);
}

$freport = "{$cfgdir}/report.dat";

// 获取上传的报告文件内容
$reportdata = get_report_filedata();

if($reportdata) {
	// 写到报告文件
	if(($fp = fopen($freport, 'a'))) {
		fwrite($fp, "{$reportmsg}\n");
		fwrite($fp, "详细如下：\n");
		fwrite($fp, $reportdata);
		fclose($fp);
	}
}

// 数据库加载
require_once(ROOT_DIR . '/ni-core/class/ni_db.php');
require_once(ROOT_DIR . '/conf/db.php');

$sql = "update cloud_platform.zeropen_device";
$sql.= " set `lasttm` = {$now}, `msg` = ?";
$sql.= " where `token` = ?";

try {
	$sth = $nidb->prepare($sql);
	$sth->bindParam(1, $msg, PDO::PARAM_STR);
	$sth->bindParam(2, $token, PDO::PARAM_STR);
	$sth->execute();
	echo "OK";
}
catch (NiDBException $e) {
	exit;
}
