<?php
/*
 * 该文件来自 task.php?r=opssvc&name=zeropen&act=fetch
 *				> apps/devops/task-api/opssvc.php 的请求回调
 * 用于响应客户端的任务请求，更新客户端执行任务的状态。
 *
 * 已解析的参数有：
 * $keyno 12位授权编号 
 * $name 服务名称 
 * $act 服务功能 
 * $token 客户端唯一编码，服务令牌 token
 * $_REQUEST 附加数据，可从这里取
 *
 */

function lsdir($path)
{
	$ret = array();


	if (($dh = opendir($path))){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				$fconfig = $path . '/' . $file . '/config.dat';
				if (file_exists($fconfig))
					array_push($ret, $file);
			}
		}
		closedir($dh);
	}

	return $ret;
}

if(empty($token)) exit;

defined('OPSZEROPEN_DIR') or define('OPSZEROPEN_DIR', OPSSVC_DIR . "/zeropen");
defined('OPSZEROPEN_TOKEN_DIR') or define('OPSZEROPEN_TOKEN_DIR', OPSTOKEN_DIR . "/zeropen");

$tokendir = OPSZEROPEN_TOKEN_DIR . "/{$token}";
if(!file_exists($tokendir))
	exit;

// 设置 URL 路径 $url_path
$http = "http";
if(isset($_SERVER['REQUEST_SCHEME'])
&& intval($_SERVER['REQUEST_SCHEME']))
	$http = $_SERVER['REQUEST_SCHEME'];
else
if(isset($_SERVER['HTTP_UPGRADE_INSECURE_REQUESTS'])
	&& intval($_SERVER['HTTP_UPGRADE_INSECURE_REQUESTS'])) {
		$http = "https";
}
else
if(isset($_SERVER['SERVER_PORT'])
	&& intval($_SERVER['SERVER_PORT']) == 443) {
		$http = "https";
}
$url_path = $http . "://" . $_SERVER['HTTP_HOST'];

// 检查是否有内容需要更新
$content = '';

// 检查系统名称是否需要同步
$cpedir = "{$tokendir}/sdwan/cpe";

$cpes = lsdir($cpedir);

foreach($cpes as $cpe_id) {
	$fconf = "{$cpedir}/{$cpe_id}/config.dat";
	$config = trim(file_get_contents($fconf), " \n");
	if($config) 
		$content.= "CPE {$config}\n";
	unlink($fconf);
}

echo $content;
