<?php
namespace cloud\apps\zeropen\sdwan\cpe;

require_once('link.php');
ni_app_load('zeropen', 'config');

function select($data)
{
	global $nidb, $user;


	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = "`disabled` < " . TB_ROW_DEL_VALUE . " and ";
	
	if(format_and_push($data, 'cpe_id', $optional, '', 'int', false) === false)
		$optional['cpe_id'] = 0;
	
	if($optional['cpe_id'])
		$where_str .= "`cpe_id` = {$optional['cpe_id']} and ";

	if(format_and_push($data, 'zpd_id', $optional, '', 'int', false))
		$where_str .= "`zpd_id` = {$optional['zpd_id']} and ";
	
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false)
		$wkpid = \cloud\apps\work\project\project_enable();
	else
		$wkpid = $optional['wkpid'];

	if($wkpid) 
		$where_str .= "`wkpid` = {$wkpid} and ";
	if(!is_supadmin($user->username)) {
		if($wkpid == 0) {
			$wkpids = \cloud\apps\work\project\get_work_for_user($user->username);
			if(!$wkpids) return $result;
			$where_str .= "`wkpid` in ({$wkpids}) and ";
		}
	}

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`name` like ? or `device` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"cpe_id",
		"wkpid",
		"name",
		"device",
		"svrcnt",
		"mtime",
		"zpd_id",
		"ctime"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.sdwan_client";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
	}

	$sql = "select * from cloud_platform.sdwan_client";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}


	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}


function add($data)
{
	global $nidb, $user;


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}

	if(isset($data['device']) == false || empty(($data['device'] = trim($data['device'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_,]{12,})$/", $data['device'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '名称不能为空。');
		return false;
	}

	$frmData = array(
		'wkpid'		=> $wkpid,
		'name'		=> $data['name'],
		'device'	=> $data['device'],
		'ctime'		=> time()
	);

	if(insert_data('cloud_platform`.`sdwan_client', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}
	$id = $nidb->lastInsertId();

	return $id;
}

function add_link_for_pop($data)
{
	global $nidb, $user;


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}

	if(isset($data['pop_id']) == false || ($pop_id = intval($data['pop_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定有效的POP点服务端。');
		return false;
	}

	if(isset($data['device']) == false || empty(($data['device'] = trim($data['device'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $data['device'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['acct']))
		$acct = trim($data['acct']);
	else
		$acct = '';

	if(isset($data['pass']))
		$pass = trim($data['pass']);
	else
		$pass = '';

	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '名称不能为空。');
		return false;
	}

	if(isset($data['dstip']))
		$dstip = trim($data['dstip']);
	else
		$dstip = 'any';

	// 是否提供 cookie
	if(isset($data['cookie']) && !empty($cookie = trim($data['cookie']))) {
		if(preg_match("/^([a-zA-Z0-9-]{83})$/", $cookie, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "83位系统编码格式不正确！");
			return false;
		}
	}
	else
		$cookie = '';
	
	$day = 0;
	if(isset($data['expire']) == false || empty(($data['expire'] = trim($data['expire'])))) {
		$data['expire'] = date('Y-m-d') . ' 23:59:59';
		$day = 30 * 86400; // 为空，默认有效使用期 30 天
	}

	// 到期时间格式如：2020-07-19 or 2020-07-19 16:38:31
	if(preg_match("/^([0-9]{4}-[0-9]{2}-[0-9]{2}|[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2})$/", $data['expire'], $match) == false){
		set_errmsg(MSG_LEVEL_ARG, __function__, '到期时间格式不正确。');
		return false;
	}

	$expire = new \DateTime($data['expire']);
	$expire = $expire->getTimestamp() + $day;

	// 查询 设备 是否存在
	try {
		$sql = "select `license_id12`, `license_id83` from `palog`.`cloud_device`";
		$sql.= " where `license_id12` = '{$data['device']}'";
		$sth = $nidb->prepare($sql);
		$sth->execute();

		$dev = $sth->fetch(\PDO::FETCH_ASSOC);
		// $cnt = $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if($dev) {
		$cookie = $dev['license_id83'];
	}
	else {
		set_errmsg(MSG_LEVEL_EXP, __function__, '找不到这台的设备编号。');
		return false;
	}
		

	// 查询 pop_id 是否存在
	try {
		$sql = "select `port`, `acctcount`, `svcip` from `cloud_platform`.`sdwan_server`";
		$sql.= " where `pop_id` = {$pop_id}";
		$sth = $nidb->prepare($sql);
		$sth->execute();

		$pop = $sth->fetch(\PDO::FETCH_ASSOC);
		// $cnt = $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if(!$pop) {
		set_errmsg(MSG_LEVEL_EXP, __function__, 'POP点服务端不存在');
		return false;
	}

	// 零配置中查询 关联的 zpd_id
	try {
		$sql = "select `zpd_id` from `cloud_platform`.`zeropen_device`";
		$sql.= " where `device` = ? and `cookie` = ?";
		$sth = $nidb->prepare($sql);

		$sth->bindParam(1, $data['device'], \PDO::PARAM_STR);
		$sth->bindParam(2, $cookie, \PDO::PARAM_STR);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);

		if(!$row) {
			$sql = "select `zpd_id` from `cloud_platform`.`zeropen_device`";
			$sql.= " where `device` = '' and `cookie` = ?";
			$sth = $nidb->prepare($sql);
			$sth->bindParam(1, $cookie, \PDO::PARAM_STR);

			$sth->execute();
			$row = $sth->fetch(\PDO::FETCH_ASSOC);
		}

		// $cnt = $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	// 没有，则创建
	if($row) {
		$zpd_id = $row['zpd_id'];
	}
	else {
		if(!($zpd_id = \cloud\apps\zeropen\config\add(array(
			'name'		=> $data['name'],
			'device'	=> $data['device'],
			'cookie'	=> $cookie
		)))) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '创建CPE配置失败。');
			return false;
		}
	}

	$frmData = array(
		'wkpid'		=> $wkpid,
		'zpd_id'	=> $zpd_id,
		'dstip'		=> $dstip,
		'name'		=> $data['name'],
		'device'	=> $data['device'],
		'ctime'		=> time()
	);

	if(insert_data('cloud_platform`.`sdwan_client', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}
	$cpe_id = $nidb->lastInsertId();


	if(empty($acct)) {
		// 密码表
		$map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$l = strlen($map) - 1;
		$nc = 10; // 密码长度 10 个字符串

		// 生成帐号与密码
		$addcount = 1;
		$acct	= 'u' . substr('0000000000' . base_convert($pop['acctcount'] + $addcount, 9, 16), -10);
		$pass = '';
		while($nc-- > 0) $pass .= $map{mt_rand(0, $l)};
	}
	
	// 创建 link 关系
	$frmData = array(
		'pop_id'	=> $pop_id,
		'cpe_id'	=> $cpe_id,
		'acct'		=> $acct,
		'pass'		=> $pass,
		'expire'	=> $expire,
		'ctime'		=> time()
	);

	if(insert_data('cloud_platform`.`sdwan_link', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}
	$link_id = $nidb->lastInsertId();

	// 更新服务端的计数
	try {
		$sql = "update `cloud_platform`.`sdwan_server`";
		$sql.= " set `clicnt` = `clicnt` + 1";
		$sql.= " , `acctcount` = `acctcount` + 1";
		$sql.= " where `pop_id` = {$pop_id}";
		$sth = $nidb->prepare($sql);
		$sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
	}

	$cpedir = OPSZEROPEN_DIR . "/device/{$zpd_id}/sdwan/cpe/{$cpe_id}";
	if(!is_dir($cpedir))
		exec("mkdir -p {$cpedir} 2>&1", $output, $ret);

	$name = iconv('utf-8', 'gbk', $data['name']);

	$content = "name={$name} ";
	$content.= "cpe_id={$cpe_id} ";
	$content.= "acct={$acct} ";
	$content.= "pass={$pass} ";
	$content.= "svcip={$pop['svcip']} ";
	$content.= "port={$pop['port']} ";
	$content.= "mtu=1460 ";
	$content.= "dstip={$dstip} ";

	$fconfig = "{$cpedir}/config.dat";
	file_put_contents($fconfig, $content);
	
	$text = "【{$data['name']}】iWAN客户于 " . date('Y-m-d H:i:s') . " 创建，正在等待客户端执行...\n\n";
	$freport = "{$cpedir}/report.dat";
	file_put_contents($freport, $text);

	return $cpe_id;
}

function save($data)
{
	global $nidb, $user;


	if(isset($data['cpe_id']) == false || ($cpe_id = intval($data['cpe_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '未指定操作对象。');
		return false;
	}

	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '名称不能为空。');
		return false;
	}


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}
	
	// 检查复制对象
	try {
		$sql = "select * from `cloud_platform`.`sdwan_client`";
		$sql.= " where `cpe_id` = {$cpe_id}";
		if($wkpids)
			$sql.= " and `wkpid` in ({$wkpids})";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		// $cnt = $sth->rowCount();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的客户端不存在。');
		return false;
	}


	$frmData = array(
		'wkpid'		=> $wkpid,
		'name'		=> $data['name'],
//		'device'	=> $row['device'],
		'mtime'		=> time()
	);

	if(update_data('cloud_platform`.`sdwan_client', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}

	return true;
}

function del($data)
{
	global $nidb, $user;

	
	if(isset($data['cpe_id']) == false || ($ids = trim($data['cpe_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要删除的客户端。');
		return false;
	}

	if(preg_match("/^([0-9,]{1,})$/", $ids, $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "客户的ID编号格式不正确！");
		return false;
	}
	
	$wkpids = \cloud\apps\work\project\project_enable();
	if(!$wkpids && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}
	
	// 获取其关联的 zpd_id, pop_id 集合
	try {
		$sql = "select `zpd_id`, `cpe_id`";
		$sql.= " from `cloud_platform`.`sdwan_client` ";
		$sql.= " where `pop_id` in ({$ids})";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();

		$dels = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	// 获取其关联的 link_id 集合
	try {
		$sql = "select group_concat(`link_id`) as `ids`";
		$sql.= " from `cloud_platform`.`sdwan_link` ";
		$sql.= " where `cpe_id` in ({$ids})";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();

		$group = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	$ret = true;
	if($group && !empty($group->ids)) {
		$ret = \cloud\apps\zeropen\sdwan\links($group->ids);
	}

	if($ret) {
		try {
			$sql = "delete from `cloud_platform`.`sdwan_client` where `pop_id` in ({$ids})";
			$sth = $nidb->prepare($sql);
			$ret = $sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
		
		foreach($dels as $row) {
			$cpedir = OPSZEROPEN_DIR . "/device/{$row->zpd_id}/sdwan/cpe/{$row->cpe_id}";
			if(is_dir($cpedir))
				exec("rm -rf {$cpedir} 2>&1", $output, $ret);
		}
	}

	return true;
}
