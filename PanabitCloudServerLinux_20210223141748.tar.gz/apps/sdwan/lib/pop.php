<?php
namespace cloud\apps\zeropen\sdwan\pop;

defined('OPSZEROPEN_DIR') or define('OPSZEROPEN_DIR', OPSSVC_DIR . "/zeropen");
defined('OPSZEROPEN_TOKEN_DIR') or define('OPSZEROPEN_TOKEN_DIR', OPSTOKEN_DIR . "/zeropen");

require_once('link.php');
ni_app_load('zeropen', 'config');

function select($data)
{
	global $nidb, $user;


	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = "`disabled` < " . TB_ROW_DEL_VALUE . " and ";

	if(format_and_push($data, 'pop_id', $optional, '', 'int', false) === false)
		$optional['pop_id'] = 0;
	
	if($optional['pop_id'])
		$where_str .= "`pop_id` = {$optional['pop_id']} and ";
	
	if(format_and_push($data, 'zpd_id', $optional, '', 'int', false))
		$where_str .= "`zpd_id` = {$optional['zpd_id']} and ";

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false)
		$wkpid = \cloud\apps\work\project\project_enable();
	else
		$wkpid = $optional['wkpid'];

	if($wkpid) 
		$where_str .= "`wkpid` = {$wkpid} and ";
	if(!is_supadmin($user->username)) {
		if($wkpid == 0) {
			$wkpids = \cloud\apps\work\project\get_work_for_user($user->username);
			if($wkpids) // return $result;
				$where_str .= "`wkpid` in (0,{$wkpids}) and ";
		}
	}

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`name` like ? or `device` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"pop_id",
		"wkpid",
		"name",
		"device",
		"clicnt",
		"mtime",
		"zpd_id",
		"ctime"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.sdwan_server";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
	}

	$sql = "select * from cloud_platform.sdwan_server";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}


	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function select_cpe($data)
{
	global $nidb, $user;


	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = "";
	
	if(format_and_push($data, 'pop_id', $optional, '', 'int', false) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "请指定服务！");
		return false;
	}

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false)
		$wkpid = \cloud\apps\work\project\project_enable();
	else
		$wkpid = $optional['wkpid'];

	if(!is_supadmin($user->username)) {
		if(!$wkpid) {
			$wkpids = \cloud\apps\work\project\get_work_for_user($user->username);
			if($wkpids) // return $result;
				$where_str .= "`wkpid` in (0,{$wkpids}) and ";
		}
	}
	if($wkpid) 
		$where_str .= "`wkpid` = {$wkpid} and ";

	// 检查服务对象是否存在
	try {
		$sql = "select * from `cloud_platform`.`sdwan_server`";
		$sql.= " where $where_str `pop_id` = {$optional['pop_id']}";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		// $cnt = $sth->rowCount();
		$pop = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$pop) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的服务不存在。');
		return false;
	}
	

	$where_str = "`pop_id` = {$optional['pop_id']} and ";

	
	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`acct` like ? or `port` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"link_id",
		"pop_id",
		"acct",
		"port",
		"disabled",
		"expire",
		"mtime",
		"ctime"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.sdwan_link";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
	}

	$key = "a.`link_id`, if(b.`name`,'',b.`name`) as `name`, ";
	$key.= " if(b.`device`,'',b.`device`) as `device`,";
	$key.= " b.`zpd_id`, a.`pop_id`, a.`cpe_id`, a.`pass`, a.`disabled`,";
	$key.= " a.`acct`, a.`expire`, a.`mtime`, a.`ctime`";
	$sql = "select {$key} from cloud_platform.sdwan_link as `a`";
	$sql.= " left join cloud_platform.sdwan_client as `b`";
	$sql.= " on a.`cpe_id` = b.`cpe_id`";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}


	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function add($data)
{
	global $nidb, $user;


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}

	if(isset($data['device']) == false || empty(($data['device'] = trim($data['device'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $data['device'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
		return false;
	}

	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '名称不能为空。');
		return false;
	}

	// 是否提供 cookie
	if(isset($data['cookie']) && !empty($cookie = trim($data['cookie']))) {
		if(preg_match("/^([a-zA-Z0-9-]{83})$/", $cookie, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "83位系统编码格式不正确！");
			return false;
		}
	}
	else
		$cookie = '';
	
	// 是否服务地址 svcip
	if(isset($data['svcip']) && !empty($svcip = trim($data['svcip']))) {
		if(preg_match("/^([a-z0-9.,]{6,})$/", $svcip, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "服务地址格式不正确！");
			return false;
		}
	}
	else
		$svcip = '';

	if(isset($data['port']) == false || ($port = intval($data['port'])) <= 0 || $port > 65535) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '端口不正确。应为 1~65535 间的值。');
		return false;
	}

	// 查询 设备 是否存在
	try {
		$sql = "select `license_id12`, `license_id83` from `palog`.`cloud_device`";
		$sql.= " where `license_id12` = '{$data['device']}'";
		$sth = $nidb->prepare($sql);
		$sth->execute();

		$dev = $sth->fetch(\PDO::FETCH_ASSOC);
		// $cnt = $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if($dev) {
		$cookie = $dev['license_id83'];
	}
	
	// 零配置中查询 关联的 zpd_id
	try {
		$sql = "select `zpd_id` from `cloud_platform`.`zeropen_device`";
		$sql.= " where `device` = ?";
		if(empty($cookie) == false)
			$sql.= " and `cookie` = ?";

		$sth = $nidb->prepare($sql);

		$index = 1;
		$sth->bindParam($index++, $data['device'], \PDO::PARAM_STR);
		if(empty($cookie) == false)
			$sth->bindParam($index++, $cookie, \PDO::PARAM_STR);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		// $cnt = $sth->rowCount();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	// 没有，则创建
	if($row) {
		$zpd_id = $row['zpd_id'];
	}
	else {
		/*
		if(!($zpd_id = \cloud\apps\zeropen\config\add(array(
			'name'		=> $data['name'],
			'device'	=> $data['device'],
			'cookie'	=> $cookie
		)))) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '创建POP配置失败。');
			return false;
		}
		*/
		$zpd_id = 0;
	}

	if(isset($data['startip']) == false || empty(($data['startip'] = trim($data['startip'])))) {
		$endip = ip2long('10.10.0.1');
	}
	else
	if(!($startip = ip2long($data['startip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始IP地址不正确。');
		return false;
	}
	
	if(isset($data['endip']) == false || empty(($data['endip'] = trim($data['endip'])))) {
		$endip = ip2long('10.10.0.255');
	}
	else
	if(!($endip = ip2long($data['endip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '截止IP地址不正确。');
		return false;
	}
	
	if($endip <= $startip) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始截止的IP地址范围不正确。');
		return false;
	}
	if($endip - $startip > 1000) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始截止的IP地址范围不能超过1000个IP地址。');
		return false;
	}

	if(isset($data['gatewayip']) == false || empty(($data['gatewayip'] = trim($data['gatewayip'])))) {
		$gatewayip = ip2long('10.10.0.254');
	}
	else
	if(!($gatewayip = ip2long($data['gatewayip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '网关IP地址不正确。');
		return false;
	}
	$mip = ($gatewayip && 0xFF);
	if($mip === 0 || $mip === 255) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '网关IP地址不正确。结尾地址不能是0或255。');
		return false;
	}

	$iwanip_tb = array();
	for($ip = $startip; $ip <= $endip; $ip++) {
		if($endip == $gatewayip) continue;
		$mip = ($ip && 0xFF);
		if($mip == 0 || $mip == 255) continue;
		array_push($iwanip_tb, long2ip($ip));
	}

	$frmData = array(
		'wkpid'		=> $wkpid,
		'zpd_id'	=> $zpd_id,
		'port'		=> $port,
		'svcip'		=> $svcip,
		'name'		=> $data['name'],
		'device'	=> $data['device'],
		'ctime'		=> time()
	);

	if(insert_data('cloud_platform`.`sdwan_server', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}
	$id = $nidb->lastInsertId();

	$popdir = OPSZEROPEN_DIR . "/device/{$zpd_id}/sdwan/pop/{$id}";
	$fiwanip_tb = "${popdir}/iwanip_tb.json";
	if(!is_dir($popdir))
		exec("mkdir -p {$popdir} 2>&1", $output, $ret);

	if(!($iwanip_tbstr = json_encode($iwanip_tb))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, 'iwanip_tb 编码失败！未保存IP地址范围分配表。');
		return false;
	}
	file_put_contents($fiwanip_tb, $iwanip_tbstr);

	return $id;
}

function cpobj($data)
{
	global $nidb, $user;


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) { 
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}

	if(isset($data['zpd_id']) == false || ($zpd_id = intval($data['zpd_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要绑定的设备。');
		return false;
	}

	if(isset($data['pop_id']) == false || ($pop_id = intval($data['pop_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '复制对象不正确。');
		return false;
	}

	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '名称不能为空。');
		return false;
	}
	
	if(isset($data['startip']) == false || empty(($data['startip'] = trim($data['startip'])))) {
		$endip = ip2long('10.10.0.1');
	}
	else
	if(!($startip = ip2long($data['startip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始IP地址不正确。');
		return false;
	}
	
	if(isset($data['endip']) == false || empty(($data['endip'] = trim($data['endip'])))) {
		$endip = ip2long('10.10.0.255');
	}
	else
	if(!($endip = ip2long($data['endip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '截止IP地址不正确。');
		return false;
	}
	
	if($endip <= $startip) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始截止的IP地址范围不正确。');
		return false;
	}
	if($endip - $startip > 1000) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始截止的IP地址范围不能超过1000个IP地址。');
		return false;
	}
	
	if(isset($data['gatewayip']) == false || empty(($data['gatewayip'] = trim($data['gatewayip'])))) {
		$gatewayip = ip2long('10.10.0.254');
	}
	else
	if(!($gatewayip = ip2long($data['gatewayip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '网关IP地址不正确。');
		return false;
	}
	$mip = ($gatewayip && 0xFF);
	if($mip === 0 || $mip === 255) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '网关IP地址不正确。结尾地址不能是0或255。' . $mip);
		return false;
	}

	$iwanip_tb = array();
	for($ip = $startip; $ip <= $endip; $ip++) {
		if($endip == $gatewayip) continue;
		$mip = ($ip && 0xFF);
		if($mip == 0 || $mip == 255) continue;
		array_push($iwanip_tb, long2ip($ip));
	}

	// 检查复制对象
	try {
		$sql = "select * from `cloud_platform`.`sdwan_server`";
		$sql.= " where `pop_id` = {$pop_id}";
		if($wkpids)
			$sql.= " and `wkpid` in ({$wkpids})";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		// $cnt = $sth->rowCount();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的任务不存在。');
		return false;
	}

	$frmData = array(
		'wkpid'		=> $wkpid,
		'name'		=> $data['name'],
		'device'	=> $row['device'],
		'startip'	=> $startip,
		'endip'		=> $endip,
		'gatewayip'	=> $gatewayip,
		'ctime'		=> time()
	);

	if(insert_data('cloud_platform`.`sdwan_server', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}
	$id = $nidb->lastInsertId();
	
	// 生成IP范围表
	$popdir = OPSZEROPEN_DIR . "/device/{$row['zpd_id']}/sdwan/pop/{$id}";
	$fiwanip_tb = "${popdir}/iwanip_tb.json";
	if(!is_dir($popdir))
		exec("mkdir -p {$popdir} 2>&1", $output, $ret);

	if(!($iwanip_tbstr = json_encode($iwanip_tb))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, 'iwanip_tb 编码失败！未保存IP地址范围分配表。');
		return false;
	}
	file_put_contents($fiwanip_tb, $iwanip_tbstr);

	return $id;
}

function save($data)
{
	global $nidb, $user;


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) { 
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}
	

	if(isset($data['zpd_id']) == false || ($zpd_id = intval($data['zpd_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要绑定的设备。');
		return false;
	}
	
	if(isset($data['pop_id']) == false || ($pop_id = intval($data['pop_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '未指定操作对象。');
		return false;
	}

	if(isset($data['name']) == false || empty(($data['name'] = trim($data['name'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '名称不能为空。');
		return false;
	}
	
	if(isset($data['startip']) == false || empty(($data['startip'] = trim($data['startip'])))) {
		$endip = ip2long('10.10.0.1');
	}
	else
	if(!($startip = ip2long($data['startip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '起始IP地址不正确。');
		return false;
	}
	
	if(isset($data['endip']) == false || empty(($data['endip'] = trim($data['endip'])))) {
		$endip = ip2long('10.10.0.255');
	}
	else
	if(!($endip = ip2long($data['endip']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '截止IP地址不正确。');
		return false;
	}

	// 检查对象
	try {
		$sql = "select * from `cloud_platform`.`sdwan_server`";
		$sql.= " where `pop_id` = {$pop_id}";
		if($wkpids)
			$sql.= " and `wkpid` in ({$wkpids})";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		// $cnt = $sth->rowCount();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if(!$row) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的服务端不存在。');
		return false;
	}

	$frmData = array(
		'wkpid'		=> $wkpid,
		'name'		=> $data['name'],
		'device'	=> $data['device'],
		'startip'	=> $row['startip'],
		'endip'		=> $row['endip'],
		'gatewayip'	=> $row['gatewayip'],
		'mtime'		=> time()
	);
	
	$changeip = ($data['startip'] != $row['startip'] || $data['endip'] != $row['endip']);
	if($changeip) {
		// 检查新的IP地址范围是否正确
		if($endip <= $startip) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '起始截止的IP地址范围不正确。');
			return false;
		}
		if($endip - $startip > 1000) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '起始截止的IP地址范围不能超过1000个IP地址。');
			return false;
		}
		
		if(isset($data['gatewayip']) == false || empty(($data['gatewayip'] = trim($data['gatewayip'])))) {
			$gatewayip = ip2long('10.10.0.254');
		}
		else
		if(!($gatewayip = ip2long($data['gatewayip']))) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '网关IP地址不正确。');
			return false;
		}
		$mip = ($gatewayip && 0xFF);
		if($mip === 0 || $mip === 255) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '网关IP地址不正确。结尾地址不能是0或255。');
			return false;
		}

		$iwanip_tb = array();
		for($ip = $startip; $ip <= $endip; $ip++) {
			if($endip == $gatewayip) continue;
			$mip = ($ip && 0xFF);
			if($mip == 0 || $mip == 255) continue;
			array_push($iwanip_tb, long2ip($ip));
		}
		
		$frmData['startip'] = $startip;
		$frmData['endip'] = $endip;
		$frmData['gatewayip'] = $gatewayip;
	}


	if(update_data('cloud_platform`.`sdwan_server', $frmData) === false) {
		$errmsg = implode(' ', $nidb->errorInfo());
		set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
		return false;
	}

	if($changeip) {
		// 生成IP范围表
		$popdir = OPSZEROPEN_DIR . "/device/{$zpd_id}/sdwan/pop/{$pop_id}";
		$fiwanip_tb = "${popdir}/iwanip_tb.json";
		if(!is_dir($popdir))
			exec("mkdir -p {$popdir} 2>&1", $output, $ret);

		if(!($iwanip_tbstr = json_encode($iwanip_tb))) {
			set_errmsg(MSG_LEVEL_ARG, __function__, 'iwanip_tb 编码失败！未保存IP地址范围分配表。');
			return false;
		}
		file_put_contents($fiwanip_tb, $iwanip_tbstr);
	}

	return true;
}

function del($data)
{
	global $nidb, $user;


	$wkpids = \cloud\apps\work\project\project_enable();
	if(!$wkpids && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) { 
		$wkpid = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}
/*
	if(isset($data['zpd_id']) == false || ($zpd_id = intval($data['zpd_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要绑定的设备。');
		return false;
	}
*/
	if(isset($data['pop_id']) == false || ($ids = trim($data['pop_id'])) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要删除的服务端。');
		return false;
	}

	if(preg_match("/^([0-9,]{1,})$/", $ids, $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "服务的ID编号格式不正确！");
		return false;
	}

	// 获取其关联的 zpd_id, pop_id 集合
	try {
		$sql = "select `zpd_id`, `pop_id`";
		$sql.= " from `cloud_platform`.`sdwan_server` ";
		$sql.= " where `pop_id` in ({$ids})";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();

		$dels = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	// 获取其关联的 link_id 集合
	try {
		$sql = "select group_concat(`link_id`) as `ids`";
		$sql.= " from `cloud_platform`.`sdwan_link` ";
		$sql.= " where `pop_id` in ({$ids})";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();

		$group = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	$ret = true;
	if($group && !empty($group->ids)) {
		$ret = \cloud\apps\zeropen\sdwan\links\del($group->ids);
	}

	if($ret) {
		try {
			$sql = "delete from `cloud_platform`.`sdwan_server` where `pop_id` in ({$ids})";
			$sth = $nidb->prepare($sql);
			$ret = $sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}

		foreach($dels as $row) {
			$popdir = OPSZEROPEN_DIR . "/device/{$row->zpd_id}/sdwan/pop/{$row->pop_id}";
			if(is_dir($popdir))
				exec("rm -rf {$popdir} 2>&1", $output, $ret);
		}
	}

	return $ret;
}
