<?php
namespace cloud\apps\zeropen\sdwan\links;

defined('OPSZEROPEN_DIR') or define('OPSZEROPEN_DIR', OPSSVC_DIR . "/zeropen");
defined('OPSZEROPEN_TOKEN_DIR') or define('OPSZEROPEN_TOKEN_DIR', OPSTOKEN_DIR . "/zeropen");

function select($data)
{
	global $nidb, $user;


	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = "";
	
	if(format_and_push($data, 'pop_id', $optional, '', 'int', false) && $optional['pop_id'] > 0)
		$where_str.= "`pop_id` = {$optional['pop_id']} and ";
	
	if(format_and_push($data, 'cpe_id', $optional, '', 'int', false) && $optional['cpe_id'] > 0)
		$where_str.= "`cpe_id` = {$optional['cpe_id']} and ";

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false)
		$wkpid = \cloud\apps\work\project\project_enable();
	else
		$wkpid = $optional['wkpid'];

	if(!is_supadmin($user->username)) {
		if(!$wkpid) {
			$wkpids = \cloud\apps\work\project\get_work_for_user($user->username);
			if(!$wkpids) return $result;
			$where_str .= "`wkpid` in ({$wkpids}) and ";
		}
	}
	if($wkpid) 
		$where_str .= "`wkpid` = {$wkpid} and ";

	// 检查服务对象是否存在
	try {
		$sql = "select * from `cloud_platform`.`sdwan_server`";
		$sql.= " where $where_str `pop_id` = {$optional['pop_id']}";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		// $cnt = $sth->rowCount();
		$pop = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$pop) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的服务不存在。');
		return false;
	}
	

	$where_str = "`pop_id` = {$optional['pop_id']} and ";

	
	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`acct` like ? or `port` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"link_id",
		"pop_id",
		"acct",
		"port",
		"disabled",
		"expire",
		"mtime",
		"ctime"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.sdwan_link";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
	}

	$key = "a.`link_id`, if(b.`name`,'',b.`name`) as `name`, ";
	$key.= " if(b.`device`,'',b.`device`) as `device`,";
	$key.= " a.`pop_id`, a.`cpe_id`, a.`port`, a.`disabled`,";
	$key.= " a.`acct`, a.`expire`, a.`mtime`, a.`ctime`";
	$sql = "select {$key} from cloud_platform.sdwan_link as `a`";
	$sql.= " left join cloud_platform.sdwan_client as `b`";
	$sql.= " on a.`cpe_id` = b.`cpe_id`";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}


	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function add_pop()
{
//	cloud_platform.sdwan_bindline_server
	
}

function add_cpe()
{
//	cloud_platform.sdwan_bindline_server
	
}

function add($data)
{
	global $nidb, $user;


	$wkpid = \cloud\apps\work\project\project_enable();
	if(!$wkpid && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}
	
	if(isset($data['pop_id']) == false || empty(($data['pop_id'] = trim($data['pop_id'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '服务器未指定。');
		return false;
	}

	if(isset($data['devices']) == false || empty(($data['devices'] = trim($data['devices'])))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '设备编号不能为空。');
		return false;
	}
	$devices = explode(',', $data['devices']);
	foreach($devices as $device) {
		if(preg_match("/^([a-zA-Z0-9-_]{12,})$/", $device, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号格式不正确！");
			return false;
		}
	}
/*
	if(isset($data['port']) == false || ($data['port'] = intval($data['port'])) <= 0 || $data['port'] > 65535) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '端口不正确。应为 1~65535 间的值。');
		return false;
	}
*/
	$day = 0;
	if(isset($data['expire']) == false || empty(($data['expire'] = trim($data['expire'])))) {
		$data['expire'] = date('Y-m-d') . ' 23:59:59';
		$day = 30 * 86400; // 为空，默认有效使用期 30 天
	}

	// 到期时间格式如：2020-07-19 or 2020-07-19 16:38:31
	if(preg_match("/^([0-9]{4}-[0-9]{2}-[0-9]{2}|[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2})$/", $data['expire'], $match) == false){
		set_errmsg(MSG_LEVEL_ARG, __function__, '到期时间格式不正确。');
		return false;
	}

	$expire = new \DateTime($data['expire']);
	$expire = $expire->getTimestamp() + $day;

	try {
		$sql = "select `device`, `acctcount`, `startip`, `endip`, `gateway`, `port` from `cloud_platform`.`sdwan_server`";
		$sql.= " where `pop_id` = {$data['pop_id']}";

		$sth = $nidb->prepare($sql);

		$sth->execute();
		$pop = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if(!$pop) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '指定的服务不存在。');
		return false;
	}


	if(empty($pop['startip']) || empty($pop['endip'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请先为POP点配置分配给CPE的IP地址范围。');
		return false;
	}
	if(empty($pop['gateway'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请先为POP点配置一个网关IP。');
		return false;
	}

	$keynodir = OPSZEROPEN_DIR . "/serialno/{$pop['device']}";
	if(!is_dir($linkdir))
		exec("mkdir -p {$linkdir} 2>&1", $output, $ret);
	$fiwanip_tb = "{$keynodir}/iwanip_tb.json";
	if(!file_exists($fiwanip_tb)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '找不到POP点的IP地址范围表，请为POP再重新配置一次。');
		return false;
	}
	if(!($iwanip_tb = readjson($fiwanip_tb))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '读取POP点的IP地址范围表失败，请为POP再重新配置后再试。');
		return false;
	}
	if(count($iwanip_tb) == 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, 'POP点当前的IP地址已分配完，无法再添加新的连接用户。');
		return false;
	}
	if(count($devices) < count($iwanip_tb)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, 'POP点当前的IP地址已分配不足，当前还剩“' . count($iwanip_tb) . '”，需要分配“' . count($devices) . '”。');
		return false;
	}

	$linkdir = OPSZEROPEN_DIR . "/links";
	if(!is_dir($linkdir))
		exec("mkdir -p {$linkdir} 2>&1", $output, $ret);

	$popdir = OPSZEROPEN_DIR . "/serialno/{$pop['device']}/pop";
	if(!is_dir($popdir))
		exec("mkdir -p {$popdir} 2>&1", $output, $ret);

	$now = time();
	$link = array(
		'pop_id'	=> $data['pop_id'],
		'expire'	=> $expire,
		'port'		=> $data['port'],
		'ctime'		=> $now
	);

	// 密码表
	$map = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
	$l = strlen($map) - 1;
	$nc = 10; // 密码长度 10 个字符串

	$addcount = 0;
	$newcnt = 0;
	$ret = array();
	foreach($devices as $device) {

		$cpeip = array_pop($iwanip_tb);

		// 检查对象
		try {
			$sql = "select * from `cloud_platform`.`sdwan_client`";
			$sql.= " where `device` = '{$device}'";
			$sth = $nidb->prepare($sql);
			$sth->execute();
			// $cnt = $sth->rowCount();
			$row = $sth->fetch(\PDO::FETCH_ASSOC);
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}

		$newpop = 0;
		// POP 是否为新加
		if($row) {
			$link['cpe_id'] = $row['cpe_id'];
			try {
				// 是否为新连接的POP，是则需要给客户端的svrcnt计数 + 1
				$sql = "select `pop_id` from `cloud_platform`.`sdwan_link`";
				$sql.= " where `cpe_id` = {$row['cpe_id']} and `pop_id` = {$data['pop_id']} limit 1";
				$sth = $nidb->prepare($sql);
				$sth->execute();
				if(!$sth->rowCount()) {
					$newpop = 1;
				}
			}
			catch (\NiDBException $e) {
				set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			}
		} else {
			// 对象不存在自动创建
			$cpe = array(
				'wkpid'		=> $wkpid,
				'name'		=> 'CPE',
				'svrcnt'	=> 1,
				'device'	=> $device,
				'ctime'		=> $now
			);
			if(insert_data('cloud_platform`.`sdwan_client', $cpe) === false) {
				$errmsg = implode(' ', $nidb->errorInfo());
				set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
				return false;
			}
			$link['cpe_id'] = $nidb->lastInsertId();
			$newcnt++;
		}

		// 生成帐号与密码
		$addcount++;
		$link['acct']	= 'u' . substr('0000000000' . base_convert($pop['acctcount'] + $addcount, 9, 16), -10);
		$r = '';
		while($nc-- > 0) $r .= $map{mt_rand(0, $l)};
		$link['pass']	= $r;

		if(insert_data('cloud_platform`.`sdwan_link', $link) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
		$link_id = $nidb->lastInsertId(); 

		if($newpop) {
			// 更新客户端的计数
			try {
				$sql = "update `cloud_platform`.`sdwan_client`";
				$sql.= " set `svrcnt` = `svrcnt` + 1";
				$sql.= " where `cpe_id` = {$link['cpe_id']}";
				$sth = $nidb->prepare($sql);
				$sth->execute();
			}
			catch (\NiDBException $e) {
				set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			}
		}

		$cpedir = OPSCONF_DIR . "/zeropen/license/{$device}/cpe";
		if(!is_dir($cpedir))
			exec("mkdir -p {$cpedir} 2>&1", $output, $ret);

		$content = "link_id={$link_id} ";
		$content.= "pop_id={$link['pop_id']} ";
		$content.= "cpe_id={$link['cpe_id']} ";
		$content.= "pop={$pop['device']} ";
		$content.= "cpe={$device} ";
		$content.= "startip={$pop['startip']} ";
		$content.= "endip={$pop['endip']} ";
		$content.= "gateway={$pop['gateway']} ";
		$content.= "cpeip={$cpeip} ";
		$content.= "poplanip= "; // 如果为空，则自动选择第一个状态正常的LAN
		$content.= "popvlanid=0 "; // POP LAN 接口上的 VLAN-ID
		$content.= "cpelanip= "; // 如果为空，则自动选择第一个状态正常的LAN
		$content.= "cpevlanid=0 "; // CPE LAN 接口上的 VLAN-ID
		$content.= "port={$link['port']} ";
		$content.= "acct={$link['acct']} ";
		$content.= "pass={$link['pass']} ";
		$content.= "expire={$expire} ";
		$content.= "starttm={$now} ";
		$content.= "ctime={$now}";

		$flink = "{$linkdir}/{$link_id}.dat";
		file_put_contents($flink, $content);

		// 生成 CPE 配置
		$fconf = "{$cpedir}/{$link_id}.dat";
		if(file_exists($fconf))
			unlink($fconf);
		exec("ln -s {$flink} {$fconf}");

		// 生成 POP 配置
		$fconf = "{$popdir}/{$link_id}.dat";
		if(file_exists($fconf))
			unlink($fconf);
		exec("ln -s {$flink} {$fconf}");

		// 返回结果
		array_push($ret, array(
			$device => array(
				'link_id'	=> $nidb->lastInsertId(),
				'link_id'	=> $link_id,
			)
		));
	}

	if($newcnt || $addcount) {
		// 更新服务端的计数
		try {
			$sql = "update `cloud_platform`.`sdwan_server`";
			$sql.= " set `clicnt` = `clicnt` + {$newcnt}";
			$sql.= " , `acctcount` = `acctcount` + {$addcount}";
			$sql.= " where `pop_id` = {$data['pop_id']}";
			$sth = $nidb->prepare($sql);
			$sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		}
	}

	if(!($iwanip_tbstr = json_encode($iwanip_tb))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, 'iwanip_tb 编码失败！未保存最后的IP分配表。');
		return false;
	}
	file_put_contents($fiwanip_tb, $iwanip_tbstr);

	return $ret;
}

function del($data)
{
	global $nidb, $user;


	if(isset($data['link_id']) == false || empty($data['link_id'] = trim($data['link_id']))) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定要删除的联接。');
		return false;
	}

	if(preg_match("/^([0-9,]{1,})$/", $data['link_id'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "联接编号格式不正确！");
		return false;
	}
	
	$link_ids = explode(',', $data['link_id']);

	$wkpids = \cloud\apps\work\project\project_enable();
	if(!$wkpids && !\cloud\apps\work\project\in_work_project(ROLE_ADMIN)) {
		$wkpids = 0;
//		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
//		return false;
	}
	
	try {
		$sql = "select `pop_id`, `cpe_id` ";
		$sql.= " from `cloud_platform`.`sdwan_link`";
		$sql.= " where `link_id` in ({$data['link_id']})";
		$sth = $nidb->prepare($sql);

		$sth->execute();
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) <= 0)
		return false;

	// 删除所有连接
	try {
		$sql = "delete from `cloud_platform`.`sdwan_link` where `link_id` in ({$data['link_id']})";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

//	$fiwanip_tb = OPSCONF_DIR . "/zeropen/license/{$pop['device']}/iwanip_tb.json";
//	if(!file_exists($fiwanip_tb) || !($iwanip_tb = readjson($fiwanip_tb))) 
		$iwanip_tb = array();

	$linkdir = OPSCONF_DIR . "/zeropen/links";
	if(is_dir($linkdir)) {
		// 删除配置文件
		foreach($link_ids as $id) {
			$flink = "{$linkdir}/{$id}.dat";
			if(!file_exists($flink)) continue;
			
			$content = file_get_contents($flink, $content);
			unlink($flink);
			$row = explode(' ', $content);
			
			$cpe_keyno = '';
			$pop_keyno = '';
			
			// 删除pop与cpe设备目录下的 link 链接文件
			foreach($row as $val) {
				$node = explode('=', $val);
				if(count($node) == 2) {
					if($node[0] == 'cpe') {
						$flink = OPSCONF_DIR . "/zeropen/license/{$node[1]}/cpe/{$id}.dat";
						if(file_exists($flink)) unlink($flink);
					}
					else
					if($node[0] == 'pop') {
						$flink = OPSCONF_DIR . "/zeropen/license/{$node[1]}/cpe/{$id}.dat";
						if(file_exists($flink)) unlink($flink);
					}
					else
					if($node[0] == 'cpeip' && !empty($node[1]))
						array_push($iwanip_tb, $node[1]);
				}
			}
		}
	}

//	if(($iwanip_tbstr = json_encode($iwanip_tb)))
//		file_put_contents($fiwanip_tb, $iwanip_tbstr);

	$cpe_ids = array();
	$pop_ids = array();
	foreach($rows as $row) {
		if(!in_array($row->cpe_id, $cpe_ids))
			array_push($cpe_ids, $row->cpe_id);

		if(!in_array($row->pop_id, $pop_ids))
			array_push($pop_ids, $row->pop_id);
	}

	try {
		$sql = "update `cloud_platform`.`sdwan_server`";
		$sql.= " set `clicnt` = 0";
		$sql.= " where `pop_id` in (" . implode(',', $pop_ids) . ")";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	try {
		$sql = "update `cloud_platform`.`sdwan_client`";
		$sql.= " set `svrcnt` = 0";
		$sql.= " where `cpe_id` in (" . implode(',', $cpe_ids) . ")";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	// 统计影响的pop，以便更新计数器
	try {
		$sql = "select `pop_id`, count(`cpe_id`) as `count` ";
		$sql.= " from `cloud_platform`.`sdwan_link` ";
		$sql.= " where `pop_id` in (" . implode(',', $pop_ids) . ")";
		$sql.= " group by `cpe_id`";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	foreach($rows as $row) {
		try {
			$sql = "update `cloud_platform`.`sdwan_server`";
			$sql.= " set `clicnt` = {$row->count}";
			$sql.= " where `pop_id` = {$row->pop_id}";
			$sth = $nidb->prepare($sql);
			$ret = $sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
	}

	// 统计影响的pop，以便更新计数器
	try {
		$sql = "select `cpe_id`, count(`pop_id`) as `count` ";
		$sql.= " from `cloud_platform`.`sdwan_link` ";
		$sql.= " where `cpe_id` in (" . implode(',', $cpe_ids) . ")";
		$sql.= " group by `pop_id`";
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	foreach($rows as $row) {
		try {
			$sql = "update `cloud_platform`.`sdwan_client`";
			$sql.= " set `svrcnt` = {$row->count}";
			$sql.= " where `cpe_id` = {$row->cpe_id}";
			$sth = $nidb->prepare($sql);
			$ret = $sth->execute();
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}
	}

	return true;
}
