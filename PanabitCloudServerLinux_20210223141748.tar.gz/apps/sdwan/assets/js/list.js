// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga()
{
	return _tb_paga;
}
function set_tb_paga(paga)
{
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function setcol_entlist(d)
{
	var html = '';

	if (this.field == undefined)
		return html;

	if (this.field == 'name')
		html = '<span class="setBtn" lay-event="branch">' + d[this.field] + '</span>';
	else
	if (this.field == 'operate') {
		html = [
			'<span class="setBtn" lay-event="branch">分支</span>',
			'<span class="setBtn" lay-event="edit">编辑</span>',
			'<span class="setBtn" lay-event="del">删除</span>'
		].join(" | ");
	}
	else
		html = d[this.field];

	return html;
}

function setcol_branchlist(d)
{
	var html = '';

	if (this.field == undefined)
		return html;

	if (this.field == 'popname')
		html = '<span class="setBtn" lay-event="pop">' + d[this.field] + '</span>';
	else
	if (this.field == 'entname')
		html = '<span class="setBtn" lay-event="ent">' + d[this.field] + '</span>';
	else
		html = d[this.field];

	return html;
}

function setcol_poplist(d)
{
	var html = '';

	if (this.field == undefined)
		return html;
	else
		html = d[this.field];

	if (this.field == 'name')
		html = '<span class="setBtn" lay-event="branch">' + d[this.field] + '</span>';
	else
	if (this.field == 'svrlist')
		html = '<span class="setBtn" lay-event="edit">' + d.svcip + ':' + d.port + '</span>';
	else
	if (this.field == 'operate') {
		html = [
			'<span class="setBtn" lay-event="branch">客户端</span>',
			'<span class="setBtn" lay-event="edit">编辑</span>',
			'<span class="setBtn" lay-event="del">删除</span>'
		].join(" | ");
	}
	else
		html = d[this.field];

	return html;
}
layui.config({
    base: '/cloud/assets/lib/layui/'
}).use(['treeTable'], function () {
    var treeTable = layui.treeTable;
});
var timer = new taskTimer();

layui.use(['form', 'element', 'layer', 'transfer', 'treeTable', 'util'], function() {
	var form = layui.form;
	var element = layui.element;
	var table = layui.table;
	var treeTable = layui.treeTable;
	var layer = layui.layer;
	var transfer = layui.transfer;
	var util = layui.util;
	var tabs = {};
	var tb_options = {
		poplist: {
			parseData: function(res) {
				var d, i;
				if (res.ret == 0) {
					res.count = res.data.total;
					res.data = res.data.rows;

					for(i = 0; i < res.data.length; i++) {
						d = res.data[i];
						d.count = 0;
					}
				}

				res.code = res.ret;
				res.msg = res.msg;

				var e = $(this.elem).parent();
				set_tb_paga(e.find('.layui-laypage-limits select').val());
			}
		}
	};

	function tab_select(elem) {
		var filter = elem.attr('lay-filter');
		if(!tabs[filter]) {
			if(elem.attr('data-treetable') == "yes") {
				tabs[filter] = {
					id: filter
				};
				tabs[filter].tb = treeTable.render({
					elem: '#' + filter,
					request: {},        // 懒加载请求携带的参数名称
					skin: 'line',
					tree: {
						iconIndex: 2,           // 折叠图标显示在第几列
						isPidData: true,        // 是否是id、pid形式数据
					},
					reqData: function(parseData, callback) {
						var e = $('[lay-filter="entlist"]');
						var where = {};
						e.parent().find('form [name]').each(function(i, e) {
							where[e.getAttribute('name')] = $.trim(e.value);
						});
						$.ajax({
							url:'api.php?r=sdwan@ent-list',
							data: where,
							success: function(res){
								res.code = res.ret;
								res.msg = res.msg;

								var e = elem.parent();
								set_tb_paga(e.find('.layui-laypage-limits select').val());
								callback(res.data.rows);
							},
						});
					},
					cols: [[
						{type: 'numbers', width:30, fixed: 'left', title: '序号'},
						{type: 'checkbox', width:25},
						{field: 'name', width:200, title: '名称', templet: function(d) {
							return '<span class="setBtn" lay-event="name">' + d.name + '</span>';
						}},
						{field: 'serialno', width:188, title: '编号'},
						{field: 'id', width:80, title: 'KEYID', templet: function(d) {
							return (d.srid==="" && d.pid ? "" : d.id);
						}},
						{field: 'srid', width:80, title: 'SRID'},
						{field: 'popname', width:180, title: 'POP点', templet: function(d) {
							return '<span class="setBtn" lay-event="pop">' + d.popname + '</span>';
						}},
						{field: 'netaddrs',  title: '互联地址', templet: function(d) {
							return '<span class="setBtn" lay-event="netaddrs">' + d.netaddrs + '</span>';
						}},
						{field: 'operate', width:80,  title: '操作', templet: function(d) {
							if(d.type == 0)
								//return '<span class="setBtn" lay-event="del-ent">删除企业</span> | ' + 
								return '<span class="setBtn" lay-event="add-cpe">添加分支</span>';
							if(d.type == 1)
								// return '<span class="setBtn" lay-event="del-cpe">删除分支</span> | ' + 
								return '<span class="setBtn" lay-event="add-iwan">添加会话</span>';
							return '';
							// return '<span class="setBtn" lay-event="del-iwan">删除会话</span>';
						}}
					]]
				});
			}
			else {
				table.init(filter, $.extend({
					parseData: function(res) {
						var d, i;
						if (res.ret == 0) {
							res.count = res.data.total;
							res.data = res.data.rows;

							for(i = 0; i < res.data.length; i++) {
								d = res.data[i];
								if ((Number(d.lasttime) + 15) < Number(d.servertime))
									d.linkdown = 1;
								else
									d.linkdown = 0;
							}
						}

						res.code = res.ret;
						res.msg = res.msg;

						var e = elem.parent();
						set_tb_paga(e.find('.layui-laypage-limits select').val());
					}
				}, tb_options[filter]||{}));
				tabs[filter] = {
					id: filter
				};
			}
		}
		else
			tb_search(tabs[filter].id, 1);
	}

	element.on('tab(tab-iwan)', function(data){
		tab_select($(data.elem).find('.layui-tab-content>.layui-show .layui-show table'));
	});
	form.render();
	tab_select($('[lay-filter="entlist"]'));
	$('[lay-filter="entlist"]').parents('.layui-tab-item').toggleClass('layui-show', true);

	// 搜索
	function tb_search(tbid, page, obj) {
		var e = $('[lay-filter="' + tbid + '"]');
		var where = {};
		e.parent().find('form [name]').each(function(i, e) {
			where[e.getAttribute('name')] = $.trim(e.value);
		});

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} 

		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op;
			}
		}

		table.reloadExt(tbid, option);
	}

	$('.c_ent .c_searchBtn').click(function() {
		tabs['entlist'].tb.refresh(); 
	});

	$('.c_ent .c_add').click(function() {
		layer.open({
			type: 1,
			title: '添加企业',
			area: ['380px', 'auto'],
			shadeClose: true,
			resize: false,
			btnAlign: 'c',
			btn: ['确认'],
			content: $('#tpl-add-ent').html(),
			success: function(layero, index) {
				var that = this;
				layero.find('input').css('width', '210px');
				form.on('submit', function(data) {
					that.yes(index, layero);
					return false;
				});
			},
			yes: function(index, layero) {
				var data = form.val('addent');
				$.ajax({
					url: 'api.php?r=sdwan@ent-add',
					data: data,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.ret == 0) layer.msg('创建成功', {
							icon: 1
						});
						layer.close(index);
						tabs['entlist'].tb.refresh(); 
					},
					error: function() {
						layer.msg('连接超时，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});

	$('.c_ent .c_del').click(function() {
		var checkStatus = tabs['entlist'].tb.checkStatus('entlist');
		var selected = [];
		checkStatus.forEach(function(e, i) {
			selected.push(e.srid);
		});
		if (selected.length <= 0) {
			layer.msg('请先选择要删除的企业。');
			return;
		}
		layer.confirm('确定要删除选中的企业吗?', {
			icon: 0,
			title: '删除企业'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=sdwan@ent-del',
				data: {
					ent: selected.join(',')
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					tabs['entlist'].tb.refresh(); 
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});

	table.on('sort(entlist)', function(obj) {
		tb_search('entlist', 0, obj);
	});

	treeTable.on('tool(entlist)', function(obj){
		var data = obj.data;  // 获得当前行数据
		var event = obj.event; // 获得lay-event对应的值

		if(event == 'add-cpe') {
			layer.open({
				type: 1,
				title: '添加分支',
				area: ['600px', '460px'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['保存', '重置'],
				content: $('#tpl-add-cpe').html(),
				rehoverMsg: function(layero, index) {
					layero.find(".layui-transfer-data .layui-unselect span").on('mouseover mouseout', function(e) {
						if(event.type == "mouseover") {
							e.currentTarget.__htips = layer.tips('提示信息', $(e.currentTarget), {tips:[1, '#ff6700'], time: 30000});
						}
						else if(event.type == "mouseout") {
							if(e.currentTarget.__htips)
								layer.close(e.currentTarget.__htips);
						}
						
					});
				},
				parseData: function(res){
					return res;
				},
				onchange: function(data, index) {
					console.log(data); //得到当前被穿梭的数据
					console.log(index); //如果数据来自左边，index 为 0，否则为 1
				},
				success: function(layero, index) {
					var that = this;
					form.val('editcpe', data);
					form.on('submit', function(data) {
						that.yes(index, layero);
						return false;
					});

var data1 = [
{"value": "1", "title": "<a>李白</a>"}
,{"value": "2", "title": "PN800A0713aH 宝鸡文理学院"}
,{"value": "3", "title": "苏轼"}
,{"value": "4", "title": "李清照"}
,{"value": "5", "title": "鲁迅", "disabled": true}
,{"value": "6", "title": "巴金"}
,{"value": "7", "title": "冰心"}
,{"value": "8", "title": "矛盾"}
,{"value": "9", "title": "贤心"}
,{"value": "10", "title": "贤心"}
,{"value": "11", "title": "贤心"}
,{"value": "12", "title": "贤心"}
]

					transfer.render({
						title: ['设备列表', '已选择'],
						elem: layero.find('.c_branch_transfer'),
						data: data1,
						width: 240,
						height: 310,
						id: 'branch_transfer', //定义唯一索引
						showSearch: true
					});
					layero.find('.layui-transfer-data').css('height', '218px');
					this.rehoverMsg(layero, index);

					// 批量办法定事件
					util.event('lay-demoTransferActive', {
						getData: function(othis) {
							var getData = transfer.getData('branch_transfer'); // 获取右侧数据
							layer.alert(JSON.stringify(getData)); 
						}
					});
				},
				yes: function(index, layero) {
					var data = form.val('editcpe');
					$.ajax({
						url: 'api.php?r=sdwan@cpe-save',
						data: data,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.ret == 0) layer.msg('保存完毕', {
								icon: 1
							});
							layer.close(index);
							tb_search('entlist');
						},
						error: function() {
							layer.msg('连接超时，请稍后再试。', {
								icon: 2
							});
						}
					});
				},
				btn2: function(index, layero) {
					transfer.reload('branch_transfer', {
						title: ['设备列表', '已选择'],
						value: [],
						showSearch: true
					});
					this.rehoverMsg(layero, index);
					return false;
				}
			});
			return;
		}
		else
		if(event == 'name') {
			if(data.type == 0) {
				layer.open({
					type: 1,
					title: '编辑企业',
					area: ['380px', 'auto'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['保存'],
					content: $('#tpl-edit-ent').html(),
					success: function(layero, index) {
						var that = this;
						form.val('editent', data);
						layero.find('input').css('width', '210px');
						form.on('submit', function(data) {
							that.yes(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						var data = form.val('editent');
						$.ajax({
							url: 'api.php?r=sdwan@ent-save',
							data: data,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.ret == 0) layer.msg('保存完毕', {
									icon: 1
								});
								layer.close(index);
								tb_search('entlist');
							},
							error: function() {
								layer.msg('连接超时，请稍后再试。', {
									icon: 2
								});
							}
						});
					}
				});
				return;
			}
			else if(data.type == 1) {
				layer.open({
					type: 1,
					title: '编辑分支',
					area: ['380px', 'auto'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['保存'],
					content: $('#tpl-edit-cpe').html(),
					success: function(layero, index) {
						var that = this;
						form.val('editcpe', data);
						layero.find('input').css('width', '210px');
						form.on('submit', function(data) {
							that.yes(index, layero);
							return false;
						});
/*
 //模拟数据
  var data1 = [
    {"value": "1", "title": "李白"}
    ,{"value": "2", "title": "杜甫"}
    ,{"value": "3", "title": "苏轼"}
    ,{"value": "4", "title": "李清照"}
    ,{"value": "5", "title": "鲁迅", "disabled": true}
    ,{"value": "6", "title": "巴金"}
    ,{"value": "7", "title": "冰心"}
    ,{"value": "8", "title": "矛盾"}
    ,{"value": "9", "title": "贤心"}
  ]
*/
						transfer.render({
							elem: layero.find('.c_branch_transfer'),
							data: {},
							id: 'branch_transfer' //定义唯一索引
						});

						// 批量办法定事件
						util.event('lay-demoTransferActive', {
							getData: function(othis) {
								var getData = transfer.getData('branch_transfer'); // 获取右侧数据
								layer.alert(JSON.stringify(getData)); 
							},
							reload: function() {
								// 实例重载
								transfer.reload('branch_transfer', {
									title: [],
									value: [],
									showSearch: true
								});
							}
						});
					},
					yes: function(index, layero) {
						var data = form.val('editcpe');
						$.ajax({
							url: 'api.php?r=sdwan@cpe-save',
							data: data,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.ret == 0) layer.msg('保存完毕', {
									icon: 1
								});
								layer.close(index);
								tb_search('entlist');
							},
							error: function() {
								layer.msg('连接超时，请稍后再试。', {
									icon: 2
								});
							}
						});
					}
				});
				return;
			}
			else if(data.type == 2) {
				layer.open({
					type: 1,
					title: '编辑会话',
					area: ['380px', 'auto'],
					shadeClose: true,
					resize: false,
					btnAlign: 'c',
					btn: ['保存'],
					content: $('#tpl-edit-iwan').html(),
					success: function(layero, index) {
						var that = this;
						form.val('editcpe', data);
						layero.find('input').css('width', '210px');
						form.on('submit', function(data) {
							that.yes(index, layero);
							return false;
						});
					},
					yes: function(index, layero) {
						var data = form.val('editcpe');
						$.ajax({
							url: 'api.php?r=sdwan@iwan-save',
							data: data,
							type: 'post',
							dataType: 'json',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {
										icon: 5
									});
									return;
								}
								if (d.ret == 0) layer.msg('保存完毕', {
									icon: 1
								});
								layer.close(index);
								tb_search('entlist');
							},
							error: function() {
								layer.msg('连接超时，请稍后再试。', {
									icon: 2
								});
							}
						});
					}
				});
				return;
			}
		}
		else if(event == 'pop') {
			layer.open({
				type: 1,
				title: '编辑会话',
				area: ['380px', 'auto'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['保存'],
				content: $('#tpl-edit-iwan').html(),
				success: function(layero, index) {
					var that = this;
					form.val('editcpe', data);
					layero.find('input').css('width', '210px');
					form.on('submit', function(data) {
						that.yes(index, layero);
						return false;
					});
				},
				yes: function(index, layero) {
					var data = form.val('editcpe');
					$.ajax({
						url: 'api.php?r=sdwan@iwan-save',
						data: data,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.ret == 0) layer.msg('保存完毕', {
								icon: 1
							});
							layer.close(index);
							tb_search('entlist');
						},
						error: function() {
							layer.msg('连接超时，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
			return;
		}
		else if(event == 'netaddrs') {

			layer.open({
				type: 1,
				title: '编辑会话',
				area: ['380px', 'auto'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['保存'],
				content: $('#tpl-edit-iwan').html(),
				success: function(layero, index) {
					var that = this;
					form.val('editcpe', data);
					layero.find('input').css('width', '210px');
					form.on('submit', function(data) {
						that.yes(index, layero);
						return false;
					});
				},
				yes: function(index, layero) {
					var data = form.val('editcpe');
					$.ajax({
						url: 'api.php?r=sdwan@iwan-save',
						data: data,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.ret == 0) layer.msg('保存完毕', {
								icon: 1
							});
							layer.close(index);
							tb_search('entlist');
						},
						error: function() {
							layer.msg('连接超时，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
			return;
		}
		//obj.del(); // 删除对应行，并更新缓存
		// 同步更新缓存对应的值
		//obj.update({
		//	username: '123',
		//	title: 'xxx'
		//});
	});

	table.on('tool(entlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'del') {
			layer.confirm('确定要删除“'+data.name+'”企业吗?', {
				icon: 0,
				title: '删除企业'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=sdwan@ent-del',
					data: {
						ent_id: data.ent_id
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						tb_search('entlist');
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
			return;
		}
		else
		if (event == 'edit') {

		}
		else
		if (event == 'branch') {
			$('[lay-filter="tab-iwan"] [name="ent_id"]').val(data.ent_id);
			$('[lay-filter="tab-iwan"] > ul > li').eq(0).click();
		}
	});

	table.on('sort(branchlist)', function(obj) {
		tb_search('branchlist', 0, obj);
	});

	$('.c_cpe .c_searchBtn').click(function() {
		tb_search('branchlist', 1);
	});

	$('.c_cpe .c_add').click(function() {
		layer.open({
			type: 1,
			title: '添加分支',
			area: ['380px', 'auto'],
			shadeClose: true,
			resize: false,
			btnAlign: 'c',
			btn: ['确认'],
			content: $('#tpl-add-cpe').html(),
			success: function(layero, index) {
				var that = this;
				layero.find('input').css('width', '210px');
				form.on('submit', function(data) {
					that.yes(index, layero);
					return false;
				});
			},
			yes: function(index, layero) {
				var data = form.val('addcpe');
				if(!data.ent_id) return;

				$.ajax({
					url: 'api.php?r=sdwan@cpe-add',
					data: data,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.ret == 0) layer.msg('创建成功', {
							icon: 1
						});
						layer.close(index);
						tb_search('branchlist', 1);
					},
					error: function() {
						layer.msg('连接超时，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});

	$('.c_cpe .c_del').click(function() {
		var checkStatus = table.checkStatus('poplist');
		var selected = [];
		checkStatus.data.forEach(function(e, i) {
			selected.push(e.pop_id);
		});
		if (selected.length <= 0) {
			layer.msg('请先选择要删除的分支连接。');
			return;
		}
		layer.confirm('确定要删除选中的分支连接吗?', {
			icon: 0,
			title: '删除分支连接'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=sdwan@cpe-del',
				data: {
					cpe: selected.join(',')
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					tb_search('branchlist', 1);
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});

	table.on('sort(poplist)', function(obj) {
		tb_search('poplist', 0, obj);
	});

	$('.c_pop .c_searchBtn').click(function() {
		tb_search('poplist', 1);
	});

	table.on('tool(poplist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'del') {
			layer.confirm('确定要删除“'+data.name+'”POP点吗?', {
				icon: 0,
				title: '删除POP点'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=sdwan@pop-del',
					data: {
						ent_id: data.ent_id
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						tb_search('poplist', 1);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
			return;
		}
		else
		if (event == 'edit') {
			layer.open({
				type: 1,
				title: '编辑POP点',
				area: ['380px', 'auto'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['保存'],
				content: $('#tpl-edit-pop').html(),
				success: function(layero, index) {
					var that = this;
					form.val('editpop', data);
					layero.find('input').css('width', '210px');
					form.on('submit', function(data) {
						that.yes(index, layero);
						return false;
					});
				},
				yes: function(index, layero) {
					var data = form.val('editpop');
					$.ajax({
						url: 'api.php?r=sdwan@pop-save',
						data: data,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.ret == 0) layer.msg('保存完毕', {
								icon: 1
							});
							layer.close(index);
							tb_search('entlist');
						},
						error: function() {
							layer.msg('连接超时，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
			return;
		}
		else
		if (event == 'branch') {
			$('[lay-filter="tab-iwan"] [name="pop_id"]').val(data.pop_id);
			$('[lay-filter="tab-iwan"] > ul > li').eq(0).click();
		}
	});

	$('.c_pop .c_add').click(function() {
		layer.open({
			type: 1,
			title: '添加POP',
			area: ['380px', 'auto'],
			shadeClose: true,
			resize: false,
			btnAlign: 'c',
			btn: ['确认'],
			content: $('#tpl-add-pop').html(),
			success: function(layero, index) {
				var that = this;
				layero.find('input').css('width', '210px');
				form.on('submit', function(data) {
					that.yes(index, layero);
					return false;
				});
			},
			yes: function(index, layero) {
				var data = form.val('addpop');

				$.ajax({
					url: 'api.php?r=sdwan@pop-add',
					data: data,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.ret == 0) layer.msg('创建成功', {
							icon: 1
						});
						layer.close(index);
						tb_search('poplist', 1);
					},
					error: function() {
						layer.msg('连接超时，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});

	$('.c_pop .c_del').click(function() {
		var checkStatus = table.checkStatus('poplist');
		var selected = [];
		checkStatus.data.forEach(function(e, i) {
			selected.push(e.pop_id);
		});
		if (selected.length <= 0) {
			layer.msg('请先选择要删除的POP点。');
			return;
		}
		layer.confirm('确定要删除选中的POP点吗?', {
			icon: 0,
			title: '删除POP点'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=sdwan@pop-del',
				data: {
					pop: selected.join(',')
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					tb_search('poplist', 1);
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});
});
