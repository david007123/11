<?php
define ("ROOT_DIR", dirname(dirname(dirname(__DIR__))));
require_once(ROOT_DIR . '/conf/config.php');
require_once(ROOT_DIR . '/apps/user/lib/login.php');


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

// 创建SD-WAN服务端表
$sql = "create table if not exists cloud_platform.sdwan_server (";
$sql.= "`pop_id` bigint NOT NULL auto_increment primary key COMMENT 'iWAN服务端ID' ,";
$sql.= "`zpd_id` bigint NOT NULL DEFAULT 0 COMMENT '零配置ID' ,";
$sql.= "`wkpid` bigint NOT NULL DEFAULT 0 COMMENT '项目ID' ,";
$sql.= "`name` char(32) NOT NULL DEFAULT '' COMMENT '服务名' ,";
$sql.= "`device` char(16) NOT NULL DEFAULT '' COMMENT '首次绑定设备的12编号' ,";
$sql.= "`clicnt` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '设备数' ,";
$sql.= "`disabled` tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '0：正常，1：禁用；100：删除' ,";
$sql.= "`acctcount` bigint UNSIGNED NOT NULL DEFAULT 0 COMMENT '帐号的计数器' ,";
$sql.= "`svcip` char(255) NOT NULL DEFAULT '' COMMENT '承载线路名，为空则绑定所有静态线路，多个则用逗号隔开。' ,";
$sql.= "`ifname` char(255) NOT NULL DEFAULT '' COMMENT '承载线路名，为空则绑定所有静态线路，多个则用逗号隔开。' ,";
$sql.= "`port` smallint UNSIGNED NOT NULL DEFAULT 0 COMMENT '服务的端口' ,";
$sql.= "`startip` char(48) NOT NULL DEFAULT '' COMMENT '起始分配IP' ,";
$sql.= "`endip` char(48) NOT NULL DEFAULT '' COMMENT '截至分配IP' ,";
$sql.= "`gateway` char(16) NOT NULL DEFAULT '' COMMENT '网关' ,";
$sql.= "`dns` char(64) NOT NULL DEFAULT '' COMMENT '填两个,逗号隔开,如114.114.114.114,8.8.8.8' ,";
$sql.= "`maxonlinetime` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '在线时间' ,";
$sql.= "`clntepa` tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '对过期账号' ,";
$sql.= "`mtime` bigint NOT NULL DEFAULT 0 COMMENT '修改时间' ,";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);

/*
// 创建服务端的线路绑定表
$sql = "create table if not exists cloud_platform.sdwan_bind_ippool (";
$sql.= "`ippool_id` bigint NOT NULL auto_increment primary key COMMENT 'IP及帐号群组池ID' ,";
$sql.= "`startip` char(48) NOT NULL DEFAULT '' COMMENT '起始分配IP' ,";
$sql.= "`endip` char(48) NOT NULL DEFAULT '' COMMENT '截至分配IP' ,";
$sql.= "`gateway` char(16) NOT NULL DEFAULT '' COMMENT '网关' ,";
$sql.= "`dns` char(64) NOT NULL DEFAULT '' COMMENT '填两个,逗号隔开,如114.114.114.114,8.8.8.8' ,";
$sql.= "`maxonlinetime` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '在线时间' ,";
$sql.= "`clntepa` tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '对过期账号' ,";
$sql.= "`mtime` bigint NOT NULL DEFAULT 0 COMMENT '修改时间' ,";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);

// 创建服务端的线路绑定表
$sql = "create table if not exists cloud_platform.sdwan_bindline_server (";
$sql.= "`sline_id` bigint NOT NULL auto_increment primary key COMMENT 'iWAN服务绑定线路ID' ,";
$sql.= "`pop_id` bigint NOT NULL DEFAULT 0 COMMENT 'iWAN服务端ID' ,";
$sql.= "`ifname` char(255) NOT NULL DEFAULT '' COMMENT '承载线路名，为空则绑定所有静态线路，多个则用逗号隔开。' ,";
$sql.= "`port` smallint UNSIGNED NOT NULL DEFAULT 0 COMMENT '端口' ,";
$sql.= "`startip` char(48) NOT NULL DEFAULT '' COMMENT '起始分配IP' ,";
$sql.= "`endip` char(48) NOT NULL DEFAULT '' COMMENT '截至分配IP' ,";
$sql.= "`gateway` char(16) NOT NULL DEFAULT '' COMMENT '网关' ,";
$sql.= "`dns` char(64) NOT NULL DEFAULT '' COMMENT '填两个,逗号隔开,如114.114.114.114,8.8.8.8' ,";
$sql.= "`maxonlinetime` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '在线时间' ,";
$sql.= "`clntepa` tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '对过期账号' ,";
$sql.= "`mtime` bigint NOT NULL DEFAULT 0 COMMENT '修改时间' ,";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);
*/

// 创建SD-WAN客户端表
$sql = "create table if not exists cloud_platform.sdwan_client (";
$sql.= "`cpe_id` bigint NOT NULL auto_increment primary key COMMENT 'iWAN服务端ID' ,";
$sql.= "`zpd_id` bigint NOT NULL DEFAULT 0 COMMENT '零配置ID' ,";
$sql.= "`wkpid` bigint NOT NULL DEFAULT 0 COMMENT '项目ID' ,";
$sql.= "`name` char(32) NOT NULL DEFAULT '' COMMENT '客户端名' ,";
$sql.= "`device` char(16) NOT NULL DEFAULT '' COMMENT '首次绑定设备的12编号' ,";
$sql.= "`svrcnt` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '设备数' ,";
$sql.= "`disabled` tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '0：正常，1：禁用；100：删除' ,";
$sql.= "`ifname` char(255) NOT NULL DEFAULT '' COMMENT '承载线路名，为空则绑定所有静态线路，多个则用逗号隔开。' ,";
$sql.= "`dstip` char(255) NOT NULL DEFAULT '' COMMENT '服务的目的地址。' ,";
$sql.= "`mtime` bigint NOT NULL DEFAULT 0 COMMENT '修改时间' ,";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);

/*
// 创建客户端的线路绑定表
$sql = "create table if not exists cloud_platform.sdwan_bindline_client (";
$sql.= "`cline_id` bigint NOT NULL auto_increment primary key COMMENT '绑定线路ID' ,";
$sql.= "`cpe_id` bigint NOT NULL DEFAULT 0 COMMENT 'iWAN客户端ID' ,";
$sql.= "`ifname` char(32) NOT NULL DEFAULT '' COMMENT '承载线路名' ,";
$sql.= "`port` smallint UNSIGNED NOT NULL DEFAULT 0 COMMENT '端口' ,";
$sql.= "`mtime` bigint NOT NULL DEFAULT 0 COMMENT '修改时间' ,";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);
*/

// 创建SD-WAN连接关系表
$sql = "create table if not exists cloud_platform.sdwan_link (";
$sql.= "`link_id` bigint NOT NULL auto_increment primary key COMMENT '绑定线路ID' ,";
$sql.= "`ippool_id` bigint NOT NULL DEFAULT 0 COMMENT 'IP及帐号群组池ID' ,";
$sql.= "`pop_id` bigint NOT NULL DEFAULT 0 COMMENT '关联的iWAN服务端ID' ,";
$sql.= "`cpe_id` bigint NOT NULL DEFAULT 0 COMMENT '关联的iWAN客户端ID' ,";
$sql.= "`disabled` tinyint UNSIGNED NOT NULL DEFAULT 0 COMMENT '0：正常，1：禁用；100：删除' ,";
$sql.= "`acct` char(32) NOT NULL DEFAULT '' COMMENT '帐号' ,";
$sql.= "`pass` char(32) NOT NULL DEFAULT '' COMMENT '密码' ,";
$sql.= "`expire` bigint NOT NULL DEFAULT 0 COMMENT '到期时间' ,";
$sql.= "`mtime` bigint NOT NULL DEFAULT 0 COMMENT '修改时间' ,";
$sql.= "`ctime` bigint NOT NULL DEFAULT 0 COMMENT '创建时间'";
$sql.= ") engine=myisam default charset=utf8";
$nidb->query($sql);


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);  

