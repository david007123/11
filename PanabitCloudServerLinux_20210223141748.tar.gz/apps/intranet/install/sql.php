<?php
define ("ROOT_DIR", dirname(dirname(dirname(__DIR__))));
require_once(ROOT_DIR . '/conf/config.php');
require_once(ROOT_DIR . '/apps/user/lib/login.php');


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

$sql = "alter table intool_list add httpport int not null default '0'";
$nidb->query($sql);

$sql = "alter table intool_list add acctimes int not null default '0'";
$nidb->query($sql);

$sql = "alter table intool_list add lasttime int not null default '0'";
$nidb->query($sql);	

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
