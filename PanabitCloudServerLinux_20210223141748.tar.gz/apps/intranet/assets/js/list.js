// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function getcentername(obj) {
	var sch = $.trim(obj.value);

	$(obj).parent().find('input[name="centercode"]').val('');
	
	if (sch == "") return;
	$.ajax({
		url: 'api.php?r=gateway@devlist',
		data: {
			page: 1,
			limit: 5,
			grpid: -1,
			keyword: sch,
			sort: 'serialno',
			g_ascdesc: 'asc',
			expire: 0
		},
		dataType: 'json',
		type: 'post',
		success: function(data) {
			var d = data.data.rows;
			var e = $(obj).parents('.transfercontent').find(".nameouter-table");
			var s = '';
			
			e.html("");
			if (d.length > 0)
				e.show();

			e.children().remove();
			for (i = 0; i < d.length; i++) {
				r = d[i];
				if (r.name != "") {
					s = '<p><a href="javascript:void(0);" onclick="setname(this);">' + r.name + '</a></p>';
					e.append($(s).prop('__mydata_', r));
				}
			}
		}
	});
}

function setname(obj)
{
	var that = $(obj).parents('.transfercontent');
	var d = $(obj).parent().prop('__mydata_');

	that.find('input[name="centercode"]').val(d.serialno);
	that.find('input[name="centername"]').val(d.sysname);
	that.find('.nameouter-table').hide();
}

var remoteCnt = 0;

function open_remote(maphost, hostport, centercode, type, id, callback)
{
	var index = layer.load(0, {shade: 0});
	var op = {
		maphost: maphost,
		hostport: hostport,
		serialno: centercode,
		inacc: id
	};

	op[type] = 1;

	$.ajax({
		url: 'api.php?r=gateway@sshport_open',
		data: op,
		dataType: 'json',
		type: 'post',
		success: function(d) {
			layer.close(index);
			if (ajax_resultCallBack(d) == false) {
				layer.msg(d.msg, {
					icon: 5
				});
				return;
			}

			if (typeof callback == 'function')
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {
				icon: 2
			});
		}
	});
}

function hostgrplistoperate(d)
{
	return '<span class="setBtn" lay-event="del">删除</span>';
}

var timer = new taskTimer();

layui.use(['element', 'form', 'table', 'layer'], function() {
	var element = layui.element;
	var form = layui.form;
	var table = layui.table;
	var layer = layui.layer;
	
	function maingrp(children) 
	{
		return $('[lay-filter="main-toolbar"] select[name="grpid"]' + (children ? ' >' : ''));
	}
	
	function maingroup_refresh() 
	{
		timer.add('read_group', 3, {
			fuc: function() {
				var that = this;
				$.ajax({
					url: 'api.php?r=intranet@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						var grp = maingrp();

						var selected = grp.val();
						grp.children().not('[value=0]').remove();
						for (i = 0; i < data.rows.length; i++)
							grp.append(new Option(data.rows[i].name, data.rows[i].id));

						grp.val(selected);
						form.render('select');
						timer.rmv('read_group');
					}
				});
			}
		}, 1);
	}
	maingroup_refresh();

	// 搜索
	function search(page) {
		var where = {
			grpid: maingrp().val(),
			keyword: $.trim($('[lay-filter="main-toolbar"] input[name="keyword"]').val()),
		};
		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number"){
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} 
		table.reloadExt('host_list', option);
	}
	
	function host_remove()
	{
		var checkStatus = table.checkStatus('host_list');
		var host = [];

		checkStatus.data.forEach(function(e, i) {
			host.push(e.id);
		});

		if (host.length <= 0) {
			layer.msg('请先选择要删除的主机。');
			return;
		}

		layer.confirm('确认要删除这些主机吗?', {
			icon: 0,
			title: '主机删除'
		}, function(index) {
			layer.close(index);
			$.ajax({
				url: 'api.php?r=intranet@host-remove',
				data: {
					id: host
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					search();
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
		});
	}

	//添加主机
	function host_add() 
	{
		layer.open({
			type: 1,
			shadeClose: true,
			title: '添加主机',
			area: ['410px', ''],
			content: $('#add-host').html(),
			btnAlign: 'c',
			btn: ['确认'],
			mysubmit: function(index, layero) {
				var data = form.val('devconfig');
				$.ajax({
					url: 'api.php?r=intranet@host-add',
					data: data,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						layer.close(index);
						maingroup_refresh();
						table.refresh('host_list');
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			},
			success: function(layero, index) {
				var form_data = form.val('devconfig');
				var that = this;
				var tab,
					dev = {
						hostname:form_data.hostname,
						hostip:form_data.hostip,
						webport:form_data.webport,
						httpport:form_data.httpport,
						sshport:form_data.sshport,
						rdpport:form_data.rdpport,
						hostgrpid:form_data.hostgrpid,
						centername:form_data.centername,
	
					};

				if (dev.grpid == 10000)
					dev.grpid = 0;

				tab = layero.find('select[name="hostgrpid"]');
				maingrp(1).not('[value=0]').each(function(i, e) {
					tab.append($(e).clone());
				});

				tab.parents('.layui-layer-content').css('overflow', 'inherit');
				tab.children('[value="' + dev.grpid + '"]').prop('selected', true);
				form.val('devconfig', {
					'hostname':form_data.hostname,
					'hostip':form_data.hostip,
					'webport':form_data.webport,
					'httpport':form_data.httpport,
					'sshport':form_data.sshport,
					'rdpport':form_data.rdpport,
					'hostgrp':form_data.hostgrp,
					'centername':form_data.centername,
				});
				form.render(null, 'devconfig');
				element.render();
				form.on('submit', function(data) {
					that.mysubmit(index, layero);
					return false;
				});
			},
			yes: function(index, layero) {
				this.mysubmit(index, layero);
			}
		});
	}

	function remote_show() {
		layer.open({
			type: 1,
			shadeClose: true,
			title: '远程中设备',
			area: ['800px', '600px'],
			resize: true,
			maxmin: true,
			content: $('#tpl-remote').html(),
			resizing: function(layero){
				console.log(layero);
			},
			myrefresh: function(index, layero) {
				$.ajax({
					url: 'api.php?r=gateway@sshport_list',
					dataType: 'json',
					success: function(d) {
						var rows = [];
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						
						d.data.forEach(function(row, index) {
							if (row.hostname)
								d.data[index].name = row.hostname;
							else
								d.data[index].name = row.sysname;
							d.data[index].onlinetime = row.usetime + 's';
						});
						
						d.data.map(function(d){
							if (d.cliip == 'localhost')
							return;
							rows.push(d);
							remoteCnt++;
						});
						
						table.reload('remotelist', {
							data: rows,
							done: function(res, curr, count) {
								$('[lay-id="remotelist"]').css('margin-top', '0px');
								$('[lay-id="remotelist"] .layui-table-tool').css('background-color', 'white');
							}
						});
					}
				});
			},
			success: function(layero, index) {
				var that = this;
				table.init('remotelist');

				$('[lay-id="remotelist"]').css('margin-top', '0px');
				$('[lay-id="remotelist"] .layui-table-tool').css('background-color', 'white');
				table.on('toolbar(remotelist)', function(obj) {
					var checkStatus = table.checkStatus(obj.config.id),
						devs = [];

					switch (obj.event) {
						case 'LAYTABLE_REFRESH':
							that.myrefresh();
							break;
						case 'LAYTABLE_DEL':
							checkStatus.data.forEach(function(e, i) {
								devs.push({
									serialno: e.serialno,
									cliip: e.cliip,
									bigport: e.bigport,
									minport: e.minport,
								});
							});
							if (devs.length <= 0) return;
							layer.confirm('确定要断开设备连接吗？', function(index) {
								$.ajax({
									url: 'api.php?r=gateway@sshport_close',
									data: {
										dev: devs
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});
										that.myrefresh();
										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
							break;
					}
				});
				that.myrefresh();
			}
		});
	}
	
	//主机组
	function hostgroup_mgd()
	{
		layer.open({
			type: 1,
			shadeClose: true,
			title: '主机组管理',
			area: ['600px', '400px'],
			resize: false,
			btnAlign: 'c',
			content: $('#hostgrp').html(),
			success: function(layero, index) {
				table.init('hostgrplist', {
					id: 'hostgrplist',
					height: 330,
					url: 'api.php?r=intranet@group',
					method: 'post',
					limit: 50,
					skin: 'line',
					initSort: {
						field: 'id',
						type: 'asc'
					},
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					toolbar: true,
					defaultToolbar: [{
						title: '添加主机组',
						layEvent: 'LAYTABLE_ADDGROUP',
						icon: 'layui-icon-add-circle'
					}],
					page: false,
					done: function(res, curr, count) {
						layero.find('.layui-table-tool').css('background-color', 'white');
					},
					parseData: function(res) {
						if (res.ret == 0) {
							res.count = res.data.total;
							res.data = res.data.rows;
						}

						res.code = res.ret;
						res.msg = res.msg;
					},
				});

				table.on('tool(hostgrplist)', function(obj) {
					var data = obj.data,
						event = obj.event;

					if (event === 'del') {
						layer.confirm('确定要删除该组吗？', function(index){
							$.ajax({
								url: 'api.php?r=intranet@group-remove',
								data: {
									grpid: data.id
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}
									if (d.msg) layer.msg(d.msg, {
										icon: 1
									});

									obj.del();
									layer.close(index);
									maingroup_refresh();
								},
								error: function() {
									layer.msg('获取数据失败，请稍后再试。', {
										icon: 2
									});
								}
							});
						});
					}
				});
				table.on('toolbar(hostgrplist)', function(obj) {
					var checkStatus = table.checkStatus(obj.config.id),
						data = checkStatus.data;

					switch (obj.event) {
						case 'LAYTABLE_ADDGROUP':
							layer.prompt({
								formType: 0,
								value: '',
								// maxlength: 32,
								title: '请输入主机组名称',
								area: ['300px', '120px']
							}, function(value, index, elem) {
								value = $.trim(value);
								if (value == '') {
									layer.msg('主机组名称不能为空！', {
										icon: 5
									});
									return;
								}
								$.ajax({
									url: 'api.php?r=intranet@group-add',
									data: {
										name: value
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});
										layer.close(index);
										table.refresh('hostgrplist');
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
							break;
					}
				});
			}
		});
	}
	
	$('[lay-filter="main-toolbar"] button[dom-filter]').on('click', function() {
		var event = this.getAttribute('dom-filter');

		switch(event) {
			case "search":
				search.call(this, 1);
			break;
			case "del":
				host_remove.call(this);
			break;
			case "add":
				host_add.call(this);
			break;
			case "remote":
				remote_show.call(this);
			break;
			case "groupmgd":
				hostgroup_mgd.call(this);
			break;
			default:
			break;
		}
	});

	form.on('select(grpid)', function(data) {
		search(1);
	});
	
	table.render({
		elem: '#host_list',
		even: true,
		url: 'api.php?r=intranet@host-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			if(res.ret == 0) {
				res.count = res.data.total;
				res.data = res.data.rows;
			}
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#host_list').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
					width: 35,
				}, {
					title: '主机',
					minWidth: 180,
					templet: function(d) {
						return '<span class="setBtn" lay-event="edit_set">' + d.hostip + '&nbsp;' + d.hostname + '</span>';
					}
				}, {
					field: 'hostgrpid',
					title: '主机组',
					templet: function(d) {
						var grpname;
						if (d.hostgrpid == 0) return '';
						grpname = maingrp().children('option[value="' + d.hostgrpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'centername',
					title: '跳板机'
				}, {
					title: '访问',
					minWidth: 190,
					templet: function(r){
						var m = '';
						if (r.httpport != "0")
							m += '<span class="setBtn" lay-event="open_http">HTTP</span>';
						else
							m += '<span style="color:#ddd">HTTP</span>';
						if (r.webport != "0")
							m += '&nbsp;&nbsp;|&nbsp;&nbsp;<span class="setBtn" lay-event="open_https">HTTPS</span>';
						else
							m += '&nbsp;&nbsp;|&nbsp;&nbsp;<span style="color:#ddd">HTTPS</span>';
						if (r.sshport != "0")
							m += '&nbsp;&nbsp;|&nbsp;&nbsp;<span class="setBtn" lay-event="open_ssh">SSH</span>';
						else
							m += '&nbsp;&nbsp;|&nbsp;&nbsp;<span style="color:#ddd">SSH</span>';
						if (r.rdpport != "0")
							m += '&nbsp;&nbsp;|&nbsp;&nbsp;<span class="setBtn" lay-event="open_rdp">RDP</span>';
						else
							m += '&nbsp;&nbsp;|&nbsp;&nbsp;<span style="color:#ddd">RDP</span>';
						return m;
					}
				}, {
					field: 'acctimes',
					title: '次数',
					minWidth: 50
				}, {
					field: 'lasttime',
					title: '最近访问',
					minWidth: 120,
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.lasttime, 'MM-dd HH:mm:ss');
					}
				},
				{
					title: '操作',
					width: 60,
					templet: function(d) {
						return '<span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});
	table.on('tool(host_list)', function(obj) {
		var data = obj.data;
		var event = obj.event;

		if (event === 'edit_set') {
			layer.open({
				type: 1,
				shadeClose: true,
				title: '编辑主机',
				area: ['410px', ''],
				content: $('#edit-host').html(),
				btnAlign: 'c',
				btn: ['保存'],
				mysubmit: function(index, layero) {
					var d = form.val('edit-host');
					d.id = data.id;
					$.ajax({
						url: 'api.php?r=intranet@host-save',
						data: d,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							// table.refresh('devlist');
							table.reloadExt('host_list');
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				},
				success: function(layero, index) {
					var that = this;
					var tab;

					tab = layero.find('form[lay-filter="edit-host"] select[name="hostgrpid"]');
					maingrp(1).not('[value=0]').each(function(i, e) {
						tab.append($(e).clone());
					});

					tab.parents('.layui-layer-content').css('overflow', 'inherit');
					tab.children('[value="' + data.id + '"]').prop('selected', true);
					form.val('edit-host', data);
					form.render(null, 'edit-host');
					element.render();
					form.on('submit', function(data) {
						that.mysubmit(index, layero);
						return false;
					});
				},
				yes: function(index, layero) {
					this.mysubmit(index, layero);
				}
			
			}, function(value, index) {
				obj.update({
					email: value
				});
				layer.close(index);
			});
		} else if (event == 'del') {
			layer.confirm('确定要删除该主机吗？', function(index) {
				$.ajax({
					url: 'api.php?r=intranet@host-remove',
					data: {
						id: data.id
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('host_list');
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			});
		} 
		else if (event == 'open_http') {
			open_remote(data.hostip, data.httpport, data.centercode, "webenable", data.id, function(d) {
				if(layui.device().ios) {
					layer.msg('映射完成!', {
						time: 0,
						btn: ['连接', '不用了'], 
						yes: function(index){
						   layer.close(index);
						   window.open('http://' + d.hostip + ":" + d.webport, "_blank");
						}
					});
				}
				else
					window.open('http://' + d.hostip + ":" + d.webport, "_blank");
				table.reloadExt('host_list');
			});
		} 
		else if (event == 'open_https') {
			open_remote(data.hostip, data.webport, data.centercode, "webenable", data.id, function(d) {
				if(layui.device().ios) {
					layer.msg('映射完成!', {
						time: 0,
						btn: ['连接', '不用了'], 
						yes: function(index){
						   layer.close(index);
						   window.open('https://' + d.hostip + ":" + d.webport, "_blank");
						}
					});
				}
				else
					window.open('https://' + d.hostip + ":" + d.webport, "_blank");
				table.reloadExt('host_list');
			});
		} 
		else if (event == 'open_ssh') {
			open_remote(data.hostip, data.sshport, data.centercode, "sshenable", data.id, function(d) {
				window.open("ssh://" + window.document.location.hostname + ":" + d.sshport, "_blank");
				table.reloadExt('host_list');
			});
		} 
		else if (event == 'open_rdp') {
			open_remote(data.hostip, data.rdpport, data.centercode, "rdpenable", data.id, function(d) {
				layer.msg("映射已完成，请双击执行下载的bat文件", {icon: 1});
				window.open("../download/mstsc_"+ d.webport + ".bat", "_blank");
				table.reloadExt('host_list');
			});
		}
	});


});
