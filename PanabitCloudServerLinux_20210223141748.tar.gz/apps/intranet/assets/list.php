<?php

ni_app_load('user', 'login');
\cloud\apps\user\auth_json_exit();

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<!-- <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" /> -->
		<link rel="stylesheet" href="assets/css/font.css">
		<link rel="stylesheet" href="assets/css/xadmin.css">
		<link rel="stylesheet" type="text/css" href="assets/lib/layui/css/layui.css" />
		<link rel="stylesheet" type="text/css" href="assets/css/cloud.css" />
		<script src="assets/js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="assets/lib/layui/layui.js" charset="utf-8"></script>
		<script type="text/javascript" src="assets/js/comm.js" charset="utf-8"></script>
		<script type="text/javascript" src="assets/js/jq.cookie.js" charset="utf-8"></script>
	</head>
	<body>
		<div class="layui-fluid">
			<div class="layui-tab layui-tab-brief">
				<div class="layui-tab-content">
					<div class="layui-tab-itemlayui-show">
						<form class="layui-form getwaytool" action="" lay-filter="main-toolbar">
							<div class="toolleft">
								<div class="layui-form-item">
									<label class="layui-form-label" style="min-width: 50px;">显示组</label>
									<div class="layui-input-block">
										<select name="grpid" lay-filter="grpid">
											<option value="0" selected="selected">所有组</option>
										</select>
									</div>
								</div>
								<div class="layui-form-item">
									<div class="layui-input-block">
										<input type="text" name="keyword" required placeholder="输入主机IP / 主机名" autocomplete="off" class="layui-input form-group-text">
									</div>
								</div>
								<div class="layui-form-item">
									<button type="button" class="layui-btn layui-btn-sm rightbtn" dom-filter="search"><i class="layui-icon">&#xe615;</i></button>
								</div>
								<div class="layui-form-item">
									<button type="button" class="layui-btn layui-btn-sm" dom-filter="del"><i class="layui-icon">&#xe640;</i></button>
								</div>
							</div>
							<div class="toolright">
								<div class="layui-form-item">
								<?php
									global $user;
									if($user->username == ADMIN_ACCT){
										echo '<button type="button" class="layui-btn layui-btn-sm rightbtn" dom-filter="groupmgd"><i class="layui-icon icontext">主机组</i></button>';
									}
								?>	
								</div>
								<div class="layui-form-item">
									<button type="button" class="layui-btn layui-btn-sm rightbtn" dom-filter="add"><i class="layui-icon icontext">添加主机</i></button>
								</div>
								<div class="layui-form-item">
									<button type="button" class="layui-btn layui-btn-sm rightbtn" dom-filter="remote"><i class="layui-icon icontext">远程中设备</i></button>
								</div>
							</div>
						</form>
						<table id="host_list" lay-filter="host_list"></table>
					</div>
				</div>
			</div>
		</div>
		<script id="hostgrp" type="text/html">
			<form class="layui-form" action="" lay-filter="hostgrpmgd" style="margin-top: -12px;">
				<table class="layui-table" lay-filter="hostgrplist">
				  <thead>
					<tr>
					  <th lay-data="{field:'id', width: 40, fixed: 'left', type: 'numbers'}">序号</th>
					  <th lay-data="{field:'name', sort: true}">组名称</th>
					  <th lay-data="{field:'operate', width: 65, templet: hostgrplistoperate}">操作</th>
					</tr>
				  </thead>
				</table>
			</form>
		</script>
		<script id="add-host" type="text/html">
			<div class="transfercontent">
				<form class="layui-form" action=""  lay-filter="devconfig">
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">主机名称</label>
						<div class="layui-input-block">
							<input type="text" name="hostname" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">主机IP</label>
						<div class="layui-input-block">
							<input type="text" name="hostip" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">HTTP端口</label>
						<div class="layui-input-block">
							<input type="text" name="httpport" autocomplete="off" placeholder="80，不需要可为空或0" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">HTTPS端口</label>
						<div class="layui-input-block">
							<input type="text" name="webport" autocomplete="off" placeholder="443，不需要可为空或0" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">SSH端口</label>
						<div class="layui-input-block">
							<input type="text" name="sshport" autocomplete="off" placeholder="22，不需要可为空或0" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">RDP端口</label>
						<div class="layui-input-block">
							<input type="text" name="rdpport" autocomplete="off" placeholder="3389，不需要可为空或0" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">主机所属组</label>
						<div class="layui-input-block">
							<select class="pupgrplist" name="hostgrpid">
								<option value="0" selected="selected">空组</option>
							</select>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">跳板机</label>
						<div class="layui-input-block">
							<input type="hidden" name="centercode" />
							<input type="text" name="centername" onkeyup="getcentername(this)" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
				</form>
				<div class="nameouter-table"></div>
				</div>
		</script>
		<script id="edit-host" type="text/html">
			<div class="popupscontent transfercontent">
				<form class="layui-form" action="" lay-filter="edit-host">
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">主机名称</label>
						<div class="layui-input-block">
						<input type="text" name="hostname" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">主机IP</label>
						<div class="layui-input-block">
						<input type="text" name="hostip" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">HTTP端口</label>
						<div class="layui-input-block">
							<input type="text" name="httpport" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">HTTPS端口</label>
						<div class="layui-input-block">
							<input type="text" name="webport" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">SSH端口</label>
						<div class="layui-input-block">
							<input type="text" name="sshport" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">RDP端口</label>
						<div class="layui-input-block">
							<input type="text" name="rdpport" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">主机所属组</label>
						<div class="layui-input-block">
							<select class="pupgrplist" name="hostgrpid">
								<option value="0" selected="selected">空组</option>
							</select>
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label intranet-align">跳板机</label>
						<div class="layui-input-block">
							<input type="hidden" name="centercode" />
							<input type="text" name="centername" onkeyup="getcentername(this)" autocomplete="off" class="layui-input form-group-text">
						</div>
					</div>
				</form>
				<div class="nameouter-table"></div>
			</div>
		</script>
		<script id="tpl-remote" type="text/html">
			<table class="layui-table" lay-data="{even: true, limit: 50, skin: 'line', toolbar: true, page:true, 
			defaultToolbar: [{title: '刷新远程列表', layEvent: 'LAYTABLE_REFRESH', icon: 'layui-icon-refresh-3'}, 
			{title: '断开远程连接', layEvent: 'LAYTABLE_DEL', icon: 'layui-icon-delete'}], id:'remotelist'}" ,
			lay-filter="remotelist">
			  <thead>
				<tr>
				  <th lay-data="{field:'id', width: 40, fixed: 'left', type: 'numbers'}">序号</th>
				  <th lay-data="{type:'checkbox', width: 40}"></th>
				  <th lay-data="{field:'name', sort: true, width: 150}">主机名</th>
				  <th lay-data="{field:'bigport', sort: true}">外网端口</th>
				  <th lay-data="{field:'minport', sort: true}">内网端口</th>
				  <th lay-data="{field:'borntime', sort: true}">映射时间</th>
				  <th lay-data="{field:'onlinetime', sort: true}">在线时间</th>
				</tr>
			  </thead>
			</table>
		</script>
	</body>
	<script src="apps/intranet/assets/js/list.js" type="text/javascript" charset="utf-8"></script>
</html>
