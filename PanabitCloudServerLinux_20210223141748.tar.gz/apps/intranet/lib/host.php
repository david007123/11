<?php
namespace cloud\apps\intranet\host;


function select($data)
{
	global $nidb, $user; 

	
	$result = array(
			'total' => 0,
			'rows'	=> array()
		);
		
	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`hostname` like ? or `hostip` like ? or `centername` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}
	
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false) {
		$optional['grpid'] = -1;
	}
	

	// 设置用户组
	if ($user->username != ADMIN_ACCT) {
		if($user->intool_grpids == '')
			return $result;
		if($optional['grpid'] <= 0) {
			$where_str .= "`hostgrp` in ({$user->intool_grpids}) and ";
		}
		else {
			$grpids = explode(',', $user->intool_grpids);
			if(in_array($optional['grpid'], $grpids) == false) {
				return $result;
			}
			$where_str .= "`hostgrp` = ? and ";
			array_push($values, $optional['grpid']);
		}
	}
	else 
	if($optional['grpid'] > 0) {
		$where_str .= "`hostgrp` = ? and ";
		array_push($values, $optional['grpid']);
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$order_map = array(
		"id",
		"hostname",
		"hostip",
		"webport",
		"sshport",
		"hostgrp",
		"centercode",
		"centername",
		"httpport",
		"acctimes",
		"lasttime",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}
	
	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by id asc';

	$sql = "select count(*) as `total` from intool_list $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) > 0) {
		$result['total'] = $rows[0]->total;
		$result['rows'] = array();
	}
	else {
		return $result;
	}

	$keys = '`id`,
		`hostname`,
		`hostip`,
		`webport`,
		`sshport`,
		`rdpport`,
		`hostgrp` as `hostgrpid`,
		`centercode`,
		`centername`,
		`httpport`,
		`acctimes`,
		`lasttime`';

	$sql = "select $keys from intool_list $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		
		while($row = $sth->fetch(\PDO::FETCH_ASSOC)) {
			array_push($result['rows'], $row);
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function add($data) 
{
	global $nidb, $user;
	
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	$optional = array();
	format_and_push($data, 'webport', $optional, '', 'int', true);
	format_and_push($data, 'httpport', $optional, '', 'int', true);
	format_and_push($data, 'sshport', $optional, '', 'int', true);
	format_and_push($data, 'rdpport', $optional, '', 'int', true);
	if(format_and_push($data, 'hostgrpid', $optional, 'hostgrp', 'int', true) == false)
		$optional['hostgrp'] = 0;

	if(format_and_push($data, 'hostname', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '请输入主机名称！');
		return false;
	}

	if(format_and_push($data, 'centername', $optional, '', 'string', false) == false)
		$optional['centername'] = '';
	if(format_and_push($data, 'centercode', $optional, '', 'string', false) == false)
		$optional['centercode'] = '';

	if(format_and_push($data, 'hostip', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '主机IP不能为空！');
		return false;
	}
	if(is_ipaddr($optional['hostip']) == false || $optional['hostip'] == '0.0.0.0') {
		set_errmsg(MSG_LEVEL_EXP, __function__, '主机IP不正确！');
		return false;
	}
	
	// 设置用户组
	if ($user->username != ADMIN_ACCT) {
		if($user->intool_grpids == ''){
			set_errmsg(MSG_LEVEL_EXP, __function__, '请先申请一个主机组。');
			return false;
		}
		if($optional['hostgrp'] <= 0) {
			set_errmsg(MSG_LEVEL_EXP, __function__, '请先指定一个主机组。');
			return false;
		}
		else {
			$grpids = explode(',', $user->intool_grpids);
			if(in_array($optional['hostgrp'], $grpids) == false) {
				set_errmsg(MSG_LEVEL_EXP, __function__, '指定的主机组不存在。');
				return false;
			}
		}
	}

	$sql = "select * from intool_list where hostip=? and centercode=? limit 1";
	$smt= $nidb->prepare($sql);
	$smt->bindParam(1, $optional['hostip']);
	$smt->bindParam(2, $optional['centercode']);
	$smt->execute();
	$rows = $smt->fetchAll();
	$row_count = $smt->rowCount();
	if($row_count>0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '主机已存在!');
		return false;
	}

	$sql = "insert into intool_list(hostname, hostip, webport, sshport, rdpport, hostgrp, centercode, centername, httpport)values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
	//var_dump($sql);
	$smt = $nidb->prepare($sql);
	$index = 1;
	$smt->bindParam($index++, $optional['hostname']);
	$smt->bindParam($index++, $optional['hostip']);
	$smt->bindParam($index++, $optional['webport']);
	$smt->bindParam($index++, $optional['sshport']);
	$smt->bindParam($index++, $optional['rdpport']);
	$smt->bindParam($index++, $optional['hostgrp']);
	$smt->bindParam($index++, $optional['centercode']);
	$smt->bindParam($index++, $optional['centername']);
	$smt->bindParam($index++, $optional['httpport']);
	
	$str=$smt->execute();
	if (!$str){
		set_errmsg(MSG_LEVEL_DEF, __function__, '添加主机失败！');
		return false;
	}
    
	return true;
}

function save($data) 
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$optional = array();
	format_and_push($data, 'id', $optional, '', 'int', true);
	format_and_push($data, 'webport', $optional, '', 'int', true);
	format_and_push($data, 'httpport', $optional, '', 'int', true);
	format_and_push($data, 'sshport', $optional, '', 'int', true);
	format_and_push($data, 'rdpport', $optional, '', 'int', true);
	if(format_and_push($data, 'hostgrpid', $optional, 'hostgrp', 'int', true) == false)
		$optional['hostgrp'] = 0;

	if(format_and_push($data, 'hostname', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '请输入主机名称！');
		return false;
	}
	format_and_push($data, 'centername', $optional, '', 'string', false);
	format_and_push($data, 'centercode', $optional, '', 'string', false);
	
	if(format_and_push($data, 'hostip', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '主机IP不能为空！');
		return false;
	}
	if(is_ipaddr($optional['hostip']) == false || $optional['hostip'] == '0.0.0.0') {
		set_errmsg(MSG_LEVEL_EXP, __function__, '主机IP不正确！');
		return false;
	}

	// 设置用户组
	$where_str = '';
	if ($user->username != ADMIN_ACCT) {
		if($user->intool_grpids == ''){
			set_errmsg(MSG_LEVEL_EXP, __function__, '请先申请一个主机组。');
			return false;
		}
		if($optional['hostgrp'] <= 0) {
			set_errmsg(MSG_LEVEL_EXP, __function__, '请先指定一个主机组。');
			return false;
		}
		else {
			$grpids = explode(',', $user->intool_grpids);
			if(in_array($optional['hostgrp'], $grpids) == false) {
				set_errmsg(MSG_LEVEL_EXP, __function__, '指定的主机组不存在。');
				return false;
			}
		}
		$where_str = "`hostgrp` in ({$user->intool_grpids}) and ";
	}
	
	$sql = "update intool_list set hostname=?, hostip=?, webport=?, sshport=?, rdpport=?, hostgrp=?, centercode=?, centername=?, httpport=? where {$where_str}id= ? ";
	$smt = $nidb->prepare($sql);
	$index = 1;
	$smt->bindParam($index++, $optional['hostname']);
	$smt->bindParam($index++, $optional['hostip']);
	$smt->bindParam($index++, $optional['webport']);
	$smt->bindParam($index++, $optional['sshport']);
	$smt->bindParam($index++, $optional['rdpport']);
	$smt->bindParam($index++, $optional['hostgrp']);
	$smt->bindParam($index++, $optional['centercode']);
	$smt->bindParam($index++, $optional['centername']);
	$smt->bindParam($index++, $optional['httpport']);
	$smt->bindParam($index++, $optional['id']);
	$smt->execute();
		
	if ($smt->execute() == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '编辑主机失败! ');
		return false;
	}	
	return true;
}

function remove($data)
{
	global $nidb, $user;


	if(!isset($data['id'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请勾选要删除的对象!');
		return false;
	}

	// 设置用户组
	$where_str = '';
	if ($user->username != ADMIN_ACCT) {
		if($user->intool_grpids == ''){
			set_errmsg(MSG_LEVEL_EXP, __function__, '请先申请一个主机组。');
			return false;
		}
		$where_str = "`hostgrp` in ({$user->intool_grpids}) and ";
	}
	
	if(is_array($data['id']) == true) {

		$ids = array();
		
		
		foreach($data['id'] as $val)
			array_push($ids, intval($val));
		
		if(count($ids) == 0) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请勾选要删除的对象!');
			return false;
		}
		
		$str = '?';
		if(count($ids) > 1) 
			$str.= str_repeat(',?', count($ids) - 1); 
		
		$sql = "delete from intool_list where {$where_str}`id` in ({$str})";
		$smt = $nidb->prepare($sql);
		if($smt->execute($ids) == false){
			set_errmsg(MSG_LEVEL_DEF, __function__, '删除主机失败! ');
			return false;
		}
		return true;
	}
	else{
		$sql = "delete from intool_list where {$where_str}`id` =? ";
		
		$smt = $nidb->prepare($sql);
		$smt->bindParam(1, $data['id']);
			
		if($smt->execute() == false){
			set_errmsg(MSG_LEVEL_DEF, __function__, '删除主机失败! ');
			return false;
		}
		
		return true;
	}
}
 

