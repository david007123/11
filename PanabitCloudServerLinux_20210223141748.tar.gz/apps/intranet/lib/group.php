<?php
namespace cloud\apps\intranet\group;


function dump_group()
{
	global $nidb, $user;

	try {
		$sql = "select `id`, `name` from intool_grp";

		$sth = $nidb->prepare($sql);
		$sth->execute();
		$data = $sth->fetchAll(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$sorts = array();
	foreach($data as $key => $row) {
		array_push($sorts, $row['name']);
	}
	array_multisort($sorts, SORT_ASC, SORT_STRING, $data);
	
	return $data;
}

function get_user_group($account)
{
	global $nidb;

	try {
		$sql = "select `intool_grpids` as `grp` from cloud_users where `username` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $account, \PDO::PARAM_STR);
		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) {
		return array();
	}

	$group = array();
	$grp = explode(',', $row['grp']);
	foreach($grp as $val) {
		if($val && ($id = intval($val)) > 0) 
			array_push($group, $id);
	}

	if(count($group) == 0)
		return array();

	$grp = implode(',', $group);
	try {
		$sql = "select `id`, `name` from intool_grp where `id` in ({$grp})";

		$sth = $nidb->prepare($sql);
		$sth->execute();

		$data = $sth->fetchAll(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$sorts = array();
	foreach($data as $key => $row) {
		array_push($sorts, $row['name']);
	}
	array_multisort($sorts, SORT_ASC, SORT_STRING, $data);
	
	return $data;
}

function add($data){
	
	global $nidb;
	
    $hostgrp_name = $data['name'];
	$sql = "insert into intool_grp(name)values(?)";
	$smt = $nidb->prepare($sql);
	
	$smt->bindParam(1,$hostgrp_name);
	if($smt->execute()!= false){
		set_errmsg(MSG_LEVEL_ARG, __function__, '添加主机组成功! ');
	}
	else{
		set_errmsg(MSG_LEVEL_ARG, __function__, '添加主机组失败！');
		return false;
	}

	return true;
}

function remove($data){
	global $nidb;

	$id = $data['grpid'];
	
	$sql = "delete from intool_grp where id = ?";
	$smt = $nidb->prepare($sql);
	$smt->bindParam(1,$id);
	$str=$smt->execute();
	if(!$str){
		set_errmsg(MSG_LEVEL_ARG, __function__, '删除主机组失败! ');
		return false;
	}
	
	set_errmsg(MSG_LEVEL_ARG, __function__, '删除主机组成功! ');
	return true;

}

function group($data)
{
	global $user;

	if(is_supadmin($user->username))
		$result = dump_group();
	else
		$result = get_user_group($user->username);

	return $result;
}
