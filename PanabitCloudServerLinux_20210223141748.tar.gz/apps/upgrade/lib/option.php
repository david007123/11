<?php
namespace cloud\apps\upgrade\option;


function option($data)
{
	global $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$result = array(
		'maxdown'	=> 5,
		'downport'	=> 0,
	);

	if (file_exists(CLOUD_CONF)) {
		$lines = file(CLOUD_CONF);
		foreach($lines as $val) {
			if (strstr($val, "download_max=") != false) {
				$ds = explode('=', $val);
				$result['maxdown'] = intval(trim($ds[1], "\n"));
				break;
			}
		}
	}

	$nginxconf_cloud = "/usr/local/etc/nginx/nginx.conf.cloud";
	$fp = fopen($nginxconf_cloud, "r");
	if ($fp) {
		$httpport = 0;
		while (!feof($fp)) {
			$buff = fgets($fp);
			if ($buff !== false) {
				if (strstr($buff, "listen") !== false && 
					strstr($buff, "ssl") === false && 
					strstr($buff, "#") === false) {
						for ($i = 0; $i < strlen($buff); $i++) {
							$poschr = substr($buff, $i, 1);
							if ($poschr >= '0' && $poschr <= '9')
								$httpport = $httpport * 10 + ($poschr - '0');
						}
					}
			}
		}
		fclose($fp);
		$result['downport'] = $httpport;
	}

	return $result;
}

function save($data)
{
	global $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['maxdown'])) {
		$maxdown = intval($data['maxdown']);
		if($maxdown <= 0) {
			set_errmsg(MSG_LEVEL_EXP, __function__, '同时升级最大设备数不正确！');
			return false;
		}
	}
	if(isset($data['downport'])) {
		$downport = intval($data['downport']);
		if($downport <= 0 || $downport > 65535) {
			set_errmsg(MSG_LEVEL_EXP, __function__, '文件下载端口不正确！');
			return false;
		}
	}

	if(isset($maxdown)) {

		cloud_insertlog($user->username, "配置同时升级最大设备数为{$maxdown}");	

		if (!file_exists(CLOUD_CONF)) {
			if (($fp = fopen(CLOUD_CONF, "w")) === false) {
				set_errmsg(MSG_LEVEL_EXP, __function__, '配置文件不存在！');
				return false;
			}
			fwrite($fp, "download_max={$maxdown}\n");
			fclose($fp);
		}
		else {
			$lines = file(CLOUD_CONF);
			if (($fp = fopen(CLOUD_CONF, "w")) != false) {
				$fd = 0;
				foreach($lines as $val) {
					if (strstr($val, "download_max=") != false) {
						fwrite($fp, "download_max={$maxdown}\n");
						$fd = 1;
						continue;
					}
					fwrite($fp, $val);
				}
				if ($fd == 0)
					fwrite($fp, "download_max={$maxdown}\n");
				fclose($fp);
			}
		}
	}

	if(isset($downport)) {

		cloud_insertlog($user->username, "文件下载端口修改为{$downport}");	

		$nginxconf_cluster  = "/usr/local/etc/nginx/nginx.conf.cluster";
		$nginxconf_cloud = "/usr/local/etc/nginx/nginx.conf.cloud";

		if (!file_exists($nginxconf_cloud))
			copy($nginxconf_cluster, $nginxconf_cloud);

		$lines = file($nginxconf_cloud);

		$s = 0;	
		foreach($lines as $k => $val) {
			if (strstr($val, "listen") !== false && strstr($val, "ssl") === false && strstr($val, "#") === false)
				$lines[$k] = "	listen	{$downport};\n";

			if (strstr($val, "/usr/logd/www") != false && $s == 0) {
				$s = 1;
				continue;
			}

			if (strstr($val, "/usr/logd/www") != false && $s == 1) {
				$s = 1;
				$lines[$k] = "		#root /usr/logd/www/;\n";
				continue;
			}

			if (strstr($val, "/usr/logdata/file_cluster") != false && $s == 0) {
				$s = 1;
				$lines[$k] = "		root /usr/logd/www/;\n";
			}
		}

		if (($fp = fopen($nginxconf_cloud, "w")) != false) {
			foreach($lines as $k => $val) 
				fwrite($fp, $val);

			fclose($fp);
		}

		$fp = fopen(PANABIT_BAGS_PATH . "/webport.conf", "w");
		if ($fp) {
			fprintf($fp, "WEBPORT={$downport}\n");
			fclose($fp);
		}
		
		exec('ps axwww | grep \'nginx.conf.cloud\' | grep -v grep | awk \'{print $1}\'', $out, $ret);
		foreach($out as $val) {
			$pid = trim($val, "\n");
			system("/bin/logeye killpro {$pid} >/dev/null 2>&1");
		}

		if ($downport != 0)
			system("/usr/local/sbin/nginx -c {$nginxconf_cloud}");
	}

	return true;
}