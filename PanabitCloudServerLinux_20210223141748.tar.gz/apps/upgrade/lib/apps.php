<?php
namespace cloud\apps\upgrade\apps;


function select($data)
{
	global $user;

	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0,
		'page'		=> 0,
		'limit'		=> 0
	);

	$now = time();
	$result['now'] = $now;

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;
	
	if(format_and_push($data, 'onlyone', $optional, '', 'int', false) == false)
		$optional['onlyone'] = 0;
	if(format_and_push($data, 'notmout', $optional, '', 'int', false) == false)
		$optional['notmout'] = 0;

	if(format_and_push($data, 'app', $optional, '', 'string', false) == false)
		$optional['app'] = '';
	

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
		$optional['keyword'] = strtolower($optional['keyword']);
	}
	else
		$optional['keyword'] = '';

	if(format_and_push($data, 'reverse', $optional, '', 'int', false) == false)
		$optional['reverse'] = 0;
	
	if(format_and_push($data, 'page', $result, '', 'int', false) == false)
		$result['page'] = 1;
	
	if(format_and_push($data, 'limit', $result, '', 'int', false) == false)
		$result['limit'] = 20;
	else
		if($result['limit'] <= 0) $result['limit'] = 20;


	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		$optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid']);
		if($optional['grpid'] === false)
			return $result;
		if(empty($optional['grpid']) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
		else
		if($optional['grpid'] == 0)
			$optional['grpid'] = '10000,0';
		else 
		if($optional['grpid'] < 0)
			$optional['grpid'] = '';
	}

	$cmd = DATAEYE . " app list page={$result['page']}";
	$cmd.= " limit={$result['limit']}";
	$cmd.= " usergrp={$optional['grpid']} sch='{$optional['keyword']}'";
	$cmd.= " reverse={$optional['reverse']}";
	// 超时60秒的不显示
	if($optional['notmout'])
		$cmd.= " tmout=90"; 

	exec($cmd, $out, $ret);

	$now = time();
	if($optional['onlyone']) {
		$devs = array();
		$havapp = array();
		foreach($out as $val) {
			if (strstr($val, "total=") != false) {
				$row = explode('=', $val);
				$result['total'] = intval($row[1]);
				continue;
			}
			$row = explode(' ', $val);

			$grpid = intval($row[5]);

			$pos = stripos($row[22], '(');
			$ver = substr($row[22], $pos);

			$ver = to_utf8($ver);
			$map_address = to_utf8($row[21]);

			// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
			$sysname = to_utf8($row[1]);
			$app_cname = to_utf8($row[3]);
			$serialno = to_utf8($row[0]);
			
			if(empty($optional['app']) == false
			&& strpos($app_cname, $optional['app']) !== false)
				array_push($havapp, $app_cname);

			if(isset($devs[$serialno]) == false) {
				$devs[$serialno] = array(
					"serialno"		=> $serialno,
					"sysname"		=> $sysname,
					"grpid"			=> $row[5],
					"apps"			=> array()
				);
			}

			array_push($devs[$serialno]['apps'], array(
				'cname'		=> $app_cname,
				'version'	=> $row[4],
			));
		}
		
		if(empty($optional['app']))
			$result['rows'] = array_values($devs);
		else {
			foreach($havapp as $key) 
				array_push($result['rows'], $devs[$key]);
		}

		$result['total'] = count($result['rows']);
	}
	else {
		foreach($out as $val) {
			if (strstr($val, "total=") != false) {
				$row = explode('=', $val);
				$result['total'] = intval($row[1]);
				continue;
			}
			$row = explode(' ', $val);

			$grpid = intval($row[5]);

			$pos = stripos($row[22], '(');
			$ver = substr($row[22], $pos);

			$ver = to_utf8($ver);
			$map_address = to_utf8($row[21]);

			// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
			$sysname = to_utf8($row[1]);
			$app_cname = to_utf8($row[3]);
			$serialno = to_utf8($row[0]);

			array_push($result['rows'], array(
				"serialno"		=> $serialno,
				"sysname"		=> $sysname,
				"app_name"		=> $row[2],
				"app_cname"		=> $app_cname,
				"app_version"	=> $row[4],
				"grpid"			=> $row[5],
				"time"			=> intval($row[6]),
				"systime"		=> $now,
				"app_status"	=> $row[7],
				"startmask"		=> $row[8],
			));
		}
	}

	return $result;
}

function showtask($data)
{
	global $nidb, $user;


	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`license_id12` like ? or `sysname` like ? or `app_cname` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$order_map = array(
		"license_id12",
		"name",
		"app_name",
		"ori_version",
		"last_version",
		"upgrade_bag",
		"complete",
		"errors",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	$sql = "select count(*) as `total` from cloud_appup $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`license_id12`,
		`name`,
		`app_name`,
		`ori_version`,
		`last_version`,
		`upgrade_bag`,
		`complete`,
		`errors`';

	$sql = "select $keys from cloud_appup $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($rows as $key => $val) {
		$rows[$key]->name = iconv("gbk", "utf-8", $val->name);
		$rows[$key]->app_name = iconv("gbk", "utf-8", $val->app_name);
		$rows[$key]->last_version = iconv("gbk", "utf-8", $val->last_version);
		$rows[$key]->errors = iconv("gbk", "utf-8", $val->errors);
		$rows[$key]->complete = intval($val->complete);
		
	}

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function control($data)
{
	global $nidb, $user;


	if(isset($data['op']) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '请选择要操作的对象。');
		return false;
	}

	$op = array();
	if(is_array($data['op']) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, "操作对象不正确！");
		return false;
	}
	
	$op = $data['op'];

	foreach($op as $key => $val) {
		if(isset($val['s']) == false) {
			set_errmsg(MSG_LEVEL_EXP, __function__, "设备编号不能为空！");
			return false;
		}
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $val['s'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$val['s']}”不正确！");
			return false;
		}
		$op[$key]['s'] = $val['s'];
		if(isset($val['n']) == false || empty($val['n'] = trim($val['n']))) {
			set_errmsg(MSG_LEVEL_EXP, __function__, "“{$val['s']}”的APP名称不能为空！");
			return false;
		}
		$op[$key]['n'] = $val['n'];

		if(isset($val['e']) == false) {
			set_errmsg(MSG_LEVEL_EXP, __function__, "“{$val['s']}”的操作方法不能为空！");
			return false;
		}

		if(intval($val['e']))
			$op[$key]['e'] = 'disable';
		else
			$op[$key]['e'] = 'enable';
	}

	foreach($op as $val) {
		$cmd = DATAEYE . " backup set license_id12={$val['s']} app_name={$val['n']} state={$val['e']}";
		exec($cmd, $out, $ret);
	}
	
	return true;
}

function create($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$optional = array();

	if(format_and_push($data, 'package', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定一个有效的升级包。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_.]{10,})$/", $optional['package'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "升级包“{$optional['package']}”不正确！");
		return false;
	}

	if(format_and_push($data, 'appname', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "“{$optional['package']}”的APP名称不能为空！");
		return false;
	}
	$optional['appname'] = iconv("utf-8", "gbk", $optional['appname']);
	if(format_and_push($data, 'version', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "“{$optional['package']}”的APP版本不能为空！");
		return false;
	}
	$optional['version'] = iconv("utf-8", "gbk", $optional['version']);

//	if(format_and_push($data, 'upgrade_time', $optional, '', 'string', false)) 
//		$optional['upgrade_time'] = strtotime($optional['upgrade_time']);
//	else
//		$optional['upgrade_time'] = time();

//	if(format_and_push($data, 'desc', $optional, '', 'string', false) == false)
//		$optional['desc'] = '';

	if(isset($data['devs']) == false || is_array($data['devs']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	$serialno = array();
	$devs = array();
	foreach($data['devs'] as $val) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $val['s'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$val['s']}”不正确！");
			return false;
		}
		if(isset($val['n']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "“{$val['s']}”的设备名称不能为空！");
			return false;
		}
		if(in_array($val['s'], $serialno) === false) {
			array_push($devs, array(
				'serialno'	=> $val['s'],
				'name'		=> iconv("utf-8", "gbk", $val['n']),
			));
		}
	}
	
	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	$serialno = array();
//	cloud_insertlog($user->username, "创建升级任务");	

	try {

		$sql = "delete from cloud_appup";
		$sth = $nidb->prepare($sql);
		$sth->execute();

		foreach($devs as $key => $val) {

			$frmData = array(
				'app_name'		=> $optional['appname'],
				'license_id12'	=> $val['serialno'],
				'name'			=> $val['name'],
				'upgrade_bag'	=> $optional['package'],
				'ori_version'	=> $optional['version'],
			);

			if(insert_data('cloud_appup', $frmData) === false) {
				$errmsg = implode(' ', $nidb->errorInfo());
				set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
				return false;
			}
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function upgradecount()
{
	global $nidb;


	try {
		$sql = "select count(*) as `total` from cloud_appup where complete < 2";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if($row)
		return $row['total'];

	return 0;
}
