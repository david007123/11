<?php
namespace cloud\apps\upgrade;


function select($data)
{
	global $nidb;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	if(format_and_push($data, 'type', $optional, '', 'string', false) == false)
		$optional['type'] = 'PA';

	switch($optional['type']) {
		case "APP":
			$where_str.= "filename like 'PanabitApp%' and ";
			break;
		default: // PA
			$where_str.= "filename not like 'PanabitApp%' and ";
			
			if(format_and_push($data, 'devtype', $optional, '', 'int', false)) {
				if($optional['devtype'] == 2) {
					$where_str.= "filename like 'iXCache%' and ";
				}
				else
				if($optional['devtype'] == 1) {
					$where_str.= "filename not like 'iXCache%' and ";
				}
			}
			break;
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`filename` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);


	$order_map = array(
		"filename",
		"filesize",
		"uptime",
		"app_version",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by uptime desc, filename asc';

	$sql = "select count(*) as `total` from upload_bags $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		return array(
			'total' => 0,
			'rows'	=> array()
		);
	}

	$keys = '`filename`,
		`filesize`,
		`uptime`,
		`app_cname`,
		`app_version`';

	$sql = "select $keys from upload_bags $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($rows as $key => $val) 
		$rows[$key]->app_cname = iconv("gbk", "utf-8", $val->app_cname);

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function upload($data)
{
	global $nidb;
	

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	
	if (!is_dir(PANABIT_BAGS_PATH)) {
		if(mkdir(PANABIT_BAGS_PATH) === false) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '创建升级包目录失败！' . PANABIT_BAGS_PATH);
			return false;
		}
	}

	if (isset($_FILES['package']))
		$upfile = $_FILES['package'];
	else {
		set_errmsg(MSG_LEVEL_DEF, __function__, '上传失败！');
		return false;
	}

	$upname = $upfile['name'];
	$uppath = PANABIT_BAGS_PATH . "/" . $upname;
	if (strstr($upname, ".php") != false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '无效的上传文件！');
		return false;
	}

	if (!move_uploaded_file($upfile['tmp_name'], $uppath)) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '文件上传失败！');
		return false;
	}
	
	$type = '';
	if (isset($data['type']) && $data['type'] == 'APP')
		$type = 'APP';

	$app_cname = "";
	$app_cname_en = "";
	$app_version = "";
	/***************************************************************/
	# 网关升级包和缓存升级包
	if ($type != "APP") {
		exec("/usr/logd/bin/chkpacket checkfile {$upname}", $out, $ret);
		if ($out[0] != "succ") {
			if(file_exists($uppath)) unlink($uppath);
			set_errmsg(MSG_LEVEL_DEF, __function__, iconv("gbk", "utf-8", $out[0]));
			return false;
		}
	}
	else {
		exec("tar ztvf {$uppath} | grep appctrl", $out, $ret);
		if (count($out) == 0) {
			if(file_exists($uppath)) unlink($uppath);
			set_errmsg(MSG_LEVEL_DEF, __function__, '升级包不正确！');
			return false;
		}

		exec("tar ztvf {$uppath} | grep app.inf", $out, $ret);
		if (count($out) == 0) {
			if(file_exists($uppath)) unlink($uppath);
			set_errmsg(MSG_LEVEL_DEF, __function__, '升级包不正确！');
			return false;
		}
		
		exec("mkdir -p /usr/logdata/tmp/app");
		exec("rm -rf /usr/logdata/tmp/app/*");
		exec("tar zxf {$uppath} -C /usr/logdata/tmp/app");
		
		if (file_exists("/usr/logdata/tmp/app/app.inf")) {
			if (($fp = fopen("/usr/logdata/tmp/app/app.inf", "r")) != false) {
				while (!feof($fp)) {
					$buf = fgets($fp);
					if (strstr($buf, "app_cname=") != false) {
						$ds = explode('=', $buf);
						$app_cname = str_replace('"', '', trim($ds[1], "\r\n"));
					}
					if (strstr($buf, "app_cname_en=") != false) {
						$ds = explode('=', $buf);
						$app_cname_en = str_replace('"', '', trim($ds[1], "\r\n"));
					}
					if (strstr($buf, "app_version") != false) {
						$ds = explode('=', $buf);
						$app_version = trim($ds[1], "\r\n");
						$app_version = str_replace('"', '', $app_version);
					}
				}
			}
		}
		exec("rm -rf /usr/logdata/tmp/app/*");
	}

	$uptime = time(NULL);
	$upsize = filesize($uppath);
	
	$sql = "select count(*) as `total` from upload_bags where filename = ?";

	try {
		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $upname, \PDO::PARAM_STR);
		$sth->execute();

		$row = $sth->fetch(\PDO::FETCH_LAZY);
		if($row && $row->total > 0) {
			$frmData = array(
				'filesize'		=> $upsize,
				'uptime'		=> $uptime,
				'app_cname'		=> $app_cname . '|' . $app_cname_en,
				'app_version'	=> $app_version,
			);

			if(update_data('upload_bags', $frmData, array('filename' => $upname)) === false) {
				$errmsg = implode(' ', $nidb->errorInfo());
				set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
				return false;
			}
		}
		else {
			$frmData = array(
				'filename'		=> $upname,
				'filesize'		=> $upsize,
				'uptime'		=> $uptime,
				'app_cname'		=> $app_cname . '|' . $app_cname_en,
				'app_version'	=> $app_version,
			);

			if(insert_data('upload_bags', $frmData) === false) {
				$errmsg = implode(' ', $nidb->errorInfo());
				set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
				return false;
			}
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	return true;
}

function remove($data)
{
	global $nidb;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['filename']) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '请选择要删除的文件。');
		return false;
	}

	$file = array();
	if(is_array($data['filename']) == false)
		$file = explode(",", $data['filename']);
	else
		$file = $data['filename'];

	foreach($file as $name) {
		if(preg_match("/^([a-zA-Z0-9-_.]{4,})$/", $name, $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "升级包“{$name}”不正确！");
			return false;
		}
	}

	if(count($file) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "删除对象不能为空！");
		return false;
	}

	foreach($file as $name) {
		if (file_exists(PANABIT_BAGS_PATH . "/" . $name))
			unlink(PANABIT_BAGS_PATH . "/" . $name);
	}

	$str = "?";
	if(count($file) > 1)
		$str.= str_repeat(',?', count($file) - 1);

	$sql = "delete from upload_bags where filename in ({$str})";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($file);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}
