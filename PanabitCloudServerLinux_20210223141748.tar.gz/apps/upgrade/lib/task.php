<?php
namespace cloud\apps\upgrade\task;


function select($data)
{
	global $nidb, $user;



	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(is_supadmin($user->username))
			$where_str = '';
		else {
			$where_str = '`create_user` = ? and ';
			array_push($values, $user->username);
		}
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`filename` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);


	$order_map = array(
		"task_id",
		"upgrade_bag",
		"upgrade_start",
		"total",
		"succ",
		"fail",
		"updesc",
		"upgrade_pro",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by task_id desc';

	$sql = "select count(*) as `total` from cloud_task $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`task_id`,
		`upgrade_bag`,
		`upgrade_start`,
		`total`,
		`succ`,
		`fail`,
		`updesc`,
		`upgrade_pro`';

	$sql = "select $keys from cloud_task $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$now = time();
	foreach($rows as $key => $val) {
		$rows[$key]->updesc = iconv("gbk", "utf-8", $val->updesc);
		$rows[$key]->upgrade_start = intval($val->upgrade_start);
		$rows[$key]->now 	= $now;
	}

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function remove($data)
{
	global $nidb;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(isset($data['task_id']) == false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, '请选择要删除的任务。');
		return false;
	}

	$taskid = array();
	if(is_array($data['task_id']) == false)
		$taskid = explode(",", $data['task_id']);
	else
		$taskid = $data['task_id'];

	foreach($taskid as $key => $id) {
		$taskid[$key] = intval($id);
		if($taskid[$key] <= 0) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "任务“{$key}->{$id}”不正确！");
			return false;
		}
	}

	if(count($taskid) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "任务不能为空！");
		return false;
	}

	$cmd = DATAEYE . " als_upgrade remove task=1 taskid=" . implode(',', $taskid);
	exec($cmd, $out, $ret);

	$str = "?";
	if(count($taskid) > 1)
		$str.= str_repeat(',?', count($taskid) - 1);

	try {
		$sql = "delete from cloud_upgrade where task_id in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($taskid);

		$sql = "delete from cloud_task where task_id in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($taskid);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function create($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$optional = array();
	$devtable = array(
		array('name' => 'panabit', 'cname' => '网关设备'),
		array('name' => 'ixcache', 'cname' => '缓存设备'),
	);
	
	if(format_and_push($data, 'type', $optional, '', 'int', false) == false
	|| isset($devtable[$optional['type'] - 1]) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择一个有效的升级对象。');
		return false;
	}
	$type = $devtable[$optional['type'] - 1];
	if(format_and_push($data, 'package', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定一个有效的升级包。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_.]{10,})$/", $optional['package'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "升级包“{$optional['package']}”不正确！");
		return false;
	}

	if(format_and_push($data, 'upgrade_time', $optional, '', 'string', false)) 
		$optional['upgrade_time'] = strtotime($optional['upgrade_time']);
	else
		$optional['upgrade_time'] = time();

	if(format_and_push($data, 'desc', $optional, '', 'string', false) == false)
		$optional['desc'] = '';

	if(isset($data['devs']) == false || is_array($data['devs']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	$devs = array();
	foreach($data['devs'] as $val) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $val['s'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$val['s']}”不正确！");
			return false;
		}
		if(isset($val['n']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "“{$val['s']}”的设备名称不能为空！");
			return false;
		}
		if(isset($val['v']) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "“{$val['s']}”的设备版本不能为空！");
			return false;
		}
		array_push($devs, array(
			'serialno'	=> $val['s'],
			'name'		=> iconv("utf-8", "gbk", $val['n']),
			'version'	=> iconv("utf-8", "gbk", $val['v']),
		));
	}
	
	if(count($devs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}


	cloud_insertlog($user->username, "创建升级任务");	

	try {

		$taskid = 0;
		$sql = "select task_id from cloud_task order by task_id desc limit 1";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		if(($row = $sth->fetch(\PDO::FETCH_ASSOC))) {
			if ($row['task_id'] > $taskid)
				$taskid = $row['task_id'];
		}
		$taskid++;

		/*
		 * Create task
		 */
		$frmData = array(
			'task_id'		=> $taskid,
			'total'			=> count($devs),
			'upgrade_type'	=> $type['cname'],
			'upgrade_pro'	=> $type['name'],
			'create_user'	=> $user->username,
			'updesc'		=> $optional['desc'],
			'upgrade_bag'	=> $optional['package'],
			'upgrade_start'	=> $optional['upgrade_time'],
		);

		if(insert_data('cloud_task', $frmData) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}

		foreach($devs as $key => $val) {
			$sql = "select * from cloud_upgrade where license_id12='{$val['serialno']}' and task_id={$taskid}";
			$sth = $nidb->prepare($sql);
			$sth->execute();
			$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
			if(count($rows) > 0)
				continue;

			$frmData = array(
				'task_id'		=> $taskid,
				'license_id12'	=> $val['serialno'],
				'name'			=> $val['name'],
				'ori_version'	=> $val['version'],
				'upgrade_type'	=> $type['cname'],
				'upgrade_pro'	=> $type['name'],
				'upgrade_bag'	=> $optional['package'],
				'upgrade_start'	=> $optional['upgrade_time'],
			);

			if(insert_data('cloud_upgrade', $frmData) === false) {
				$errmsg = implode(' ', $nidb->errorInfo());
				set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
				return false;
			}
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function showson($data)
{
	global $nidb, $user;


	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	if(format_and_push($data, 'task_id', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的任务不正确。');
		return false;
	}
	if($optional['task_id'] <= 0){
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的任务不正确。');
		return false;
	}

	$where_str = '`task_id` = ' . $optional['task_id'] . ' and '; 

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`license_id12` like ? or `name` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$rows = array();
	$cmd = DATAEYE . " als_upgrade list showdevice=1 taskid={$optional['task_id']}";
	exec($cmd, $out, $ret);
	if($ret == 0 && $out && count($out) > 1) {
		foreach($out as $k=>$val) {
			list($taskid, $license_id12, $sysname, $status, $ver, $new_ver, $resp) = explode(' ', $val);
			if ($taskid == "taskid" || $taskid == "")
				continue;

			array_push($rows, array(
				"license_id12"	=> $license_id12,
				"name"			=> iconv("gbk", "utf-8", $sysname),
				"ori_version"	=> iconv("gbk", "utf-8", $ver),
				"last_version"	=> iconv("gbk", "utf-8", $new_ver),
				"servertime"	=> time(NULL),
				"complete"		=> $status,
				"errors"		=> iconv("gbk", "utf-8", $resp),
				"task_id"		=> (int)$taskid
			));
		}

		return array(
			'rows'	=> $rows,
			'total'	=> count($rows),
			'limit'	=> $optional['limit'],
			'now'	=> time()
		);
	}
	
	$order_map = array(
		"task_id",
		"license_id12",
		"name",
		"ori_version",
		"last_version",
		"upgrade_start",
		"complete",
		"errors",
		"upgrade_bag",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	$sql = "select count(*) as `total` from cloud_upgrade $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`task_id`,
		`license_id12`,
		`name`,
		`ori_version`,
		`last_version`,
		`upgrade_start`,
		`complete`,
		`errors`,
		`upgrade_bag`';

	$sql = "select $keys from cloud_upgrade $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($rows as $key => $val) {
		$rows[$key]->name = iconv("gbk", "utf-8", $val->name);
		$rows[$key]->ori_version = iconv("gbk", "utf-8", $val->ori_version);
		$rows[$key]->errors = iconv("gbk", "utf-8", $val->errors);
		$rows[$key]->last_version = iconv("gbk", "utf-8", $val->last_version);
	}

	$result['rows'] = $rows;
	$result['limit'] = $optional['limit'];
	$result['now'] = time();

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function rmvson($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$optional = array();

	if(format_and_push($data, 'task_id', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的任务不正确。');
		return false;
	}
	if(format_and_push($data, 'serialno', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的任务不正确。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}

	$cmd = DATAEYE . " als_upgrade remove taskid={$optional['task_id']} license_id12={$optional['serialno']} device=1";
	exec($cmd, $out, $ret);
	
	try {
		$sql = "delete from cloud_upgrade where license_id12='{$optional['serialno']}' and task_id={$optional['task_id']}";
		$ret = $nidb->query($sql);
		
		$sql = "delete from cloud_upgrade_log where license_id12='{$optional['serialno']}' and task_id={$optional['task_id']}";
		$ret = $nidb->query($sql);
		
		$sql = "select total from cloud_task where task_id={$optional['task_id']}";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if($row) {
			$total = $row['total'] - 1;

			$sql = "update cloud_task set total={$total} where task_id={$optional['task_id']}";
			$ret = $nidb->query($sql);
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function retry($data)
{
	global $nidb;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$optional = array();
	if(format_and_push($data, 'task_id', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的任务不正确。');
		return false;
	}
	if(format_and_push($data, 'serialno', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的任务不正确。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $optional['serialno'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$optional['serialno']}”不正确！");
		return false;
	}

	try {
		$sql = "select `upgrade_bag`, `complete` from cloud_upgrade";
		$sql.= " where `task_id` = {$optional['task_id']} and `license_id12` = '{$optional['serialno']}'";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	if(!$row) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "无此任务！");
		return false;
	}
	if($row && $row['complete'] == 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "此台设备已经在升级的序列中！");
		return false;
	}
	if (!file_exists(PANABIT_BAGS_PATH . "/" . $row['upgrade_bag'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "此台设备升级用的升级包已经不存在！");
		return false;
	}


	try {
		$frmData = array(
			'complete'		=> 0,
			'upgrade_start'	=> time(),
			'errors'		=> '',
		);

		$where = array(
			'task_id'		=> $optional['task_id'],
			'license_id12'	=> $optional['serialno'],
		);

		if(update_data('cloud_upgrade', $frmData, $where) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}

		// set fail count - 1
		$sql = "update cloud_task set `fail` = `fail` - 1 where `task_id` = {$optional['task_id']}";
		$ret = $nidb->query($sql);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}
