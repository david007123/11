// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

function getcol_state(d)
{
	return d.app_status;
}

function setcol_devlist(d)
{
	var state = getcol_state(d);
	var html = '';
	if(typeof this.mytemplet == 'function') {
		html = this.mytemplet.call(this, d, state);
	}
	else
	if(this.field == undefined)
		return html;
	else
		html = d[this.field];

	if(state != "enable")
		return '<div class="off_txt">' + html + '</div>';
	else
		return html;
}

function col_appuplist(d)
{
	var html = '';

	if (this.field == undefined)
		return html;
	else
		html = d[this.field];

	if(this.field == 'complete') {
		switch (d.complete) {
			case 2:
				html = '<img src="assets/img/online.png" class="icon" title="升级成功"/>';
				break;
			case 3:
				html = '<img src="assets/img/off.png" class="icon" title="升级失败"/>';
				break;
			default:
				html = '<img src="assets/img/loading.gif" class="icon" title="正在升级"/>';
				break;
		}
	}
	
	if (this.field == 'errors' && d.complete == 2)
		return '升级成功';
	else
	if (d.complete == 3)
		return '<div class="off_txt">' + html + '</div>';
	else
		return html;
}

function col_appdevlist(d)
{
	var html = '';

	if(typeof this.mytemplet == 'function') {
		html = this.mytemplet.call(this, d);
	}
	else
	if (this.field == undefined)
		return html;
	else
		html = d[this.field];

	return html;
}

layui.use(['element', 'form', 'upload', 'table', 'layer'], function() {
	var element = layui.element;
	var form = layui.form;
	var table = layui.table;
	var layer = layui.layer;
	var upload = layui.upload;
	var timer = new taskTimer();

	timer.add('apps_upgradecount', 3, {fuc: function(){
		var that = this;
		$.ajax({
			url: 'api.php?r=upgrade@apps-upgradecount',
			type: 'post',
			success(d) {
				if(ajax_resultCallBack(d) == false) return;
				$('#tb_toolbar .currentupgrade .icontext>span').text(d.data);
				// timer.rmv('apps_upgradecount');
			}
		});
	}}, 1);
	
	function maingroup_refresh (){
		timer.add('read_group', 3, {fuc: function(){
			var that = this;
			$.ajax({
				url: 'api.php?r=gateway@group',
				type: 'post',
				success(d) {
					if(ajax_resultCallBack(d) == false) return;
					var i, data = d.data;
					
					$('#tb_toolbar select[lay-filter="filter-group"] option').not('[value="-1"]').remove();
					for(i = 0; i < data.rows.length; i++) 
						$('select[lay-filter="filter-group"]')
						.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

					form.render('select');
					timer.rmv('read_group');
				}
			});
		}}, 1);
	}
	maingroup_refresh();

	table.render({
		elem: '#packagelist',
		even: true,
		loading: false,
		url: 'api.php?r=upgrade@package-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		where: {
			type: 'APP'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#packagelist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
				}, {
					field: 'filename',
					title: '文件名',
				}, {
					field: 'app_cname',
					title: 'App名称',
				}, {
					field: 'app_version',
					title: 'App版本',
				}, {
					title: '文件大小',
					templet: function(d) {
						return numberformats(d.filesize);
					}
				}, {
					field: 'uptime',
					title: '上传时间',
					width: 130,
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.uptime, 'yyyy-MM-dd HH:mm:ss');
					}
				}, {
					field: 'servertime',
					title: '操作',
					width: 100,
					templet: function(d) {
						return '<a class="setBtn" href="/paupbags/' + d.filename + '" target="_blank">下载</a><span>&nbsp;|&nbsp;</span><span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});

	upload.render({
		elem: '#uppackage',
		url: 'api.php?r=upgrade@package-upload',
		data: {type: 'APP'},
		field: 'package',
		dataType: "text",
		drag: true,
		accept: 'file',
		before: function(obj) {
			layer.load();
		},
		done: function(d) {
			layer.closeAll('loading');
			if(ajax_resultCallBack(d) === false) {
				layer.msg(d.msg, {icon: 5});
				return;
			}
			if (d.msg) layer.msg(d.msg, {
				icon: 1
			});
			table.reloadExt('packagelist', {
				page: {
					curr: 1
				}
			});
		},
		error: function(index, upload) {
			layer.closeAll('loading'); //关闭loading
		}
	});
	
	table.on('tool(packagelist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'del') {
			layer.confirm('确认要删除升级包吗?', {
				icon: 0,
				title: '升级包删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@package-remove',
					data: {
						filename: data.filename
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('packagelist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	$('#remove-pack').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('lay-filter');
		var checkStatus = table.checkStatus('packagelist');
		var filenames = [];

		checkStatus.data.forEach(function(e, i) {
			filenames.push(e.filename);
		});

		if (event == 'del') {
			if (filenames.length <= 0) {
				layer.msg('请先选择要删除的升级包。');
				return;
			}

			layer.confirm('确认要删除这些升级包吗?', {
				icon: 0,
				title: '升级包删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@package-remove',
					data: {
						filename: filenames
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
						 	return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('packagelist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	table.render({
		elem: '#applist',
		even: true,
		loading: false,
		url: 'api.php?r=upgrade@apps-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#applist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
				}, {
					field: 'serialno',
					title: '编号',
					templet: setcol_devlist
				}, {
					field: 'sysname',
					title: '系统名称',
					templet: setcol_devlist
				}, {
					field: 'grpid',
					title: '属组',
					templet: setcol_devlist,
					mytemplet: function(d) {
						var grpname;
						if(d.grpid == 0) return '';
						grpname = $('#tb_toolbar select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, 
				{
					field: 'app_cname',
					title: '名称',
					templet: setcol_devlist
				},{
					field: 'app_version',
					title: '版本',
					templet: setcol_devlist
				}, {
					title: '状态',
					width: 40,
					templet: setcol_devlist,
					mytemplet: function(d) {
						if(d.startmask != '0') {
							return '<img src="assets/img/loading.gif" class="icon" title="更新中" style="width: 18px;"/>';
						}
						if (d.app_status == "enable") {
							return '<img src="assets/img/online.png" class="icon" title="启用" style="width: 18px;"/>';
						} else {
							return '<img src="assets/img/off.png" class="icon" title="禁用" style="width: 18px;"/>';
						}
					}
				}, {
					title: '操作',
					width: 50,
					templet: function(d) {
						if (d.app_status == "enable") {
							return '<span class="setBtn" lay-event="enable">禁用</span>';
						}
						else {
							return '<span class="setBtn" lay-event="enable">启用</span>';
						}
					}
				}
			]
		]
	});
	
	table.on('tool(applist)', function(obj){
		var data = obj.data,
			stat = (data.app_status == 'enable'? 1:0),
			event = obj.event;

		if(event == 'enable') {
			layer.confirm('确定要' + (stat ? '<span class="off_txt">禁用</span>' : '<span style="color:#30A645;">启用</span>') + '“<span style="font-weight: bold;">' + data.app_cname + '</span>”APP吗？', {
				icon: 0,
				title: 'APP 启动/停止'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@apps-control',
					data: {
						op: [{s: data.serialno, n: data.app_name, e: stat}]
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						search();
					},
					error: function() {
						layer.msg('操作失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	// 搜索
	function search(page, obj) 
	{
		var grpid = Number($('#tb_toolbar select[lay-filter="filter-group"]').val());
		var where = {
				grpid: 0,
				keyword: $.trim($('#tb_toolbar input[name="keyword"]').val()),
				reverse: 0
			};

		if(grpid) where.grpid = grpid;

		var option = {
				method: 'post',
				where: where
		};
		if(typeof page == "number") {
			if(page > 0)
				option.page = {curr: page}; //重新从第 1 页开始
		}
		else
			page = 0;

		if(obj) {
			if(obj.field) where.sort = obj.field;
			if(obj.type) where.g_ascdesc = obj.type;
		}
		else {
			option.wherecb = function(w) {
				var op = {};
				if (w.sort && w.g_ascdesc) {
					op.sort = w.sort;
					op.g_ascdesc = w.g_ascdesc;
				}
				return op; 
			}
		}

		table.reloadExt('applist', option);
		
		timer.add('update_appslist', 3, {fuc: function(){
			if($('[lay-id="applist"] img[title="更新中"]').length <= 0) {
				timer.rmv('update_appslist');
				return;
			}
			search();
		}});
	}

	form.on('select(filter-group)', function(data) {
		search(1);
	});

	$('#searchbtn').on('click', function() {
		search(1);
	});

	$('#tb_toolbar input[name="keyword"]').keyup(function(event){
		if(event.keyCode == 13){
			search(1);
		}
	});

	//当前升级中的APP
	var first;
	$('.currentupgrade').on('click', function() {
		layer.open({
			type: 1,
			title: '当前升级中的APP',
			area: ['700px', '500px'],
			shadeClose: true,
			//resize: true,
			// maxmin: true,
			content: $('#tpl-appuplist').html(),
			resizing: function(layero) {
			},
			myrefresh: function(index, layero) {
				if($('[lay-id="appuplist"]').length == 0) {
					layer.close(index);
					return;
				}
				
				$.ajax({
					url: 'api.php?r=upgrade@apps-showtask',
					data: {limit: 1000},
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						
						if(first) {
							first = 0;
							table.reload('appuplist', {
								data: d.data.rows,
								done: function(res, curr, count) {
									$('[lay-id="appuplist"]').css('margin-top', '0px');
								}
							});
						}
						else {
							var rows = layero.find('[lay-id="appuplist"] .layui-table-main>table tr[data-index]');
							d.data.rows.forEach(function(e, i) {
								if(rows.eq(i).attr('complete') == e.complete) return;
								rows.eq(i).attr('complete', e.complete);

								rows.eq(i).find('[data-field="id"] .layui-table-cell')
								.html(col_appuplist.call({field: 'id'}, e));
								rows.eq(i).find('[data-field="license_id12"] .layui-table-cell')
								.html(col_appuplist.call({field: 'license_id12'}, e));
								rows.eq(i).find('[data-field="name"] .layui-table-cell')
								.html(col_appuplist.call({field: 'name'}, e));
								rows.eq(i).find('[data-field="app_name"] .layui-table-cell')
								.html(col_appuplist.call({field: 'app_name'}, e));
								rows.eq(i).find('[data-field="ori_version"] .layui-table-cell')
								.html(col_appuplist.call({field: 'ori_version'}, e));

								rows.eq(i).find('[data-field="last_version"] .layui-table-cell')
								.html(col_appuplist.call({field: 'last_version'}, e));
								rows.eq(i).find('[data-field="complete"] .layui-table-cell')
								.html(col_appuplist.call({field: 'complete'}, e));
								rows.eq(i).find('[data-field="errors"] .layui-table-cell')
								.html(col_appuplist.call({field: 'errors'}, e));
							});
						}
					}
				});
			},
			success: function(layero, index) {
				var that = this;
				table.init('appuplist');

				$('[lay-id="appuplist"]').css('margin-top', '0px');
				first = 1;
				timer.add('read_group', 3, {fuc: function(){
					that.myrefresh(index, layero);
				}}, 1);
				
			}
		});
	});
	
	$('.appcontrol').on('click', function() {
		var checkStatus = table.checkStatus('applist');
		var devs = [];

		checkStatus.data.forEach(function(e, i){
			devs.push({s: e.serialno, n: e.app_name, e: (e.app_status == 'enable'? 1:0)});
		});

		if(devs.length == 0) {
			layer.msg('请先选择要操作的设备。');
			return;
		}

		layer.confirm('操作后APP自动根据自己的状态启动或停止，确认要操作吗？', {
			icon: 0,
			title: 'APP 启动/停止'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=upgrade@apps-control',
				data: {
					op: devs
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if(ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {icon: 5});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					search();
				},
				error: function() {
					layer.msg('操作失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});
	
	//升级app
	$('.upgradeapp').on('click', function() {
		layer.open({
			type: 1,
			title: '升级APP',
			area: ['800px', '540px'],
			shadeClose: true,
			//resize: true,
			// maxmin: true,
			content: $('#tpl-taskset').html(),
			resizing: function(layero) {
			},
			myrefresh: function(index, layero) {
				var reverse;
				var grpid;
				var e = layero.find('select[lay-filter="upbags"]');
				var appcname = $.trim(e.children('option[value="' + e.val() + '"]').attr('app-cname'));
				
				if($('[lay-id="taskset"]').length == 0) {
					layer.close(index);
					return;
				}
				
				grpid = layero.find('select[name="grpid"]').val();

				reverse = (layero.find('[lay-filter="noinstall"]').eq(0).prop("checked") ? 1 : 0);

				$.ajax({
					url: 'api.php?r=upgrade@apps-list&onlyone=1',
					data: {
						notmout: 1,
						grpid: grpid,
						limit: 10000,
						keyword: $.trim(layero.find('input[name="keyword"]').val()),
						app: appcname,
						reverse: reverse
					},
					type: 'POST',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						table.reload('equipmentlist').config.parseData(d);
						table.reload('equipmentlist', {
							data: d.data,
							page: {
								curr: 1
							}
						});
					}
				});
			},
			myupbagschg: function (layero){
				var v, s = layero.find('select[name="upbags"] option:selected').text();
				var reverse = (layero.find('[lay-filter="noinstall"]').eq(0).prop("checked") ? 1 : 0);
				
				if (layero.find('select[name="upbags"] option:selected').val() == "") 
					return;

				if(!reverse) {
					layero.find('input[name="keyword"]').val('');
					return;
				}

				v = s.split("--");

				if (!reverse)
					layero.find('input[name="keyword"]').val($.trim(v[1]));
				else
					layero.find('input[name="keyword"]').val($.trim(v[1]) + ',' + $.trim(v[2]));
			},
			success: function(layero, index) {
				var tab, that = this;

				$('[lay-id="equipmentlist"]').css('margin-top', '0px');
				
				tab = layero.find('select[name="grpid"]');
				$('#tb_toolbar select[name="grpid"] option').not('[value="-1"]').each(function(i, e) {
					tab.append($(e).clone());
				});
				
				form.on('checkbox(noinstall)', function(data) {
					that.myupbagschg(layero);
					that.myrefresh(index, layero);
				});

				form.on('checkbox(nred)', function(data) {
					that.myrefresh(index, layero);
				});
				
				form.on('select(filter-group)', function(data) {
					that.myrefresh(index, layero);
				});

				$('#task_toolbar input[name="keyword"]').keyup(function(event){
					if(event.keyCode == 13){
						that.myrefresh(index, layero);
					}
				});
				
				form.on('select(upbags)', function(data) {
					var reverse = (layero.find('[lay-filter="noinstall"]').eq(0).prop("checked") ? 1 : 0);
					if(reverse)
						that.myupbagschg(layero);
					that.myrefresh(index, layero);
				});
				
				layero.find('button[lay-filter="search"]').on('click', function(){
					that.myrefresh(index, layero);
				});
				
				layero.find('button[lay-filter="upgradenow"]').on('click', function(){
					var packages = $("#upbags").val();
				
					if (packages == '') {
						layer.alert("请选择升级包");
						return false;
					}

					var v = layero.find('select[name="upbags"] option:selected').text().split("--");
					var appname = $.trim(v[1]);
					var version = $.trim(v[2]);
					var devs = [];
					var checkStatus = table.checkStatus('equipmentlist');
					checkStatus.data.forEach(function(e, i) {
						var obj = {
							s: e.serialno,
							n: e.sysname
						}
						devs.push(obj);
					});
					if (devs.length <= 0) {
						layer.alert("请选择要升级的设备");
						return;
					}

					layer.confirm("确定需要升级这些设备吗？", {
						btn: ['确定', '取消']
					}, function(index) {
						layer.close(index);
						$.ajax({
							url: 'api.php?r=upgrade@apps-create',
							data: {
								devs: devs,
								appname: appname,
								version: version,
								package: packages
							},
							dataType: 'json',
							type: 'post',
							success: function(d) {
								if(ajax_resultCallBack(d) == false) {
									if(d.msg)
										layer.msg(d.msg, {icon: 5});
									return;
								}
								if (d.msg) layer.msg(d.msg, {
									icon: 1
								});
								
								table.reloadExt('applist', {
									page: {
										curr: 1
									}
								});

								$('.currentupgrade').click();
							}
						});
					});
					
				});

				timer.add('read_appupbags_list', 3, {fuc: function(){
					var that = this;
					$.ajax({
						url: 'api.php?r=upgrade@package-list',
						data: {
							type: 'APP'
						},
						type: 'post',
						success(d) {
							if(ajax_resultCallBack(d) == false) return;
							var cname, op, i, data = d.data;

							layero.find('select[lay-filter="upbags"] option').not('[value=""]').remove();
							for(i = 0; i < data.rows.length; i++) {
								cname = data.rows[i].app_cname.split('|');
								op = new Option(data.rows[i].filename + '-- ' + cname[0] + '-- ' + data.rows[i].app_version, data.rows[i].filename);
								op.getAttribute('app-cname', cname[0]);
								layero.find('select[lay-filter="upbags"]').append(op);
							}

							form.render('select');
							timer.rmv('read_appupbags_list');
						}
					});
				}}, 1);
				
				form.render();

				table.render({
					elem: '#equipmentlist',
					even: true,
					loading: false,
					skin: 'line',
					limit: 50,
					limits: [50,100,150,200],
					page: true,
					defaultToolbar: ['filter', 'print', 'exports', {
						title: '提示',
						layEvent: 'LAYTABLE_TIPS',
						icon: 'layui-icon-tips'
					}],
					parseData: function(res) {
						var data = res.data;

						if (res.ret == 0) {
							var rows = [];
							var bagname = $("#upbags").val();
							var appname = $.trim(layero.find('select[lay-filter="upbags"] option[value="' + layero.find('select[lay-filter="upbags"]').val() + '"]').text().split('--')[1]);
							//if (layero.find('[name="nred"]').eq(0).prop("checked")) {
								data.rows.map(function(d) {
									// 过滤断线
									if (d.systime - d.time >= 60) {
										return;
									}
									d.appcname = '';
									d.appversion = '';
									d.apps.sort(function(a,b){
										if(!d.app && a.cname == appname) {
											d.appcname = a.cname;
											d.appversion = a.version;
										}
										if(a.cname > b.cname) return 1;
										else if(a.cname == b.cname) return 0;
										return -1;
									});
									rows.push(d);
								});
								res.data	= rows;
								res.count	= rows.length;
							//}
							//else  {
							//	res.count	= data.total;
							//	res.data	= data.rows;
							//}

						}
						res.code = res.ret;
						res.msg = res.msg;
					},
					done: function(res, curr, count) {
					},
					cols: [
						[{
								field: 'id',
								title: '序号',
								width: 40,
								fixed: 'left',
								type: 'numbers',
								templet: col_appdevlist
							},
							{
								type: 'checkbox',
							}, {
								field: 'serialno',
								width: 110,
								title: '设备编号',
								sort: true,
								templet: col_appdevlist
							}, {
								field: 'sysname',
								title: '设备名称',
								sort: true,
								templet: col_appdevlist
							}, {
								field: 'grpid',
								width: 150,
								title: '所属组',
								sort: true,
								templet: col_appdevlist,
								mytemplet: function(d) {
									var grpname;
									if (d.grpid == 0) return '';
									grpname = layero.find('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
									return grpname;
								}
							}, {
								field: 'appversion',
								title: 'APP',
								sort: true,
								templet: col_appdevlist,
								mytemplet: function(d) {
									var app, str = '';
									if(d.appversion) 
										str += '<br>' + d.appcname + ' [' + d.appversion + ']';

									for(i = 0; i < d.apps.length; i++) {
										app = d.apps[i];
										if(d.appcname == app.cname) continue;
										str += '<br>' + app.cname + ' [' + app.version + ']';
									}
									return str.substr(4);
								}
							}
						]
					]
				});
			}
		});
	});
});
