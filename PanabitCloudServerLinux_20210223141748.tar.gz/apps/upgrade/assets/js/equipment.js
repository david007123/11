// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

var flag = false;

function addzero(str) {
	if (str.length <= 1) {
		str = '0' + str;
	}
	return str;
}

function unique(arr) {
	for (var i = 0; i < arr.length; i++) {
		for (var j = i + 1; j < arr.length; j++) {
			if (arr[i] == arr[j]) {
				arr.splice(j, 1);
				j--;
			}
		}
	}
	return arr;
}

function getOperate(r) {
	var mk = "";
	if (r.complete == "3") {
		mk += '<a lay-event="updateAgain" class="setBtn">再次升级</a>'
		mk += '&nbsp;&nbsp;|&nbsp;&nbsp;';
	}
	mk += '<a lay-event="cancelUpdate" class="setBtn">删除</a>';
	return mk;
}

function getTaskStatus(r) {
	if (r.complete == "0")
		return "等待升级";
	else if (r.complete == "1")
		return "正在升级";
	else if (r.complete == "2")
		return "当前在线";
	else if (r.complete == "3") {
		return "断开连接";
		mk = '<a href="javascript:upgrade_again(' + r.task_id + ', \'' + r.license_id12 + '\')" class="setBtn">再次升级</a>';
		mk += '&nbsp;&nbsp;|&nbsp;&nbsp;';
	}
}

var timer = new taskTimer();
layui.use(['element', 'upload', 'table', 'form', 'layer', 'laydate'], function() {
	var element = layui.element;
	var upload = layui.upload;
	var table = layui.table;
	var form = layui.form;
	var layer = layui.layer;
	var laydate = layui.laydate;
	var tablelns;
	var taskTable;


	tablelns = table.render({
		elem: '#packagelist',
		even: true,
		url: 'api.php?r=upgrade@package-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.code = 0;
			res.count = res.data.total;
			res.data = res.data.rows;
			res.msg = '';
			
			var e = $('#packagelist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[{
					field: 'id',
					title: '序号',
					fixed: 'left',
					width: 40,
					type: 'numbers'
				},
				{
					type: 'checkbox',
					width: 40,
				}, {
					field: 'filename',
					title: '文件名',
					minWidth: 390,
				}, {
					field: 'filename',
					title: '类型',
					templet: function(d) {
						if ((d.filename).indexOf("FREE") != -1)
							return '标准版';
						else if ((d.filename).indexOf('WB') != -1)
							return '网吧版';
						else if ((d.filename).indexOf('DPI') != -1 &&
							(d.filename).indexOf('pdb') != -1)
							return '特征库';
						return '<span style="color:red">专业版</span>';
					}
				}, {
					field: 'filesize',
					title: '文件大小',
					templet: function(d) {
						return numberformats(d.filesize);
					}
				}, {
					field: 'uptime',
					title: '上传时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.uptime, true);
					}
				}, {
					title: '操作',
					width: 100,
					templet: function(d) {
						return '<span class="setBtn" lay-event="download">下载</span><span>&nbsp;|&nbsp;</span><span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});

	upload.render({
		elem: '#uppackage',
		url: 'api.php?r=upgrade@package-upload',
		data: {
			type: 'upbagsupload'
		},
		field: 'package',
		dataType: "text",
		drag: true,
		accept: 'file',
		before: function(obj) {
			layer.load();
		},
		done: function(d) {
			layer.closeAll('loading');
			if(ajax_resultCallBack(d) === false) {
				layer.msg(d.msg, {icon: 5});
				return;
			}
			if (d.msg) layer.msg(d.msg, {
				icon: 1
			});
			table.reloadExt('packagelist', {
				page: {
					curr: 1
				}
			});
		},
		error: function(index, upload) {
			layer.closeAll('loading');
		}
	});

	table.on('tool(packagelist)', function(obj) {
		var data = obj.data,
			event = obj.event;
		if (event == 'del') {
			layer.confirm('确认要删除升级包吗?', {
				icon: 0,
				title: '升级包删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@package-remove',
					data: {
						// type: 'upbags_delete',
						filename: data.filename
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('packagelist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == 'download') {
			window.open("../paupbags/" + data.filename, "_blank");
		}
	});

	$('#tb_toolbar button').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('lay-filter');
		var checkStatus = table.checkStatus(tablelns.config.id);
		var filenames = [];
		checkStatus.data.forEach(function(e, i) {
			filenames.push(e.filename);
		});
		if (event == 'del') {
			if (filenames.length <= 0) {
				layer.msg('请先选择要删除的升级包。');
				return;
			}

			layer.confirm('确认要删除这些升级包吗?', {
				icon: 0,
				title: '升级包删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@package-remove',
					data: {
						type: 'upbags_delete',
						filename: filenames.join(',')
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('packagelist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	taskTable = table.render({
		elem: '#tasklist',
		even: true,
		url: 'api.php?r=upgrade@task-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'task_id',
			type: 'desc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],

		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = 0;
			res.msg = '';

			var e = $('#packagelist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		cols: [
			[{
					field: 'task_id',
					title: '任务编号',
					width: 60
				},
				{
					type: 'checkbox',
					width: 30
				}, {
					title: '状态',
					sort: true,
					width: 120,
					templet: function(d) {
						var start = d.upgrade_start;
						now = d.now,
							at = start - now;
						if (at >= 0)
							return '<span style="color:#CAC074;font-weight:bold;">' + at + '后开始升级</span>';
						else if (at < 0 && (d.succ + d.fail != d.total))
							return '<span style="color:#30A645;font-weight:bold;">正在升级</span>';
						if (d.succ + d.fail == d.total)
							return '<span style="color:#30A645;font-weight:bold;">升级完成</span>';
					}
				}, {
					field: 'upgrade_bag',
					title: '升级包',
					width: 370,
					templet: function(d) {
						return '<div class="cell-left">' + d.upgrade_bag + '</div>';
					}
				}, {
					field: 'upgrade_start',
					title: '开始时间',
					width: 135,
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.upgrade_start, true);
					}
				}, {
					field: 'total',
					title: '升级台数',
					width: 72
				},
				{
					field: 'succ',
					title: '升级成功',
					width: 72
				},
				{
					field: 'fail',
					title: '升级失败',
					width: 72
				},
				{
					field: 'updesc',
					title: '说明',
					width: 150
				},
				{
					title: '操作',
					width: 90,
					templet: function(d) {
						return '<span class="setBtn" lay-event="edit_check">查看</span><span>&nbsp;|&nbsp;</span><span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});

	table.on('tool(tasklist)', function(obj) {
		var data = obj.data,
			event = obj.event,
			d = obj.rows;
		if (event == 'del') {
			layer.confirm('确认要删除任务吗?', {
				icon: 0,
				title: '任务删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@task-remove',
					data: {
						type: 'task_delete',
						task_id: data.task_id
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('tasklist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == 'edit_check') {
			layer.open({
				type: 1,
				title: '任务编号：' + data.task_id + ' -- ' + data.upgrade_bag,
				area: ['1000px', '520px'],
				shadeClose: true,
				resize: false,
				btnAlign: 'c',
				btn: ['关闭'],
				content: $('#check-taskinfo').html(),
				myrefresh: function(index, layero) {
					$.ajax({
						url: 'api.php?r=upgrade@task-view',
						dataType: 'json',
						data: {
							// type: 'obj_list',
							task_id: data.task_id
						},
						type: 'post',
						success: function(d) {
							if(ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {icon: 5});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							table.reload('taskinfolist', {
								data: d.data.rows,
							});
						}
					});
				},
				success: function(layero, index) {
					var that = this, first = 1;
					var tasktb = table.init('taskinfolist');
					tasktb.config.mywindow = that;

					timer.add('taskinfolist', 3, {
						fuc: function() {
							var that = this;
							$.ajax({
								url: 'api.php?r=upgrade@task-view',
								type: 'post',
								dataType: 'json',
								data: {
									// type: 'obj_list',
									task_id: data.task_id,
									limit: 1000
								},
								success(d) {
									if(d.ret) return;
									if(first) {
										first = 0;
										table.reload('taskinfolist', {
											data: d.data.rows
										});
									}
									else {
										var rows = layero.find('[lay-id="taskinfolist"] .layui-table-main>table tr[data-index]');
										d.data.rows.forEach(function(e, i){
											if(rows.eq(i).attr('complete') == e.complete) return;
											rows.eq(i).attr('complete', e.complete);
											/*
											rows.eq(i).find('[data-field="name"] .layui-table-cell')
											.text(e.name);
											rows.eq(i).find('[data-field="ori_version"] .layui-table-cell')
											.text(e.ori_version);
											*/
											rows.eq(i).find('[data-field="last_version"] .layui-table-cell')
											.text(e.last_version);
											rows.eq(i).find('[data-field="status"] .layui-table-cell')
											.html(getTaskStatus(e));
											rows.eq(i).find('[data-field="errors"] .layui-table-cell')
											.text(e.errors);
											rows.eq(i).find('[data-field="operate"] .layui-table-cell')
											.html(getOperate(e));
										});
									}
								}
							});
						}
					}, 1);
				},
				end: function() {
					timer.rmv('taskinfolist');
				}
			});
		}
	});
	table.on('tool(taskinfolist)', function(obj) {
		var event = obj.event,
			d = obj.data;
		if (event == 'cancelUpdate') {
			layer.confirm('确定要取消此设备的升级吗？', function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@task-rmvson',
					data: {
						// type: 'upgrade_delete_upgrade',
						task_id: d.task_id,
						serialno: d.license_id12
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});

						table.render('taskinfolist').config.mywindow.myrefresh();
						table.refresh('tasklist');
					},
					error: function() {
						layer.msg('操作失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == "updateAgain") {
			layer.confirm('确定要再次升级此设备吗？', function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@task-retry',
					data: {
						// type: 'upgrade_again',
						task_id: d.task_id,
						serialno: d.license_id12
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});

						table.render('taskinfolist').config.mywindow.myrefresh();
						table.refresh('tasklist');
					},
					error: function() {
						layer.msg('操作失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	$('#task_toolbar button').on('click', function(obj) {
		var event = obj.currentTarget.getAttribute('lay-filter');
		var checkStatus = table.checkStatus(taskTable.config.id);
		var taskArr = [];
		checkStatus.data.forEach(function(e, i) {
			taskArr.push(e.task_id);
		});
		if (event == 'del') {
			if (taskArr.length <= 0) {
				layer.msg('请先选择要删除的任务。');
				return;
			}

			layer.confirm('确认要删除这些任务吗?', {
				icon: 0,
				title: '任务删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=upgrade@task-remove',
					data: {
						type: 'task_delete',
						task_id: taskArr.join(',')
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if(ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {icon: 5});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('tasklist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	//刷新
	var taskoff = 0;

	function tasklist_fresh() {
		timer.add('task_list', 3, {
			fuc: function() {
				var that = this;
				table.reloadExt('tasklist');
			}
		}, 1);
	}
	tasklist_fresh();

	$('.upconfig').click(function() {
		$.ajax({
			url: 'api.php?r=upgrade@option',
			type: 'post',
			success(d) {
				$('#maxdown').val(d.data.maxdown);
				$('#downport').val(d.data.downport);
			}
		});
	});

	$('.close-refresh').click(function(e) {
		e.currentTarget.taskoff = !e.currentTarget.taskoff;
		if (e.currentTarget.taskoff) {
			$(this).find(".freshtext").text("打开刷新");
			e.currentTarget.taskoff = 1;
			timer.rmv('task_list');
		} else {
			$(this).find(".freshtext").text("关闭刷新");
		}
		tasklist_fresh();
	});

	$('.max-count').click(function() {
		var dwmax = $("#maxdown").val();
		if (dwmax == "" || isNaN(dwmax)) {
			alert("请输入正确的下载最大设备数");
			$("#maxdown").select();
			return false;
		}

		if (!confirm("确认要修改下载最大设备数吗"))
			return false;

		$.ajax({
			url: 'api.php?r=upgrade@option-save',
			data: {
				type: 'dwconfig',
				maxdown: dwmax
			},
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if(ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {icon: 5});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
			}
		});
	});

	$('.file-port').click(function() {
		{
			var downport = $("#downport").val();
			if (downport == "") {
				alert("请输入正确的端口号！");
				$("#downport").focus();
				return false;
			}

			if (isNaN(downport)) {
				alert("请输入正确的端口号！");
				$("#downport").focus();
				return false;
			}


			if (!confirm("确定要修改http访问的端口号吗"))
				return false;

			$.ajax({
				url: 'api.php?r=upgrade@option-save',
				data: {
					downport: downport
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if(ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {icon: 5});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				}
			});
		}
	});

	// 搜索
	function search(page, obj) {
		var grpid = Number($('select[lay-filter="filter-group"]').val());
		var version = $('select[lay-filter="filter-version"]').val();
		var txt = $.trim($('#task_toolbar input[name="keyword"]').val());
		var arr = [];

		switch(parseInt(form.val('upgrade-form-filter').upgrade_pro)) {
			case 1: 
				url = 'api.php?r=gateway@devlist';
				break;
			case 2:
				url = 'api.php?r=ixcache@devlist';
				break;
			default:
				return;
		}

		if (version == "0" || version == null) version = "";
		if (version != "") arr.push(version);

		if (txt != "")
			arr.push(txt);
		var where = {
			grpid: grpid,
			keyword: arr.join('|'),
			sort: 'serialno',
			g_ascdesc: 'asc',
			expire: 2,
		};
		if (grpid) where.grpid = grpid;
		if (version) where.version = version;

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				};
		} else
			page = 0;

		$.ajax({
			url: url,
			data: where,
			type: 'POST',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				table.reload('equipmentlist').config.parseData(d);
				table.reload('equipmentlist', {
					data: d.data,
					page: {
						curr: 1
					}
				});
			}
		});
	}

	//创建任务
	$('.newtask').on('click', function() {
		layer.open({
			type: 1,
			title: '任务管理',
			area: ['900px', '500px'],
			shadeClose: true,
			content: $('#set-task').html(),
			success: function(layero, index) {
				$("#upgradetime").hide();
				laydate.render({
					elem: '#upgradedate',
					trigger: 'click'
				});

				form.render();

				$('.keyword').keyup(function(event) {
					if (event.keyCode == 13) {
						search(1);
					}
				});

				$('.searchBtn').click(function(d) {
					search(1);
				});

				$('.upgradenow').click(function(data) {
					var packages = $("#upbags").val()
					var upgrade_pro = $("#upgrade_pro").val();
					if ($("#upgrade_pro").val() == 0) {
						layer.alert("请选择升级对象");
						return;
					}
					if ($("#upbags").val() == 0) {
						layer.alert("请选择升级包");
						return false;
					}

					var updesc = $.trim($("#updesc").val());
					var upgradetype;
					var datestr;
					var upgradedate = $("#upgradedate").val();
					var upgradehours = $("#upgradehours").val().toString();
					var upgrademin = $("#upgrademin").val().toString();
					$(".layui-form-radio").each(function() {
						if ($(this).hasClass("layui-form-radioed"))
							upgradetype = $(this).prev().val();
					});
					upgradehours = addzero(upgradehours);
					upgrademin = addzero(upgrademin);
					if (upgradetype == "later") {
						datestr = upgradedate + " " + upgradehours + ":" + upgrademin + ":0";
					}

					var devs = [];
					var checkStatus = table.checkStatus('equipmentlist');
					checkStatus.data.forEach(function(e, i) {
						var obj = {
							s: e.serialno,
							n: e.name,
							v: e.version
						}
						devs.push(obj);
					});
					if (devs.length <= 0) {
						layer.alert("请选择要升级的设备");
						return;
					}

					layer.confirm("确定需要升级这些设备吗？", {
						btn: ['确定', '取消']
					}, function(index) {
						$.ajax({
							url: 'api.php?r=upgrade@task-create',
							data: {
								devs: devs,
								desc: updesc,
								package: packages,
								upgrade_time: datestr,
								type: $('#upgrade_pro').val()
							},
							dataType: 'json',
							type: 'post',
							success: function(data) {
								if (data.res == 0) {
									layer.alert('配置成功');
								} else {
									layer.alert(data.msg);
								}
								table.reloadExt('tasklist', {
									page: {
										curr: 1
									}
								});
							}
						});
					});
				});
			}
		});

		form.on('radio(upgradetype)', function(data) {
			var v = data.value;
			if (v == "later") {
				$("#upgradetime").show();
				$(".upgrade_submit").text("稍后升级");
			} else {
				$("#upgradetime").hide();
				$(".upgrade_submit").text("立即升级");
			}
			form.render("radio");
		});

	});

	form.on('radio(upgradetype)', function(data) {
		var v = data.value;
		if (v == "later") {
			$(".update-time").css('display', 'inline-block');
			$(".upgrade_submit").text("保存配置，稍后升级");
		} else {
			$(".update-time").css('display', 'none');
			$(".upgrade_submit").text("保存配置，立即升级");
		}
	});

	form.on('select(upgrade_pro)', function(data) {
		flag = true;
		if (data.value == '1') {
			$.ajax({
				url: 'api.php?r=gateway@group',
				dataType: 'json',
				type: 'post',
				success: function(d) {
					if (ajax_resultCallBack(d) == false) return;
					var i, data = d.data;

					$('select[lay-filter="filter-group"] option').not('[value=-1]').remove();
					for (i = 0; i < data.rows.length; i++)
						$('select[lay-filter="filter-group"]')
						.append(new Option(data.rows[i].grpname, data.rows[i].grpid));
					form.render('select');
				}
			});

			$.ajax({
				url: 'api.php?r=upgrade@package-list',
				dataType: 'json',
				data: {
					limit: 1000,
					devtype: 1
				},
				type: 'post',
				success: function(d) {
					if (ajax_resultCallBack(d) == false) return;
					var i, data = d.data;

					$('select[lay-filter="upbags"] option').not('[value=0]').remove();
					for (i = 0; i < data.rows.length; i++)
						$('select[lay-filter="upbags"]')
						.append(new Option(data.rows[i].filename));

					form.render('select');
				}
			});

			table.render({
				elem: '#equipmentlist',
				even: true,
				limit: 50,
				limits: [50,100,150,200],
				skin: 'line',
				page: true,
				defaultToolbar: ['filter', 'print', 'exports', {
					title: '提示',
					layEvent: 'LAYTABLE_TIPS',
					icon: 'layui-icon-tips'
				}],
				parseData: function(res) {
					var data = res.data.rows;
					var varr = [];

					if (res.ret == 0) {
						var rows = [];
						var bagname = $("#upbags").val();
						var packtype = '',
							packtag = '';

						if ($("[name='bags_filter']").eq(0).prop("checked")) {
							if (bagname.indexOf("PanabitFREE") != -1)
								packtype = 'FREE';
							if (bagname.indexOf("PanabitOEM") != -1)
								packtype = 'OEM';
							if (bagname.indexOf("PanabitWB") != -1)
								packtype = 'WB';
							if (bagname.indexOf("PanabitSMB") != -1)
								packtype = 'SMB';

							var spost = bagname.indexOf("FreeBSD");
							var epost = bagname.indexOf(".tar.gz");
							if (spost != -1 && epost != -1) {
								packtag = bagname.substr(spost + 7, epost - spost - 7);
								packtag = '[' + packtag ;
							}
						}

						res.data.rows.map(function(d) {
							// 过滤断线
							if ((d.lasttime + 15) < d.servertime)
								return;
							// 过滤不匹配的包
							if (packtype == 'FREE' && d.serialno.substr(0, 1) != 'F')
								return;
							else
							if (packtype == 'OEM' && (d.serialno.substr(0, 1) == 'F' || d.serialno.substr(0, 2) == 'PW'))
								return;
							else
							if (packtype == 'WB' && d.serialno.substr(0, 2) != 'PW')
								return;
							else
							if (packtype == 'SMB' && d.serialno.substr(0, 2) != 'PE')
								return;
							if (packtag != '' && d.version.indexOf(packtag) == -1)
								return;

							rows.push(d);
						});

						res.count = res.data.total;
						res.data = rows;

						if (flag) {
							flag = false;
							for (var i = 0; i < data.length; i++) {
								if (varr.indexOf(data[i].version) == -1) {
									varr.push(data[i].version);
								}
							}
							varr.sort(function(a, b) {
								var a1, ax1 = a.split(',');
								var b1, bx1 = b.split(',');
								a1 = ax1.length > 1 ? ax1[1] : ax1[0];
								b1 = bx1.length > 1 ? bx1[1] : bx1[0];
								return (a1 < b1 ? 1 : (a1 == b1 ? 0 : -1));
							});
							$('select[lay-filter="filter-version"] option').not('[value=0]').remove();
							for (i = 0; i < varr.length; i++)
								$('select[lay-filter="filter-version"]')
								.append(new Option(varr[i]));
							form.render('select');
						}
					}
					res.code = res.ret;
					res.msg = res.msg;
				},
				cols: [
					[{
							field: 'id',
							title: '序号',
							width: 40,
							fixed: 'left',
							type: 'numbers'
						},
						{
							type: 'checkbox',
							width: 40,
						}, {
							field: 'serialno',
							title: '设备编号',
							sort: true
						}, {
							field: 'name',
							title: '设备名称',
							sort: true
						}, {
							field: 'grpid',
							title: '所属组',
							sort: true,
							templet: function(d) {
								var grpname;
								if (d.grpid == 0) return '';
								grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
								return grpname;
							}
						}, {
							field: 'version',
							title: '版本',
							sort: true
						}
					]
				]
			});

		} else if (data.value == '2') {
			$.ajax({
				url: 'api.php?r=ixcache@group',
				dataType: 'json',
				type: 'post',
				success: function(d) {
					if (ajax_resultCallBack(d) == false) return;
					var i, data = d.data;

					$('select[lay-filter="filter-group"] option').not('[value=-1]').remove();
					for (i = 0; i < data.rows.length; i++)
						$('select[lay-filter="filter-group"]')
						.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

					form.render('select');
				}
			});

			$.ajax({
				url: 'api.php?r=upgrade@package-list',
				dataType: 'json',
				data: {
					limit: 1000,
					devtype: 2
				},
				type: 'post',
				success: function(d) {
					if (ajax_resultCallBack(d) == false) return;
					var i, data = d.data;

					$('select[lay-filter="upbags"] option').not('[value=0]').remove();
					for (i = 0; i < data.rows.length; i++)
						$('select[lay-filter="upbags"]')
						.append(new Option(data.rows[i].filename));

					form.render('select');
				}
			});

			table.render({
				elem: '#equipmentlist',
				even: true,
				limit: 50,
				limits: [50,100,150,200],
				skin: 'line',
				page: true,
				defaultToolbar: ['filter', 'print', 'exports', {
					title: '提示',
					layEvent: 'LAYTABLE_TIPS',
					icon: 'layui-icon-tips'
				}],
				parseData: function(res) {
					if (res.ret == 0) {
						var rows = [];
						var bagname = $("#upbags").val();
						var packtag = '';

						if ($("[name='bags_filter']").eq(0).prop("checked")) {
							var spost = bagname.indexOf("[");
							var epost = bagname.indexOf("]");
							if (spost != -1 && epost != -1) {
								packtag = bagname.substr(spost + 1, epost - spost - 1);
								packtag = '[' + packtag + ']';
							}
						}

						res.data.rows.map(function(d) {
							// 过滤断线
							if ((d.lasttime + 15) < d.servertime)
								return;
							// 过滤不匹配的包
							if (packtag != '' && d.version.indexOf(packtag) == -1)
								return;

							rows.push(d);
						});

						res.count = res.data.total;
						res.data = rows;

						if (flag) {
							flag = false;
							var data = res.data;
							var varr = [];

							for (var i = 0; i < data.length; i++) {
								if (varr.indexOf(data[i].version) == -1) {
									varr.push(data[i].version);
								}
							}
							varr.sort(function(a, b) {
								return (a < b ? 1 : (a == b ? 0 : -1));
							});
							$('select[lay-filter="filter-version"] option').not('[value=0]').remove();
							for (var i = 0; i < varr.length; i++) {
								$('select[lay-filter="filter-version"]')
									.append(new Option(varr[i]));
							}
							form.render('select');
						}
					}
					res.code = res.ret;
					res.msg = res.msg;
				},
				cols: [
					[{
							field: 'id',
							title: '序号',
							width: 40,
							fixed: 'left',
							type: 'numbers'
						},
						{
							type: 'checkbox',
						}, {
							field: 'serialno',
							title: '设备编号',
							sort: true
						}, {
							field: 'sysname',
							title: '设备名称',
							sort: true
						}, {
							field: 'grpid',
							title: '所属组',
							sort: true,
							templet: function(d) {
								var grpname;
								if (d.grpid == 0) return '';
								grpname = $('select[lay-filter="filter-group"] option[value="' + d.grpid + '"]').text();
								return grpname;
							}
						}, {
							field: 'version',
							title: '版本',
							sort: true
						}
					]
				]
			});
		}
	});

	form.on('select(filter-group)', function(data) {
		search(1);
	});

	form.on('select(upbags)', function(data) {
		search(1);
	});

	form.on('select(filter-version)', function(data) {
		search(1);
	});

});
