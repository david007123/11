<?php
define ("ROOT_DIR", dirname(dirname(dirname(__DIR__))));
require_once(ROOT_DIR . '/conf/config.php');
require_once(ROOT_DIR . '/apps/user/lib/login.php');


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

$sql = "alter table upload_bags add app_cname varchar(64) not null default ''";
$nidb->query($sql);

$sql = "alter table upload_bags add app_version varchar(64) not null default ''";
$nidb->query($sql);


$sql = "alter table cloud_task add";
$sql.= " status int not null default '0',";
$sql.= " add upgrade_pro varchar(32) not null default ''";
$nidb->query($sql);

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

