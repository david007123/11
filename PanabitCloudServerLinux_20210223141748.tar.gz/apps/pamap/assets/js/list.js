function open_remote(serialno, webenable, sshenable, callback) {
	var index = layer.load(0, {
		shade: 0
	});

	$.ajax({
		url: 'api.php?r=gateway@sshport_open',
		data: {
			serialno: serialno,
			webenable: webenable,
			sshenable: sshenable
		},
		dataType: 'json',
		type: 'post',
		success: function(d) {
			layer.close(index);
			if (ajax_resultCallBack(d) == false) {
				layer.msg(d.msg, {
					icon: 5
				});
				return;
			}

			if (typeof callback == 'function')
				callback(d.data);
		},
		error: function() {
			layer.close(index);
			layer.msg('获取数据失败，请稍后再试。', {
				icon: 2
			});
		}
	});
}

function open_https_gateway(serialno) {
	var protocol = window.document.location.protocol + '//';

	open_remote(serialno, 1, 0, function(d) {
		var path = '/login/userverify.cgi?pakey=' + d.md5str + '&username=admin';
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(protocol + d.hostip + ":" + d.web_port + path, "_blank");
				}
			});
		} else
			window.open(protocol + d.hostip + ":" + d.web_port + path, "_blank");
	});
}

function open_https_ixcache(serialno) {
	var protocol = window.document.location.protocol + '//';

	open_remote(serialno, 1, 0, function(d) {
		var as = (d.str).split(',');
		var path = '/login/userverify.cgi?verify=' + as[2] + '&username=admin';
		if (layui.device().ios) {
			layer.msg('映射完成!', {
				time: 0,
				btn: ['连接', '不用了'],
				yes: function(index) {
					layer.close(index);
					window.open(protocol + d.hostip + ":" + as[0] + path, "_blank");
				}
			});
		} else
			window.open(protocol + d.hostip + ":" + as[0] + path, "_blank");
	});
}

layui.use(['form', 'table', 'element'], function() {
	var form = layui.form;
	var table = layui.table;
	var element = layui.element;
	var map;

	var cluster;
	//载入地图
	function showMap(e) {
		var points = [];
		AMapLoader.load({
			key: '879aeda95ba1284189507f81c5a13bbc',
			version: '2.0',
			plugins: ['AMap.Scale', 'AMap.ToolBar', 'AMap.MarkerCluster'],
			zoom: 5
		}).then((AMap) => {
			map = new AMap.Map(e);
			map.addControl(new AMap.Scale());
			map.addControl(new AMap.ToolBar());
			cluster = new AMap.MarkerCluster(map, points, {
				gridSize: 60, // 聚合网格像素大小
				// 自定义聚合点样式
				renderClusterMarker: function(context) {
					// 聚合中点个数
					var clusterCount = context.count;
					var div = document.createElement('div');
					// 聚合点配色
					// var defaultColor = [
					// 	'220,87,18',
					// 	'201,186,131',
					// 	'137,190,178',
					// 	'244,208,0',
					// 	'229,131,8'
					// ]
					// var defaultColor = [
					// 	'175, 238, 238',
					// 	'176, 224, 230',
					// 	'173, 216, 230',
					// 	'135, 206, 250',
					// 	'30, 144, 255'
					// ]
					var defaultColor = [
						'173,216,230',
						'0,191,255',
						'70,130,180',
						'65,105,225',
						'30,144,255'
					]
					if (clusterCount >= 0 && clusterCount < 10) {
						bgColor = defaultColor[0];
					} else if (clusterCount >= 10 && clusterCount < 100) {
						bgColor = defaultColor[1];
					} else if (clusterCount >= 100 && clusterCount < 1000) {
						bgColor = defaultColor[2];
					} else if (clusterCount >= 1000 && clusterCount < 10000) {
						bgColor = defaultColor[3];
					} else if (clusterCount >= 10000) {
						bgColor = defaultColor[4];
					}
					div.style.backgroundColor = 'rgba(' + bgColor + ',1)';
					var size = Math.round(25 + Math.pow(clusterCount / points.length, 1 / 5) * 40);
					// div.style.width = div.style.height = size + 'px';
					div.style.padding = '2px';
					div.style.minWidth = '20px';
					div.style.minHeight = '16px';
					div.style.border = 'solid 1px rgba(' + bgColor + ',1)';
					div.style.borderRadius = size / 2 + 'px';
					div.innerHTML = context.count;
					div.style.lineHeight = size + 'px';
					div.style.color = '#ffffff';
					div.style.fontSize = '12px';
					div.style.textAlign = 'center';
					context.marker.setOffset(new AMap.Pixel(-size / 2, -size / 2));
					context.marker.setContent(div);
				},
				//自定义非聚合点样式
				renderMarker: function(context) {
					var content =
						'<div style="background-color: #228B22; height: 18px; width: 18px; border-radius: 12px; box-shadow: rgba(0, 0, 0, 1) 0px 0px 3px;"></div>';
					if (context.data[0].linkdown) {
						content =
							'<div style="background-color: #A52A2A; height: 18px; width: 18px; border-radius: 12px; box-shadow: rgba(0, 0, 0, 1) 0px 0px 3px;"></div>';
					}
					if (typeof(context.data[0].usedays) != 'string' && context.data[0].usedays <= 7) {
						if (context.data[0].usedays <= 7 && context.data[0].usedays > 0) {
							content =
								'<div style="background-color: #FFD700; height: 18px; width: 18px; border-radius: 12px; box-shadow: rgba(0, 0, 0, 1) 0px 0px 3px;"></div>';
						}
					}
					if (context.data[0].usedays < 0 && context.data[0].linkdown == 0) {
						content =
							'<div style="background-color: #FFD700; height: 18px; width: 18px; border-radius: 12px; box-shadow: rgba(0, 0, 0, 1) 0px 0px 3px;"></div>';
					}
					if(context.data[0].usedays < 0 && context.data[0].linkdown == 1){
						content =
							'<div style="background-color: #A52A2A; height: 18px; width: 18px; border-radius: 12px; box-shadow: rgba(0, 0, 0, 1) 0px 0px 3px;"></div>';
					}
					var offset = new AMap.Pixel(-9, -9);
					context.marker.setContent(content);
					context.marker.setOffset(offset);
				}
			});
			cluster.on('click', function(e) {
				editPos(e);
			});

		}).catch((e) => {
			console.error(e);
		});
	}

	showMap("amap-gateway");

	//点击显示设备信息
	function editPos(e) {
		layer.open({
			type: 1,
			title: '设备信息',
			area: ['450px', 'auto'],
			shadeClose: true,
			resize: false,
			btnAlign: 'c',
			btn: ['确定'],
			content: $('#edit-position').html(),
			success: function(index, layero) {
				index.find('.layui-layer-content').css('overflow', 'visible');
				var data = e.clusterData;
				form.render();
				for (i = 0; i < data.length; i++) {
					$('select[lay-filter="device-name"]')
						.append("<option grp=" + data[i].grpid + " sel=" + data[i].serialno + " value='" + i + "'>" + data[
							i].serialno + " " + data[i].name + "</option>");
				}

				form.render('select');
				if (e.cluster.p.map_address == "none") {
					index.find('input[name="address"]').val("");
				} else {
					index.find('input[name="address"]').val(e.cluster.p.map_address);
				}

				var lasttime = $.myTime.UnixToStrDate(e.cluster.p.lasttime, 'yyyy-MM-dd HH:mm:ss');

				index.find('.version').html(e.cluster.p.version);

				if (e.cluster.p.linkdown == 1) {
					index.find('.lasttime').html('<span class="off_txt">' + lasttime +
						'</span> <span class="off_txt"> [断开]</span>');
				} else {
					index.find('.lasttime').html(lasttime);
				}

				if (typeof(e.cluster.p.usedays) != 'string' && e.cluster.p.usedays < 0) {
					index.find('.usedate').html('<span class="off_txt">' + e.cluster.p.usedays +
						'天</span> <span class="off_txt"> [到期]</span>');
				} else if (e.cluster.p.usedays === '' && e.cluster.p.serialno.indexOf('F') === 0) {
					index.find('.usedate').html('无任何时间限制');
				} else {
					index.find('.usedate').html(e.cluster.p.usedays + '天');
				}

				form.on('select(device-name)', function(d) {
					var formdata = data[d.value];
					var lasttime = $.myTime.UnixToStrDate(formdata.lasttime, 'yyyy-MM-dd HH:mm:ss');

					if (formdata.map_address == "none") {
						index.find('input[name="address"]').val("");
					} else {
						index.find('input[name="address"]').val(formdata.map_address);
					}

					index.find('.version').attr('sel', formdata.serialno).html(formdata.version);
					formdata.linkdown == 1 ? index.find('.lasttime').html('<span class="off_txt">' + lasttime + '</span>') :
						index.find('.lasttime').html(lasttime);

					if (formdata.linkdown == 1) {
						index.find('.lasttime').html('<span class="off_txt">' + lasttime +
							'</span> <span class="off_txt"> [断开]</span>');
					} else {
						index.find('.lasttime').html(lasttime);
					}

					if (typeof(formdata.usedays) != 'string' && formdata.usedays < 0) {
						index.find('.usedate').html('<span class="off_txt">' + formdata.usedays +
							'天</span> <span class="off_txt"> [到期]</span>');
					} else if (formdata.usedays === '' && formdata.serialno.indexOf('F') === 0) {
						index.find('.usedate').html('无任何时间限制');
					} else {
						index.find('.usedate').html(formdata.usedays + '天');
					}
				});
			},
			yes: function(index, layero) {
				var name = $('select[lay-filter="device-name"] option:selected').val(),
					serialno = $('select[lay-filter="device-name"] option:selected').attr('sel'),
					grpid = $('select[lay-filter="device-name"] option:selected').attr('grp'),
					address = $('input[name="address"]').val();
				$.ajax({
					url: 'api.php?r=gateway@devconfig',
					data: {
						serialno: serialno,
						name: name,
						address: address,
						grpid: grpid
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						layer.close(index);
						showMap("amap-gateway");
						$('button[lay-filter="search"]').click();
					},
					error: function() {
						layer.msg(_lang('L10', '获取数据失败，请稍后再试。'), {
							icon: 2
						});
					}
				});
			}
		});
	}

	var listener = [];
	var min_license = 7;
	var min_time = 30;

	function addMarker(devtype, longitude, latitude, labelcont, serialno, now, ptime, usedays) {
		/* 设置弹跳 */
		var marker, myIcon;
		if (now >= min_time + ptime) {
			myIcon = new AMap.Icon({
				image: "../img/map_disconnect.png",
				size: new AMap.Size(33, 33)
			});
			marker = new AMap.Marker({
				position: [longitude, latitude],
				draggable: true,
				icon: myIcon
			});

			marker.setMap(map);
			marker.setAnimation('AMAP_ANIMATION_BOUNCE'); //跳动的动画
			marker_status = 0;
		} else
		if (usedays <= min_license && usedays != 0) {
			myIcon = new AMap.Icon({
				image: "../img/map_warning.png",
				size: new AMap.Size(33, 33)
			});
			marker = new AMap.Marker({
				position: [longitude, latitude],
				draggable: true,
				icon: myIcon
			});

			marker.setMap(map);
			marker.setAnimation('AMAP_ANIMATION_BOUNCE'); //跳动的动画
			marker_status = 0;
		} else {
			if (serialno[0] == 'F')
				myIcon = new AMap.Icon({
					image: "../img/free.png",
					size: new AMap.Size(33, 33)
				});
			else
				myIcon = new AMap.Icon({
					image: "../img/profession.png",
					size: new AMap.Size(33, 33)
				});
			marker = new AMap.Marker({
				position: [longitude, latitude],
				draggable: true,
				icon: myIcon
			});
			marker.setMap(map);
			marker_status = 1;
		}

		marker.setTitle(labelcont);

		var mpt = {
			marker: marker,
			time: ptime,
			status: marker_status,
			longitude: longitude,
			latitude: latitude
		};
		gmarker.push(mpt);

		listener.push(AMap.event.addListener(marker, "click", function() {
			window['open_https_' + devtype](serialno);
		}));

		//marker.setLabel({content:labelcont, offset:new AMap.Pixel(20,10)});
		marker.setTitle(labelcont);
	}

	function updatemarker(obj, labelcont, now, ptime, longitude, latitude, usedays) {
		(obj.marker).setPosition([longitude, latitude]);
		(obj.marker).setTitle(labelcont);

		if (ptime == obj.time)
			return false;
		else {
			if (ptime != obj.time && obj.status == 0) {
				return "create";
			}
		}

		if (usedays != 0 && usedays > min_license && obj.status == 0)
			return "create";
		if (usedays != 0 && usedays <= min_license && obj.status)
			return "create";

		obj.time = ptime;

		return true;
	}

	var iscenter = 0;
	var gmarker = [];
	var glocalip = "";

	function search() {
		var form = layui.form;
		var table = layui.table;
		var element = layui.element;
		var data = form.val('toolbar');
		var postdata = $.extend({}, data);

		delete postdata.devtype;
		$.ajax({
			url: 'api.php?r=' + data.devtype + '@amap',
			type: 'post',
			data: postdata,
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) return;
				var node = d.data;
				cluster.setData(node.rows);
			}
		});
	}

	function refreshGroup() {
		var data = form.val('toolbar');
		$.ajax({
			url: 'api.php?r=' + data.devtype + '@group',
			type: 'post',
			success(d) {
				if (ajax_resultCallBack(d) == false) return;
				var i, data = d.data;

				$('select[lay-filter="filter-group"] option').not('[value=0]').remove();
				for (i = 0; i < data.rows.length; i++)
					$('select[lay-filter="filter-group"]')
					.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

				form.render('select');
			}
		});
	}
	refreshGroup();

	form.on('select(filter-devtype)', function(data) {
		refreshGroup();
		search();
	});

	form.on('select(filter-group)', function(data) {
		search();
	});
	$('#tb_toolbar [lay-filter="search"]').click(function(data) {
		search();
	});
	$('#tb_toolbar [name="keyword"]').on('keypress', function(e) {
		if (e.keyCode == "13") {
			$('#tb_toolbar [lay-filter="search"]').click();
		}
	});
	$('#tb_toolbar [lay-filter="refresh"]').click(function(data) {
		layui.layer.load();
		showMap("amap-gateway");
		layui.layer.closeAll();
		search();
	});

	// 自动刷新
	var auto_refresh_hd = 0;

	function auto_refresh() {
		var interval = $('select[lay-filter="auto-refresh"]').val();
		if (auto_refresh_hd) {
			clearInterval(auto_refresh_hd);
			auto_refresh_hd = 0;
		}
		var tm = Number(interval);
		if (tm)
			auto_refresh_hd = setInterval(search, tm * 1000);
	}
	form.on('select(auto-refresh)', function(data) {
		auto_refresh();
	});
	auto_refresh();

	resize();
});
