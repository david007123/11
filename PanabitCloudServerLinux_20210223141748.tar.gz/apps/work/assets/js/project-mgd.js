// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}
function wkp_typedesc(type)
{
	var map = ["网关", "日志", "缓存", "SAC"];

	if(typeof (map[type - 1]) == 'string') {;
		return map[type - 1];
	}

	return 'none';
}
function ringdesc(ring)
{
	var r, i, map = { r_1:"负责人", r_2:"管理员", r_100:"技术员", r_255:"巡检员"};

	if(ring && map['r_' + ring]) 
		return map['r_' + ring];

	return 'none';
}

function update_parent_wkp(id, name) {
	if(typeof(parent.onchange_work_project) == 'function')
		parent.onchange_work_project(id, name);
}

layui.use(['transfer', 'element', 'table', 'layer', 'form'], function() {
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var form = layui.form;
	var transfer = layui.transfer;
	var timer = new taskTimer();

	table.render({
		elem: '#projectlist',
		even: true,
		loading: false,
		url: 'api.php?r=work@project-list',
		height: 'full-130',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		cellMinWidth: 80, 
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		initSort: {
			field: 'name',
			type: 'desc'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			var wkps = [], wkpsarr = [];
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			if(res.ret == 0) {
				res.data.forEach(function(e, i){
					res.data[i].admin = '';
					res.data[i].count = 0;
					res.data[i].mancnt= 0;
					wkps['wkp_' + e.wkpid] = res.data[i];
					wkpsarr.push(e.wkpid);
				});
				if(wkpsarr.length) {
					$.ajax({
						url: 'api.php?r=work@ring-admin',
						type: 'POST',
						async: false,
						data: {
							wkpidstr: wkpsarr.join(',')
						},
						success: function (res) {
							var i, rows;
							if(res && res.ret == 0 && res.data) {
								rows = res.data;
								for(i = 0; i < rows.length; i++) {
									if(wkps['wkp_' + rows[i].wkpid])
										wkps['wkp_' + rows[i].wkpid].admin = rows[i].user;
								}
							}
						}
					});

					$.ajax({
						url: 'api.php?r=work@group-total',
						type: 'POST',
						async: false,
						data: {
							wkpidstr: wkpsarr.join(',')
						},
						success: function (res) {
							var i, rows;
							if(res && res.ret == 0 && res.data) {
								rows = res.data.g;
								for(i = 0; i < rows.length; i++) {
									if(wkps['wkp_' + rows[i].wkpid]) {
										wkps['wkp_' + rows[i].wkpid].count = rows[i].count;
									}
								}
								rows = res.data.u;
								for(i in rows) {
									if(wkps[i]) {
										wkps[i].mancnt = rows[i];
									}
								}
							}
						}
					});

				}
			}
			
			var e = $('#projectlist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 35,
					fixed: 'left',
					type: 'numbers'
				}, {
					type: 'checkbox',
					width: 25
				}, {
					field: 'name',
					title: '项目名称',
					sort: true,
					width: 120,
					templet: function(d) {
						return '<span class="setBtn" lay-event="edit">' + d.name + '</span>';
					}
				}, {
					field: 'admin',
					title: '负责人',
					width: 80
				}, {
					field: 'count',
					title: '人员数',
					width: 80,
					templet: function(d) {
						return '<span class="setBtn" lay-event="man">' + d.mancnt + '</span>';
					}
				}, {
					field: 'count',
					title: '分组数',
					width: 80,
					templet: function(d) {
						return '<span class="setBtn" lay-event="group">' + d.count + '</span>';
					}
				}, {
					field: 'remarks',
					title: '备注'
				}, {
					title: '操作',
					width: 140,
					templet: function(d) {
						return '<span class="setBtn" lay-event="group">分组</span><span>&nbsp;|&nbsp;<span class="setBtn" lay-event="admin">人员</span><span>&nbsp;|&nbsp;</span><span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});

	$('#tb_toolbar button.add').click(function(){
		layer.open({
			type: 1,
			shadeClose: true,
			title: '创建项目',
			area: ['550px', '240px'],
			resize: false,
			btnAlign: 'c',
			btn: ['确认', '取消'],
			content: $('#tpl-project-add').html(),
			success: function(layero, index) {
				// form.render();
			},
			yes: function(index, layero) {
				var d = form.val('project-add');
				
				if(d.name == '') {
					layer.msg('项目名称不能为空！', {icon: 5});
					return;
				}

				$.ajax({
					url: 'api.php?r=work@project-add',
					data: d,
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						search(0);
						layer.close(index);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}
		});
	});


	$('#tb_toolbar button.del').on('click', function(obj) {

		var checkStatus = table.checkStatus('projectlist');
		var wkpids = [];
		checkStatus.data.forEach(function(e, i) {
			wkpids.push(e.wkpid);
		});
		
		if (wkpids.length <= 0) {
			layer.msg('请先选择要删除的项目。');
			return;
		}

		layer.confirm('确定要删除这些项目吗?', {
			icon: 0,
			title: '设备删除'
		}, function(index) {
			$.ajax({
				url: 'api.php?r=work@project-del',
				data: {
					wkpid: wkpids.join(',')
				},
				type: 'post',
				dataType: 'json',
				success: function(d) {
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
					search(0);
					
				},
				error: function() {
					layer.msg('获取数据失败，请稍后再试。', {
						icon: 2
					});
				}
			});
			layer.close(index);
		});
	});

	function administrator_edit(caption, wkpids) {
		var wkpidstr = wkpids.join(',');
		
		layer.open({
			type: 1,
			shadeClose: true,
			title: '人员管理 - ' + (caption?caption:'已选 ' + wkpids.length + ' 个项目'),
			area: ['600px', '460px'],
			resize: false,
			btnAlign: 'c',
			btn: ['关闭'],
			content: $('#tpl-administrator').html(),
			end: function() {
				search(0);
			},
			success: function(layero, index) {
				var where = {}, that = this;
				
				if(wkpids.length != 1) 
					layero.find('[lay-filter="only-has"]').siblings().hide();
				else {
					where.wkpid = wkpids[0];
					where.onlyhas = 1;
					form.render();
				}

				
				table.render({
					elem: '#tb-administrator',
					even: true,
					loading: false,
					url: 'api.php?r=work@ring-user',
					method: 'post',
					limit: 6,
					limits: [6, 12, 24, 50],
					skin: 'line',
					height: 260,
					cellMinWidth: 80,
					where: where,
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					initSort: {
						field: 'username',
						type: 'asc'
					},
					defaultToolbar: ['filter', 'print', 'exports', {
						title: '提示',
						layEvent: 'LAYTABLE_TIPS',
						icon: 'layui-icon-tips'
					}],
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3
					},
					parseData: function(res) {
						var users = {};
						res.count = res.data.total;
						res.data = res.data.rows;
						res.code = res.ret;
						res.msg = res.msg;
						
						if(res.ret == 0 && wkpids.length == 1
						&& !layero.find('.toolleft input[lay-filter="only-has"]').prop('checked')) {
							res.data.forEach(function(e, i){
								users[e.username] = res.data[i];
							});

							$.ajax({
								url: 'api.php?r=work@ring-user',
								type: 'POST',
								async: false,
								data: {
									wkpid: wkpids[0],
									page: 1,
									limit: 5000
								},
								success: function (res) {
									var i, rows;
									if(res && res.ret == 0 && res.data && res.data.rows) {
										rows = res.data.rows;
										for(i = 0; i < rows.length; i++) {
											if(users[rows[i].username])
												users[rows[i].username].ring = rows[i].ring;
										}
									}
								}
							});
						}
					},
					done: function() {
						layero.find('input[lay-event="ring"]').siblings().click(function(e) {
							var obj = $(e.currentTarget).siblings();
							var user = obj.attr('name');
							var url, ring = parseInt(obj.prop('value'));
							
							if(ring) 
								url = 'api.php?r=work@ring-add';
							else {
								url = 'api.php?r=work@ring-del';
								ring = null;
							}

							$.ajax({
								url: url,
								type: 'POST',
								data: {
									user: user,
									type: 0,
									ring: ring,
									wkpidstr: wkpidstr
								},
								success: function (d) {
									var i, rows;
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}

									if (d.msg)
										layer.msg(d.msg, {icon: 1});
									else
										layer.msg('修改成功！', {icon: 1});
								}
							});
						});
					},
					cols: [
						[
							{
								field: 'id',
								title: '序号',
								width: 35,
								fixed: 'left',
								type: 'numbers'
							}, {
								field: 'username',
								title: '帐号',
								sort: true,
								width: 200
							}, {
								field: 'mobile',
								title: '联系方式',
								width: 110
							}, {
								title: '负责人',
								width: 50,
								templet: function(d) {
									return '<input type="radio" lay-event="ring" value="1" name="' + d.username + '" lay-skin="primary"'+ (d.ring==1?' checked':'') +'>';
								}
							}, {
								title: '管理员',
								width: 50,
								templet: function(d) {
									return '<input type="radio" lay-event="ring" value="2" name="' + d.username + '" lay-skin="primary"'+ (d.ring==2?' checked':'') +'>';
								}
							}, {
								title: '巡检员',
								width: 50,
								templet: function(d) {
									return '<input type="radio" lay-event="ring" value="255" name="' + d.username + '" lay-skin="primary"'+ (d.ring==255?' checked':'') +'>';
								}
							}, {
								title: '无权限',
								width: 50,
								templet: function(d) {
									return '<input type="radio" lay-event="ring" value="0" name="' + d.username + '" lay-skin="primary"'+ (d.ring?'':' checked') +'>';
								}
							}
						]
					]
				});

				//搜索
				function user_search(page, obj) {
					var table = layui.table;

					var where = {
						keyword: $.trim(layero.find('.toolleft input[name="keyword"]').val()),
						onlyhas: (layero.find('.toolleft input[lay-filter="only-has"]').prop('checked') ? 1:0)
					};
					
					if(where.onlyhas && wkpids.length == 1)
						where.wkpid = wkpids[0];
					else
						where.wkpid = null;

					var option = {
						method: 'post',
						where: where
					};
					if (typeof page == "number") {
						if (page > 0)
							option.page = {
								curr: page
							};
					} else
						page = 0;

					if (obj) {
						option.initSort = obj;
						if (obj.field && obj.type) {
							where.order = [{column: obj.field, dir: obj.type}];
						}
					} else {
						option.wherecb = function(w) {
							var op = {};
							if (w.order && w.order.length) {
								op.column = w.order[0].column;
								op.dir = w.order[0].dir;
							}
							return op;
						}
					}

					table.reloadExt('tb-administrator', option);
				}

				table.on('sort(tb-administrator)', function(obj) {
					user_search(0, obj);
				});

				layero.find('.toolleft .searchBtn').click(function() {
					user_search(1);
				});

				form.on('checkbox(only-has)', function(data){
					user_search(1);
				});
				
				layero.find('.toolleft input[name="keyword"]').keyup(function(event) {
					if (event.keyCode == 13) {
						user_search(1);
					}
				});
				
				
			}
		});
	}

	function group_edit(caption, wkpid) {
		layer.open({
			type: 1,
			shadeClose: true,
			title: '分组管理 - ' + caption,
			area: ['600px', '460px'],
			resize: false,
			btnAlign: 'c',
			btn: ['关闭'],
			content: $('#tpl-group-edit').html(),
			end: function() {
				search(0);
			},
			success: function(layero, index) {
				var where = {}, that = this;
				
				where.wkpid = wkpid;
				where.type = 1;
				form.render();

				table.render({
					elem: '#tb-group-edit',
					even: true,
					loading: false,
					url: 'api.php?r=work@group-list',
					method: 'post',
					limit: 6,
					limits: [6, 12, 24, 50],
					skin: 'line',
					height: 260,
					cellMinWidth: 80,
					where: where,
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					initSort: {
						field: 'name',
						type: 'asc'
					},
					defaultToolbar: ['filter', 'print', 'exports', {
						title: '提示',
						layEvent: 'LAYTABLE_TIPS',
						icon: 'layui-icon-tips'
					}],
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3
					},
					parseData: function(res) {
						var users = {};
						res.count = res.data.total;
						res.data = res.data.rows;
						res.code = res.ret;
						res.msg = res.msg;
					},
					done: function() {
						layero.find('input[lay-event="ring"]').siblings().click(function(e) {
							var obj = $(e.currentTarget).siblings();
							var grpid = obj.attr('data-grpid');
							var url, ring = parseInt(obj.prop('value'));
							
							if(ring) 
								url = 'api.php?r=work@group-add';
							else {
								url = 'api.php?r=work@group-del';
								ring = null;
							}

							$.ajax({
								url: url,
								type: 'POST',
								data: {
									grpid: grpid,
									type: type,
									ring: ring,
									wkpid: wkpid
								},
								success: function (d) {
									var i, rows;
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}

									if (d.msg)
										layer.msg(d.msg, {icon: 1});
									else
										layer.msg('修改成功！', {icon: 1});
								}
							});
						});
					},
					cols: [
						[
							{
								field: 'id',
								title: '序号',
								width: 35,
								fixed: 'left',
								type: 'numbers'
							}, {
								field: 'name',
								title: '组名称',
								sort: true
							}, {
								field: 'type',
								title: '类型',
								sort: true,
								width: 100,
								templet: function(d) {
									return wkp_typedesc(d.type);
								}
							}, {
								field: 'ring',
								title: '访问',
								sort: true,
								width: 100,
								templet: function(d) {
									return '<span class="setBtn" lay-event="ring">' + ringdesc(d.ring) + '</span>';
								}
							}, {
								title: '操作',
								width: 90,
								templet: function(d) {
									return '<span class="setBtn" lay-event="del">删除</span>';
								}
							}
						]
					]
				});

				table.on('tool(tb-group-edit)', function(obj) {
					var data = obj.data,
						event = obj.event;

					if (event == 'ring') {
						layer.open({
							type: 1,
							shadeClose: true,
							title: '访问权限',
							area: ['350px', '180px'],
							resize: false,
							btnAlign: 'c',
							btn: ['保存', '取消'],
							content: $('#tpl-grpring-edit').html(),
							success: function(layero, index) {
								layero.find('.layui-layer-content').css('overflow', 'inherit');
								form.val('grpring-edit', data);
							},
							yes: function(index, layero) {
								var d = form.val('grpring-edit');
								
								d.wkpid = wkpid;
								
								$.ajax({
									url: 'api.php?r=work@group-add',
									data: d,
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});
										group_search(0);
										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							}
						});
					}
					else
					if(event === 'del') {
						layer.confirm('确定要删除“<span style="color: red; font-weight: bold;">' + data.name + '</span>”项目分组吗?', {
							icon: 0,
							title: '项目分组删除'
						}, function(index) {
							layer.close(index);
							$.ajax({
								url: 'api.php?r=work@group-del',
								data: {
									wkpid: wkpid,
									type: data.type,
									grpid: data.grpid
								},
								type: 'post',
								dataType: 'json',
								success: function(d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}
									if (d.msg) layer.msg(d.msg, {
										icon: 1
									});
									group_search(0);
								},
								error: function() {
									layer.msg('获取数据失败，请稍后再试。', {
										icon: 2
									});
								}
							});
						});
					}
				});

				//搜索
				function group_search(page, obj) {
					var table = layui.table;

					var where = {
						keyword: $.trim(layero.find('.toolleft input[name="keyword"]').val()),
						type: parseInt(layero.find('.toolleft [name="type"]').val()),
						wkpid: wkpid
					};

					var option = {
						method: 'post',
						where: where
					};
					if (typeof page == "number") {
						if (page > 0)
							option.page = {
								curr: page
							};
					} else
						page = 0;

					if (obj) {
						option.initSort = obj;
						if (obj.field && obj.type) {
							where.order = [{column: obj.field, dir: obj.type}];
						}
					} else {
						option.wherecb = function(w) {
							var op = {};
							if (w.order && w.order.length) {
								op.column = w.order[0].column;
								op.dir = w.order[0].dir;
							}
							return op;
						}
					}

					table.reloadExt('tb-group-edit', option);
				}

				table.on('sort(tb-group-edit)', function(obj) {
					group_search(0, obj);
				});

				layero.find('.toolleft .searchBtn').click(function() {
					group_search(1);
				});

				form.on('checkbox(only-has)', function(data){
					group_search(1);
				});
				
				layero.find('.toolleft input[name="keyword"]').keyup(function(event) {
					if (event.keyCode == 13) {
						group_search(1);
					}
				});

				form.on('select(group-type)', function(data){
					group_search(1);
				});

				layero.find('.toolleft [lay-filter="apply-group"]').click(function(){
					var wkp_type = layero.find('select[lay-filter="group-type"]').val();

					layer.open({
						type: 1,
						shadeClose: true,
						title: '分组添加 - ' + caption,
						area: ['350px', '240px'],
						resize: false,
						btnAlign: 'c',
						btn: ['添加', '取消'],
						content: $('#tpl-group-add').html(),
						end: function() {
							search(0);
						},
						success: function(layero, index) {
							layero.find('.layui-layer-content').css('overflow', 'inherit');

							form.render('select');
							$.ajax({
								url: 'api.php?r=work@group-dump',
								type: 'POST',
								data: {
									wkpid: wkpid,
									type: wkp_type
								},
								success: function (d) {
									var i, rows;
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}

									for (i = 0; i < d.data.length; i++)
										layero.find('select[lay-filter="grpid"]')
										.append(new Option(d.data[i].name, d.data[i].grpid));

									form.val('group-add-form', {
										wkpid: wkpid,
										type: wkp_type,
										ring: 4,
									});

								}
							});
						},
						yes: function (index, layero) {
							var grpid = layero.find('select[lay-filter="grpid"]').val();
							var ring = layero.find('select[lay-filter="ring"]').val();
							
							$.ajax({
								url: 'api.php?r=work@group-add',
								type: 'POST',
								data: {
									wkpid: wkpid,
									type: wkp_type,
									grpidstr: grpid,
									ring: ring
								},
								success: function (d) {
									if (ajax_resultCallBack(d) === false) {
										layer.msg(d.msg, {
											icon: 5
										});
										return;
									}

									if (d.msg)
										layer.msg(d.msg, {icon: 1});
									else
										layer.msg('添加成功！', {icon: 1});

									group_search(0);
									layer.close(index);
								}
							});
						}
					});
				});
			}
		});
	}
	
	$('#tb_toolbar button[lay-filter="administrator"]').click(function() {
		var checkStatus = table.checkStatus('projectlist');
		var wkpids = [];
		checkStatus.data.forEach(function(e, i) {
			wkpids.push(e.wkpid);
		});

		if (wkpids.length <= 0) {
			layer.msg('请先选择要修改的项目。');
			return;
		}

		administrator_edit(null, wkpids);
	});
	
	table.on('tool(projectlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event == 'admin' || event == 'man') {
			administrator_edit(data.name, [data.wkpid]);
		}
		else
		if (event == 'group') {
			group_edit(data.name, data.wkpid);
		}
		else
		if (event == 'edit') {
			layer.open({
				type: 1,
				shadeClose: true,
				title: '编辑项目',
				area: ['550px', '240px'],
				resize: false,
				btnAlign: 'c',
				btn: ['确认', '取消'],
				content: $('#tpl-project-edit').html(),
				success: function(layero, index) {
					// form.render();
					form.val('project-edit', data);
				},
				yes: function(index, layero) {
					var d = form.val('project-edit');
					
					if(d.name == '') {
						layer.msg('项目名称不能为空！', {icon: 5});
						return;
					}

					$.ajax({
						url: 'api.php?r=work@project-save',
						data: d,
						type: 'post',
						dataType: 'json',
						success: function(d) {
							if (ajax_resultCallBack(d) === false) {
								layer.msg(d.msg, {
									icon: 5
								});
								return;
							}
							if (d.msg) layer.msg(d.msg, {
								icon: 1
							});
							search(0);
							layer.close(index);
						},
						error: function() {
							layer.msg('获取数据失败，请稍后再试。', {
								icon: 2
							});
						}
					});
				}
			});
		}
		else
		if(event === 'del') {
			layer.confirm('确定要删除“<span style="color: red; font-weight: bold;">' + data.name + '</span>”项目吗?', {
				icon: 0,
				title: '项目删除'
			}, function(index) {
				layer.close(index);
				$.ajax({
					url: 'api.php?r=work@project-del',
					data: {
						wkpid: data.wkpid
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						search(0);
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			});
		}
	});

	table.on('sort(projectlist)', function(obj) {
		search(0, obj);
	});
	
	//搜索
	function search(page, obj) {
		var table = layui.table;

		var where = {
			keyword: $.trim($('#tb_toolbar input[name="keyword"]').val())
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				};
		} else
			page = 0;

		if (obj) {
			option.initSort = obj;
			if (obj.field && obj.type) {
				where.order = [{column: obj.field, dir: obj.type}];
			}
		} else {
			option.wherecb = function(w) {
				var op = {};
				if (w.order && w.order.length) {
					op.column = w.order[0].column;
					op.dir = w.order[0].dir;
				}
				return op;
			}
		}

		table.reloadExt('projectlist', option);
	}
	
	$('#tb_toolbar .searchBtn').click(function() {
		search(1);
	});

	$('#tb_toolbar input[name="keyword"]').keyup(function(event) {
		if (event.keyCode == 13) {
			search(1);
		}
	});

});
