// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

layui.use(['element', 'table', 'layer', 'form'], function() {
	var element = layui.element;
	var table = layui.table;
	var layer = layui.layer;
	var form = layui.form;
	var timer = new taskTimer();
	var parentFrameIndex = parent.layer.getFrameIndex(window.name);

	function projectlist_refresh() {
		timer.add('project_list', 3, {
			fuc: function() {
				var that = this;
				var data = {
						order: [{
							column: 'name',
							dir: 'asc'
						}],
						keyword: $.trim($('.wkp-seach input[name="keyword"]').val())
					};
				$.ajax({
					url: 'api.php?r=work@project-list',
					type: 'post',
					data: data,
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var cnt, i, index, html, box,
							data = d.data.rows.sort(),
							wkpid;

						$.ajax({
							url: 'api.php?r=work@project-curr',
							async: false,
							success(d) {
								if(d.ret == 0)
									wkpid = d.data.wkpid;
							}
						});
						
						data = d.data.rows;
						cnt = parseInt(data.length / 6);
						html = '';
						for(index = 0; index < cnt; index = index + 6) {
							i = index * 6;
							html+= '<div class="layui-row">';
							html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
							html+= '<span data-wkpid="' + data[i].wkpid + '" title="' + data[i].remarks + '">' + data[i].name + '</span>';
							html+= '</div></div>';
							html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
							html+= '<span data-wkpid="' + data[i+1].wkpid + '" title="' + data[i+1].remarks + '">' + data[i+1].name + '</span>';
							html+= '</div></div>';
							html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
							html+= '<span data-wkpid="' + data[i+2].wkpid + '" title="' + data[i+2].remarks + '">' + data[i+2].name + '</span>';
							html+= '</div></div>';
							html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
							html+= '<span data-wkpid="' + data[i+3].wkpid + '" title="' + data[i+3].remarks + '">' + data[i+3].name + '</span>';
							html+= '</div></div>';
							html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
							html+= '<span data-wkpid="' + data[i+4].wkpid + '" title="' + data[i+4].remarks + '">' + data[i+4].name + '</span>';
							html+= '</div></div>';
							html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
							html+= '<span data-wkpid="' + data[i+5].wkpid + '" title="' + data[i+5].remarks + '">' + data[i+5].name + '</span>';
							html+= '</div></div></div>';
						}
						if(data.length % 6) {
							html+= '<div class="layui-row">';
							for(i = cnt * 6; i < data.length; i++) {
								html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"><div class="project-item">';
								html+= '<span data-wkpid="' + data[i].wkpid + '" title="' + data[i].remarks + '">' + data[i].name + '</span>';
								html+= '</div></div>';
							}
							for(i = 6 - (data.length % 6); i > 0; i--) 
								html+= '<div class="layui-col-xs12 layui-col-sm6 layui-col-md2"></div>';
							html+= '</div>';
						}

						if(!wkpid) wkpid = 0;
						$('#project_list').html(html);
						$('#project_list').find('span[data-wkpid="'+wkpid+'"]').parent().addClass('active');

						$('#project_list').find('span[data-wkpid]').click(function(){
							var id = this.getAttribute('data-wkpid');
							$.ajax({
								url: 'api.php?r=work@project-curr',
								type: 'POST',
								data: {
									wkpid: id
								},
								success(d) {
									$.cookie("work_project_chage", id, {expires: 31});
									parent.layer.close(parentFrameIndex);
								}
							});
						});

						timer.rmv('project_list');
					}
				});
			}
		}, 1);
	}
	projectlist_refresh();

	$('.wkp-seach .layui-icon-close').click(function(){
		$('.wkp-seach input[name="keyword"]').val('');
	});
	
	$('.wkp-seach .wkp-seach-icon').click(function(){
		projectlist_refresh();
	});
	
	$('.wkp-seach input[name="keyword"]').keyup(function(event) {
		if (event.keyCode == 13) {
			projectlist_refresh();
		}
	});

});
