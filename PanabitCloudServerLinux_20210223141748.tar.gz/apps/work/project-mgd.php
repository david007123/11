<?php
$appdir = dirname(__FILE__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

$token = $appname . '_' . $appmethod;


// 装载功能 | load function
// ni_app_load('user', 'login');

// 验证用户 | auth user
//\raas\apps\user\_auth_js_exit($appname, IDENTITY_TOKEN_LIST);

// exec page
//hook_register('get_wallet_hook', '获取库存信息', 'web_body');

// exec page
require_once(__DIR__  . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . $appmethod . '.html');
