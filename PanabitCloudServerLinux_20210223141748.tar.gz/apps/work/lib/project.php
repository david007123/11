<?php
namespace cloud\apps\work\project;


require_once("ring.php");

function select($data)
{
	global $nidb, $user;


	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';

	if(!is_supadmin($user->username)) {
		$where_str .= "r.`user` = ? and r.`ring` > 0 and ";
		array_push($values, $user->username);
	}
	
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false)) {
		$where_str .= "p.`wkpid` = ? and ";
		array_push($values, $optional['wkpid']);
	}
	
	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(p.`name` like ? or p.`remarks` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"wkpid",
		"name",
		"remarks"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "p.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.work_project as p";
	if(!is_supadmin($user->username)) {
		$sql.= " inner join cloud_platform.work_ring as r";
		$sql.= " on p.wkpid = r.wkpid";
	}
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = 'p.`wkpid`,
p.`name`,
p.`remarks`';

	$sql = "select $keys from cloud_platform.work_project as p";
	if(!is_supadmin($user->username)) {
		$sql.= " inner join cloud_platform.work_ring as r";
		$sql.= " on p.wkpid = r.wkpid";
	}
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

//	if(is_supadmin($user->username)) {
		$result['rows'] = array_merge(array(
			array(
				"name" => "空项目",
				"remarks" => "",
				"wkpid" => 0,
			)), $rows);
//	}
//	else {
//		$result['rows'] = $rows;
//	}

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function info($data)
{
	global $nidb, $user;


	$values = array();
	$optional = array();

	$where_str = 'where ';

	if(!is_supadmin($user->username)) {
		$where_str .= "r.`user` = ? and r.`ring` > 0 and ";
		array_push($values, $user->username);
	}
	
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目ID未指定。');
		return false;
	}
	$where_str .= "p.`wkpid` = ?";
	array_push($values, $optional['wkpid']);

	$keys = 'p.`wkpid`,
p.`name`,
p.`remarks`';

	$sql = "select $keys from cloud_platform.work_project as p";
	if(!is_supadmin($user->username)) {
		$sql.= " inner join cloud_platform.work_ring as r";
		$sql.= " on p.wkpid = r.wkpid";
	}
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);

		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!row) return false;

	return (object)$row;
}

function add($data)
{
	global $nidb, $user;


	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	$optional = array();
	if(format_and_push($data, 'name', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目名称不能为空。');
		return false;
	}

	if(format_and_push($data, 'remarks', $optional, '', 'string', false) == false)
		$optional['remarks']	= '';

	$optional['option']	= '';

	try {
		$sql = "select `wkpid` from cloud_platform.work_project where `name` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['name'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if($row) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该项目已存在！');
			return false;
		}

		if(insert_data('cloud_platform`.`work_project', $optional) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}

		return true;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return false;
}

function save($data)
{
	global $nidb, $user;
	

	$where = array();
	$optional = array();
	if(format_and_push($data, 'wkpid', $where, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无效的项目指定。');
		return false;
	}

	if(format_and_push($data, 'name', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目名称不能为空。');
		return false;
	}
	if($_SESSION['work_project_id'] == $where['wkpid'])
		$_SESSION['work_project_name'] = $optional['name'];

	if(format_and_push($data, 'remarks', $optional, '', 'string', false) == false)
		$optional['remarks']	= '';

	if(!is_supadmin($user->username)) {
		$ring = is_admin($user->username, $where['wkpid'], 0, ROLE_ROOT);
		if(!$ring) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

	try {
		$sql = "select `wkpid` from cloud_platform.work_project where `name` = ? limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $optional['name'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		if($row && $row['wkpid'] != $where['wkpid']) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '该项目已存在！');
			return false;
		}

		cloud_insertlog($user->username, "编辑项目【{$optional['name']}】");	

		if(update_data('cloud_platform`.`work_project', $optional, $where) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function remove($data)
{
	global $nidb, $user;
	
	
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	if(isset($data['wkpid']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的项目不能为空。');
		return false;
	}
	if(empty($data['wkpid']) || gettype($data['wkpid']) != 'string') {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要删除的项目。');
		return false;
	}

	$wkpidstr = $data['wkpid'];
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $wkpidstr, $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '参数错误，请重新选择要删除的项目。');
		return false;
	}

	try {
		// 清空项目中的分组权限表
		$sql = "delete from cloud_platform.work_group_ring where `wkpid` in ({$wkpidstr})";
		$sth = $nidb->prepare($sql);
		$sth->execute($users);

		// 清空项目中的用户权限表
		$sql = "delete from cloud_platform.work_ring where `wkpid` in ({$wkpidstr})";
		$sth = $nidb->prepare($sql);
		$sth->execute($users);

		$sql = "select `name` from cloud_platform.work_project where `wkpid` in ({$wkpidstr})";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);

		if(count($rows) > 0) {
			foreach($rows as $row)
				cloud_insertlog($user->username, "删除项目【" . $row->name . "】");

			// 清空项目中
			$sql = "delete from cloud_platform.work_project where `wkpid` in ({$wkpidstr})";
			$sth = $nidb->prepare($sql);
			$sth->execute($users);
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function project_enable()
{
	if(isset($_SESSION['work_project_id'])
	&& $_SESSION['work_project_id'] > 0) 
		return $_SESSION['work_project_id'];
	return 0;
/*
	$optional = array();
	if(format_and_push($data, 'enable', $optional, '', 'int', false) == false) {
		$ret = myconf_read('/usr/logd/cloud.conf', array('work_mgd_enable'));
		if(!isset($ret['work_mgd_enable']))
			return 0;
		return (intval($ret['work_mgd_enable'])?1:0);
	}
	
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}
	
	return myconf_save('/usr/logd/cloud.conf', array('work_mgd_enable' => ($optional['enable']?1:0)));
*/
}

function set_curr_work_project($data)
{
	global $user;
	
	$optional = array();
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) === false) {

		$ret = get_curr_work_project();
		if($ret === false) return false;
		return $ret;
	}
	
	if($_SESSION['work_project_id'] == $optional['wkpid'])
		return true;

	if(!is_supadmin($user->username)) {
		
		if($optional['wkpid'] > 0
		&& !($ring = is_admin($user->username, $optional['wkpid'], 0, ROLE_GUEST))) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

	if($optional['wkpid']) {
		$info = info(array('wkpid' => $optional['wkpid']));
		if(!$info) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目不存在。');
			return false;
		}
		
		$_SESSION['work_project_id'] = $info->wkpid;
		$_SESSION['work_project_name'] = $info->name;
	}
	else {
		$_SESSION['work_project_id'] = 0;
		$_SESSION['work_project_name'] = '';
	}
	return true;
}

function get_curr_work_project($ring = ROLE_GUEST, $type = 0)
{
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	global $nidb, $user;
	
	if(isset($_SESSION['work_project_id'])
	&& $_SESSION['work_project_id'] > 0) {
		
		$id = $_SESSION['work_project_id'];
		if(!is_supadmin($user->username)) {
			if(!($ring = is_admin($user->username, $id, $type, $ring))) {

				return array (
					'wkpid'	=> 0,
					'ring'	=> 0,
					'name'	=> '空项目'
				);
				//set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
				//return false;
			}
		}
		else
			$ring = 1;
		
		return array (
			'wkpid'	=> $id,
			'ring'	=> $ring,
			'name'	=> $_SESSION['work_project_name']
		);

	}

	return array (
		'wkpid'	=> 0,
		'ring'	=> 0,
		'name'	=> '空项目'
	);
}

function get_curr_work_groupstr($type, $ring = ROLE_GUEST) 
{
	global $nidb, $user;


	if(!check_group_type($type)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型不正确。');
		return false;
	}

	$wkp = get_curr_work_project($ring, 0);
	if($wkp === false) return false;
	
	if(is_supadmin($user->username)) {
		if($wkp['wkpid'] == 0) {
			switch($type) {
				case 1: // 网关
					$group = get_gateway_group(-1);
					break;
				case 2: // 日志
					$group = get_panalog_group(-1);
					break;
				case 3: // 缓存
					$group = get_ixcache_group(-1);
					break;
				case 4: // SAC
					$group = get_sac_group(-1);
					break;
				default:// 
					$group = '';
					break;
			}
		}
		else {
			$group = get_groupstr($wkp['wkpid'], $type, 1);
			if($group === false) return false;
		}

		if(empty($group))
			return '10000,0';
		return $group . ',10000,0';
	}

	if($wkp['wkpid'] == 0) return '';

	return get_groupstr($wkp['wkpid'], $type, $wkp['ring']);
}

// 测试操作要管理的帐号 $username 是否可以管理
function get_work_for_user($username, $ring = ROLE_ADMIN) 
{
	global $nidb, $user;

	try {
		$sql = "select group_concat(`wkpid`) as `wkpids`";
		$sql.= " from cloud_platform.work_ring";
		$sql.= " where `user` = ? and `ring` > 0 and `ring` <= ?";
		$sql.= " group by `wkpid`";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $user->username, \PDO::PARAM_STR);
		$sth->bindParam(2, $ring, \PDO::PARAM_INT);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return false;

	return $row['wkpids'];
}

function in_work_grpidstr($type, $grpidstr, $ring = ROLE_GUEST) 
{
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	global $nidb, $user;


	if(!check_group_type($type)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型不正确。');
		return false;
	}

	$wkp = get_curr_work_project($ring, 0);
	if($wkp === false) return false;

	if(is_supadmin($user->username)) {
		if($wkp['wkpid'] == 0) {
			if($grpidstr < 0)
				return '';
			if($grpidstr === 0)
				return '10000,0';

			switch($type) {
				case 1: // 网关 
					$group = get_gateway_group($grpidstr);
					break;
				case 2: // 日志
					$group = get_panalog_group($grpidstr);
					break;
				case 3: // 缓存
					$group = get_ixcache_group($grpidstr);
					break;
				case 4: // SAC
					$group = get_sac_group($grpidstr);
					break;
				default:// 
					$group = '';
					break;
			}

			return $group;
		}

		$wkp['ring'] = 1;
		
		if($grpidstr < 0) {
			$grpidstr = get_groupstr($wkp['wkpid'], $type, $wkp['ring']);
			if($grpidstr)
				return $grpidstr . ',10000,0';
			return $grpidstr;
		}
		
	}
	
	if($wkp['wkpid'] == 0) return '';

	if($grpidstr === -1)
		return get_groupstr($wkp['wkpid'], $type, $wkp['ring']);

	try {
		// $sql = "select `wkpid`, `type`, `grpid`";
		$sql = "select group_concat(`grpid`) as `grpidstr`";
		$sql.= " from cloud_platform.work_group_ring";
		$sql.= " where `wkpid` = ? and `ring` >= ? and `type` = ?";
		$sql.= " and `grpid` in (?)";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $wkp['wkpid'], \PDO::PARAM_INT);
		$sth->bindParam(2, $wkp['ring'], \PDO::PARAM_INT);
		$sth->bindParam(3, $type, \PDO::PARAM_INT);
		$sth->bindParam(4, $grpidstr, \PDO::PARAM_STR);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row || $row['grpidstr'] == NULL)
		return '';

	return $row['grpidstr'];
}

function in_work_project($ring = ROLE_GUEST, $type = 0) 
{
	global $user;
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限

	if(is_supadmin($user->username))
		return 1;

	$wkp = get_curr_work_project($ring, $type);
	if($wkp === false) return false;
	if($wkp['wkpid'] == 0) return 0;

	return $wkp['ring'];
}

// 测试操作要管理的帐号 $username 是否可以管理
function in_work_user($username, $ring = ROLE_ADMIN) 
{
	global $nidb, $user;


	if(is_supadmin($user->username)) 
		return true;

	$wkpids = get_work_for_user($username, $ring);
	if(!$wkpids) return false;

	try {
		$sql = "select `wkpid`";
		$sql.= " from cloud_platform.work_ring";
		$sql.= " where `user` = ? and `wkpid` in (?)";
		$sql = " limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $username, \PDO::PARAM_STR);
		$sth->bindParam(2, $wkpids, \PDO::PARAM_STR);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return false;

	return true;
}

function get_gateway_group($grpids)
{
	global $nidb;


	try {
		if($grpids == -1)
			$sql = "select group_concat(`grpid`) as `groupstr` from cloud_grp";
		else
			$sql = "select group_concat(`grpid`) as `groupstr` from cloud_grp where `grpid` in ({$grpids})";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);

		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return '';

	return $row['groupstr'];
}

function get_ixcache_group($grpids)
{
	global $nidb;


	try {
		if($grpids == -1)
			$sql = "select group_concat(`grpid`) as `groupstr` from ixcache_grp";
		else
			$sql = "select group_concat(`grpid`) as `groupstr` from ixcache_grp where `grpid` in ({$grpids})";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);

		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return '';

	return $row['groupstr'];
}

function get_panalog_group($grpids)
{
	global $nidb;


	try {
		if($grpids == -1)
			$sql = "select group_concat(`grpid`) as `groupstr` from logserver_grp";
		else
			$sql = "select group_concat(`grpid`) as `groupstr` from logserver_grp where `grpid` in ({$grpids})";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);

		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return '';

	return $row['groupstr'];
}

function get_intool_group($grpids)
{
	global $nidb;


	try {
		if($grpids == -1)
			$sql = "select group_concat(`id`) as `groupstr` from intool_grp";
		else
			$sql = "select group_concat(`id`) as `groupstr` from intool_grp where `id` in ({$grpids})";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);

		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return '';

	return $row['groupstr'];
}

function get_sac_group($grpids)
{
	global $nidb;


	try {
		if($grpids == -1)
			$sql = "select group_concat(`grpid`) as `groupstr` from sac_grp";
		else
			$sql = "select group_concat(`grpid`) as `groupstr` from sac_grp where `grpid` in ({$grpids})";
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);

		$sth = null;
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row) return '';

	return $row['groupstr'];
}

function ring_user($data)
{
	global $nidb, $user;

	
	$values = array();
	$optional = array();


	if(format_and_push($data, 'onlyhas', $optional, '', 'int', false) == false) {
		$optional['onlyhas'] = 0;
	}
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false)) {
		$where_str .= "r.`wkpid` = ? and ";
		array_push($values, $optional['wkpid']);
		if($optional['onlyhas'])
			$where_str .= "r.`ring` > 0 and ";
	}
	
	if(!is_supadmin($user->username)) {
		if(!in_work_project(ROLE_ADMIN)) {
			$ring = is_admin($user->username, $optional['wkpid'], 0, ROLE_GUEST);
			if(!$ring) {
				return array(
					'total' => 0,
					'rows'	=> array()
				);
			}
		}
	}

	// set order, limit, offset value
	format_list_arg($data, $optional);

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(u.`username` like ? or u.`mobile` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"username"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "u.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_users as u";
	if(isset($optional['wkpid'])) {
		if($optional['onlyhas'])
			$sql.= " inner join cloud_platform.work_ring as r";
		else
			$sql.= " left join cloud_platform.work_ring as r";
		$sql.= " on u.username = r.user";
	}

	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);

		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = 'u.`username`,
u.`mobile`';
	if(isset($optional['wkpid']))
		$keys.=', r.`ring`';
	else
		$keys.=', 0 as `ring`';

	$sql = "select $keys from cloud_users as u";
	if(isset($optional['wkpid'])) {
		if($optional['onlyhas'])
			$sql.= " inner join cloud_platform.work_ring as r";
		else
			$sql.= " left join cloud_platform.work_ring as r";
		$sql.= " on u.username = r.user";
	}
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$result['rows'] = $rows;

	
	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function ring_admin($data) 
{
	global $nidb, $user;


	$optional = array();

	if(format_and_push($data, 'wkpidstr', $optional, '', 'string', false) == false) {
		if(!isset($optional['wkpidstr'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
			return false;
		}
	}
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $optional['wkpidstr'], $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目不正确。');
		return false;
	}

	$sql = "select `wkpid`, `user` from cloud_platform.work_ring";
	$sql.= " where `ring` & 1 and `wkpid` in ({$optional['wkpidstr']})";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $rows;
}

function add_ring($data) 
{
	global $nidb, $user;


	$optional = array();
	if(format_and_push($data, 'user', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '用户未指定。');
		return false;
	}

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false))
		$optional['wkpidstr'] = $optional['wkpid'];

	if(format_and_push($data, 'wkpidstr', $optional, '', 'string', false) == false) {
		if(!isset($optional['wkpidstr'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
			return false;
		}
	}
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $optional['wkpidstr'], $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目不正确。');
		return false;
	}
	
	if(format_and_push($data, 'type', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '资源类型未指定。');
		return false;
	}
	
	if(format_and_push($data, 'ring', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '权限未指定。');
		return false;
	}

	$wkpidstr = explode(',', $optional['wkpidstr']);
	foreach($wkpidstr as $wkpid) {

		if(($wkp = info(array('wkpid' => $wkpid))))
			$project_name = $wkp->name;
		else
			$project_name = '';

		if(!is_supadmin($user->username)) {
			$ring = is_admin($user->username, $wkpid, $optional['type'], ROLE_ADMIN);
			if(!$ring) {
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。无法操作“' . $project_name . '”项目。');
				return false;
			}

			if($optional['ring'] && $ring >= $optional['ring']) {
				// 如果被操作的帐号也有同样的管理权限，则操作失败。
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足，无法对自己或同级权限的用户操作。');
				return false;
			}
			$thenring = is_admin($optional['user'], $wkpid, $optional['type'], ROLE_ADMIN);
			if($thenring && $ring >= $thenring) {
				// 如果被操作的帐号也有同样的管理权限，则操作失败。
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足，无法对自己或同级权限的用户操作。');
				return false;
			}
		}

		$ringdesc = ringdesc($optional['ring']);
		cloud_insertlog($user->username, "在“{$project_name}”项目中为 {$optional['user']} 帐号配置 {$ringdesc} 权限。");

		$ret = set_ring($optional['user'], $wkpid, $optional['type'], $optional['ring']);

		if($ret === false)
			return false;
	}

	return true;
}

function clean_ring($data)
{
	// $user = 帐号 空值：指所有的默认
	// $wkpid = 项目ID 0：指所有的默认
	global $nidb, $user;


	$optional = array();
	if(format_and_push($data, 'user', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '用户未指定。');
		return false;
	}
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false))
		$optional['wkpidstr'] = $optional['wkpid'];

	if(format_and_push($data, 'wkpidstr', $optional, '', 'string', false) == false) {
		if(!isset($optional['wkpidstr'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
			return false;
		}
	}
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $optional['wkpidstr'], $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目不正确。');
		return false;
	}
	
	if(format_and_push($data, 'type', $optional, '', 'int', false) == false)
		$optional['type'] = null;

	if(format_and_push($data, 'ring', $optional, '', 'int', false) == false) {
		$optional['ring'] = null;
		$ringdesc = '所有';
	}
	else
		$ringdesc = ringdesc($optional['ring']);

	
	$wkpidstr = explode(',', $optional['wkpidstr']);
	foreach($wkpidstr as $wkpid) {

		if(($wkp = info(array('wkpid' => $wkpid))))
			$project_name = $wkp->name;
		else
			$project_name = '';

		if(!is_supadmin($user->username)) {
			$ring = is_admin($user->username, $wkpid, $optional['type'], ROLE_ADMIN);
			if(!$ring) {
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
				return false;
			}

			if($optional['ring'] && $ring >= $optional['ring']) {
				// 如果被操作的帐号也有同样的管理权限，则操作失败。
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足，无法对自己或同级权限的用户操作。');
				return false;
			}
			$thenring = is_admin($optional['user'], $wkpid, $optional['type'], ROLE_ADMIN);
			if($thenring && $ring >= $thenring) {
				// 如果被操作的帐号也有同样的管理权限，则操作失败。
				set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足，无法对自己或同级权限的用户操作。');
				return false;
			}
		}

		cloud_insertlog($user->username, "从“{$project_name}”项目中清除 {$optional['user']} 帐号的 {$ringdesc} 权限。");
		$ret = rmv_ring($optional['user'], $wkpid, $optional['type'], $optional['ring']);

		if($ret === false)
			return false;
	}
}

function group_dump($data)
{
	global $nidb, $user;

	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	$group_map = array (
		'cloud_grp',
		'logserver_grp',
		'ixcache_grp',
		'sac_grp',
	);

	$values = array();
	$optional = array();

	// set order, limit, offset value
	format_list_arg($data, $optional);
	if(format_and_push($data, 'type', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型未指定。');
		return false;
	}

	$type = $optional['type'];
	if($type <= 0 || $type > count($group_map)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型不正确。');
		return false;
	}

	$group_tb = $group_map[$type - 1];

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
		return false;
	}

	if(!is_supadmin($user->username)) {
		$ring = is_admin($user->username, $optional['wkpid'], 0, ROLE_GUEST);
		if(!$ring) {
			return array();
		}
	}
	array_push($values, $optional['wkpid']);

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`grpname` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	if(format_and_push($data, 'all', $optional, '', 'int', false) == false)
		$optional['all'] = 0;

	$order_map = array(
		"grpname"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if(!$optional['all']) {

		$sql = "select group_concat(`grpid`) as `grpidstr` from cloud_platform.work_group_ring";
		$sql.= " where `wkpid` = {$optional['wkpid']} and `type` = {$type}";

		try {
			$sth = $nidb->prepare($sql);
			$sth->execute();
			$row = $sth->fetch(\PDO::FETCH_ASSOC);
		}
		catch (\NiDBException $e) {
			set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
			return false;
		}

		if($row && !empty($row['grpidstr']))
			$where_str.= "`grpid` not in ({$row['grpidstr']}) and ";
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select `grpid`, `grpname` as `name` from {$group_tb}";
	$sql.= " {$where_str} {$order_by}";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$rows = $sth->fetchAll(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$sorts = array();
	foreach($rows as $key => $row) {
		array_push($sorts, $row['name']);
		if(($type == 1 && $name = iconv("gbk", "utf-8//translit", $row['name'])))
			$rows[$key]['name'] = $name;
	}

	array_multisort($sorts, SORT_ASC, SORT_STRING, $rows);

	return $rows;
}

function group_list($data)
{
	global $nidb, $user;


	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	$group_map = array(
		'cloud_grp',
		'logserver_grp',
		'ixcache_grp',
		'sac_grp',
	);

	$values = array();
	$optional = array();

	// set order, limit, offset value
	format_list_arg($data, $optional);

	if(format_and_push($data, 'type', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型未指定。');
		return false;
	}

	$type = $optional['type'];
	if(!check_group_type($type)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型不正确。');
		return false;
	}

	$where_str .= "r.`type` = {$type} and ";
	$group_tb = $group_map[$type - 1];

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
		return false;
	}

	if(!is_supadmin($user->username)) {
		$ring = is_admin($user->username, $optional['wkpid'], 0, ROLE_GUEST);
		if(!$ring) {
			return array(
				'total' => 0,
				'rows'	=> array(),
			);
		}
	}

	$where_str .= "r.`wkpid` = ? and ";
	array_push($values, $optional['wkpid']);

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(g.`grpname` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"grpname"
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "g.`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from cloud_platform.work_group_ring as r";
	$sql.= " inner join `$group_tb` as g";
	$sql.= " on g.`grpid` = r.`grpid`";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = 'r.`grpid`,
g.`grpname` as `name`,
r.`type`,
r.`ring`';

	$sql = "select $keys from cloud_platform.work_group_ring as r";
	$sql.= " inner join `$group_tb` as g";
	$sql.= " on g.grpid = r.grpid";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	$sorts = array();
	foreach($rows as $key => $row) {
		array_push($sorts, $row['name']);
		if(($type == 1 && $name = iconv("gbk", "utf-8//translit", $row['name'])))
			$rows[$key]['name'] = $name;
	}

	array_multisort($sorts, SORT_ASC, SORT_STRING, $rows);

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function check_group_type($type)
{
	return ($type > 0 && $type <= 4);
}

function group_listY($data)
{
	global $nidb, $user;

	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	$group_map = array(
		'cloud_grp',
		'logserver_grp',
		'ixcache_grp',
		'cloud_platform.sac_grp',
	);

	$values = array();
	$optional = array();

	if(!is_supadmin($user->username)) {
		$ring = is_admin($user->username, $where['wkpid'], 0, ROLE_GUEST);
		if(!$ring) {
			return array(
				'total' => 0,
				'rows'	=> array(),
			);
		}
	}

	// set order, limit, offset value
	format_list_arg($data, $optional);

	if(format_and_push($data, 'type', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型未指定。');
		return false;
	}

	$type = $optional['type'];
	if(!check_group_type($type)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型不正确。');
		return false;
	}

	$group_tb = $group_map[$type - 1];

	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
		return false;
	}
	$where_str .= "`wkpid` = ? and ";
	array_push($values, $optional['wkpid']);

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`grpname` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	$order_map = array(
		"grpname",
		"wkpid",
		"ring",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($op['dir'])) {
				if(in_array($op['column'], $order_map)) {
					array_push($order, "`" . $op['column'] . "` " . ($op['dir']=='desc'?'desc':'asc'));
				}
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = '';

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$sql = "select count(*) as `total` from {$group_tb}";
	$sql.= " $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);

		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`grpid`,
`grpname` as `name`,
`wkpid`,
`ring`';

	$sql = "select $keys from {$group_tb}";
	$sql.= " $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function group_total($data) 
{
	global $nidb, $user;


	$optional = array();

	if(format_and_push($data, 'wkpidstr', $optional, '', 'string', false) == false) {
		if(!isset($optional['wkpidstr'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
			return false;
		}
	}
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $optional['wkpidstr'], $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目不正确。');
		return false;
	}

	$sql = "select `wkpid`, count(`grpid`) as `count` from cloud_platform.work_group_ring";
	$sql.= " where `wkpid` in ({$optional['wkpidstr']})";
	$sql.= " group by `wkpid`";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$rows_grp = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$sql = "select `wkpid`, `user` from cloud_platform.work_ring";
	$sql.= " where `wkpid` in ({$optional['wkpidstr']})";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute();
		$rows_user = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	$user = array();
	foreach($rows_user as $u) {
		$id = 'wkp_' . $u->wkpid;
		if(isset($user[$id])) {
			if(!in_array($u->user, $user[$id])) {
				array_push($user[$id], $u->user);
			}
		} else {
			$user[$id] = array($u->user);
		}
	}
	foreach($user as $i => $v)
		$user[$i] = count($v);
	
	return array(
		'g' => $rows_grp,
		'u' => $user,
	);
}

function add_group($data) 
{
	global $nidb, $user;
	
	
	$optional = array();
	if(format_and_push($data, 'wkpid', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目未指定。');
		return false;
	}

	if(format_and_push($data, 'type', $optional, '', 'int', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请指定资源类型。');
		return false;
	}
	if(!check_group_type($optional['type'])) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '类型不正确。');
		return false;
	}
	
	if(format_and_push($data, 'ring', $optional, '', 'int', false) == false)
		$optional['ring'] = 0xFFFFFFFF;

	
	if(format_and_push($data, 'grpid', $optional, '', 'int', false))
		$optional['grpidstr'] = $optional['grpid'];

	if(format_and_push($data, 'grpidstr', $optional, '', 'string', false) == false) {
		if(!isset($optional['grpidstr'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目组不能为空。');
			return false;
		}
	}

	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $optional['grpidstr'], $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目组不正确。');
		return false;
	}

	if(!is_supadmin($user->username)) {
		$ring = is_admin($user->username, $optional['wkpid'], $optional['type'], ROLE_ADMIN);
		if(!$ring) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

	if(($wkp = info($optional)))
		$project_name = $wkp->name;
	else
		$project_name = '';
	
	$grpids = explode(',', $optional['grpidstr']);
	foreach($grpids as $id) {
		if($id && set_grpid($optional['wkpid'], $optional['type'], $optional['ring'], $id))
			$cnt++;
	}

	cloud_insertlog($user->username, "在“{$project_name}”项目配置 {$cnt} 个分组。");
	
	return $cnt == count($grpids);
}

function clean_group($data)
{
	// $user = 帐号 空值：指所有的默认
	// $wkpid = 项目ID 0：指所有的默认
	global $nidb, $user;


	$optional = array();
	format_and_push($data, 'wkpid', $optional, '', 'int', false);
	format_and_push($data, 'type', $optional, '', 'int', false);

	if(format_and_push($data, 'ring', $optional, '', 'int', false) == false)
		$optional['ring'] = null;

	
	if(format_and_push($data, 'grpid', $optional, '', 'int', false))
		$optional['grpidstr'] = $optional['grpid'];

	if(format_and_push($data, 'grpidstr', $optional, '', 'string', false) == false) {
		if(!isset($optional['grpidstr'])) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '项目组不能为空。');
			return false;
		}
	}
	
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $optional['grpidstr'], $match) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '项目组不正确。');
		return false;
	}

	if(!isset($optional['wkpid']) || !isset($optional['type'])) {
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}

		cloud_insertlog($user->username, "删除所有项目的分组");

		return rmv_grpidstr(null, null, $optional['ring'], null);
	}

	if(!is_supadmin($user->username)) {
		if(!is_admin($user->username, $optional['wkpid'], $optional['type'], ROLE_ADMIN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

	if(($wkp = info($optional)))
		$project_name = $wkp->name;
	else
		$project_name = '';

	if($optional['grpidstr']) {
/*
		switch($optional['type']) {
			case 1: // 网关
				$group = get_gateway_group($optional['grpidstr']);
				break;
			case 2: // 日志
				$group = get_panalog_group($optional['grpidstr']);
				break;
			case 3: // 缓存
				$group = get_ixcache_group($optional['grpidstr']);
				break;
			case 4: // SAC
				$group = get_sac_group($optional['grpidstr']);
				break;
			default:// 
				break;
		}
*/
		$group = explode(',', $optional['grpidstr']);
		cloud_insertlog($user->username, "从“{$project_name}”项目中删除 " . count($group) . " 个分组");
	}
	else
		cloud_insertlog($user->username, "从“{$project_name}”项目中删除所有分组");

	return rmv_grpidstr($optional['wkpid'], $optional['type'], $optional['ring'], $optional['grpidstr']);
}

