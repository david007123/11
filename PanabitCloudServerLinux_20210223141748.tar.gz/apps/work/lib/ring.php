<?php
namespace cloud\apps\work\project;



function resources($index)
{
	$resources = array("所有", "网关", "日志", "缓存", "SAC");
	if(isset($resources[$index])) return $resources[$index];

	return "未知";
}

function ringdesc($ring)
{
	$map = array( 'r_1' => "负责人", 'r_2' => "管理员",  'r_100' => "技术员",  'r_255' => "巡检员");
	if($ring) {
		if(isset($map['r_' . $ring])) 
			return $map['r_' . $ring];
	}
	
	return '无';
}

function set_grpid($wkpid = 0, $type = 0, $ring = 0, $grpid = 0)
{
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	// $grpidstr = 项目组ID
	global $nidb;


	try {
		$sql = "insert into cloud_platform.work_group_ring (`type`, `grpid`, `wkpid`, `ring`) values (?,?,?,?) on duplicate key update `wkpid` = ?, `ring` = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $type, \PDO::PARAM_INT);
		$sth->bindParam(2, $grpid, \PDO::PARAM_INT);
		$sth->bindParam(3, $wkpid, \PDO::PARAM_INT);
		$sth->bindParam(4, $ring, \PDO::PARAM_INT);
		$sth->bindParam(5, $wkpid, \PDO::PARAM_INT);
		$sth->bindParam(6, $ring, \PDO::PARAM_INT);
		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $ret;
}

function rmv_grpidstr($wkpid, $type, $ring, $grpidstr)
{
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	// $grpidstr = 项目组ID
	global $nidb;

/*
	if(preg_match("/^[0-9]{1,}$|^([0-9]{1,},[0-9]{1,}){1,}$/", $grpidstr, $match) === false) {
		set_errmsg(MSG_LEVEL_EXP, __function__, 'arg err. "grpidstr"');
		return false;
	}
*/
	try {

		$sql = "delete from cloud_platform.work_group_ring";

		$where = '';
		if(isset($grpidstr))
			$where.= " and `grpid` in ({$grpidstr})";
		if(isset($wkpid))
			$where.= " and `wkpid` = ?";

		if(isset($type))
			$where.= " and `type` = ?";

		if(isset($ring))
			$where.= " and `ring` = 0 and `ring` <= ?";

		if($where)
			$sql.= ' where ' . substr($where, 4);

		$sth = $nidb->prepare($sql);
		
		$index = 1;
		if(isset($wkpid))
			$sth->bindParam($index++, $wkpid, \PDO::PARAM_INT);
		
		if(isset($type))
			$sth->bindParam($index++, $type, \PDO::PARAM_INT);
			
		if(isset($ring))
			$sth->bindParam($index++, $ring, \PDO::PARAM_INT);

		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $ret;
}

function get_groupstr($wkpid = 0, $type = 0, $ring = 0)
{
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	global $nidb;


	try {
		// $sql = "select `wkpid`, `type`, `grpid`";
		$sql = "select group_concat(`grpid`) as `groupstr`";
		$sql.= " from cloud_platform.work_group_ring";
		$sql.= " where `wkpid` = ? and `ring` >= ? and `type` = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $wkpid, \PDO::PARAM_INT);
		$sth->bindParam(2, $ring, \PDO::PARAM_INT);
		$sth->bindParam(3, $type, \PDO::PARAM_INT);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if(!$row || $row['groupstr'] == NULL)
		return '';

	return $row['groupstr'];
}

function set_ring($user = '', $wkpid = 0, $type = 0, $ring = 0)
{
	// $user = 帐号 空值：指所有的默认
	// $wkpid = 项目ID 0：指所有的默认
	// $type = 组类别 0：指所有的默认，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	global $nidb;


	try {
		$sql = "insert into cloud_platform.work_ring";
		$sql.= " (`user`,`wkpid`,`type`,`ring`) values (?,?,?,?)";
		$sql.= " on duplicate key update `ring` = ?";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $user, \PDO::PARAM_STR);
		$sth->bindParam(2, $wkpid, \PDO::PARAM_INT);
		$sth->bindParam(3, $type, \PDO::PARAM_INT);
		$sth->bindParam(4, $ring, \PDO::PARAM_INT);
		$sth->bindParam(5, $ring, \PDO::PARAM_INT);

		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $ret;
}

function get_ring($user = '', $wkpid = 0, $type = 0)
{
	// $user = 帐号
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	global $nidb, $user;

	if($user == ADMIN_ACCT)
		return 0xFFFFFFFF;

	if(!$ring) return 0;

	try {
		$sql = "select `ring`";
		$sql.= " from cloud_platform.work_ring";
		$sql.= " where `user` = ? and `wkpid` = ? and `type` = ?";

		$sql.= " limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $user, \PDO::PARAM_STR);
		$sth->bindParam(2, $wkpid, \PDO::PARAM_INT);
		$sth->bindParam(3, $type, \PDO::PARAM_INT);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if($row) 
		return intval($row['ring']);

	return 0;
}

function rmv_ring($user, $wkpid, $type, $ring)
{
	// $user = 帐号 空值：指所有的默认
	// $wkpid = 项目ID 0：指所有的默认
	// $type = 组类别 0：指所有的默认，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	global $nidb;


	try {
		$sql = "delete from cloud_platform.work_ring";

		$where = '';
		if(isset($user))
			$where.= " and `user` = ?";

		if(isset($wkpid))
			$where.= " and `wkpid` = ?";

		if(isset($type))
			$where.= " and `type` = ?";

		if(isset($ring)) {
			$where.= " and `ring` = 0 and `ring` <= ?";
		}
		
		if($where)
			$sql.= ' where ' . substr($where, 4);

		$sth = $nidb->prepare($sql);

		$index = 1;
		if(isset($user))
			$sth->bindParam($index++, $user, \PDO::PARAM_STR);
		if(isset($wkpid))
			$sth->bindParam($index++, $wkpid, \PDO::PARAM_INT);
		if(isset($type))
			$sth->bindParam($index++, $type, \PDO::PARAM_INT);
		if(isset($ring) && $ring) {
			$sth->bindParam($index++, $ring, \PDO::PARAM_INT);
		}

		$ret = $sth->execute();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $ret;
}

function is_admin($user = '', $wkpid = 0, $type = 0, $ring = 0)
{
	// $user = 帐号
	// $wkpid = 项目ID
	// $type = 组类别 0：所有，1：网关；2：日志；3：缓存；4：SAC
	// $ring = 访问权限：0: 无权限，1：负责人权限，2：管理员权限，4：维护人员权限，8：查看权限
	global $nidb;


//	if(($ret = is_supadmin($user)))
//		return $ret;

	if(!$ring) return 0;

	try {
		$sql = "select `ring`";
		$sql.= " from cloud_platform.work_ring";
		$sql.= " where `user` = ? and `wkpid` = ? and `ring` > 0 and `ring` <= ? and (`type` = 0 or `type` = ?)";

		$sql.= " order by `type` desc limit 1";

		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $user, \PDO::PARAM_STR);
		$sth->bindParam(2, $wkpid, \PDO::PARAM_INT);
		$sth->bindParam(3, $ring, \PDO::PARAM_INT);
		$sth->bindParam(4, $type, \PDO::PARAM_INT);

		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	if($row) 
		return intval($row['ring']);

	return 0;
}

function is_access($wkpid, $ring = 15, $type = 0)
{
	global $user;
	
	if(!is_supadmin($user->username)) {
		if(!is_admin($user->username, $wkpid, $type, $ring)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}
	
	return true;
}

