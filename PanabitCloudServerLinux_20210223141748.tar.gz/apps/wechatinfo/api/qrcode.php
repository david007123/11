<?php
namespace cloud\apps\wechatinfo;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

// header("Content-type: application/json; charset=" . WEB_CHARSET);

// 支持库装载 | load lib
// ni_library_load('nidb');

// 装载功能 | load function
ni_app_load('user', 'login');
ni_app_load($appname, 'weixin');


// 验证用户 | auth user
if(($user = \cloud\apps\user\logged()) === false)  {
	header("Content-type: image/jpg");
	$fd = fopen($appdir . '/assets/img/qrcode_for_error.jpg', 'rb');
	while (!feof($fd)) 
		echo fread($fd, 8192);
	fclose($fd);
}

// 执行 | exec function
$result = weixin_qrcode($_REQUEST);


// 结果输出 | printf result
if($result === false) {
	header("Content-type: image/jpg");
	$fd = fopen($appdir . '/assets/img/qrcode_for_error.jpg', 'rb');
	while (!feof($fd)) 
		echo fread($fd, 8192);
	fclose($fd);
}
