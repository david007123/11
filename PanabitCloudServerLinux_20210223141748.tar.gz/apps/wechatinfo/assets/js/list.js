layui.use(['element', 'form', 'table'], function() {
	var element = layui.element;
	var form = layui.form;
	var table = layui.table;
	var timer = new taskTimer();
	
	table.render({
		elem: '#wechatuserlist',
		even: true,
		autoSort: false,
		loading: false,
		url: 'api.php?r=wechatinfo@user',
		method: 'post',
		limit: 20,
		skin: 'line',
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3 
		},
		parseData: function(res) {
			// res.count = res.user_info_list.length;
			if(res == "") return;
			res.data = res.user_info_list;
			res.code = 0;
			res.msg = '';
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				}, {
					title: '用户头像',
					templet: function(d) {
						return '<img src="' + d.headimgurl + '" width="30px" />';
					}
				}, {
					title: '用户昵称',
					templet: function(r) {
						return (typeof r.nickname == "undefined" ? "请关注Panabit公众号" : r.nickname);
					}
				}, {
					field: 'openid',
					title: '详细信息',
				}, {
					field: 'grpname',
					title: '操作',
					templet: function() {
						return '<span class="setBtn" lay-event="unbind">取消关联</span>'
					}
				}
			]
		]
	});

	table.on('tool(wechatuserlist)', function(obj) {
		var data = obj.data,
			event = obj.event;

		if (event === 'unbind') {
			layer.confirm('确认取消关联吗?', {
				icon: 0,
				title: '取消关联'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=wechatinfo@unbind',
					data: {
						openid: data.openid
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							if (d.msg) layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reload('wechatuserlist');
						layer.close(index);
					},
					error: function() {
						layer.msg('取消关联失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			});
		}
	});

	form.on('switch(bindsel)', function(data) {
		if (data.elem.checked == false) {
			layer.confirm('确认要取消所有用户的关联吗?', {
				icon: 0,
				title: '取消关联'
			}, function(index) {
				layer.close(index);
				$.ajax({
					url: 'api.php?r=wechatinfo@cancel',
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							if (d.msg) layer.msg(d.msg, {
								icon: 5
							});
							data.elem.checked = true;
							data.elem.disabled = false;
							form.render('checkbox');
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reload('wechatuserlist');
						data.elem.checked = false;
						data.elem.disabled = true;
						form.render('checkbox');
					},
					error: function() {
						data.elem.checked = true;
						data.elem.disabled = false;
						form.render('checkbox');
						layer.msg('取消关联失败，请稍后再试。', {
							icon: 2
						});
					}
				});
			}, function(index){
				data.elem.checked = true;
				data.elem.disabled = false;
				form.render('checkbox');
				layer.close(index);
			});
		}
	});

	form.on('checkbox(monwq)', function(data) {
		var data = {};

		$('input[lay-filter="monwq"]').each(function(i, e) {
			data[e.value] = e.checked ? 1 : 0;
		});

		$.ajax({
			url: 'api.php?r=wechatinfo@msgswitch',
			data: data,
			type: 'post',
			dataType: 'json',
			success: function(d) {
				if (ajax_resultCallBack(d) === false) {
					if (d.msg) layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
			},
			error: function() {
				layer.msg('取消关联失败，请稍后再试。', {
					icon: 2
				});
			}
		});
	});
	

	function maingroup_refresh (){
		timer.add('wechat_config', 3, {fuc: function(){
			var that = this;
			$.ajax({
				url: 'api.php?r=wechatinfo@config',
				type: 'post',
				success(d) {
					if(ajax_resultCallBack(d) == false) return;
					var i, conf = d.data;
					
					if(conf.wxbound) {
						$('#switch').prop('checked', true);
						$('#switch').prop('disabled', false);
					}
					else {
						$('#switch').prop('checked', false);
						$('#switch').prop('disabled', true);
					}
					$('input[name="monitor[discon]"]').prop('checked', !!conf.discon);
					$('input[name="monitor[expire]"]').prop('checked', !!conf.expire);

					form.render();
				}
			});
		}}, 1);
		timer.add('wechatuserlist', 15, {fuc: function(){
			table.reloadExt('wechatuserlist', {});
		}});
	}
	maingroup_refresh();

});
