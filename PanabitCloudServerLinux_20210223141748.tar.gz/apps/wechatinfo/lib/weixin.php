<?php
namespace cloud\apps\wechatinfo;


function getconfig($tag)
{
	$conf = LOG_CONF;

	$v = '';
	if (file_exists($conf)) {
		$lines = file($conf);
		foreach($lines as $val) {
			if (strstr($val, $tag) !== false) {
				$ds = explode('=', $val);
				$v = trim($ds[1], "\r\n");
				return $v;
			}
		}
	}
	
	return 0;
}

function setconfig($tag, $v)
{
	$conf = LOG_CONF;
	
	$tag_exists = 0;
	
	if (file_exists($conf)) {
		$lines = file($conf);
		
		if (($fp = fopen($conf, "w")) == false)
			return false;
		if (flock($fp, LOCK_EX)) {	
			foreach($lines as $val) {
				if (strstr($val, $tag."=") !== false) {
					fwrite($fp, "$tag=$v\n");
					$tag_exists = 1;
				}else
					fwrite($fp, $val);
				fflush($fp);
			}
		
			if ($tag_exists == 0) {
				fwrite($fp, "$tag=$v\n");
				fflush($fp);
			}
			flock($fp, LOCK_UN);
		}
		fclose($fp);

		return true;
	}

	return false;
}

function _get_uuidgen()
{
	$ret = '';

	if (file_exists("/etc/uuidgen.conf")) {
		$ret = trim(file_get_contents("/etc/uuidgen.conf"), "\n");
		if(empty($ret) == false)
			return $ret;
	}
	else {
		exec('/bin/uuidgen >> /etc/uuidgen.conf', $out, $ret);
		if($ret)
			set_errmsg(MSG_LEVEL_DEF, __function__, "UUIDGEN.CONF_NEXISTS");
		else {
			$ret = trim(file_get_contents("/etc/uuidgen.conf"), "\n");
			if(empty($ret) == false)
				return $ret;
		}
	}

	return false;
}

function weixin_config($data)
{
	global $user;

	$result = array(
		'discon'	=> 0,
		'expire'	=> 0,
		'wxbound'	=> 0,
	);

	$objs = getconfig("cloud_weixin_relation_obj");
	$ds = explode(',', $objs);
	foreach($ds as $val) {
		if ($val == "discon")
			$result['discon'] = 1;
		if ($val == "expire_license")
			$result['expire'] = 1;
	}

	$guid = _get_uuidgen();
	if ($guid) {
		$ret = httpPost("http://www.panabit.com/wxcloud/user_stat.php?guid={$guid}&user={$user->username}", array(), false);
		if(empty($ret) == false) {
			$data = json_decode($ret, true);
			if(json_last_error() == JSON_ERROR_NONE && $data['out'] == 'ERR_BIND')
				$result['wxbound'] = 1;
		}
	}

	return $result;
}

function weixin_user($data)
{
	global $user;

	$guid = _get_uuidgen();
	if ($guid) {
//		$ret = httpPost("http://www.panabit.com/wxcloud/user_list.php?guid={$guid}&user={$user->username}", array(), false);
		$ret = httpPost("http://www.panabit.com/wxcloud/user_list1.php?guid={$guid}&user={$user->username}", array(), false);
		echo $ret;
	}
	else
		echo '{"ret":-1,"out":"NO_USER"}';

	return true;
}

function weixin_cancel()
{
	global $user;

	$guid = _get_uuidgen();
	if ($guid) {
		$ret = httpPost("http://www.panabit.com/wxcloud/user_cancel.php?guid={$guid}&user={$user->username}", array(), false);
		$data = json_decode($ret, true);
		if(json_last_error() == JSON_ERROR_NONE) {
			if($data['ret'] != 0) {
				set_errmsg(MSG_LEVEL_DEF, __function__, $data['out']);
				return false;
			}
		}
	}
	
	return true;
}

function weixin_unbind($data)
{
	global $user;
	
	$optional = array();

	if(format_and_push($data, 'openid', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '操作对象不能为空。');
		return false;
	}
	if(preg_match("/^([a-zA-Z0-9-_]{20,})$/", $optional['openid'], $match) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "用户“{$optional['openid']}”不正确！");
		return false;
	}

	$guid = _get_uuidgen();
	if ($guid) {
//		$ret = httpPost("http://www.panabit.com/wxcloud/user_unbind.php?guid={$guid}&openid={$optional['openid']}", array(), false);
		$ret = httpPost("http://www.panabit.com/wxcloud/user_unbind1.php?guid={$guid}&openid={$optional['openid']}&user={$user->username}", array(), false);
		$data = json_decode($ret, true);
		if(json_last_error() == JSON_ERROR_NONE) {
			if($data['ret'] != 0) {
				set_errmsg(MSG_LEVEL_DEF, __function__, $data['out']);
				return false;
			}
		}
	}

	return true;
}

function weixin_msgswitch($data)
{
	$optional = array();

	$discon = 0;
	if(isset($data['discon']) && ($discon = intval($data['discon'])) != 0) {
		$discon = 1;
		array_push($optional, 'discon');
	}

	if(isset($data['expire']) && intval($data['expire']) != 0) {
		array_push($optional, 'expire_license');
	}

	$cmd = DATAEYE . " device config notify_discon={$discon}";
	exec($cmd, $out, $ret);

	setconfig("cloud_weixin_relation_obj", implode(',', $optional));

	return true;
}

function weixin_qrcode($data)
{
	global $user;


	$guid = _get_uuidgen();
	if (!$guid) return false;
		
	$appid = "wxc51276c9c38e2344";
//	$redirect_uri = "http://www.panabit.com/wxcloud/qrcode_create.php";
	$redirect_uri = "http://www.panabit.com/wxcloud/qrcode_create1.php";
	$state = "cloud {$user->username} {$guid}";

	// 二维码内容 
	$value = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_base&state={$state}#wechat_redirect";

	// 容错级别 
	$errorCorrectionLevel = 'L';	

	// 生成图片大小
	$matrixPointSize = 5;

	// 生成二维码图片 
	$path = dirname(__DIR__) . '/assets/qrcode';
	if(is_dir($path) == false) {
		if(mkdir($path, 755) === false) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '创建二维码图片文件夹失败！' . $path);
			return false;
		}
	}
	$QRfile = tempnam($path, '');
	if(!$QRfile) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '创建二维码图片文件失败！' . $path);
		return false;
	}

	\QRcode::png($value, $QRfile, $errorCorrectionLevel, $matrixPointSize, 2); 

	$QR = imagecreatefromstring(file_get_contents($QRfile)); 

	//二维码图片宽度 
	$QR_width = imagesx($QR);

	//二维码图片高度 
	$QR_height = imagesy($QR);
	$from_width = ($QR_width - 11) / 2; 

	//imagecopyresampled($QR, "", $from_width, $from_width, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height); 
	header("Content-type: image/png");
	ImagePng($QR);
	unlink($QRfile);

	return true;
}
