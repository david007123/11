// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

layui.use(['element', 'table', 'form'], function() {
	var element = layui.element;
	var table = layui.table;
	var form = layui.form;
	var timer = new taskTimer();
	var tablelns;

	function maingroup_refresh() {
		timer.add('fluid-off', 3, {
			fuc: function() {
				var that = this;

				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if(ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						
						$('select[lay-filter="fluid-group"] option').not('[value=-1]').remove();
						$('select[lay-filter="other-group"] option').not('[value=-1]').remove();
						for(i = 0; i < data.rows.length; i++) {
							$('select[lay-filter="fluid-group"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

							$('select[lay-filter="other-group"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));
						}

						form.render('select');
						timer.rmv('fluid-off');
					}
				});

			}
		}, 1);
		
		timer.add('cache-off', 3, {
			fuc: function() {
				var that = this;

				$.ajax({
					url: 'api.php?r=ixcache@group',
					type: 'post',
					success(d) {
						if(ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						
						$('select[lay-filter="cache-group"] option').not('[value=-1]').remove();
						for(i = 0; i < data.rows.length; i++) 
							$('select[lay-filter="cache-group"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
						timer.rmv('cache-off');
					}
				});
			}
		}, 1);
	}
	maingroup_refresh();
	
	table.render({
		elem: '#operateloglist',
		even: true,
		loading: false,
		url: 'api.php?r=system@logger-operate',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'time',
			type: 'desc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],

		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;

			var e = $('#operateloglist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					fixed: 'left',
					type: 'numbers',
					width: 40
				},
				{
					field: 'user',
					title: '用户名',
				}, {
					field: 'time',
					title: '操作时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.time, 'yyyy/MM-dd HH:mm:ss');
					}
				}, {
					field: 'ipaddr',
					title: '访问地址',
				}, {
					field: 'cont',
					title: '详细内容',
				}
			]
		]
	});

	table.render({
		elem: '#flowofflist',
		even: true,
		loading: false,
		url: 'api.php?r=system@logger-gateway',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
		 	field: 'time',
		 	type: 'desc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#flowofflist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					fixed: 'left',
					type: 'numbers',
					width: 40,
				},
				{
					field: 'license_id12',
					title: '设备编号',
				}, {
					field: 'name',
					title: '设备名称',
				}, {
					field: 'grpid',
					title: '属组',
					width: 98,
					templet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="fluid-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'time',
					title: '断开时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.time, 'yyyy/MM-dd HH:mm:ss');
					}
				}, {
					field: 'uptime',
					title: '操作时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.uptime, 'yyyy/MM-dd HH:mm:ss');
					}
				}
			]
		]
	});

	table.render({
		elem: '#cacheofflist',
		even: true,
		loading: false,
		url: 'api.php?r=system@logger-ixcache',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'time',
			type: 'desc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#cacheofflist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					fixed: 'left',
					type: 'numbers',
					width: 40
				},
				{
					field: 'license_id12',
					title: '设备编号',
				}, {
					field: 'name',
					title: '设备名称',
				}, {
					field: 'grpid',
					title: '属组',
					width: 98,
					templet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="cache-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'time',
					title: '断开时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.time, 'yyyy/MM-dd HH:mm:ss');
					}
				}, {
					field: 'uptime',
					title: '操作时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.uptime, 'yyyy/MM-dd HH:mm:ss');
					}
				}
			]
		]
	});

	table.render({
		elem: '#otherloglist',
		even: true,
		loading: false,
		url: 'api.php?r=system@logger-other',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		initSort: {
			field: 'time',
			type: 'desc'
		},
		request: {
			pageName: 'page',
			limitName: 'limit'
		},
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			res.count = res.data.total;
			res.data = res.data.rows;
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#otherloglist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					fixed: 'left',
					type: 'numbers',
					width: 40,
				},
				{
					field: 'license_id12',
					title: '设备编号',
				}, {
					field: 'name',
					title: '设备名称',
				}, {
					field: 'grpid',
					title: '属组',
					width: 98,
					templet: function(d) {
						var grpname;
						if (d.grpid == 0) return '';
						grpname = $('select[lay-filter="other-group"] option[value="' + d.grpid + '"]').text();
						return grpname;
					}
				}, {
					field: 'time',
					title: '检测时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.time, 'yyyy/MM-dd HH:mm:ss');
					}
				}, {
					field: 'log',
					title: '日志',
					templet: function(d) {
						return '<span class="off_txt">' + d.log + '</span>';
					}
				}
			]
		]
	});

	$('.search_operate').on('click', function() {
		search_operate(1);
	});
	
	$('.search_fluid').on('click', function() {
		search_fluid(1);
	});

	$('.searchcache').on('click', function() {
		searchcache(1);
	});

	$('.searchother').on('click', function() {
		searchother(1);
	});

	form.on('select(fluid-group)', function(data) {
		search_fluid(1);
	});
	form.on('select(cache-group)', function(data) {
		searchcache(1);
	});
	form.on('select(other-group)', function(data) {
		searchother(1);
	});

	$('.clear-flow').click(function(){
		if (!confirm("确定要清除历史断开日志吗"))
				return false;
		
			$.ajax({
				url:'/Maintain/system_handle_ex.php',
				data:{type:'disconclear'},
				dataType:'json',
				type:'post',
				success:function(data) {
					location.reload();
				}
			})
	});
	
	$('.clear-cache').click(function(){
		if (!confirm("确定要清除历史断开日志吗"))
				return false;
		
			$.ajax({
				url:'/Maintain/system_handle_ex.php',
				data:{type:'ixcdisconclear'},
				dataType:'json',
				type:'post',
				success:function(data) {
					location.reload();
				}
			})
	});
	
	function search_operate(page, obj) {
		var where = {
			keyword: $.trim($('.oplogtxt').val()),
		};
		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;

		table.reloadExt('operateloglist', option);
	}
	
	function search_fluid(page, obj) {
		var where = {
			keyword: $.trim($('.fluidtxt').val()),
			grpid: Number($('select[lay-filter="fluid-group"]').val())
		};
		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;

		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		}
		
		table.reloadExt('flowofflist', option);
	}

	function searchcache(page, obj) {
		var where = {
			keyword: $.trim($('.cachetxt').val()),
			grpid: Number($('select[lay-filter="cache-group"]').val())
		};

		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;

		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		}

		table.reloadExt('cacheofflist', option);
	}
	
	function searchother(page, obj) {
		var where = {
			keyword: $.trim($('.othertxt').val()),
			grpid: Number($('select[lay-filter="other-group"]').val())
		};
	
		var option = {
			method: 'post',
			where: where
		};
		if (typeof page == "number") {
			if (page > 0)
				option.page = {
					curr: page
				}; //重新从第 1 页开始
		} else
			page = 0;

		if (obj) {
			option.initSort = obj;
			if (obj.field) where.sort = obj.field;
			if (obj.type) where.g_ascdesc = obj.type;
		}
	
		table.reloadExt('otherloglist', option);
	}

});
