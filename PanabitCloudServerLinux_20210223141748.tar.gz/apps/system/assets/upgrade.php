<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<!-- <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" /> -->
		<link rel="stylesheet" href="assets/css/font.css">
		<link rel="stylesheet" href="assets/css/xadmin.css">
		<link rel="stylesheet" type="text/css" href="assets/lib/layui/css/layui.css" />
		<link rel="stylesheet" type="text/css" href="assets/css/cloud.css" />
		<script src="assets/js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="assets/lib/layui/layui.js" charset="utf-8"></script>
		<script type="text/javascript" src="assets/js/comm.js" charset="utf-8"></script>
		<style type="text/css">
			.header1{
				width:100%;
				display:block;
				border-bottom:rgba(204,204,204,1) 1px solid;
				padding-bottom:0px;
				padding:0px;
				margin:0px;
			}
			
			.header2{
				width:100%;
				display:block;
				background-color:rgba(204,204,204,0.3);
				padding:0px;
				margin-top:20px;
              font-size:12px;
	
			}
			
			.header3{
				width:100%;
				display:block;
				padding:5px 2px;
				margin-top:20px;
				font-size:12px;
			}
			.header3 .content1{
				display:inline-block;
				float:left;
				padding:0px;
			}
			.header3 .content2{
				display:inline-block;
				float:left;
				padding:0px;
				margin-left:200px;
			}

			body{
				padding:0px 0px;
				margin:0px;
			}
			
			#systime .layui-form-label {
				width: 60px;
			}

			.layui-form-item .layui-input-inline {
				margin-left: 5px;
				width: inherit;
			}

			[lay-filter="time_config"],
			[lay-filter="form-reboot"],
			[lay-filter="form-shutdown"] {
				margin-top: 18px;
			}

			.layui-form-item {
				margin-bottom: 6px;
			}

			.layui-form-select .layui-edge {
				right: 12px;
				left: inherit;
			}

			.layui-form-select .layui-input {
				width: 166px;
			}

			.layui-form-select dl dt {
				font-size: 14px;
				color: #2E8AE3;
				font-weight: bold;
				background: whitesmoke;
			}
		</style>
	</head>
	<body>
	<div class="layui-tab layui-tab-brief" lay-filter="system">
		<ul class="layui-tab-title">
			<li class="layui-this">系统升级</li>
			<li>系统时间</li>
<?php
	if (is_supadmin($user->username)) {
?>
			<li>系统重启</li>
			<li>系统关机</li>
<?php
	}
?>
		</ul>
		<div class="layui-tab-content">
			<div class="layui-tab-item layui-show">
				<div class="header2">
					<p  class="layui-elem-quote">系统升级大约一分钟，升级之后，如果页面没有任何变化或者显示比较杂乱，请清除浏览器缓存后重新登录，或者使用快捷键ctrl+f5进行页面强制刷新。</p>
				</div>
				<div class="header2">
					<p class="layui-elem-quote">当前版本：<span id="version"><?php echo VERSION;?></span> <?php $ver = system_version(); if($ver && isset($ver['ver'])) echo ' [' . $ver['ver'] . ']';?></p>
				</div>
				<div class="header3">
					<div class="content1">请选择升级包文件：&nbsp;&nbsp;<button type="button" class="layui-btn" id="upload"><i class="layui-icon"></i>上传文件</button></div>      
				</div>
			</div>
			<div class="layui-tab-item" id="systime">
				<form class="layui-form" action="" lay-filter="time_config">
					<div class="layui-form-item">
						<div class="layui-inline">
						  <label class="layui-form-label">时区选择</label>
						  <div class="layui-input-inline">
							<select name="timezone" lay-search="">
							  <option value="">请选择</option>
							</select>
						  </div>
						</div>
					</div>
					<div class="layui-form-item">
						<div class="layui-inline">
							<label class="layui-form-label">时间</label>
							<div class="layui-input-inline">
								<input type="text" class="layui-input" name="currtime" placeholder="yyyy-MM-dd HH:mm:ss">
							</div>
						</div>
					</div>
					<div class="layui-form-item">
						<button type="submit" class="layui-btn layui-btn-sm save" lay-submit="" lay-filter="save">
							<i class="layui-icon icontext">保存修改</i>
						</button>
					</div>
				</form>
			</div>
<?php
	if (is_supadmin($user->username)) {
?>
			<div class="layui-tab-item" id="reboot">
				<form class="layui-form" action="" lay-filter="form-reboot">
					<div class="layui-form-item">
						<div class="layui-inline">
							<label class="layui-form-label">管理密码</label>
							<div class="layui-input-inline">
								<input type="text" class="layui-input" name="pass" placeholder="">
							</div>
							<button type="submit" class="layui-btn layui-btn-sm save" lay-submit="" lay-filter="reboot">
								<i class="layui-icon icontext">重启</i>
							</button>
						</div>
					</div>
				</form>
			</div>
			<div class="layui-tab-item" id="shutdown">
				<form class="layui-form" action="" lay-filter="form-shutdown">
					<div class="layui-form-item">
						<div class="layui-inline">
							<label class="layui-form-label">管理密码</label>
							<div class="layui-input-inline">
								<input type="text" class="layui-input" name="pass" placeholder="">
							</div>
							<button type="submit" class="layui-btn layui-btn-sm save" lay-submit="" lay-filter="shutdown">
								<i class="layui-icon icontext">关机</i>
							</button>
						</div>
					</div>
				</form>
			</div>
<?php
	}
?>
		</div>
	</body>
	
	<script src="assets/lib/layui/layui.js" charset="utf-8"></script>
	<script>
	var TIMEZONF = {
	"Africa":[{"id":"Abidjan","text":"Abidjan"},{"id":"Accra","text":"Accra"},{"id":"Addis_Ababa","text":"Addis_Ababa"},{"id":"Algiers","text":"Algiers"},{"id":"Asmara","text":"Asmara"},{"id":"Bamako","text":"Bamako"},{"id":"Bangui","text":"Bangui"},{"id":"Banjul","text":"Banjul"},{"id":"Bissau","text":"Bissau"},{"id":"Blantyre","text":"Blantyre"},{"id":"Brazzaville","text":"Brazzaville"},{"id":"Bujumbura","text":"Bujumbura"},{"id":"Cairo","text":"Cairo"},{"id":"Casablanca","text":"Casablanca"},{"id":"Ceuta","text":"Ceuta"},{"id":"Conakry","text":"Conakry"},{"id":"Dakar","text":"Dakar"},{"id":"Dar_es_Salaam","text":"Dar_es_Salaam"},{"id":"Djibouti","text":"Djibouti"},{"id":"Douala","text":"Douala"},{"id":"El_Aaiun","text":"El_Aaiun"},{"id":"Freetown","text":"Freetown"},{"id":"Gaborone","text":"Gaborone"},{"id":"Harare","text":"Harare"},{"id":"Johannesburg","text":"Johannesburg"},{"id":"Juba","text":"Juba"},{"id":"Kampala","text":"Kampala"},{"id":"Khartoum","text":"Khartoum"},{"id":"Kigali","text":"Kigali"},{"id":"Kinshasa","text":"Kinshasa"},{"id":"Lagos","text":"Lagos"},{"id":"Libreville","text":"Libreville"},{"id":"Lome","text":"Lome"},{"id":"Luanda","text":"Luanda"},{"id":"Lubumbashi","text":"Lubumbashi"},{"id":"Lusaka","text":"Lusaka"},{"id":"Malabo","text":"Malabo"},{"id":"Maputo","text":"Maputo"},{"id":"Maseru","text":"Maseru"},{"id":"Mbabane","text":"Mbabane"},{"id":"Mogadishu","text":"Mogadishu"},{"id":"Monrovia","text":"Monrovia"},{"id":"Nairobi","text":"Nairobi"},{"id":"Ndjamena","text":"Ndjamena"},{"id":"Niamey","text":"Niamey"},{"id":"Nouakchott","text":"Nouakchott"},{"id":"Ouagadougou","text":"Ouagadougou"},{"id":"Porto-Novo","text":"Porto-Novo"},{"id":"Sao_Tome","text":"Sao_Tome"},{"id":"Tripoli","text":"Tripoli"},{"id":"Tunis","text":"Tunis"},{"id":"Windhoek","text":"Windhoek"}],
	"America":[{"id":"Adak","text":"Adak"},{"id":"Anchorage","text":"Anchorage"},{"id":"Anguilla","text":"Anguilla"},{"id":"Antigua","text":"Antigua"},{"id":"Araguaina","text":"Araguaina"},{"id":"Argentina","text":"Argentina"},{"id":"Aruba","text":"Aruba"},{"id":"Asuncion","text":"Asuncion"},{"id":"Atikokan","text":"Atikokan"},{"id":"Bahia","text":"Bahia"},{"id":"Bahia_Banderas","text":"Bahia_Banderas"},{"id":"Barbados","text":"Barbados"},{"id":"Belem","text":"Belem"},{"id":"Belize","text":"Belize"},{"id":"Blanc-Sablon","text":"Blanc-Sablon"},{"id":"Boa_Vista","text":"Boa_Vista"},{"id":"Bogota","text":"Bogota"},{"id":"Boise","text":"Boise"},{"id":"Cambridge_Bay","text":"Cambridge_Bay"},{"id":"Campo_Grande","text":"Campo_Grande"},{"id":"Cancun","text":"Cancun"},{"id":"Caracas","text":"Caracas"},{"id":"Cayenne","text":"Cayenne"},{"id":"Cayman","text":"Cayman"},{"id":"Chicago","text":"Chicago"},{"id":"Chihuahua","text":"Chihuahua"},{"id":"Costa_Rica","text":"Costa_Rica"},{"id":"Creston","text":"Creston"},{"id":"Cuiaba","text":"Cuiaba"},{"id":"Curacao","text":"Curacao"},{"id":"Danmarkshavn","text":"Danmarkshavn"},{"id":"Dawson","text":"Dawson"},{"id":"Dawson_Creek","text":"Dawson_Creek"},{"id":"Denver","text":"Denver"},{"id":"Detroit","text":"Detroit"},{"id":"Dominica","text":"Dominica"},{"id":"Edmonton","text":"Edmonton"},{"id":"Eirunepe","text":"Eirunepe"},{"id":"El_Salvador","text":"El_Salvador"},{"id":"Fortaleza","text":"Fortaleza"},{"id":"Glace_Bay","text":"Glace_Bay"},{"id":"Godthab","text":"Godthab"},{"id":"Goose_Bay","text":"Goose_Bay"},{"id":"Grand_Turk","text":"Grand_Turk"},{"id":"Grenada","text":"Grenada"},{"id":"Guadeloupe","text":"Guadeloupe"},{"id":"Guatemala","text":"Guatemala"},{"id":"Guayaquil","text":"Guayaquil"},{"id":"Guyana","text":"Guyana"},{"id":"Halifax","text":"Halifax"},{"id":"Havana","text":"Havana"},{"id":"Hermosillo","text":"Hermosillo"},{"id":"Indiana","text":"Indiana"},{"id":"Inuvik","text":"Inuvik"},{"id":"Iqaluit","text":"Iqaluit"},{"id":"Jamaica","text":"Jamaica"},{"id":"Juneau","text":"Juneau"},{"id":"Kentucky","text":"Kentucky"},{"id":"Kralendijk","text":"Kralendijk"},{"id":"La_Paz","text":"La_Paz"},{"id":"Lima","text":"Lima"},{"id":"Los_Angeles","text":"Los_Angeles"},{"id":"Lower_Princes","text":"Lower_Princes"},{"id":"Maceio","text":"Maceio"},{"id":"Managua","text":"Managua"},{"id":"Manaus","text":"Manaus"},{"id":"Marigot","text":"Marigot"},{"id":"Martinique","text":"Martinique"},{"id":"Matamoros","text":"Matamoros"},{"id":"Mazatlan","text":"Mazatlan"},{"id":"Menominee","text":"Menominee"},{"id":"Merida","text":"Merida"},{"id":"Metlakatla","text":"Metlakatla"},{"id":"Mexico_City","text":"Mexico_City"},{"id":"Miquelon","text":"Miquelon"},{"id":"Moncton","text":"Moncton"},{"id":"Monterrey","text":"Monterrey"},{"id":"Montevideo","text":"Montevideo"},{"id":"Montreal","text":"Montreal"},{"id":"Montserrat","text":"Montserrat"},{"id":"Nassau","text":"Nassau"},{"id":"New_York","text":"New_York"},{"id":"Nipigon","text":"Nipigon"},{"id":"Nome","text":"Nome"},{"id":"Noronha","text":"Noronha"},{"id":"North_Dakota","text":"North_Dakota"},{"id":"Ojinaga","text":"Ojinaga"},{"id":"Panama","text":"Panama"},{"id":"Pangnirtung","text":"Pangnirtung"},{"id":"Paramaribo","text":"Paramaribo"},{"id":"Phoenix","text":"Phoenix"},{"id":"Port-au-Prince","text":"Port-au-Prince"},{"id":"Port_of_Spain","text":"Port_of_Spain"},{"id":"Porto_Velho","text":"Porto_Velho"},{"id":"Puerto_Rico","text":"Puerto_Rico"},{"id":"Rainy_River","text":"Rainy_River"},{"id":"Rankin_Inlet","text":"Rankin_Inlet"},{"id":"Recife","text":"Recife"},{"id":"Regina","text":"Regina"},{"id":"Resolute","text":"Resolute"},{"id":"Rio_Branco","text":"Rio_Branco"},{"id":"Santa_Isabel","text":"Santa_Isabel"},{"id":"Santarem","text":"Santarem"},{"id":"Santiago","text":"Santiago"},{"id":"Santo_Domingo","text":"Santo_Domingo"},{"id":"Sao_Paulo","text":"Sao_Paulo"},{"id":"Scoresbysund","text":"Scoresbysund"},{"id":"Shiprock","text":"Shiprock"},{"id":"Sitka","text":"Sitka"},{"id":"St_Barthelemy","text":"St_Barthelemy"},{"id":"St_Johns","text":"St_Johns"},{"id":"St_Kitts","text":"St_Kitts"},{"id":"St_Lucia","text":"St_Lucia"},{"id":"St_Thomas","text":"St_Thomas"},{"id":"St_Vincent","text":"St_Vincent"},{"id":"Swift_Current","text":"Swift_Current"},{"id":"Tegucigalpa","text":"Tegucigalpa"},{"id":"Thule","text":"Thule"},{"id":"Thunder_Bay","text":"Thunder_Bay"},{"id":"Tijuana","text":"Tijuana"},{"id":"Toronto","text":"Toronto"},{"id":"Tortola","text":"Tortola"},{"id":"Vancouver","text":"Vancouver"},{"id":"Whitehorse","text":"Whitehorse"},{"id":"Winnipeg","text":"Winnipeg"},{"id":"Yakutat","text":"Yakutat"},{"id":"Yellowknife","text":"Yellowknife"}],
	"Antarctica":[{"id":"Casey","text":"Casey"},{"id":"Davis","text":"Davis"},{"id":"DumontDUrville","text":"DumontDUrville"},{"id":"Macquarie","text":"Macquarie"},{"id":"Mawson","text":"Mawson"},{"id":"McMurdo","text":"McMurdo"},{"id":"Palmer","text":"Palmer"},{"id":"Rothera","text":"Rothera"},{"id":"South_Pole","text":"South_Pole"},{"id":"Syowa","text":"Syowa"},{"id":"Vostok","text":"Vostok"}],
	"Arctic":[{"id":"Longyearbyen","text":"Longyearbyen"}],
	"Asia":[{"id":"Aden","text":"Aden"},{"id":"Almaty","text":"Almaty"},{"id":"Amman","text":"Amman"},{"id":"Anadyr","text":"Anadyr"},{"id":"Aqtau","text":"Aqtau"},{"id":"Aqtobe","text":"Aqtobe"},{"id":"Ashgabat","text":"Ashgabat"},{"id":"Baghdad","text":"Baghdad"},{"id":"Bahrain","text":"Bahrain"},{"id":"Baku","text":"Baku"},{"id":"Bangkok","text":"Bangkok"},{"id":"Beirut","text":"Beirut"},{"id":"Bishkek","text":"Bishkek"},{"id":"Brunei","text":"Brunei"},{"id":"Choibalsan","text":"Choibalsan"},{"id":"Chongqing","text":"Chongqing"},{"id":"Colombo","text":"Colombo"},{"id":"Damascus","text":"Damascus"},{"id":"Dhaka","text":"Dhaka"},{"id":"Dili","text":"Dili"},{"id":"Dubai","text":"Dubai"},{"id":"Dushanbe","text":"Dushanbe"},{"id":"Gaza","text":"Gaza"},{"id":"Harbin","text":"Harbin"},{"id":"Hebron","text":"Hebron"},{"id":"Ho_Chi_Minh","text":"Ho_Chi_Minh"},{"id":"Hong_Kong","text":"Hong_Kong"},{"id":"Hovd","text":"Hovd"},{"id":"Irkutsk","text":"Irkutsk"},{"id":"Jakarta","text":"Jakarta"},{"id":"Jayapura","text":"Jayapura"},{"id":"Jerusalem","text":"Jerusalem"},{"id":"Kabul","text":"Kabul"},{"id":"Kamchatka","text":"Kamchatka"},{"id":"Karachi","text":"Karachi"},{"id":"Kashgar","text":"Kashgar"},{"id":"Kathmandu","text":"Kathmandu"},{"id":"Khandyga","text":"Khandyga"},{"id":"Kolkata","text":"Kolkata"},{"id":"Krasnoyarsk","text":"Krasnoyarsk"},{"id":"Kuala_Lumpur","text":"Kuala_Lumpur"},{"id":"Kuching","text":"Kuching"},{"id":"Kuwait","text":"Kuwait"},{"id":"Macau","text":"Macau"},{"id":"Magadan","text":"Magadan"},{"id":"Makassar","text":"Makassar"},{"id":"Manila","text":"Manila"},{"id":"Muscat","text":"Muscat"},{"id":"Nicosia","text":"Nicosia"},{"id":"Novokuznetsk","text":"Novokuznetsk"},{"id":"Novosibirsk","text":"Novosibirsk"},{"id":"Omsk","text":"Omsk"},{"id":"Oral","text":"Oral"},{"id":"Phnom_Penh","text":"Phnom_Penh"},{"id":"Pontianak","text":"Pontianak"},{"id":"Pyongyang","text":"Pyongyang"},{"id":"Qatar","text":"Qatar"},{"id":"Qyzylorda","text":"Qyzylorda"},{"id":"Rangoon","text":"Rangoon"},{"id":"Riyadh","text":"Riyadh"},{"id":"Sakhalin","text":"Sakhalin"},{"id":"Samarkand","text":"Samarkand"},{"id":"Seoul","text":"Seoul"},{"id":"Shanghai","text":"Shanghai"},{"id":"Singapore","text":"Singapore"},{"id":"Taipei","text":"Taipei"},{"id":"Tashkent","text":"Tashkent"},{"id":"Tbilisi","text":"Tbilisi"},{"id":"Tehran","text":"Tehran"},{"id":"Thimphu","text":"Thimphu"},{"id":"Tokyo","text":"Tokyo"},{"id":"Ulaanbaatar","text":"Ulaanbaatar"},{"id":"Urumqi","text":"Urumqi"},{"id":"Ust-Nera","text":"Ust-Nera"},{"id":"Vientiane","text":"Vientiane"},{"id":"Vladivostok","text":"Vladivostok"},{"id":"Yakutsk","text":"Yakutsk"},{"id":"Yekaterinburg","text":"Yekaterinburg"},{"id":"Yerevan","text":"Yerevan"}],
	"Atlantic":[{"id":"Azores","text":"Azores"},{"id":"Bermuda","text":"Bermuda"},{"id":"Canary","text":"Canary"},{"id":"Cape_Verde","text":"Cape_Verde"},{"id":"Faroe","text":"Faroe"},{"id":"Madeira","text":"Madeira"},{"id":"Reykjavik","text":"Reykjavik"},{"id":"South_Georgia","text":"South_Georgia"},{"id":"St_Helena","text":"St_Helena"},{"id":"Stanley","text":"Stanley"}],
	"Australia":[{"id":"Adelaide","text":"Adelaide"},{"id":"Brisbane","text":"Brisbane"},{"id":"Broken_Hill","text":"Broken_Hill"},{"id":"Currie","text":"Currie"},{"id":"Darwin","text":"Darwin"},{"id":"Eucla","text":"Eucla"},{"id":"Hobart","text":"Hobart"},{"id":"Lindeman","text":"Lindeman"},{"id":"Lord_Howe","text":"Lord_Howe"},{"id":"Melbourne","text":"Melbourne"},{"id":"Perth","text":"Perth"},{"id":"Sydney","text":"Sydney"}],
	"Europe":[{"id":"Amsterdam","text":"Amsterdam"},{"id":"Andorra","text":"Andorra"},{"id":"Athens","text":"Athens"},{"id":"Belgrade","text":"Belgrade"},{"id":"Berlin","text":"Berlin"},{"id":"Bratislava","text":"Bratislava"},{"id":"Brussels","text":"Brussels"},{"id":"Bucharest","text":"Bucharest"},{"id":"Budapest","text":"Budapest"},{"id":"Busingen","text":"Busingen"},{"id":"Chisinau","text":"Chisinau"},{"id":"Copenhagen","text":"Copenhagen"},{"id":"Dublin","text":"Dublin"},{"id":"Gibraltar","text":"Gibraltar"},{"id":"Guernsey","text":"Guernsey"},{"id":"Helsinki","text":"Helsinki"},{"id":"Isle_of_Man","text":"Isle_of_Man"},{"id":"Istanbul","text":"Istanbul"},{"id":"Jersey","text":"Jersey"},{"id":"Kaliningrad","text":"Kaliningrad"},{"id":"Kiev","text":"Kiev"},{"id":"Lisbon","text":"Lisbon"},{"id":"Ljubljana","text":"Ljubljana"},{"id":"London","text":"London"},{"id":"Luxembourg","text":"Luxembourg"},{"id":"Madrid","text":"Madrid"},{"id":"Malta","text":"Malta"},{"id":"Mariehamn","text":"Mariehamn"},{"id":"Minsk","text":"Minsk"},{"id":"Monaco","text":"Monaco"},{"id":"Moscow","text":"Moscow"},{"id":"Oslo","text":"Oslo"},{"id":"Paris","text":"Paris"},{"id":"Podgorica","text":"Podgorica"},{"id":"Prague","text":"Prague"},{"id":"Riga","text":"Riga"},{"id":"Rome","text":"Rome"},{"id":"Samara","text":"Samara"},{"id":"San_Marino","text":"San_Marino"},{"id":"Sarajevo","text":"Sarajevo"},{"id":"Simferopol","text":"Simferopol"},{"id":"Skopje","text":"Skopje"},{"id":"Sofia","text":"Sofia"},{"id":"Stockholm","text":"Stockholm"},{"id":"Tallinn","text":"Tallinn"},{"id":"Tirane","text":"Tirane"},{"id":"Uzhgorod","text":"Uzhgorod"},{"id":"Vaduz","text":"Vaduz"},{"id":"Vatican","text":"Vatican"},{"id":"Vienna","text":"Vienna"},{"id":"Vilnius","text":"Vilnius"},{"id":"Volgograd","text":"Volgograd"},{"id":"Warsaw","text":"Warsaw"},{"id":"Zagreb","text":"Zagreb"},{"id":"Zaporozhye","text":"Zaporozhye"},{"id":"Zurich","text":"Zurich"}],
	"Indian":[{"id":"Indiana","text":"Indiana"},{"id":"Antananarivo","text":"Antananarivo"},{"id":"Chagos","text":"Chagos"},{"id":"Christmas","text":"Christmas"},{"id":"Cocos","text":"Cocos"},{"id":"Comoro","text":"Comoro"},{"id":"Kerguelen","text":"Kerguelen"},{"id":"Mahe","text":"Mahe"},{"id":"Maldives","text":"Maldives"},{"id":"Mauritius","text":"Mauritius"},{"id":"Mayotte","text":"Mayotte"},{"id":"Reunion","text":"Reunion"}],
	"Pacific":[{"id":"Apia","text":"Apia"},{"id":"Auckland","text":"Auckland"},{"id":"Chatham","text":"Chatham"},{"id":"Chuuk","text":"Chuuk"},{"id":"Easter","text":"Easter"},{"id":"Efate","text":"Efate"},{"id":"Enderbury","text":"Enderbury"},{"id":"Fakaofo","text":"Fakaofo"},{"id":"Fiji","text":"Fiji"},{"id":"Funafuti","text":"Funafuti"},{"id":"Galapagos","text":"Galapagos"},{"id":"Gambier","text":"Gambier"},{"id":"Guadalcanal","text":"Guadalcanal"},{"id":"Guam","text":"Guam"},{"id":"Honolulu","text":"Honolulu"},{"id":"Johnston","text":"Johnston"},{"id":"Kiritimati","text":"Kiritimati"},{"id":"Kosrae","text":"Kosrae"},{"id":"Kwajalein","text":"Kwajalein"},{"id":"Majuro","text":"Majuro"},{"id":"Marquesas","text":"Marquesas"},{"id":"Midway","text":"Midway"},{"id":"Nauru","text":"Nauru"},{"id":"Niue","text":"Niue"},{"id":"Norfolk","text":"Norfolk"},{"id":"Noumea","text":"Noumea"},{"id":"Pago_Pago","text":"Pago_Pago"},{"id":"Palau","text":"Palau"},{"id":"Pitcairn","text":"Pitcairn"},{"id":"Pohnpei","text":"Pohnpei"},{"id":"Port_Moresby","text":"Port_Moresby"},{"id":"Rarotonga","text":"Rarotonga"},{"id":"Saipan","text":"Saipan"},{"id":"Tahiti","text":"Tahiti"},{"id":"Tarawa","text":"Tarawa"},{"id":"Tongatapu","text":"Tongatapu"},{"id":"Wake","text":"Wake"},{"id":"Wallis","text":"Wallis"}]
	};
	var name, tz, html = '<option value="">请选择</option>';
	for(name in TIMEZONF) {
		tz = TIMEZONF[name];

		html += '<optgroup label="' + name + '">';
		for(var i = 0; i < tz.length; i++) {
			city = tz[i];
			html += '<option value="' + name + '/' + city.id + '">' + city.text + '</option>';
		}
		html += '</optgroup>';
	}
	$('#systime [name="timezone"]').html(html);
	
	var timer = new taskTimer();
	
	Date.prototype.stdTimezoneOffset = function() {
		var jan = new Date(this.getFullYear(), 0, 1);
		var jul = new Date(this.getFullYear(), 6, 1);
		return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
	}
	Date.prototype.dst = function() {
		return this.getTimezoneOffset() < this.stdTimezoneOffset();
	}

	function timezone(form)
	{
		$.ajax({
			url: 'api.php?r=system@currtime',
			success(d) {
				if (ajax_resultCallBack(d) == false) return;

				$('#systime [name="timezone"] option[value="'+ $('#systime [name="timezone"]').val() +'"]').prop('selected', false);
				$('#systime [name="timezone"] option[value="'+ d.data.timezone_id +'"]').prop('selected', true);
				$('#systime [name="currtime"]').val(d.data.time);
				
				form.render('select');
			}
		});
		
	}

	function reload_version()
	{
		timer.add('version', 1, {
			fuc: function() {
				$.ajax({
					url: 'api.php?r=system@version',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						$('#version').text(d.data);
						timer.rmv('version');
					}
				});
			}
		}, 1);
	}
	reload_version();

	layui.use(['upload', 'element', 'laydate', 'form'], function(){
		var index_loading,
			$ = layui.jquery,
			upload = layui.upload;
			element = layui.element;
			laydate = layui.laydate;
			form = layui.form;

		upload.render({
			elem: '#upload',
			url: 'api.php?r=system@upgrade',
			accept: 'file',
			before: function(obj){
				index_loading = layer.load(0, {shade: 0});
			},
			done: function(d, index, upload){
				layer.close(index_loading);
				if (ajax_resultCallBack(d) === false) {
					layer.msg(d.msg, {
						icon: 5
					});
					return;
				}
				if (d.msg) layer.msg(d.msg, {
					icon: 1
				});
				reload_version();
				// window.location.reload();
			},
			error: function(index, upload){
				layer.close(index_loading);
			}
		});

		laydate.render({
			elem: '#systime [name="currtime"]'
			,type: 'datetime'
		});

		element.on('tab(system)', function(data){
			if(data.index == 0)
				reload_version();
			if(data.index == 1) {
				timezone(form);
			}
		});

		
		form.on('submit(save)', function(data){
			var that = this;
			if(that.__submit) return false;
			that.__submit = 1;
			$.ajax({
				url: 'api.php?r=system@savetime',
				data: data.field,
				dataType:'json',
				type:'post',
				success:function(d) {
					that.__submit = 0;
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					timezone(form);
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				},
				error: function() {
					that.__submit = 0;
				}
			});
			return false;
		});

		
		form.on('submit(reboot)', function(data){
			var that = this;
			if(that.__submit) return false;
			that.__submit = 1;
			$.ajax({
				url: 'api.php?r=system@reboot',
				data: data.field,
				dataType:'json',
				type:'post',
				success:function(d) {
					that.__submit = 0;
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				},
				error: function() {
					that.__submit = 0;
				}
			});
			return false;
		});

		
		form.on('submit(shutdown)', function(data){
			var that = this;
			if(that.__submit) return false;
			that.__submit = 1;
			$.ajax({
				url: 'api.php?r=system@shutdown',
				data: data.field,
				dataType:'json',
				type:'post',
				success:function(d) {
					that.__submit = 0;
					if (ajax_resultCallBack(d) === false) {
						layer.msg(d.msg, {
							icon: 5
						});
						return;
					}
					if (d.msg) layer.msg(d.msg, {
						icon: 1
					});
				},
				error: function() {
					that.__submit = 0;
				}
			});
			return false;
		});
	});

    </script>				

</html>
