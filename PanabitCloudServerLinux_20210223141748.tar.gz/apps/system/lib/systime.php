<?php
namespace cloud\apps\system\systime;


function tz_offset_to_name($hour)
{
	$offset = $hour * 3600; // convert hour offset to seconds
	$abbrarray = timezone_abbreviations_list();

	foreach ($abbrarray as $abbr) {
		foreach ($abbr as $city) {
			if(isset($city['offset'])) {
				if ($city['offset'] == $offset) {
					return $city['timezone_id'];
				}
			}
		}
	}

	return 0;
}

function timezone_list()
{
	return timezone_abbreviations_list();
}

function config()
{
	return myconf_read(TIMEZONE_CONF, array());
}

function get()
{
	$time = new \DateTime('now'); // , new \DateTimeZone($timezone));
	return $time->format('Y-m-d H:i:s');
}

function save($data)
{
	if(isset($data['currtime'])) {
		$data['currtime'] = trim($data['currtime']);
		if(preg_match("/^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$/", $data['currtime'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "时间格式不正确！");
			return false;
		}

		$currtime = str_replace(array('-', ' ', ':'), '', $data['currtime']);
		$currsecond = substr($currtime, strlen($currtime) - 2);
		$currtime = substr($currtime, 0, strlen($currtime) - 2);

		$currtime = $currtime . '.' . $currsecond;
		exec("date {$currtime} 2>&1", $err, $ret);

		set_errmsg(MSG_LEVEL_ARG, __function__, "修改成功！");
	}

	
	if(isset($data['timezone']) && !empty($data['timezone'])) {
		$file = __DIR__ . '/zoneinfo/' . $data['timezone'];
		if(!file_exists($file)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "找不到时区文件！" . $file);
			return 0;
		}

		copy($file, '/etc/localtime');
		exec("adjkerntz -a 2>&1", $err, $ret);

		myconf_save(TIMEZONE_CONF, array(
			'timezone_id'	=> $data['timezone']
		));

		set_errmsg(MSG_LEVEL_ARG, __function__, "修改成功！");
		return 2;
	}

	return 1;
}
