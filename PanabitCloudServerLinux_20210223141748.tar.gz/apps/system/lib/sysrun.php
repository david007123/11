<?php
namespace cloud\apps\system;


defined('PANALOGEYE') or define ('PANALOGEYE', '/usr/logd/bin/panalogeye');

function boottime()
{
	exec("/sbin/sysctl -n kern.boottime | cut -d',' -f1 | cut -d' ' -f4", $out, $ret);
	if($ret) {
		set_errmsg(MSG_LEVEL_DEF, __function__, $out);
		return false;
	}

	return (int)$out[0];
}

function cpu($data)
{
	$version = 0;
	exec(PANALOGEYE." receiver stat | grep version", $out, $ret);

	foreach($out as $val) {
		list($tag, $v) = explode('=', trim($val));
		if ($tag == "version") {
			$version = $v;
			break;
		}
	}
	unset($out);

	$json = array();
	switch($version) {
	case 0:		/* free */
		if (file_exists("/tmp/cpustat.log")) {
			$list = file("/tmp/cpustat.log");
			list($ncpu, $cpu, $totalmem, $mem, $hper, $hsize) = explode(' ', $list[0]);
		}

		$json["ipdata"] = "";
		if (isset($data["ipdata_checked"])) {
			$ipdata_checked = $data["ipdata_checked"];
			if (!$ipdata_checked) {
				$ip = "/usr/logd/bin/ip_data.txt";
				if (file_exists($ip))
					exec("file $ip", $out, $ret);
				if (is_array($out))
					$json["ipdata"] = $out[0];
			}
			else
				$json["ipdata"] = "";
		}

		$json["ncpu"] = $ncpu;
		$json["cpu"] = $cpu;
		$json["mem"] = $mem;
		$json["totalmem"] = (int)($totalmem / 1024 / 1024 / 1024);
		$json["hard"] = trim($hper, "%");
		$json["hsize"] = ($hsize > 1024) ? ceil($hsize / 1024)."T" : $hsize."G";
		break;
	case 1:		/* professional */
		$nodes = 0;
		$cmd = PANALOGEYE." node list";
		exec($cmd, $out, $ret);
		foreach($out as $val) {
			list($ipaddr, $uuid, $status, $uptime, $cpu_count, $cpuper, $memsz, $memper, $hardsz, $hardper, $position) = explode(' ', trim($val));
			if ($ipaddr == "ipaddr") continue;
			$nodes++;
			$ncpu += $cpu_count;
			$cpu += $cpuper;
			$mem += $memper;
			$totalmem += $memsz;
			$hsize += $hardsz;
			$hper += $hardper;
		}

		if ($nodes == 0) {
			/* 集群中的节点 */
			if (file_exists("/tmp/cpustat.log")) {
				$list = file("/tmp/cpustat.log");
				list($ncpu, $cpu, $totalmem, $mem, $hper, $hsize) = explode(' ', $list[0]);
			}
			$json["ncpu"] = $ncpu;
			$json["cpu"] = $cpu;
			$json["mem"] = $mem;
			$json["totalmem"] = (int)($totalmem / 1024 / 1024 / 1024);
			$json["hard"] = trim($hper, "%");
			$json["hsize"] = ($hsize > 1024) ? ceil($hsize / 1024)."T" : $hsize."G";
		}
		else {
			$json["ncpu"] = $ncpu;
			$json["cpu"] = ($nodes != 0) ? (int)($cpu / $nodes) : 0;
			$json["mem"] = ($nodes != 0) ? (int)($mem / $nodes) : 0;
			$json["totalmem"] = $totalmem;
			$json["hard"] = ($nodes != 0) ? (int)($hper / $nodes) : 0;
			$json["hsize"] = ($hsize > 1024) ? ceil($hsize / 1024)."T" : $hsize."G";
		}
		break;
	}

	return $json;
}


function reboot()
{
	exec("sleep 3 && reboot &", $err, $ret);
	if($ret)
		set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $err));

	return $ret;
}

function shutdown()
{
	if(php_uname('s') == 'FreeBSD')
		exec("shutdown -p now 2>&1", $err, $ret);
	else
		exec("shutdown -h now 2>&1", $err, $ret);

	if($ret)
		set_errmsg(MSG_LEVEL_DEF, __function__, implode(' ', $err));

	return $ret;
}
