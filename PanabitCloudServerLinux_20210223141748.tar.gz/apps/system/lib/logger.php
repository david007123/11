<?php
namespace cloud\apps\system\logger;

defined('PANALOGEYE') or define ('PANALOGEYE', '/usr/logd/bin/panalogeye');

function operate($data)
{
	global $nidb;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';

	if(format_and_push($data, 'user', $optional, '', 'string', false)) {
		$where_str .= "`user` = ? and ";
		array_push($values, $optional['user']);
	}

	if(format_and_push($data, 'ipaddr', $optional, '', 'string', false)) {
		$where_str .= "`ipaddr` = ? and ";
		array_push($values, "%" . $optional['ipaddr'] . "%");
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`cont` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);


	$order_map = array(
		"user",
		"time",
		"cont",
		"ipaddr",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by time desc';

	$sql = "select count(*) as `total` from cloud_log $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`user`,
		`time`,
		`cont`,
		`ipaddr`';

	$sql = "select $keys from cloud_log $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function gateway_discon($data)
{
	global $nidb, $user;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';

	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;
	if(format_and_push($data, 'license_id12', $optional, '', 'string', false)) {
		$where_str .= "`license_id12` = ? and ";
		array_push($values, $optional['license_id12']);
	}

	if(format_and_push($data, 'name', $optional, '', 'string', false)) {
		$where_str .= "`name` = ? and ";
		array_push($values, "%" . $optional['name'] . "%");
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`name` like ? or `license_id12` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$where_str .= "`grpid` in ({$user->grp}) and ";
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
				$where_str .= "`grpid` = {$optional['grpid']} and ";
			}
			
		}
		else 
		if($optional['grpid'] == 0) 
			$where_str .= "`grpid` in (10000,0) and ";
		else
		if($optional['grpid'] > 0) 
			$where_str .= "`grpid` = {$optional['grpid']} and ";
	}
	
	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);


	$order_map = array(
		"license_id12",
		"name",
		"time",
		"uptime",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = ''; //'order by time desc';

	$sql = "select count(*) as `total` from device_discon $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`license_id12`,
		`grpid`,
		`name`,
		`time`,
		`uptime`';

	$sql = "select $keys from device_discon $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($rows as $key => $row){
		$rows[$key]->name = iconv("gbk", "utf-8", $row->name);
	}
	
//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function ixcache_discon($data)
{
	global $nidb, $user;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';

	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'license_id12', $optional, '', 'string', false)) {
		$where_str .= "`license_id12` = ? and ";
		array_push($values, $optional['license_id12']);
	}

	if(format_and_push($data, 'name', $optional, '', 'string', false)) {
		$where_str .= "`name` = ? and ";
		array_push($values, "%" . $optional['name'] . "%");
	}

	if(isset($data['keyword'])) {
		$optional["keyword"] = iconv("utf-8", "gbk", $optional["keyword"]);
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`name` like ? or `license_id12` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$where_str .= "`grpid` in ({$user->grp}) and ";
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
				$where_str .= "`grpid` = {$optional['grpid']} and ";
			}
			
		}
		else 
		if($optional['grpid'] == 0) 
			$where_str .= "`grpid` in (10000,0) and ";
		else
		if($optional['grpid'] > 0) 
			$where_str .= "`grpid` = {$optional['grpid']} and ";
		
		if($where_str != '')
			$where_str = substr("where $where_str", 0, -5);
	}

	$order_map = array(
		"license_id12",
		"name",
		"time",
		"uptime",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by time desc';

	$sql = "select count(*) as `total` from ixcache_discon $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		$result = array(
			'total' => 0,
		);
	}

	$keys = '`license_id12`,
		`grpid`,
		`name`,
		`time`,
		`uptime`';

	$sql = "select $keys from ixcache_discon $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($rows as $key => $row){
		$rows[$key]->name = iconv("gbk", "utf-8", $row->name);
	}
//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}


function other($data)
{
	global $nidb, $user;

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	

	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'license_id12', $optional, '', 'string', false)) {
		$where_str .= "`license_id12` = ? and ";
		array_push($values, $optional['license_id12']);
	}

	if(format_and_push($data, 'name', $optional, '', 'string', false)) {
		$where_str .= "`name` = ? and ";
		array_push($values, "%" . $optional['name'] . "%");
	}

	if(isset($data['keyword'])) {
		if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
			$where_str .= "(`name` like ? or `license_id12` like ?) and ";
			array_push($values, "%" . $optional['keyword'] . "%");
			array_push($values, "%" . $optional['keyword'] . "%");
		}
	}

	$result = array(
		'total' => 0,
	);

	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		if(($grp = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid'], ROLE_GUEST)) === false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
		if($grp == '')
			return $result;
		$where_str .= "`grpid` in ({$grp}) and ";
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$where_str .= "`grpid` in ({$user->grp}) and ";
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
				$where_str .= "`grpid` = {$optional['grpid']} and ";
			}
			
		}
		else 
		if($optional['grpid'] == 0) 
			$where_str .= "`grpid` in (10000,0) and ";
		else
		if($optional['grpid'] > 0) 
			$where_str .= "`grpid` = {$optional['grpid']} and ";
	}
	
	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);


	$order_map = array(
		"license_id12",
		"name",
		"time",
		"log",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}

	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by time desc';

	$sql = "select count(*) as `total` from cloud_otherlog $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}

	$keys = '`license_id12`,
		`grpid`,
		`name`,
		`time`,
		`log`';

	$sql = "select $keys from cloud_otherlog $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);


	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($rows as $key => $row){
		$rows[$key]->name = iconv("gbk", "utf-8", $row->name);
	}
	
//	$result['page'] = intval($optional['offset'] / $optional['limit']);
	$result['limit'] = $optional['limit'];
	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}
