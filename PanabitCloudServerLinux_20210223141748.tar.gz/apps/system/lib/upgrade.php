<?php
namespace cloud\apps\system;


function upgrade($data)
{
	global $user;


	if(!is_supadmin($user->username)){
		set_errmsg(MSG_LEVEL_ARG, __function__, "您的权限不足!");
		return false;
	}

	if(!isset($_FILES['file'])){
		set_errmsg(MSG_LEVEL_ARG, __function__, "请选择要升级的文件!");
		return false;
	}

	$upfile = $_FILES['file'];
	if(file_exists($upfile['tmp_name']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, "找不到上传的文件！error：" . $upfile['error']);
		return false;
	}

	if($upfile['error'] > 0){
		unlink($upfile['tmp_name']);
		set_errmsg(MSG_LEVEL_ARG, __function__, "文件上传失败！error：" . $upfile['error']);
		return false;
	}
	if(empty(ROOT_DIR) || is_dir(ROOT_DIR) == false){
		unlink($upfile['tmp_name']);
		set_errmsg(MSG_LEVEL_ARG, __function__, "应用程序目录不存在！error：" . ROOT_DIR);
		return false;
	}

	$path = ROOT_DIR . '/upgrade';
	$lockfile = "{$path}/update.lock";
	if(file_exists($lockfile)) {
		unlink($upfile['tmp_name']);
		set_errmsg(MSG_LEVEL_DEF, __function__, "WEB程序正在升级中！请稍后。若需要强制升级，请删除“{$lockfile}”文件。");
		return false;
	}

	if(!is_dir($path)) {
		if(!mkdir($path)) {
			unlink($upfile['tmp_name']);
			set_errmsg(MSG_LEVEL_DEF, __function__, "创建WEB程序升级目录失败！{$path}");
			return false;
		}
		file_put_contents($lockfile, date('Y-m-d H:i:s'));
	}
	else {
		file_put_contents($lockfile, date('Y-m-d H:i:s'));
		if (($dh = opendir($path)) === false) {
			unlink($upfile['tmp_name']);
			unlink($lockfile);
			set_errmsg(MSG_LEVEL_DEF, __function__, "WEB程序升级目录打开失败！{$path}");
			return false;
		}
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				exec("rm -rf {$path}/* 2>&1", $output, $ret);
				unset($output);
				break;
			}
		}
		closedir($dh);
	}
	
	@mkdir("{$path}/new");
	@mkdir("{$path}/old");

	exec("tar zxf {$upfile['tmp_name']} -C {$path}/new 2>&1", $output, $ret);
	unlink($upfile['tmp_name']);
	if($ret) {
		unlink($lockfile);
		set_errmsg(MSG_LEVEL_DEF, __function__, "请检查升级包是否有误或空间是否已满。" . implode(',', $output));
		unset($output);
		return false;
	}

	unset($output);
	if(is_file("{$path}/new/conf/version.php") == false) {
		unlink($lockfile);
		set_errmsg(MSG_LEVEL_DEF, __function__, "无效的升级包，请检查升级包的正确性。");
		return false;
	}

	$phpfile = ROOT_DIR . "/lib/getver.php";
	if(is_file($phpfile)) {
		exec("/usr/logd/bin/php {$phpfile} {$path}/new/conf/version.php 2>&1", $output, $ret);
		if($ret || count($output) == 0) {
			unlink($lockfile);
			set_errmsg(MSG_LEVEL_DEF, __function__, "获取新的版本信息失败，请检查升级包的完整性。");
			return false;
		}
		$newversion = unserialize($output[0]);
		unset($output);
		if(!$newversion) {
			unlink($lockfile);
			set_errmsg(MSG_LEVEL_DEF, __function__, "获取新的版本信息失败，请检查升级包的正确性。");
			return false;
		}
	}

	if(is_dir("{$path}/new/upgrade")) {
		exec("rm -rf {$path}/new/upgrade 2>&1", $output, $ret);
		unset($output);
		if($ret) {
			unlink($lockfile);
			set_errmsg(MSG_LEVEL_DEF, __function__, "删除升级包中的“upgrade”目录失败！");
			return false;
		}
	}
	
	// pre install
	$phpfile = "{$path}/new/install/install.php";
	if(is_file($phpfile)) {
		exec("/usr/logd/bin/php {$phpfile} 2>&1", $output, $ret);
		if($ret) {
			set_errmsg(MSG_LEVEL_DEF, __function__, "执行升级前的程序时失败！" . implode(' ', $output));
			unset($output);
			unlink($lockfile);
			return false;
		}

		if(count($output)) {
			$ret = unserialize(implode('', $output));
			unset($output);
			if($ret && isset($ret['ret']))
				return $ret;
		}
	}

	return install_webfile($newversion);
}

function install_webfile($newversion)
{
	$path = ROOT_DIR . '/upgrade';
	$lockfile = "{$path}/update.lock";

	if(updatefile("{$path}/new", ROOT_DIR, "{$path}/old") == false) {
		$error = recoveryfile(ROOT_DIR, "{$path}/old");
		if(count($error) > 0) {
			exec("rm -rf {$path}/new 2>&1", $output, $ret);
			unset($output);
			unlink($lockfile);
			set_errmsg(MSG_LEVEL_DEF, __function__, "升级失败！请手动恢复“{$path}/old”目录下的文件到“" . ROOT_DIR . "”目录下。");
		}
		return false;
	}

	$result = true;
	// after install
	$phpfile = "{$path}/new/install/afterinstall.php";
	if(is_file($phpfile)) {
		exec("/usr/logd/bin/php {$phpfile} 2>&1", $output, $ret);
		if($ret) {
			set_errmsg(MSG_LEVEL_DEF, __function__, "执行升级后的程序时失败！" . implode(' ', $output));
		}
		else {
			$ret = unserialize($output);
			if($ret && isset($ret['ret']))
				$result = $ret;
		}
		unset($output);
	}

	// clean install file
	exec("rm -rf {$path} 2>&1", $output, $ret);
	unset($output);
	$error = clean_installphp();
	if(count($error) > 0)
		set_errmsg(MSG_LEVEL_DEF, __function__, "当前有“" . count($error) . "”文件需要手动删除！<br>" . implode('<br>', $error));

    operation_logger("系统升级", "升级云平台本到-" . VERSION);

	// killall monitor
	//exec("killall logd", $output, $ret);
	//unset($output);
	
	// run it
	//exec("/usr/logd/bin/logd >/dev/null 2>&1 &");
//	$loaded_extensions = get_loaded_extensions();
//	if(in_array('pdo_mysql', $loaded_extensions) == false)
//		exec("sleep 5 && killall php-fpm >/dev/null 2>&1 &", $output, $ret);

	return $result;
}

function updatefile($update, $target, $backup)
{
	$update_files = lsdir($update);
	$target_files = lsdir($target);
	
	foreach($target_files as $file) {
		if($file == 'upgrade') continue;
		if(in_array($file, $update_files) == false) {
			if(rename("{$target}/{$file}", "{$backup}/{$file}") == false) {
				set_errmsg(MSG_LEVEL_DEF, __function__, "备份“{$file}”文件时发生错误！");
				return false;
			}
		}
	}

	foreach($update_files as $file) {
		if($file == 'upgrade') continue;
		$targetfile = $target . '/' . $file;
		if(file_exists($targetfile)) {
			if(rename($targetfile, "{$backup}/{$file}") == false) {
				set_errmsg(MSG_LEVEL_DEF, __function__, "备份“{$file}”文件时发生错误！");
				return false;
			}
		}
		if(rename("{$update}/${file}" , $targetfile) == false) {
			set_errmsg(MSG_LEVEL_DEF, __function__, "升级“{$file}”时失败！");
			return false;
		}
	}
	
	return true;
}

function recoveryfile($target, $backup)
{
	$error = array();
	
	$backup_files = lsdir($backup);
	
	foreach($backup_files as $file) {
		$targetfile = $target . '/' . $file;
		if(file_exists($targetfile)) {
			exec("rm -rf {$targetfile} 2>&1", $output, $ret);
			unset($output);
			if($ret) array_push($error, $file);
		}

		if(rename("{$backup}/{$file}", $targetfile) == false) {
			array_push($error, $file);
		}
	}
	
	return $error;
}

function clean_installphp()
{
	$error = array();

	if(empty(ROOT_DIR) || empty(ROUTE_APPDIR) || is_dir(ROOT_DIR) == false)
		return $error;

	$path = ROOT_DIR . '/' . ROUTE_APPDIR;
	$appfiles = lsdir($path);

	if(file_exists(ROOT_DIR . "/install")) {
		exec("rm -rf " . ROOT_DIR . "/install 2>&1", $output, $ret);
		unset($output);
		if($ret)
			array_push($error, substr("{$path}/install", strlen(ROOT_DIR)));
	}

	foreach($appfiles as $file) {
		$targetfile = "{$path}/{$file}/install";

		if(file_exists($targetfile)) {
			exec("rm -rf {$targetfile} 2>&1", $output, $ret);
			unset($output);
			if($ret) 
				array_push($error, substr($targetfile, strlen(ROOT_DIR)));
		}
	}

	return $error;
}
