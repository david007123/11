<?php
namespace cloud\apps\system;

$appdir = dirname(__DIR__);
$appname = basename($appdir);
$appmethod = basename(__FILE__, '.php');

header("Content-type: application/json; charset=" . WEB_CHARSET);

// 支持库装载 | load lib
// ni_library_load('nidb');

// 装载功能 | load function
ni_app_load('user', 'login');
ni_app_load($appname, 'sysrun');


// 验证用户 | auth user
\cloud\apps\user\auth_json_exit();

if (!is_supadmin($user->username))
	json_error_exit(ERR_FAILURE, "您的权限不足！");

if(isset($_REQUEST['pass']) == false)
	json_error_exit(ERR_FAILURE, "请输入管理密码！");

$pass = trim($_REQUEST['pass']);
if(md5($pass) != $user->password)
	json_error_exit(ERR_FAILURE, "密码不正确！");


// 执行 | exec function
$result = shutdown();

// 结果输出 | printf result
if($result)
	json_error_exit(ERR_FAILURE, '操作失败！');
else
	json_error_exit(ERR_OK, '操作成功！');
