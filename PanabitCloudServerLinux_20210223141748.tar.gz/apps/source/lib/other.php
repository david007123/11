<?php
namespace cloud\apps\source\other;


function select($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$optional = array();
	format_list_arg($data, $optional);

	if(is_dir(CLOUD_TOOLBAGS) === false) {
		if(!mkdir(CLOUD_TOOLBAGS)) {
			set_errmsg(MSG_LEVEL_DEF, __function__, '创建其它资源目录失败！');
			return false;
		}
	}
	if (($dir = opendir(CLOUD_TOOLBAGS)) == false) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '其它资源目录打开失败！');
		return false;
	}
	
	if(format_and_push($data, 'keyword', $optional, '', 'string', false) == false)
		$optional['keyword']	= '';

	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);
	$limit = 0;
	
	while (($name = readdir($dir)) != false) {
		if ($name == "." || $name == "..")
			continue;

		$file = CLOUD_TOOLBAGS . "/{$name}";
		if(is_file($file) === false)
			continue;

		if(!empty($optional['keyword']) && strpos($name, $optional['keyword']) === false)
			continue;

		if($limit < $optional['limit'] && $result['total'] >= $optional['offset']) {
			array_push($result['rows'], array(
				"filename"	=> $name,
				"filesize"	=> filesize($file),
				"uptime"	=> filectime($file)
			));
			$limit++;
		}
		$result['total']++;
	}
	closedir($dir);
	
	return $result;
}

function upload($data)
{
	global $user;
	
	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	$optional = array();

	if (!is_dir(CLOUD_TOOLBAGS))
		mkdir(CLOUD_TOOLBAGS);
	
	$upfile = $_FILES['file'];
	if (isset($upfile['name']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '上传失败！');
		return false;
	}
	
	if (strpos($upfile['name'], ".php") !== false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无效的上传文件！');
		return false;
	}
	
	$target = CLOUD_TOOLBAGS . "/" . $upfile['name'];

	if (file_exists($target)) 
		unlink($target);

	if (!move_uploaded_file($upfile['tmp_name'], $target)) {
		unlink($upfile['tmp_name']);
		set_errmsg(MSG_LEVEL_ARG, __function__, '文件上传失败！');
		return false;
	}

	return true;
}

function remove($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else 
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}
	if(isset($data['files']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的资源不能为空。');
		return false;
	}
	if(is_array($data['files']) === false) {
		if(empty($data['files']) || gettype($data['files']) != 'string') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要删除的资源文件。');
			return false;
		}

		$files = array($data['files']);
	}
	else
		$files = $data['files'];

	if(count($files) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的资源为空。');
		return false;
	}

	foreach($files as $name) {
		$file = CLOUD_TOOLBAGS . '/' . $name;
		if(file_exists($file))
			unlink($file);
	}

	return true;
}

