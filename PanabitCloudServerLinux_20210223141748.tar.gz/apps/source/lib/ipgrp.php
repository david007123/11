<?php
namespace cloud\apps\source\ipgrp;


function select($data)
{
	global $nidb, $user;

	
	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	$values = array();
	$optional = array();
	// set order, limit, offset value
	format_list_arg($data, $optional);

	$where_str = '';
	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$where_str .= "(`filename` like ?) and ";
		array_push($values, "%" . $optional['keyword'] . "%");
	}

	if($where_str != '')
		$where_str = substr("where $where_str", 0, -5);

	$order_map = array(
		"filename",
		"filesize",
		"uptime",
	);

	$order = array();
	if(isset($optional['order'])) {
		foreach($optional['order'] as $op) {
			if(isset($op['column']) && isset($data['columns'][$op['column']]['data'])) {
				if(in_array($data['columns'][$op['column']]['data'], $order_map))
					array_push($order, "`" . $data['columns'][$op['column']]['data'] . "` " . $op['dir']);
			}
		}
	}
	
	if(count($order) > 0)
		$order_by = 'order by ' . implode(', ', $order);
	else
		$order_by = 'order by uptime desc';

	$sql = "select count(*) as `total` from iptblupload_bags $where_str";

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}
	
	if(count($rows) > 0) {
		$result = array(
			'total' => $rows[0]->total,
		);
	}
	else {
		return array(
			'total' => 0,
			'rows'	=> array()
		);
	}

	$keys = '`filename`,
		`filesize`,
		`uptime`';

	$sql = "select $keys from iptblupload_bags $where_str $order_by limit ? offset ? ";

	array_push($values, $optional['limit']);
	array_push($values, $optional['offset']);

	try {
		$sth = $nidb->prepare($sql);
		$sth->execute($values);
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	$result['rows'] = $rows;

	if(isset($data['draw'])) $result['draw'] = $data['draw'];

	return $result;
}

function upload($data)
{
	global $nidb, $user;
	
	
	$optional = array();

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}
	format_and_push($data, 'cover', $optional, '', 'int', true);

	if (!is_dir(CLOUD_IPTABLES))
		mkdir(CLOUD_IPTABLES);
	
	$upfile = $_FILES['file'];
	if (isset($upfile['name']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '上传失败！');
		return false;
	}
	
	if (strpos($upfile['name'], ".php") !== false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '无效的上传文件！');
		return false;
	}
	
	$target = CLOUD_IPTABLES . "/" . $upfile['name'];
	if($optional['cover']) {
		if (file_exists($target)) 
			unlink($target);

		if (!move_uploaded_file($upfile['tmp_name'], $target)) {
			unlink($upfile['tmp_name']);
			set_errmsg(MSG_LEVEL_ARG, __function__, '文件上传失败！');
			return false;
		}
	}
	else {
		// ADD
		$target = CLOUD_IPTABLES . "/" . basename($upfile['name'], '.lst') . '.lst';
		if (file_exists($target) === false) {
			// new
			if (!move_uploaded_file($upfile['tmp_name'], $target)) {
				unlink($upfile['tmp_name']);
				set_errmsg(MSG_LEVEL_ARG, __function__, '文件上传失败！');
				return false;
			}
		}
		else {
			// append
			if (($ufp = fopen($upfile['tmp_name'], "r")) === false) {
				unlink($upfile['tmp_name']);
				set_errmsg(MSG_LEVEL_DEF, __function__, '打开上传文件失败！');
				return false;
			}
			
			if ($fp = fopen($target, "a+")) {
				while (!feof($ufp)) {
					if(empty($buf = trim(fgets($ufp), " \t\n\r\0\x0B")))
						continue;

					fwrite($fp, "{$buf}\n");
				}
				fclose($fp);
			}
			else {
				fclose($ufp);
				unlink($upfile['tmp_name']);
				set_errmsg(MSG_LEVEL_DEF, __function__, '原资源文件打开失败！' . $target);
				return false;
			}
			fclose($ufp);
			unlink($upfile['tmp_name']);
		}
	}

	$frmData = array(
		'filename'	=> basename($target),
		'filesize'	=> filesize($target),
		'uptime'	=> time()
	);

	try {
		$sql = "select * from iptblupload_bags where filename = ?";
		$sth = $nidb->prepare($sql);
		$sth->bindParam(1, $frmData['filename'], \PDO::PARAM_STR);
		$sth->execute();
		$row = $sth->fetch(\PDO::FETCH_ASSOC);
		
		if($row) {
			$sql = "delete from iptblupload_bags where filename = ?";
			$sth = $nidb->prepare($sql);
			$sth->bindParam(1, $frmData['filename'], \PDO::PARAM_STR);
			$sth->execute();
			$row = $sth->fetch(\PDO::FETCH_ASSOC);
		}
		
		if(insert_data('iptblupload_bags', $frmData) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return true;
}

function remove($data)
{
	global $nidb, $user;
	

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else
	if(!is_supadmin($user->username)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
		return false;
	}

	if(isset($data['files']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的资源不能为空。');
		return false;
	}
	if(is_array($data['files']) === false) {
		if(empty($data['files']) || gettype($data['files']) != 'string') {
			set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要删除的资源文件。');
			return false;
		}

		$files = array($data['files']);
	}
	else
		$files = $data['files'];

	if(count($files) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '要删除的资源为空。');
		return false;
	}

	$str = "?";
	if(count($files) > 1)
		$str.= str_repeat(',?', count($files) - 1);

	try {
		$sql = "delete from iptblupload_bags where filename in ({$str})";
		$sth = $nidb->prepare($sql);
		$sth->execute($files);
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	foreach($files as $name) {
		$file = CLOUD_IPTABLES . '/' . $name;
		if(file_exists($file))
			unlink($file);
	}

	return true;
}

function table($data)
{
	global $user;
	
	$optional = array();
	$result = array(
		'rows'		=> array(),
		'total'		=> 0
	);

	// set custom options
	if(format_and_push($data, 'grpid', $optional, '', 'int', false) == false)
		$optional['grpid'] = -1;
	if($optional['grpid'] == 10000) $optional['grpid'] = 0;

	if(format_and_push($data, 'keyword', $optional, '', 'string', false)) {
		$optional['keyword'] = iconv('utf-8', 'gbk', $optional['keyword']);
		if (strpos($optional['keyword'], "(") != false && strpos($optional['keyword'], ")") != false) {
			$pos = strpos($optional['keyword'], "(");
			$optional['keyword'] = substr($optional['keyword'], $pos);
		}
		$optional['keyword'] = addslashes($optional['keyword']);
	}
	else
		$optional['keyword'] = '';


	// 设置用户组
	if(\cloud\apps\work\project\project_enable(array())) {
		if(($optional['grpid'] = \cloud\apps\work\project\in_work_grpidstr(1, $optional['grpid'], ROLE_GUEST)) === false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
		if($optional['grpid'] == '')
			return $result;
	}
	else {
		if (!is_supadmin($user->username)) {
			if($user->grp == '')
				return $result;
			if($optional['grpid'] <= 0)
				$optional['grpid'] = $user->grp;
			else {
				$grpids = explode(',', $user->grp);
				if(in_array($optional['grpid'], $grpids) == false) {
					return $result;
				}
			}
		}
		else
		if($optional['grpid'] == 0)
			$optional['grpid'] = '10000,0';
		else
		if($optional['grpid'] < 0)
			$optional['grpid'] = '';
	}

	$cmd = DATAEYE . " iptable list sch={$optional['keyword']} grpid=0 usergrp={$optional['grpid']}";
	exec($cmd, $out, $ret);

	foreach($out as $val) {
		$row = explode(' ', trim($val));
		if ($row[0] == "license_id12") 
			continue;

		$grpid = (int)$row[13];

		// $row[1]: Panabit 上配置的名称，$row[15]：云平台上配置的名称
		$sysname = to_utf8($row[1]);
		$iptable = to_utf8($row[2]);
		$error = to_utf8($row[6]);
		
		array_push($result['rows'], array(
			"serialno"		=> $row[0],
			"name"			=> $sysname,
			"iptable"		=> $iptable,
			"grpid"			=> (int)$row[3],
			"error"			=> $error
		));
	}

	return $result;
}

function status($data)
{
	global $nidb, $user;


	$result = array(
		'total'	=> 0,
		'rows'	=> array(),
	);
	
	if(\cloud\apps\work\project\project_enable(array())) {
		$usergrp = \cloud\apps\work\project\get_curr_work_groupstr(1);
		if(empty($usergrp) && !is_supadmin($user->username))
			return $result;
	}
	else {
		if(is_supadmin($user->username))
			$usergrp = '';
		else {
			$usergrp = $user->grp;
			if($usergrp == '')
				return $result;
		}
	}
	
	$cmd = DATAEYE . " iptable list sch= grpid=0 usergrp={$usergrp} istask=1";
	exec($cmd, $out, $ret);

	foreach($out as $val) {
		$ds = explode(' ', trim($val));
		if ($ds[0] == "license_id12")
			continue;
		
		array_push($result["rows"], array(
			"serialno"	=> $ds[0],
			"name"		=> to_utf8($ds[1]),
			"istatus"	=> $ds[4],
			"tblfname"	=> $ds[5],
			"error"		=> to_utf8($ds[6])
		));
	}
	
	$result['total'] = count($result["rows"]);

	return $result;
}

function create($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	else {
		if(!is_supadmin($user->username)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足。');
			return false;
		}
	}

	$optional = array();

	if(format_and_push($data, 'grpname', $optional, '', 'string', false))
		$optional["grpname"] = iconv("utf-8", "gbk",  $optional["grpname"]);
	else
		$optional["grpname"] = '';

	if(format_and_push($data, 'file', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择一个资源文件。');
		return false;
	}

	if(isset($data['devs']) == false || is_array($data['devs']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	$serialno = array();
	$devs = array();
	$newdevs = array();
	foreach($data['devs'] as $val) {
		if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $val['s'], $match) == false) {
			set_errmsg(MSG_LEVEL_ARG, __function__, "设备编号“{$val['s']}”不正确！");
			return false;
		}
		if(empty($optional["grpname"])) {
			if(isset($val['g']) == false || is_array($val['g']) == false) {
				set_errmsg(MSG_LEVEL_ARG, __function__, "请选择“{$val['s']}”要更新的IP群组！");
				return false;
			}
		}
		else {
			if(isset($val['g']) == false || is_array($val['g']) == false || count($val['g']) == 0) {
				array_push($newdevs, $val['s']);
				array_push($serialno, $val['s']);
				continue;
			} 
		}

		$dev = array(
			'serialno'	=> $val['s'],
			'ids'		=> array()
		);
		foreach($val['g'] as $id)
			array_push($dev['ids'], intval($id));

		array_push($devs, $dev);
		
		array_push($serialno, $val['s']);
	}

	if(count($devs) <= 0 && count($newdevs) <= 0) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择要升级的设备。');
		return false;
	}

	cloud_insertlog($user->username, "更新设备IP群组：" . implode(',', $serialno));

	$cmd = DATAEYE . " iptable set clear=1";
	exec($cmd);

	foreach($newdevs as $serialno) {
		$cmd = DATAEYE . " iptable set license_id12={$serialno} ipid=0 tblfname={$optional['file']} grpname={$optional['grpname']}";
		exec($cmd, $out, $ret);
	}
	foreach($devs as $dev) {
		$ids = implode(',', $dev['ids']);
		$cmd = DATAEYE . " iptable set license_id12={$dev['serialno']} ipid={$ids} tblfname={$optional['file']} grpname=";

		exec($cmd, $out, $ret);
	}

	return true;
}

function show($data)
{
	global $nidb, $user;


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_GUEST)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}
	$optional = array();
	
	format_list_arg($data, $optional);
	
	if(format_and_push($data, 'file', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择一个资源文件。');
		return false;
	}

	$file = CLOUD_IPTABLES . "/" . $optional['file'];
	if(file_exists($file) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的资源文件不存在！');
		return false;
	}

	if(format_and_push($data, 'keyword', $optional, '', 'string', false) == false)
		$optional['keyword']	= '';
	
	if(($fp = fopen($file, 'r')) === false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '资源文件打开失败！');
		return false;
	}

	$result = array(
		'rows'	=> array(),
		'total' => 0,
	);
	$limit = 0;
	while(!feof($fp)) {
		$buf = trim(fgets($fp), " \t\n\r\0\x0B");
		if(empty($buf))
			continue;
		if(!empty($optional['keyword']) && strpos($buf, $optional['keyword']) === false)
			continue;
		
		if($limit < $optional['limit'] && $result['total'] >= $optional['offset']) {
			array_push($result['rows'], array('ip' => $buf));
			$limit++;
		}
		$result['total']++;
	}
	fclose($fp);

	return $result;
}

function addip($data)
{
	$optional = array();
	

	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(format_and_push($data, 'file', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择一个资源文件。');
		return false;
	}
	if(isset($data['ip']) == false || is_ipaddr($ip = trim($data['ip'])) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请输入正确的IP地址。');
		return false;
	}
	
	$file = CLOUD_IPTABLES . "/" . $optional['file'];
	if (!file_exists($file)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的资源文件不存在！');
		return false;
	}

	$ftmp = tempnam("/tmp", "ipgrp_addip");
	if (!($fpw = fopen($ftmp, "w"))) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '打开临时资源文件失败！' . $ftmp);
		return false;
	}

	if ($fp = fopen($file, "r")) {
		while (!feof($fp)) {
			if(empty($buf = trim(fgets($fp), " \t\n\r\0\x0B")))
				continue;

			if($buf == $ip) {
				fclose($fp);
				fclose($fpw);
				unlink($ftmp);
				set_errmsg(MSG_LEVEL_DEF, __function__, '此记录已存在！');
				return false;
			}

			fwrite($fpw, "{$buf}\n");
		}
		fclose($fp);
	}
	else {
		fclose($fpw);
		unlink($ftmp);
		set_errmsg(MSG_LEVEL_DEF, __function__, '打开资源文件失败！');
		return false;
	}
	
	fwrite($fpw, "{$ip}\n");
	fclose($fpw);

	if(rename($ftmp, $file))
		return true;

	unlink($ftmp);
	set_errmsg(MSG_LEVEL_DEF, __function__, '保存资源文件时失败！');

	return false;
}

function rmvip($data)
{
	$optional = array();


	if(\cloud\apps\work\project\project_enable(array())) {
		if(!\cloud\apps\work\project\in_work_project(ROLE_TECHN)) {
			set_errmsg(MSG_LEVEL_ARG, __function__, '您的权限不足！');
			return false;
		}
	}

	if(format_and_push($data, 'file', $optional, '', 'string', false) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请选择一个资源文件。');
		return false;
	}
	if(isset($data['ip']) == false || is_ipaddr($ip = trim($data['ip'])) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '请输入正确的IP地址。'.$ip);
		return false;
	}
	
	$file = CLOUD_IPTABLES . "/" . $optional['file'];
	if (!file_exists($file)) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '指定的资源文件不存在！');
		return false;
	}

	$ftmp = tempnam("/tmp", "ipgrp_rmvip");
	if (!($fpw = fopen($ftmp, "w"))) {
		set_errmsg(MSG_LEVEL_DEF, __function__, '打开临时资源文件失败！' . $ftmp);
		return false;
	}

	if ($fp = fopen($file, "r")) {
		while (!feof($fp)) {
			if(empty($buf = trim(fgets($fp), " \t\n\r\0\x0B")))
				continue;

			if($buf == $ip) 
				continue;

			fwrite($fpw, "{$buf}\n");
		}
		fclose($fp);
	}
	else {
		fclose($fpw);
		unlink($ftmp);
		set_errmsg(MSG_LEVEL_DEF, __function__, '打开资源文件失败！' . $file);
		return false;
	}

	fclose($fpw);

	if(rename($ftmp, $file))
		return true;

	unlink($ftmp);
	set_errmsg(MSG_LEVEL_DEF, __function__, '保存资源文件时失败！');

	return false;
}


