// 每页数据量记忆
var _tb_paga = dump_tb_paga();
var _tb_paga_tmout = _tb_paga.tmout;
_tb_paga = _tb_paga.paga;
function dump_tb_paga()
{
	var tmout = 0, paga = 20;
	var tb_paga = $.cookie("tb_paga");
	if(tb_paga) {
		if((page = tb_paga.split('.')).length == 2) {
			tmout = strToInt(page[1]);
			paga = strToInt(page[0]);
			if(paga <= 0)
				paga = 20;
		}
	}
	return {paga: paga, tmout: tmout};
}
function get_tb_paga() {
	return _tb_paga;
}
function set_tb_paga(paga) {
	if(!paga) return;
	var now = $.myTime.CurTime();
	var opt, npage = strToInt(paga);
	if(_tb_paga != npage) {
		opt = dump_tb_paga();
		if(now > opt.tmout) {
			$.cookie("tb_paga", paga + '.' + now, {expires: 31});
			_tb_paga = npage;
			_tb_paga_tmout = now;
		}
	}
}

var _iptablehash = {};
var _iptableselect = {};
var _dnstablehash = {};
var _dnstablehash = {};

function tb_taskstat(d)
{
	if (d.istatus == "3")
		return '<img src="assets/img/off.png" width="18px" />';

	if (d.istatus == "4") 
		return '<img src="assets/img/online.png" width="18px" />';

	return '<img src="assets/img/loading.gif" />';
}

function tb_taskerror(d)
{
	if (d.istatus == "2")
		return "开始更新...";

	if (d.istatus == "3") 
		return d.error;

	if (d.istatus == "4") 
		return "更新成功";

	return '等待客户端...';
}

var timer = new taskTimer();
layui.use(['element', 'form', 'upload', 'table'], function() {
	var element = layui.element;
	var form = layui.form;
	var upload = layui.upload;
	var table = layui.table;
	var tablelns;
	var uploadType = 1;
	var dnsloadType = 1;
	var ip_tsklist;
	var dns_tsklist;

	//上传ip文件
	form.on('radio(iptype)', function(data) {
		uploadType = data.value;
		console.log(uploadType);
	});
	upload.render({
		elem: '#upipfile',
		url: 'api.php?r=source@ipgrp-upload',
		data: {
			cover: function() {
				return uploadType;
			}
		},
		dataType: "text",
		drag: true,
		accept: 'file',
		before: function(obj) {
			layer.load();
		},
		done: function(result) {
			layer.closeAll('loading');
			if (result.data != true) {
				layer.msg(result.data, {
					icon: 1
				});
			} else if (result.data == true) {
				layer.msg("上传成功!", {
					icon: 1
				});
			} else {
				layer.msg("上传失败!", {
					icon: 1
				});
			}
			table.reloadExt('ipgrplist', {
				page: {
					curr: 1
				}
			});
		},
		error: function(index, upload) {
			layer.closeAll('loading');
		}
	});

	//上传域名文件
	form.on('radio(dnstype)', function(data) {
		dnsloadType = data.value;
		console.log(dnsloadType);
	});
	upload.render({
		elem: '#updomainfile',
		url: 'api.php?r=source@dnsgrp-upload',
		data: {
			cover: function() {
				return dnsloadType;
			}
		},
		dataType: "text",
		drag: true,
		accept: 'file',
		before: function(obj) {
			layer.load();
		},
		done: function(result) {
			layer.closeAll('loading');
			if (result.data != true) {
				layer.msg(result.data, {
					icon: 1
				});
			} else if (result.data == true) {
				layer.msg("上传成功!", {
					icon: 1
				});
			} else {
				layer.msg("上传失败!", {
					icon: 1
				});
			}
			table.reloadExt('domainlist', {
				page: {
					curr: 1
				}
			});
		},
		error: function(index, upload) {
			layer.closeAll('loading');
		}
	});

	//上传工具文件
	upload.render({
		elem: '#uptoolfile',
		url: 'api.php?r=source@other-upload',
		dataType: "text",
		drag: true,
		accept: 'file',
		before: function(obj) {
			layer.load();
		},
		done: function(result) {
			layer.closeAll('loading');
			if (result.data != true) {
				layer.msg(result.data, {
					icon: 1
				});
			} else if (result.data == true) {
				layer.msg("上传成功!", {
					icon: 1
				});
			} else {
				layer.msg("上传失败!", {
					icon: 1
				});
			}
			table.reloadExt('toolslist', {
				page: {
					curr: 1
				}
			});
		},
		error: function(index, upload) {
			layer.closeAll('loading');
		}
	});

	table.render({
		elem: '#ipgrplist',
		even: true,
		url: 'api.php?r=source@ipgrp-list',
		method: 'post',
		limit: get_tb_paga(),
		skin: 'line',
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: true,
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			if(res.ret == 0) {
				res.count = res.total;
				res.data = res.data.rows;
			}
			res.code = res.ret;
			res.msg = res.msg;
			
			var e = $('#ipgrplist').parent();
			set_tb_paga(e.find('.layui-laypage-limits select').val());
		},
		done: function(res, curr, count) {},
		cols: [
			[{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
				}, {
					field: 'filename',
					title: '文件名',
				}, {
					title: '文件大小',
					templet: function(r) {
						return numberformats(r.filesize);
					}
				}, {
					title: '上传时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.uptime, true);
					}
				}, {
					title: '操作',
					width: 240,
					templet: function(d) {
						var str = '<a class="setBtn" lay-event="upload" click="ipgrpTips(this, ' + d.LAY_INDEX + ')"">上传到设备</a>';
						str += '&nbsp;&nbsp;|&nbsp;&nbsp;';
						str += '<a class="setBtn" lay-event="edit">编辑</a>';
						str += '&nbsp;&nbsp;|&nbsp;&nbsp;';
						str += '<a class="setBtn" target="_blank" href="/cloud_iptables/' + d.filename + '">下载</a>';
						str += '&nbsp;&nbsp;|&nbsp;&nbsp;';
						str += '<a class="setBtn" lay-event="del">删除</a>';
						return str;
					}
				}
			]
		]
	});

	//ip群组行内操作
	table.on('tool(ipgrplist)', function(obj) {
		var filename;
		var data = obj.data,
			event = obj.event;
		filename = data.filename;
		if (event == 'del') {
			layer.confirm('确认要删除IP文件吗?', {
				icon: 0,
				title: 'IP文件删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=source@ipgrp-remove',
					data: {
						files: data.filename
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						layer.msg('删除成功', {
							icon: 1
						});
						table.reloadExt('ipgrplist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == 'edit') {
			layer.open({
				type: 1,
				title: 'IP列表',
				content: $('#iplist-layer').html(),
				area: ['600px', '450px'],
				shadeClose: true,
				resize: false,
				success: function(layero, index) {
					var that = this;
					form.render();

					var grouplns = table.render({
						elem: '#iplist',
						even: true,
						autoSort: false,
						height: 340,
						url: 'api.php?r=source@ipgrp-show',
						method: 'post',
						limit: 20,
						skin: 'line',
						request: {
							pageName: 'page',
							limitName: 'limit'
						},
						where: {
							file: data.filename
						},
						toolbar: true,
						defaultToolbar: [{
							title: '添加IP',
							layEvent: 'LAYTABLE_ADDIP',
							icon: 'layui-icon-add-circle'
						}],
						page: false, //开启分页
						parseData: function(res) {
							if (res.ret == 0) {
								res.count = res.data.rows.total;
								res.data = res.data.rows;
							}
							res.code = res.ret;
							res.msg = res.msg;
						},
						done: function(res, curr, count) {
							form.render();
						},
						cols: [
							[{
								field: 'id',
								title: '序号',
								width: 40,
								fixed: 'left',
								type: 'numbers'
							}, {
								field: 'ip',
								title: 'IP地址',
								// width: 100,
							}, {
								title: '操作',
								width: 70,
								templet: function(d) {
									return '<span class="setBtn" lay-event="del">删除</span>'
								}
							}]
						]
					});

					$(grouplns.config.elem).parent().find('.layui-table-tool').css('background-color', 'white');
					table.on('tool(iplist)', function(obj) {
						var data = obj.data,
							event = obj.event;
						if (event == 'del') {
							layer.confirm('确定要删除该IP吗？', function(index) {
								$.ajax({
									url: 'api.php?r=source@ipgrp-rmvip',
									data: {
										ip: data.ip,
										file: filename
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});

										obj.del();
										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
						}
					});
					table.on('toolbar(iplist)', function(obj) {
						var checkStatus = table.checkStatus(obj.config.id),
							data = checkStatus.data;

						switch (obj.event) {
							case 'LAYTABLE_ADDIP':
								layer.prompt({
									formType: 0,
									value: '',
									title: '请输入IP地址',
									area: ['300px', '120px']
								}, function(value, index, elem) {
									var value = $.trim(value);
									if (value == '') {
										layer.msg('IP地址不能为空', {
											icon: 5
										});
										return;
									}
									$.ajax({
										url: 'api.php?r=source@ipgrp-addip',
										data: {
											ip: value,
											file: filename
										},
										type: 'post',
										dataType: 'json',
										success: function(d) {
											if (ajax_resultCallBack(d) === false) {
												layer.msg(d.msg, {
													icon: 5
												});
												return;
											}
											if (d.msg) layer.msg(d.msg, {
												icon: 1
											});
											layer.close(index);
											table.reloadExt('iplist', {
												page: {
													curr: 1
												}
											});
										},
										error: function() {
											layer.msg('获取数据失败，请稍后再试。', {
												icon: 2
											});
										}
									});
								});
						}
					});
				}
			});
		} else if (event == 'ipdownload') {
			window.open("../cloud_ipables/" + data.filename, "_blank");
		} else if (event == 'upload') {
			newtask_create(filename);
		}
	});

	//域名群组行内操作
	table.on('tool(domainlist)', function(obj) {
		var data = obj.data,
			event = obj.event;
		var filename = data.filename;
		if (event == 'del') {
			layer.confirm('确认要删除域名文件吗?', {
				icon: 0,
				title: '域名文件删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=source@dnsgrp-remove',
					data: {
						files: data.filename,
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						layer.msg('删除成功', {
							icon: 1
						});
						table.reloadExt('domainlist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == 'edit') {
			layer.open({
				type: 1,
				title: '域名列表',
				content: $('#domainlist-layer').html(),
				area: ['600px', '450px'],
				shadeClose: true,
				resize: false,
				success: function(layero, index) {
					var that = this;
					form.render();

					var grouplns = table.render({
						elem: '#dns-list',
						even: true,
						autoSort: false,
						height: 340,
						url: 'api.php?r=source@dnsgrp-show',
						method: 'post',
						limit: 20,
						skin: 'line',
						where: {
							file: data.filename
						},
						request: {
							pageName: 'page',
							limitName: 'limit'
						},
						toolbar: true,
						defaultToolbar: [{
							title: '添加域名',
							layEvent: 'LAYTABLE_ADDDOMAIN',
							icon: 'layui-icon-add-circle'
						}],
						page: false,
						parseData: function(res) {
							if (res.ret == 0) {
								res.count = res.data.rows.total;
								res.data = res.data.rows;
							}
							res.code = res.ret;
							res.msg = res.msg;
						},
						done: function(res, curr, count) {
							form.render();
						},
						cols: [
							[{
								field: 'id',
								title: '序号',
								width: 40,
								fixed: 'left',
								type: 'numbers'
							}, {
								field: 'dns',
								title: 'IP地址',
								// width: 100
							}, {
								title: '操作',
								width: 70,
								templet: function(d) {
									return '<span class="setBtn" lay-event="del">删除</span>'
								}
							}]
						]
					});

					$(grouplns.config.elem).parent().find('.layui-table-tool').css('background-color', 'white');
					table.on('tool(dns-list)', function(obj) {
						var data = obj.data,
							event = obj.event;
						if (event == 'del') {
							layer.confirm('确定要删除该域名吗？', function(index) {
								$.ajax({
									url: 'api.php?r=source@dnsgrp-rmvdns',
									data: {
										file: filename,
										dns: data.dns
									},
									type: 'post',
									dataType: 'json',
									success: function(d) {
										if (ajax_resultCallBack(d) === false) {
											layer.msg(d.msg, {
												icon: 5
											});
											return;
										}
										if (d.msg) layer.msg(d.msg, {
											icon: 1
										});

										obj.del();
										layer.close(index);
									},
									error: function() {
										layer.msg('获取数据失败，请稍后再试。', {
											icon: 2
										});
									}
								});
							});
						}
					});
					table.on('toolbar(dns-list)', function(obj) {
						var checkStatus = table.checkStatus(obj.config.id),
							data = checkStatus.data;

						switch (obj.event) {
							case 'LAYTABLE_ADDDOMAIN':
								layer.prompt({
									formType: 0,
									value: '',
									title: '请输入域名',
									area: ['300px', '120px']
								}, function(value, index, elem) {
									var value = $.trim(value);
									if (value == '') {
										layer.msg('域名不能为空', {
											icon: 5
										});
										return;
									}
									$.ajax({
										url: 'api.php?r=source@dnsgrp-adddns',
										data: {
											dns: value,
											file: filename
										},
										type: 'post',
										dataType: 'json',
										success: function(d) {
											if (ajax_resultCallBack(d) === false) {
												layer.msg(d.msg, {
													icon: 5
												});
												return;
											}
											if (d.msg) layer.msg(d.msg, {
												icon: 1
											});
											layer.close(index);
											table.reloadExt('dns-list', {
												page: {
													curr: 1
												}
											});
										},
										error: function() {
											layer.msg('获取数据失败，请稍后再试。', {
												icon: 2
											});
										}
									});
								});
						}
					});
				}
			});
		} else if (event == 'upload') {
			dnstask_create(filename);
		}
	});

	//其他工具行内操作
	table.on('tool(toolslist)', function(obj) {
		var data = obj.data,
			event = obj.event;
		if (event == 'del') {
			layer.confirm('确认要删除该文件吗?', {
				icon: 0,
				title: '文件删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=source@other-remove',
					data: {
						files: data.filename
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (d.ret == 0)
							layer.msg('删除成功', {
								icon: 1
							});
						table.reloadExt('toolslist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('删除失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	//批量删除
	$('button').on('click', function(obj) {
		var event = this.getAttribute('lay-filter');

		var ipgrplistCheck = table.checkStatus('ipgrplist');
		var ipgrplistData = ipgrplistCheck.data;

		var domainlistCheck = table.checkStatus('domainlist');
		var domainlistData = domainlistCheck.data;

		var toolslistCheck = table.checkStatus('toolslist');
		var toolslistData = toolslistCheck.data;

		var ipgrpArr = [];
		var domainArr = [];
		var toolsArr = [];

		ipgrplistData.forEach(function(e, i) {
			ipgrpArr.push(e.filename);
		});
		toolslistData.forEach(function(e, i) {
			toolsArr.push(e.filename);
		});
		domainlistData.forEach(function(e, i) {
			domainArr.push(e.filename);
		});
		if (event == 'delipgrp') {
			if (ipgrpArr.length <= 0) {
				layer.msg('请先选择要删除的IP文件。');
				return;
			}

			layer.confirm('确认要删除这些IP文件吗?', {
				icon: 0,
				title: '文件删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=source@ipgrp-remove',
					data: {
						files: ipgrpArr
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('ipgrplist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == 'deldomaingrp') {
			if (domainArr.length <= 0) {
				layer.msg('请先选择要删除的域名文件。');
				return;
			}

			layer.confirm('确认要删除这些域名文件吗?', {
				icon: 0,
				title: '文件删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=source@dnsgrp-remove',
					data: {
						files: domainArr
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('domainlist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		} else if (event == 'deltools') {
			if (toolsArr.length <= 0) {
				layer.msg('请先选择要删除的工具文件。');
				return;
			}

			layer.confirm('确认要删除这些工具文件吗?', {
				icon: 0,
				title: '文件删除'
			}, function(index) {
				$.ajax({
					url: 'api.php?r=source@other-remove',
					data: {
						files: toolsArr
					},
					type: 'post',
					dataType: 'json',
					success: function(d) {
						if (ajax_resultCallBack(d) === false) {
							layer.msg(d.msg, {
								icon: 5
							});
							return;
						}
						if (d.msg) layer.msg(d.msg, {
							icon: 1
						});
						table.reloadExt('toolslist', {
							page: {
								curr: 1
							}
						});
					},
					error: function() {
						layer.msg('获取数据失败，请稍后再试。', {
							icon: 2
						});
					}
				});
				layer.close(index);
			});
		}
	});

	//创建任务-IP群组
	$('.newtask-ip').on('click', function() {
		newtask_create();
	});
	
	function newtask_create(fname)
	{
		layer.open({
			type: 1,
			id: 'ip-create',
			title: '创建任务',
			area: ['750px', '550px'],
			shadeClose: true,
			content: $('#set-task').html(),
			success: function(layero, index) {
				form.render();

				ip_tsklist = table.render({
					elem: '#ip-tsklist',
					even: true,
					url: 'api.php?r=source@ipgrp-table',
					method: 'post',
					limit: 10,
					skin: 'line',
					where: {
						keyword: '',
						grpid: ''
					},
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					defaultToolbar: ['filter', 'print', 'exports', {
						title: '提示',
						layEvent: 'LAYTABLE_TIPS',
						icon: 'layui-icon-tips'
					}],
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3
					},
					parseData: function(res) {
						_iptablehash = {};
						_iptableselect = {};
						if (res.ret == 0) {
							var matchgrp = $.trim(layero.find('input[name="matchgrp"]').val());
							res.data.rows.forEach(function(row, i) {
								var grp = row.iptable.split('|');
								var iptable = [];

								_iptableselect[row.serialno] = {
									row: row,
									id: []
								};
								grp.forEach(function(tb, j) {
									var grp = tb.split(',');

									if (grp.length != 2) return;
									grp[0] = $.trim(grp[0]);
									grp[1] = $.trim(grp[1]);
									if (grp[0] == '' || grp[1] == '') return;
									iptable.push({
										id: grp[0],
										name: grp[1]
									});

									if (!_iptablehash[grp[1]])
										_iptablehash[grp[1]] = [];

									_iptablehash[grp[1]].push({
										row: row,
										id: grp[0]
									});

									if (grp[1] == matchgrp) {
										_iptableselect[row.serialno].id.push(grp[0]);
										res.data.rows[i].LAY_CHECKED = true;
									}
								});

								res.data.rows[i].iptable = iptable;
							});
						}

						return {
							code: res.ret,
							msg: res.msg,
							data: res.data.rows,
							count: res.data.total
						}
					},
					done: function(res, curr, count) {
					},
					cols: [
						[{
								field: 'id',
								title: '序号',
								width: 35,
								fixed: 'left',
								type: 'numbers'
							},
							{
								type: 'checkbox',
								width: 35
							}, {
								field: 'serialno',
								title: '设备编号',
							}, {
								field: 'name',
								title: '设备名称',
							}, {
								title: '所属组',
								templet: function(d) {
									var grpname;
									if (d.grpid == 0) return '';
									grpname = $('select[lay-filter="ipgrp"] option[value="' + d.grpid + '"]').text();
									return grpname;
								}
							}, {
								title: 'IP群组（已选 / 总数）',
								templet: function(d) {
									return '<span class="setBtn ipgrpcount" onmouseover="ipgrpTips(this, ' + d.LAY_INDEX + ')">' +
										_iptableselect[d.serialno].id.length + ' / ' + d.iptable.length +
										'</span>';
								}
							}
						]
					]
				});

				table.on('checkbox(ip-tsklist)', function(obj) {
					var row = obj.data;
					var node, tb, cache = table.cache['ip-tsklist'];
					var matchgrp = $.trim(layero.find('input[name="matchgrp"]').val());

					if (obj.type == 'all') {
						tb = $(obj.tr.prevObject[0]);

						for (i in _iptableselect) {
							node = _iptableselect[i];
							if (node.id.length) {
								node.id = [];
							}

							if (!obj.checked)
								tb.find('tr[data-index="' + node.row.LAY_TABLE_INDEX + '"] .ipgrpcount')
								.text(node.id.length + ' / ' + node.row.iptable.length);
						}

						if (obj.checked) {
							cache.forEach(function(e, i) {
								node = _iptableselect[e.serialno];
								e.iptable.forEach(function(grp, i) {
									if (grp.name == matchgrp) {
										node.id.push(grp.id);
										return false;
									}
								});

								tb.find('tr[data-index="' + node.row.LAY_TABLE_INDEX + '"] .ipgrpcount')
									.text(node.id.length + ' / ' + node.row.iptable.length);
							});
						}
					} else {
						_iptableselect[row.serialno].id = [];
						if (obj.checked) {
							_iptableselect[row.serialno].row.iptable.forEach(function(e, i) {
								if (e.name == matchgrp) {
									_iptableselect[row.serialno].id.push(e.id);
									return false;
								}
							});
						}

						obj.tr.find('.ipgrpcount').text(_iptableselect[row.serialno].id.length + ' / ' + row.iptable.length);
					}
				});

				//所有组select
				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="ipgrp"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="ipgrp"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
					}
				});
				//ip文件select
				$.ajax({
					url: 'api.php?r=source@ipgrp-list',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						var fgrp = layero.find('select[lay-filter="ipfilegrp"]');

						fgrp.children().not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							fgrp.append(new Option(data.rows[i].filename));

						if(fname) 
							fgrp.val(fname);
							
						form.render('select');
					}
				});

				function search_ipgrplist(page, obj) {
					var table = layui.table;
					var grpid = Number($('#ipgrp').val());
					var txt = $.trim(layero.find('input[name="keyword"]').val());
					var where = {
						grpid: grpid,
						keyword: txt,
					};
					if (grpid) where.grpid = grpid;

					var option = {
						method: 'post',
						where: where
					};
					if (typeof page == "number") {
						if (page > 0)
							option.page = {
								curr: page
							};
					} else
						page = 0;

					table.reloadExt('ip-tsklist', option);
				}

				layero.find('input[name="keyword"]').keyup(function(event) {
					if (event.keyCode == 13) {
						search_ipgrplist(1);
					}
				});
				layero.find('input[name="matchgrp"]').keyup(function(event) {
					if (event.keyCode == 13) {
						search_ipgrplist(1);
					}
				});

				$('.searchBtn').click(function(d) {
					search_ipgrplist(1);
				});

				form.on('select(ipgrp)', function(data) {
					search_ipgrplist(1);
				});

				//IP群组更新
				layero.find('.upgradenow').click(function(data) {
					var file = layero.find('select[name="ipfilegrp"]').val();
					var newname = $.trim(layero.find('input[name="matchgrp"]').val());
					var iscreate = layero.find('input[lay-filter="createipgrp"]').prop('checked') ? 1:0;
					var row, dev, devs = [];
					var checkStatus = table.checkStatus('ip-tsklist');
					checkStatus.data.forEach(function(row, i){
						if(dev = _iptableselect[row.serialno]) {
							if(dev.id.length) {
								devs.push({
									s: row.serialno,
									g: dev.id
								});
							}
							else
							if(iscreate && newname != ''){
								devs.push({
									s: row.serialno
								});
							}
						}
					});

					if (file == 0) {
						layer.msg("请选择IP文件");
						return;
					}

					if (devs.length <= 0) {
						if(checkStatus.data.length)
							layer.msg("请为设备选择要更新的IP群组");
						else
							layer.msg("请选择要更新的设备");
						return;
					}

					layer.confirm("确定需要更新这些设备的IP群组吗？", {
						btn: ['确定', '取消']
					}, function(index) {
						$.ajax({
							url: 'api.php?r=source@ipgrp-create',
							data: {
								grpname: newname,
								devs: devs,
								file: file
							},
							dataType: 'json',
							type: 'post',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {icon: 5});
									return;
								}
								if (d.msg) layer.msg(d.msg, {icon: 1});
								layer.close(index);
								$('.newtask-show').click();
							}
						});
					});
				});
				
				form.on('checkbox(createipgrp)', function(data) {
					var grp = layero.find('input[name="matchgrp"]');
					var val = $.trim(grp.val());

					if(data.elem.checked) {
						if(val != '')
							layer.tips('当选中的设备中未勾选IP群组时，自动为选中设备创建“<span style="color: #f5b936;">' + val + '</span>”IP群组。', grp[0], {tips: 1});
						else
							layer.tips('您可以输入IP群组名称，当选中的设备中未勾选IP群组时将自动为选中设备创建此IP群组。', grp[0], {tips: 1});
					}
					
				});
			}
		});
	}

	//ip群组个数弹出
	table.on('tool(ip-tsklist)', function(obj) {
		var data = obj.data;
		console.log(data);
	});

	// 查看任务-IP群组
	$('.newtask-show').on('click', function() {
		layer.open({
			type: 1,
			id: 'newtask-show-win',
			title: '域名群组同步任务',
			area: ['700px', '500px'],
			shadeClose: true,
			content: $('#newtask-show').html(),
			success: function(layero, index) {
				table.init('newtask-show', {
					url: 'api.php?r=source@ipgrp-status',
					method: 'post',
					autoSort: false,
					loading: false,
					parseData: function(res) {
						if(res.ret == 0) {
							res.count = res.data.total;
							res.data = res.data.rows;
						}
						res.code = res.ret;
						res.msg = res.msg;
					},
					done: function(res, curr, count) {
						layero.find('[lay-id="newtask-show"]').css('margin-top', '0px');
					}
				});
				
				timer.add('newtask-show', 2, {
					fuc: function() {
						table.reloadExt('newtask-show');
					}
				}, 1);
			},
			done: function(){
				timer.rmv('newtask-show');
			}
		});
	});
	
	// 查看任务-域名群组
	$('.dnstask-show').on('click', function() {
		layer.open({
			type: 1,
			id: 'dns-dnstask-win',
			title: '域名群组同步任务',
			area: ['700px', '500px'],
			shadeClose: true,
			content: $('#dnstask-show').html(),
			success: function(layero, index) {
				table.init('dnstask-show', {
					url: 'api.php?r=source@dnsgrp-status',
					method: 'post',
					autoSort: false,
					loading: false,
					parseData: function(res) {
						if(res.ret == 0) {
							res.count = res.data.total;
							res.data = res.data.rows;
						}
						res.code = res.ret;
						res.msg = res.msg;
					},
					done: function(res, curr, count) {
						layero.find('[lay-id="dnstask-show"]').css('margin-top', '0px');
					}
				});

				timer.add('dnstask-show', 2, {
					fuc: function() {
						table.reloadExt('dnstask-show');
					}
				}, 1);
			},
			done: function(){
				timer.rmv('dnstask-show');
			}
		});
	});

	//创建任务-域名群组
	$('.newtask-domain').on('click', function() {
		dnstask_create();
	});
	
	function dnstask_create(fname)
	{
		layer.open({
			type: 1,
			id: 'dns-create',
			title: '创建任务',
			area: ['750px', '550px'],
			shadeClose: true,
			content: $('#set-domain').html(),
			success: function(layero, index) {
				form.render();

				dns_tsklist = table.render({
					elem: '#dns-tsklist',
					even: true,
					url: 'api.php?r=source@dnsgrp-table',
					method: 'post',
					limit: 10,
					skin: 'line',
					where: {
						keyword: '',
						grpid: ''
					},
					request: {
						pageName: 'page',
						limitName: 'limit'
					},
					defaultToolbar: ['filter', 'print', 'exports', {
						title: '提示',
						layEvent: 'LAYTABLE_TIPS',
						icon: 'layui-icon-tips'
					}],
					page: {
						layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
						groups: 3
					},
					parseData: function(res) {
						_dnstablehash = {};
						_dnstableselect = {};
						if (res.ret == 0) {
							var matchgrp = $.trim(layero.find('input[name="matchgrp"]').val());
							res.data.rows.forEach(function(row, i) {
								var grp = row.dnstable.split('|');
								var dnstable = [];

								_dnstableselect[row.serialno] = {
									row: row,
									id: []
								};
								grp.forEach(function(tb, j) {
									var grp = tb.split(',');

									if (grp.length != 2) return;
									grp[0] = $.trim(grp[0]);
									grp[1] = $.trim(grp[1]);
									if (grp[0] == '' || grp[1] == '') return;
									dnstable.push({
										id: grp[0],
										name: grp[1]
									});

									if (!_dnstablehash[grp[1]])
										_dnstablehash[grp[1]] = [];

									_dnstablehash[grp[1]].push({
										row: row,
										id: grp[0]
									});

									if (grp[1] == matchgrp) {
										_dnstableselect[row.serialno].id.push(grp[0]);
										res.data.rows[i].LAY_CHECKED = true;
									}
								});

								res.data.rows[i].dnstable = dnstable;
							});
						}

						return {
							code: res.ret,
							msg: res.msg,
							data: res.data.rows,
							count: res.data.total
						}
					},
					done: function(res, curr, count) {
					},
					cols: [
						[{
								field: 'id',
								title: '序号',
								width: 35,
								fixed: 'left',
								type: 'numbers'
							},
							{
								type: 'checkbox',
								width: 35
							}, {
								field: 'serialno',
								title: '设备编号',
							}, {
								field: 'name',
								title: '设备名称',
							}, {
								title: '所属组',
								templet: function(d) {
									var grpname;
									if (d.grpid == 0) return '';
									grpname = $('select[lay-filter="dnsgrp"] option[value="' + d.grpid + '"]').text();
									return grpname;
								}
							}, {
								title: '域名群组（已选 / 总数）',
								templet: function(d) {
									return '<span class="setBtn dnsgrpcount" onmouseover="dnsgrpTips(this, ' + d.LAY_INDEX + ')">' +
										_dnstableselect[d.serialno].id.length + ' / ' + d.dnstable.length +
										'</span>';
								}
							}
						]
					]
				});

				table.on('checkbox(dns-tsklist)', function(obj) {
					var row = obj.data;
					var node, tb, cache = table.cache['dns-tsklist'];
					var matchgrp = $.trim(layero.find('input[name="matchgrp"]').val());

					if (obj.type == 'all') {
						tb = $(obj.tr.prevObject[0]);

						for (i in _dnstableselect) {
							node = _dnstableselect[i];
							if (node.id.length) {
								node.id = [];
							}

							if (!obj.checked)
								tb.find('tr[data-index="' + node.row.LAY_TABLE_INDEX + '"] .dnsgrpcount')
								.text(node.id.length + ' / ' + node.row.dnstable.length);
						}

						if (obj.checked) {
							cache.forEach(function(e, i) {
								node = _dnstableselect[e.serialno];
								e.dnstable.forEach(function(grp, i) {
									if(grp.name == matchgrp) {
										node.id.push(grp.id);
										return false;
									}
								});

								tb.find('tr[data-index="' + node.row.LAY_TABLE_INDEX + '"] .dnsgrpcount')
									.text(node.id.length + ' / ' + node.row.dnstable.length);
							});
						}
					} else {
						_dnstableselect[row.serialno].id = [];
						if (obj.checked) {
							_dnstableselect[row.serialno].row.dnstable.forEach(function(e, i) {
								if(e.name == matchgrp) {
									_dnstableselect[row.serialno].id.push(e.id);
									return false;
								}
							});
						}

						obj.tr.find('.dnsgrpcount').text(_dnstableselect[row.serialno].id.length + ' / ' + row.dnstable.length);
					}
				});

				//所有组select
				$.ajax({
					url: 'api.php?r=gateway@group',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;

						$('select[lay-filter="dnsgrp"] option').not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							$('select[lay-filter="dnsgrp"]')
							.append(new Option(data.rows[i].grpname, data.rows[i].grpid));

						form.render('select');
					}
				});
				//域名文件select
				$.ajax({
					url: 'api.php?r=source@dnsgrp-list',
					type: 'post',
					success(d) {
						if (ajax_resultCallBack(d) == false) return;
						var i, data = d.data;
						var fgrp = layero.find('select[lay-filter="dnsfilegrp"]');

						fgrp.children().not('[value=-1]').remove();
						for (i = 0; i < data.rows.length; i++)
							fgrp.append(new Option(data.rows[i].filename));

						if(fname) 
							fgrp.val(fname);

						form.render('select');
					}
				});

				function search_dnsgrplist(page, obj) {
					var table = layui.table;
					var grpid = Number($('#dnsgrp').val());
					var txt = $.trim(layero.find('input[name="keyword"]').val());
					var where = {
						grpid: grpid,
						keyword: txt,
					};
					if (grpid) where.grpid = grpid;

					var option = {
						method: 'post',
						where: where
					};
					if (typeof page == "number") {
						if (page > 0)
							option.page = {
								curr: page
							};
					} else
						page = 0;

					table.reloadExt('dns-tsklist', option);
				}
				layero.find('input[name="keyword"]').keyup(function(event) {
					if (event.keyCode == 13) {
						search_dnsgrplist(1);
					}
				});
				layero.find('input[name="matchgrp"]').keyup(function(event) {
					if (event.keyCode == 13) {
						search_dnsgrplist(1);
					}
				});

				$('.searchBtn').click(function(d) {
					search_dnsgrplist(1);
				});

				form.on('select(dnsgrp)', function(data) {
					search_dnsgrplist(1);
				});

				//域名群组更新
				layero.find('.upgradedns').click(function(data) {
					var file = layero.find('select[name="dnsfilegrp"]').val();
					var newname = $.trim(layero.find('input[name="matchgrp"]').val());
					var iscreate = layero.find('input[lay-filter="creatednsgrp"]').prop('checked') ? 1:0;
					var row, dev, devs = [];
					var checkStatus = table.checkStatus('dns-tsklist');
					checkStatus.data.forEach(function(row, i){
						if(dev = _dnstableselect[row.serialno]) {
							if(dev.id.length) {
								devs.push({
									s: row.serialno,
									g: dev.id
								});
							}
							else
							if(iscreate && newname != '') {
								devs.push({
									s: row.serialno
								});
							}
						}
					});

					if (file == 0) {
						layer.msg("请选择域名文件");
						return;
					}

					if (devs.length <= 0) {
						if(checkStatus.data.length)
							layer.msg("请为设备选择要更新的域名群组");
						else
							layer.msg("请选择要更新的设备");
						return;
					}
					
					layer.confirm("确定需要更新这些设备的域名群组吗？", {
						btn: ['确定', '取消']
					}, function(index) {
						$.ajax({
							url: 'api.php?r=source@dnsgrp-create',
							data: {
								grpname: newname,
								devs: devs,
								file: file
							},
							dataType: 'json',
							type: 'post',
							success: function(d) {
								if (ajax_resultCallBack(d) === false) {
									layer.msg(d.msg, {icon: 5});
									return;
								}
								if (d.msg) layer.msg(d.msg, {icon: 1});
								layer.close(index);
								$('.dnstask-show').click();
							}
						});
					});
				});

				form.on('checkbox(creatednsgrp)', function(data) {
					var grp = layero.find('input[name="matchgrp"]');
					var val = $.trim(grp.val());

					if(data.elem.checked) {
						if(val != '')
							layer.tips('当选中的设备中未勾选域名群组时，自动创建“<span style="color: #f5b936;">' + val + '</span>”域名群组。', grp[0], {tips: 1});
						else
							layer.tips('您可以输入域名群组名称，当选中的设备中未勾选域名群组时将自动为选中设备创建此域名群组。', grp[0], {tips: 1});
					}
				});
			}
		});
	}

	//上传升级包
	upload.render({
		elem: '.upipfile',
		url: 'api.php?r=upgrade@package-upload',
		data: {
			type: 'upbagsupload'
		},
		field: 'package',
		dataType: "text",
		drag: true,
		accept: 'file',
		before: function(obj) {
			layer.load();
		},
		done: function(result) {
			layer.closeAll('loading');
			if (result.data != true) {
				layer.msg(result.data, {
					icon: 1
				});
			} else if (result.data == true) {
				layer.msg("上传成功!", {
					icon: 1
				});
			} else {
				layer.msg("上传失败!", {
					icon: 1
				});
			}
			table.reloadExt('packagelist', {
				page: {
					curr: 1
				}
			});
		},
		error: function(index, upload) {
			layer.closeAll('loading');
		}
	});

	table.render({
		elem: '#domainlist',
		even: true,
		url: 'api.php?r=source@dnsgrp-list',
		method: 'post',
		limit: 20,
		skin: 'line',
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: true,
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			if(res.ret == 0) {
				res.count = res.total;
				res.data = res.data.rows;
			}
			res.code = res.ret;
			res.msg = res.msg;
		},
		done: function(res, curr, count) {
		},
		cols: [
			[
				{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
					width: 50
				}, {
					field: 'filename',
					title: '文件名',
				}, {
					title: '文件大小',
					templet: function(r) {
						return numberformats(r.filesize);
					}
				}, {
					field: 'uptime',
					title: '上传时间',
					templet: function(d) {
						return $.myTime.UnixToStrDate(d.uptime, true);
					}
				}, {
					title: '操作',
					width: 240,
					templet: function(d) {
						var str = '<a class="setBtn" lay-event="upload">上传到设备</a>';
						str += '&nbsp;&nbsp;|&nbsp;&nbsp;';
						str += '<a class="setBtn" lay-event="edit">编辑</a>';
						str += '&nbsp;&nbsp;|&nbsp;&nbsp;';
						str += '<a class="setBtn" target="_blank" href="/cloud_urldnsgrp/' + d.filename + '">下载</a>';
						str += '&nbsp;&nbsp;|&nbsp;&nbsp;';
						str += '<a class="setBtn" lay-event="del">删除</a>';
						return str;
					}
				}
			]
		]
	});

	table.render({
		elem: '#toolslist',
		even: true,
		url: 'api.php?r=source@other-list',
		method: 'post',
		limit: 20,
		skin: 'line',
		defaultToolbar: ['filter', 'print', 'exports', {
			title: '提示',
			layEvent: 'LAYTABLE_TIPS',
			icon: 'layui-icon-tips'
		}],
		page: true,
		page: {
			layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'],
			groups: 3
		},
		parseData: function(res) {
			if(res.ret == 0) {
				res.count = res.total;
				res.data = res.data.rows;
			}
			res.code = res.ret;
			res.msg = res.msg;
		},
		done: function(res, curr, count) {
		},
		cols: [
			[{
					field: 'id',
					title: '序号',
					width: 40,
					fixed: 'left',
					type: 'numbers'
				},
				{
					type: 'checkbox',
				}, {
					field: 'filename',
					title: '文件名',
				}, {
					title: '文件大小',
					templet: function(r) {
						return numberformats(r.filesize);
					}
				}, {
					title: '操作',
					width: 100,
					templet: function(d) {
						return '<a class="setBtn" target="_blank" href="/cloud_toolbags/' + d.filename + '">' +
							'下载</a><span>&nbsp;|&nbsp;</span><span class="setBtn" lay-event="del">删除</span>';
					}
				}
			]
		]
	});
});

//ip个数弹出层
function ipgrpTips(tips, rowid) {
	var follow, row = layui.table.cache['ip-tsklist'][rowid - 1];
	var content = '<form class="layui-form ipgrpform" action="" style="padding: 10px;">';
	var data = row.iptable;
	if (data.length) {
		cnt = parseInt(data.length / 2);
		for (i = 0; i < cnt; i++) {
			id = i * 2;
			content +=
				'<div class="layui-row layui-col-space10"><div class="layui-col-md6"><input type="checkbox" data-grpid="' +
				data[id].id + '" title="' + data[id].name +
				'" lay-skin="primary"' + (_iptableselect[row.serialno].id.indexOf(data[id].id) != -1 ? ' checked' : '') +
				'></div><div class="layui-col-md6"><input type="checkbox" data-grpid="' + data[id + 1].id +
				'" title="' + data[id + 1].name + '" lay-skin="primary"' + (_iptableselect[row.serialno].id.indexOf(data[id + 1].id) !=
					-1 ? ' checked' : '') + '></div></div>';
		}
		if (data.length % 2) {
			id = i * 2;
			content +=
				'<div class="layui-row layui-col-space10"><div class="layui-col-md6"><input type="checkbox" data-grpid="' +
				data[id].id + '" title="' + data[id].name + '" lay-skin="primary"' + (_iptableselect[row.serialno].id.indexOf(data[
						id]
					.id) != -1 ? ' checked' : '') + '></div></div>';
		}
	} else {
		content = '<span>IP群组为空</span>';
	}
	content += '</form>';



	var y = $('#ip-create').parent().children('.layui-layer-title').height();
	var x = $('div[lay-id="ip-tsklist"]')[0].offsetLeft + 73;
	var h = $('#ip-create').parent().height() - y;

	y += $('#ip-create').parent()[0].offsetTop;
	x += $('#ip-create').parent()[0].offsetLeft;
	// follow = $(tips).parents('td');
	layer.open({
		// type: 4,
		time: 0,
		shade: 0,
		title: row.name + ' -- IP群组',
		area: ['470px', h + 'px'],
		offset: [y + 'px', x + 'px'],
		shadeClose: true,
		content: content, //['', follow],
		closeBtn: 0,
		success: function(layero, index) {
			layui.form.render();
			layero.on('mouseout', function(even) {
				var p = $(even.relatedTarget).parents('.layui-layer');
				if (p.is(layero) || p.is(follow) || $(even.relatedTarget).hasClass('layui-layer-move')) return;
				layer.close(index);
			});

			timer.add('checkboxSel', 0.5, {
				fuc: function() {
					if (layero.find('.layui-form-checkbox').length) {
						layero.find('.layui-form-checkbox').on('click', function(data) {
							var checked = $(this).prev().prop('checked');
							var index, id = $(this).prev().attr('data-grpid');
							if (checked) {
								if (_iptableselect[row.serialno].id.indexOf(id) == -1)
									_iptableselect[row.serialno].id.push(id);

							} else {
								if ((index = _iptableselect[row.serialno].id.indexOf(id)) != -1)
									_iptableselect[row.serialno].id.splice(index, 1);
							}

							var tr = $(tips).parents('tr');
							tr.find('.ipgrpcount').text(_iptableselect[row.serialno].id.length + ' / ' + row.iptable.length);
						});
						timer.rmv('checkboxSel');
					}
				}
			}, 1);
		}
	});
}

//dns个数弹出层
function dnsgrpTips(tips, rowid) {
	var follow, row = layui.table.cache['dns-tsklist'][rowid - 1];
	var content = '<form class="layui-form dnsgrpform" action="" style="padding: 10px;">';
	var data = row.dnstable;
	if (data.length) {
		cnt = parseInt(data.length / 2);
		for (i = 0; i < cnt; i++) {
			id = i * 2;
			content +=
				'<div class="layui-row layui-col-space10"><div class="layui-col-md6"><input type="checkbox" data-grpid="' +
				data[id].id + '" title="' + data[id].name +
				'" lay-skin="primary"' + (_dnstableselect[row.serialno].id.indexOf(data[id].id) != -1 ? ' checked' : '') +
				'></div><div class="layui-col-md6"><input type="checkbox" data-grpid="' + data[id + 1].id +
				'" title="' + data[id + 1].name + '" lay-skin="primary"' + (_dnstableselect[row.serialno].id.indexOf(data[id + 1].id) !=
					-1 ? ' checked' : '') + '></div></div>';
		}
		if (data.length % 2) {
			id = i * 2;
			content +=
				'<div class="layui-row layui-col-space10"><div class="layui-col-md6"><input type="checkbox" data-grpid="' +
				data[id].id + '" title="' + data[id].name + '" lay-skin="primary"' + (_dnstableselect[row.serialno].id.indexOf(data[
						id]
					.id) != -1 ? ' checked' : '') + '></div></div>';
		}
	} else {
		content = '<span>域名群组为空</span>';
	}
	content += '</form>';

	var y = $('#dns-create').parent().children('.layui-layer-title').height();
	var x = $('div[lay-id="dns-tsklist"]')[0].offsetLeft + 73;
	var h = $('#dns-create').parent().height() - y;

	y += $('#dns-create').parent()[0].offsetTop;
	x += $('#dns-create').parent()[0].offsetLeft;
	// follow = $(tips).parents('td');
	layer.open({
		// type: 4,
		time: 0,
		shade: 0,
		title: row.name + ' -- 域名群组',
		area: ['470px', h + 'px'],
		offset: [y + 'px', x + 'px'],
		shadeClose: true,
		content: content, //['', follow],
		closeBtn: 0,
		success: function(layero, index) {
			layui.form.render();
			layero.on('mouseout', function(even) {
				var p = $(even.relatedTarget).parents('.layui-layer');
				if (p.is(layero) || p.is(follow) || $(even.relatedTarget).hasClass('layui-layer-move')) return;
				layer.close(index);
			});

			timer.add('checkboxSel', 0.5, {
				fuc: function() {
					if (layero.find('.layui-form-checkbox').length) {
						layero.find('.layui-form-checkbox').on('click', function(data) {
							var checked = $(this).prev().prop('checked');
							var index, id = $(this).prev().attr('data-grpid');
							if (checked) {
								if (_dnstableselect[row.serialno].id.indexOf(id) == -1)
									_dnstableselect[row.serialno].id.push(id);

							} else {
								if ((index = _dnstableselect[row.serialno].id.indexOf(id)) != -1)
									_dnstableselect[row.serialno].id.splice(index, 1);
							}

							var tr = $(tips).parents('tr');
							tr.find('.dnsgrpcount').text(_dnstableselect[row.serialno].id.length + ' / ' + row.dnstable.length);
						});
						timer.rmv('checkboxSel');
					}
				}
			}, 1);
		}
	});
}
