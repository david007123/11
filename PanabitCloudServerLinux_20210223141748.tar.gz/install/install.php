<?php
require_once(dirname(__DIR__) . '/conf/config.php');
// init db table
require_once(__DIR__ . '/sql.php');



function upgrade_file ($fsrc, $fdst) {
	if(file_exists($fsrc)) {
		if(file_exists($fdst)
		&& md5_file($fsrc) == md5_file($fdst)) 
			return false;

		exec("cp -f {$fsrc} {$fdst} 2>&1", $err, $ret);
		return ($ret == 0);
	}
	return false;
}

function upgrade_exec($fsrc, $fdst) {
	if(($ret = upgrade_file($fsrc, $fdst))) {
		exec("chmod +x {$fdst} 2>&1", $err, $ret);
		return true;
	}
	return false;
}

function upgrade_execs(&$ret, $srcpath, $dstpath) {
	$files = lsdir_file($srcpath);
	foreach($files as $fname) {
		$src_file = "{$srcpath}/{$fname}";
		$dst_file = "{$dstpath}/{$fname}";
		if(upgrade_file($src_file, $dst_file)) {
			exec("chmod +x {$dst_file} 2>&1", $err, $code);
			$ret[$fname] = array(
				'ret'	=> ($code == 0),
				'err'	=> ($err ? implode(' ', $err) : '')
			);
		}
	}
}

// check libcam.so.7
if(!file_exists("/lib/libcam.so.7")) {
	if(file_exists("/lib/libcam.so.6"))
		exec("ln -s /lib/libcam.so.6 /lib/libcam.so.7");
	else
	if(file_exists("/lib/libcam.so.5"))
		exec("ln -s /lib/libcam.so.5 /lib/libcam.so.7");
	else
	if(file_exists("/lib/libcam.so.8"))
		exec("ln -s /lib/libcam.so.8 /lib/libcam.so.7");
}


// all bin file upgrade
$upgrade_ret = array();
upgrade_execs($upgrade_ret, __DIR__ . "/cloud/bin", "/usr/logd/bin");

// install saceye config
if(!file_exists("/etc/sacsvr.conf")) {
	file_put_contents("/etc/sacsvr.conf","ETCPATH=/usr/logdata
LOGPATH=/var/log
SYSPATH=/usr/logd/bin
");
	exec("mkdir -p /var/log");
}

// install oui
upgrade_file(__DIR__ . "/cloud/etc/oui.txt", "/usr/logdata/oui.txt");

// 2020-02-21
// 修正老界面退出问题
// 修改老界面退出入口
// 修改 index.php 如果无日志，则改为纯云登陆，否则日志与云结合。
$root_dir = '/usr/logd/www/';
$file = "index.php";
$packfile1 = __DIR__ . "/page/{$file}";
if(file_exists($packfile1)) {
	exec("cp -rp " . __DIR__ . "/page/* {$root_dir}");
}

/*
// cp nginx.conf
$packfile1 = __DIR__ . "/cloud/etc/nginx.conf ";
if(file_exists($packfile1)) {
	if(file_exists('/usr/local/etc/nginx/nginx.conf'))
		$nginx_conf = md5_file('/usr/local/etc/nginx/nginx.conf');
	else
		$nginx_conf = '';
	if($nginx_conf != md5_file($packfile1)) {
		exec("cp -f {$packfile1} /usr/local/etc/nginx/nginx.conf");
		unlink("/usr/local/etc/nginx/nginx.conf");
		rename($packfile1, "/usr/logd/bin/logd");
		exec("killall nginx");
	}
}
*/

// 2020-02-28 去掉之前ISO中log.conf的云配置信息。
/*
	cloud_enable=1
	cloud_weixin_relation_obj=discon
	cloud_server=1.1.1.1
	cloud_mapping_min_port=1029
	cloud_mapping_max_port=1030
*/
$kill_panacloud = false;
$conf = myconf_read('/usr/logd/bin/log.conf', array(
	'cloud_enable',
	'cloud_server',
	'cloud_mapping_min_port',
	'cloud_mapping_max_port',
	'cloud_weixin_relation_obj'));
if(count($conf)) {
	if(isset($conf['cloud_mapping_min_port'])
	&& $conf['cloud_mapping_min_port'] == 1029
	&& isset($conf['cloud_mapping_max_port'])
	&& $conf['cloud_mapping_max_port'] == 1030) {
		exec("grep -v \"^cloud_\" /usr/logd/bin/log.conf > /usr/logd/bin/log.conf.tmp", $out, $ret);
		if(!$ret) {
			unlink("/usr/logd/bin/log.conf");
			rename("/usr/logd/bin/log.conf.tmp", "/usr/logd/bin/log.conf");
			sqlquery("delete from palog.device;");

			$kill_panacloud = true;
		}
	}
}

// 2020-07-17 增加运维工具安装选项
if(file_exists(ROOT_DIR . '/apps/devops/lib/tool.php')) {
	require_once(ROOT_DIR . '/apps/devops/lib/tool.php');
	function install_opstool()
	{
		if(!defined('OPSTOOL_DIR')) return;

		if(!file_exists(OPSTOOL_DIR))
			exec("mkdir -p " . OPSTOOL_DIR);

		$path = __DIR__ . '/opstool';
		if (is_dir($path) && ($dh = opendir($path))){
			while (($file = readdir($dh)) !== false) {
				if($file != "." && $file != "..") {
					$opstool = "{$path}/{$file}";
					// 有 lock-in 文件 表示，锁定，不允许更新
					if (is_dir($opstool) && !file_exists(OPSTOOL_DIR . "/{$file}/lock-in")) {
						// exec("rm -rf " . OPSTOOL_DIR . "/{$file}");
						exec("cp -Rp {$opstool} " . OPSTOOL_DIR . "/");
						$tool = myconf_read(OPSTOOL_DIR . "/{$file}/opstool/app.inf", array('version'));
						if(isset($tool['version'])) 
							$version = $tool['version'];
						else
							$version = '';

						\cloud\apps\devops\tool\make(array('name' => $file, 'ver' => $version));
					}
				}
			}
			closedir($dh);
		}
	}
	install_opstool();

	if(file_exists(__DIR__ . "/task.php"))
		copy(__DIR__ . "/task.php", "/usr/logd/www/cloud/task.php");
}

// 多国语言支持
if(is_dir(__DIR__ . "/language")) {
	exec("mkdir -p " . dirname(dirname(__DIR__)) . "/old/language 2>&1", $err, $ret);
	exec("cp -Rp " . __DIR__ . "/language /usr/logd/www/cloud/ 2>&1", $err, $ret);
}


$install_dir = __DIR__ . "/cloud/" . PHP_OS;
if(file_exists("{$install_dir}/install.php"))
	require_once("{$install_dir}/install.php");

// 2020-09-04 迁移老界面面拓扑图的数据位置
// /usr/logd/www/Maintain/iwan/user
// 迁移到
// /usr/logdata/devops/opssvc/collection/gateway
$iwan_user_dir = '/usr/logd/www/Maintain/iwan/user';
if(is_dir($iwan_user_dir)) {
	if(!is_link($iwan_user_dir)) {
		exec("rm -rf /usr/logdata/devops/opssvc/collection/gateway 2>&1", $err, $ret);
		exec("mkdir -p /usr/logdata/devops/opssvc/collection 2>&1", $err, $ret);
		exec("mv {$iwan_user_dir} /usr/logdata/devops/opssvc/collection/gateway 2>&1", $err, $ret);
		exec("ln -s /usr/logdata/devops/opssvc/collection/gateway {$iwan_user_dir} 2>&1", $err, $ret);
		unset($err);
	}
	else
	if(is_link('/usr/logdata/devops/opssvc/collection/gateway')) {
		exec("rm -rf /usr/logdata/devops/opssvc/collection/gateway 2>&1", $err, $ret);
		exec("mkdir -p /usr/logdata/devops/opssvc/collection/gateway 2>&1", $err, $ret);
		unset($err);
	}
}

// 2020-07-17 SD-WAN拓扑图
$sdwan = __DIR__ . "/Maintain";
if(is_dir($sdwan)) {
	exec("chmod +x {$sdwan}/iwan/topo 2>&1", $err, $ret);
	exec("cp -Rp {$sdwan} /usr/logd/www/ 2>&1", $err, $ret);
	unset($err);
}

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

// 2020-02-28 增加自动删除空编号的设备记录
sqlquery("delete from palog.cloud_device where license_id12 is null or license_id12 not regexp '^[0-9a-zA-Z_\\-]{12}$'");
sqlquery("delete from palog.cloud_backup where errors is null or license_id12 is null or license_id12 not regexp '^[0-9a-zA-Z_\\-]{12}$'");

// 2020-07-01 自动修正备份配置开启后，自动创建的备份设备名称为乱码的问题。
$sql = "update cloud_backup as a";
$sql.= " inner join (select if(length(trim(sys_name2)), sys_name2, sys_name) as sysname, license_id12 from cloud_device) as b";
$sql.= " on a.license_id12 = b.license_id12";
$sql.= " set a.cname = b.sysname";
sqlquery($sql);

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

// install licmonitor
if(isset($upgrade_ret['licmonitor']) && $upgrade_ret['licmonitor']['ret'])
	exec("ps xw | awk '$6 ~ /licmonitor$/{system(\"kill \"$1);}' > /dev/null 2>&1 &");

// install getwxcontent
if(isset($upgrade_ret['getwxcontent']) && $upgrade_ret['getwxcontent']['ret'])
	exec("ps xw | awk '$6 ~ /getwxcontent$/{system(\"kill \"$1);}' > /dev/null 2>&1 &");

// install backupclean
if(isset($upgrade_ret['backupclean']) && $upgrade_ret['backupclean']['ret'])
	exec("killall -9 backupclean > /dev/null 2>&1 &");

// install sacsvr
if(isset($upgrade_ret['sacsvr']) && $upgrade_ret['sacsvr']['ret'])
	exec("killall -9 sacsvr > /dev/null 2>&1 &");

// restart panacloud
if($kill_panacloud || (isset($upgrade_ret['panacloud']) && $upgrade_ret['panacloud']['ret']))
	exec("killall -9 panacloud > /dev/null 2>&1 &", $out, $ret);


if(PHP_OS == "Linux") {
	// 2021-01-22
	// 增加进程守护
	exec("ps -xwopid,command", $process, $ret);
	$monitor = "/usr/logd/www/cloud/lib/cmd/cloud_monitor.php";
	if($ret == 0) {
		foreach($process as $line) {
			$rows = explode(" ", trim($line));
			if(count($rows) > 2 && $rows[2] == $monitor) {
				exec("kill -9 {$rows[0]} > /dev/null 2>&1 &");
			}
		}
	}

	$cmd = "nohup /usr/logd/bin/php {$monitor} ";
	exec("{$cmd}> /dev/null 2>&1 &");

	// 检查是否存在启动项
	$notfound = 1;
	$fp = fopen("/etc/rc.local", "r");
	if ($fp) {
		while(!feof($fp) && ($line = fgets($fp, 512)) !== false) {
			if(strpos(trim($line), $cmd) === 0) {
				$notfound = 0;
				break;
			}
		}
		fclose($fp);
	}

	if($notfound) {
		$fp = fopen("/etc/rc.local", "a");
		if ($fp) {
			fwrite($fp, "{$cmd}> /dev/null 2>&1 &\n");
			fclose($fp);
		}
	}
}
else {
	// 2020-02-21
	// 修改 logd 程序
	// install logd
	exec("ps -A -opid,command", $process, $ret);
	$monitor = "/usr/logd/bin/logd";
	$cmd = "{$monitor} > /dev/null 2>&1 &";
	if($ret == 0) {
		foreach($process as $line) {
			$rows = explode(" ", trim($line));
			if(count($rows) > 1 && $rows[1] == $monitor) {
				if($ret > 0)
					exec("kill -9 {$rows[0]} > /dev/null 2>&1 &");
				$ret++;
			}
		}
	}
	else
		$ret = 0;

	if($ret == 0
	|| (isset($upgrade_ret['logd']) && $upgrade_ret['logd']['ret']))
		exec($cmd);

	// 检查是否存在启动项
	$notfound = 1;
	$fp = fopen("/etc/rc.local", "r");
	if ($fp) {
		while(!feof($fp) && ($line = fgets($fp, 512)) !== false) {
			$rows = explode(" ", $line);
			if(count($rows) > 0 && $rows[0] == $monitor) {
				$notfound = 0;
				break;
			}
		}
		fclose($fp);
	}
	if($notfound) {
		$fp = fopen("/etc/rc.local", "a");
		if ($fp) {
			fwrite($fp, $cmd . "\n");
			fclose($fp);
		}
	}
}