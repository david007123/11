<?php

function _X_log_off_read($file)
{
	$ret = array();
	
	if (!file_exists($file)) 
		return $ret;

	if ($fp = fopen($file, "r")) {
		while (!feof($fp)) {
			if(empty($buf = trim(fgets($fp))))
				continue;

			$col = explode('=', $buf, 2);
			if(count($col) != 2)
				continue;
			$key = trim($col[0]);
			if(strpos($key, ' ') !== false)
				continue;

			if($key == 'log_off') {
				$ret[$key] = trim($col[1]);
				break;
			}
		}
		fclose($fp);
	}

	return $ret;
}

$conf = _X_log_off_read('/usr/logd/bin/log.conf');
if(file_exists('/root/panalog.cloud') || (isset($conf['log_off']) && intval($conf['log_off']))) {
	require_once($packfile1 = __DIR__ . "/cloud/login/index_new.php");
	exit;
}

header("Content-type: text/html; charset=utf-8");
echo "<script>location='cloud/page.php?r=user@login';</script>";	
