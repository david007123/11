<?php
if (CLOUD_LEFT_MENU == "config_backup")
	$config_backup = "active";
if (CLOUD_LEFT_MENU == "cloud_ex")
	$cloud_ex = "active";
if (CLOUD_LEFT_MENU == "bdmap")
	$bdmap = "active";
if (CLOUD_LEFT_MENU == "topoview")
	$topoview = "active";
if (CLOUD_LEFT_MENU == "taskmgd")
	$taskmgd = "active";
if (CLOUD_LEFT_MENU == "upgrade_config")
	$upgrade_config = "active";
if (CLOUD_LEFT_MENU == "cloud_user")
	$cloud_user = "active";
if (CLOUD_LEFT_MENU == "cloud_expire")
	$cloud_expire = "active";
if (CLOUD_LEFT_MENU == "cloud_appup")
	$cloud_appup = "active";
if (CLOUD_LEFT_MENU == "cloud_toolbags")
	$cloud_toolbags = "active";
if (CLOUD_LEFT_MENU == "cloud_log")
	$cloud_log = "active";
if (CLOUD_LEFT_MENU == "ixcache")
	$ixcache = "active";
if (CLOUD_LEFT_MENU == "panalog")
	$panalog = "active";
if (CLOUD_LEFT_MENU == "cloud_intool")
	$cloud_intool = "active";
if (CLOUD_LEFT_MENU == "yxkx")
	$yxkx = "active";
if (CLOUD_LEFT_MENU == "cloud_qrcode")
	$cloud_qrcode = "active";
if (CLOUD_LEFT_MENU == "brokennet")
	$cloud_brokennet = "active";
?>
<div class="product-nav-stage">
	<div class="sidebar-title">
		<span class="triangle_border_down">
		</span>
		<span class="sidebar-title-text">&nbsp;功能列表</span>
	</div>
	<ul>
		<li class="<?=$cloud_ex?>">
			<a href="cloud_ex.php?grp=0">
				<div class="nav-icon"><img src="../img/projection_screen.png" width="15px" /></div>
				<span style="width:60px;">网关设备</span>
				<span style="float:left;display:block;width:50px;height:40px;line-height:40px;"><div class="show-expire show-expire-margin-left device-expire" style="margin-top:10px;">0</div></span>
			</a>
		</li>
		<li class="<?=$ixcache?>">
			<a href="ixcache.php?grp=0">
				<div class="nav-icon"><img src="../img/projection_screen.png" width="15px" /></div>
				<span style="width:60px;">缓存设备</span>
				<span style="float:left;display:block;width:50px;height:40px;line-height:40px;"><div class="show-expire show-expire-margin-left ixcache-expire" style="margin-top:10px;">0</div></span>
			</a>
		</li>
		<li class="<?=$panalog?>">
			<a href="logdevice.php?grp=0">
				<div class="nav-icon"><img src="../img/projection_screen.png" width="15px" /></div>
				<span style="width:60px;">日志设备</span>
				<span style="float:left;display:block;width:50px;height:40px;line-height:40px;"><div class="show-expire show-expire-margin-left logserver-expire" style="margin-top:10px;">0</div></span>
			</a>
		</li>
		<li class="<?=$yxkx?>">
			<a href="gamecloud.php?grp=0">
				<div class="nav-icon"><img src="../img/gamecloud.png" width="20px" /></div>
				<span style="width:60px;">游戏快线</span>
			</a>
		</li>
		<li class="<?=$bdmap?>">
			<a href="bdmap.php?devtype=panabit&grpid=0">
				<div class="nav-icon"><img src="../img/map.png" width="15px" /></div>
				<span>设备地图</span>
			</a>
		</li>
<!--		<li class="<?=$topoview?>">
			<a href="topo.php?q=view">
				<div class="nav-icon"><img src="./iwan/img/topo.png" width="15px" /></div>
				<span>网桥拓扑</span>
			</a>
		</li>
		<li class="<?=$taskmgd?>">
			<a href="topo.php?q=taskmgd">
				<div class="nav-icon"><img src="./topo/img/task.png" width="15px" /></div>
				<span>任务下发</span>
			</a>
		</li> -->
		<li class="<?=$upgrade_config?>">
			<a href="upgrade_config.php">
				<div class="nav-icon"><img src="../img/projection_screen.png" width="15px" /></div>
				<span>设备升级</span>
			</a>
		</li>
		<li class="<?=$cloud_appup?>">
			<a href="cloud_appbags.php">
				<div class="nav-icon"><img src="../img/app.png" width="15px" /></div>
				<span>App升级</span>
			</a>
		</li>
		<li class="<?=$cloud_intool?>">
			<a href="cloud_intool.php">
				<div class="nav-icon"><img src="../img/intool.png" width="15px" /></div>
				<span>内网访问</span>
			</a>
		</li>
		<li class="<?=$config_backup?>"><a href="config_backup.php"><div class="nav-icon"><img src="../img/database.png" width="15px" /></div><span>配置备份</span></a></li>
		<li class="<?=$cloud_toolbags?>"><a href="cloud_iptables.php"><div class="nav-icon"><img src="../img/toolbox.png" width="15px" /></div><span>资源管理</span></a></li>
		<?php
			if ($_SESSION['cloud_username'] == "admin") {
				echo '<li class="'.$cloud_user.'"><a href="cloud_user.php"><div class="nav-icon"><img src="../img/user.png" width="15px" /></div><span>用户管理</span></a></li>';
				echo '<li class="'.$cloud_log.'"><a href="cloud_log.php"><div class="nav-icon"><img src="../img/text.png" width="15px" /></div><span>系统日志</span></a></li>';
				echo '<li class="'.$cloud_qrcode.'"><a href="showcode.php?type=cloud"><div class="nav-icon"><img src="../img/weixin.png" width="15px" /></div><span>微信通知</span></a></li>';
				echo '<li class="'.$cloud_brokennet.'"><a href="brokennet.php?type=cloud"><div class="nav-icon"><img src="../img/weixin.png" width="15px" /></div><span>一键断网</span></a></li>';
			}
		?>
	</ul>
</div>
<span style="position:absolute; left:10px; bottom:20px; display:block;width:50px;height:40px;line-height:40px;z-index:100;">
	<div class="show-left" style="margin-top: 10px; height: 30px; width: 30px; line-height: 30px; border-radius: 20px; background: #d3dceb; text-align:center;">
		<a href="javascript:void(0);" onclick="lefthide()"><img src="../img/arrow_left.png" style="margin-top:6px;" /></a>
	</div>
</span>
<script>
getexpirelen("panabit");
getexpirelen("ixcache");

function lefthide()
{
	if ($.cookie("cloud_left") == "block") {
		$(".product-nav-stage").hide();
		$(".product-body").css("left", 0);
		$.cookie("cloud_left", "hide", {expires: 31});
		$(".show-left").html('<a href="javascript:void(0);" onclick="lefthide()"><img src="../img/arrow_right.png" style="margin-top:6px;" /></a>');
	}else {
		$(".product-body").css("left", 180);
		$(".product-nav-stage").show();
		$.cookie("cloud_left", "block", {expires: 31});
		$(".show-left").html('<a href="javascript:void(0);" onclick="lefthide()"><img src="../img/arrow_left.png" style="margin-top:6px;" /></a>');
	}
}

$(document).ready(function(){
	if ($.cookie("cloud_left") == undefined)
		$.cookie("cloud_left", "block", {expires: 31});
	if ($.cookie("cloud_left") == "block") {
		$(".product-nav-stage").show();
		//$(".product-body").css("left", 160);
		$(".show-left").html('<a href="javascript:void(0);" onclick="lefthide()"><img src="../img/arrow_left.png" style="margin-top:6px;" /></a>');
	}else {
		$(".product-body").css("left", 0);
		$(".product-nav-stage").hide();
		$(".show-left").html('<a href="javascript:void(0);" onclick="lefthide()"><img src="../img/arrow_right.png" style="margin-top:6px;" /></a>');
	}

});
</script>
<script type="text/javascript" src="../js/jq.cookie.js"></script>
