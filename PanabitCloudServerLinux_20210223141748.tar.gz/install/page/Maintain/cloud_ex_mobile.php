<?php
session_start();
$doc = $_SERVER["DOCUMENT_ROOT"];
include($doc."/common.php");
if (!isset($_SESSION['cloud_username']) || $_SESSION['cloud_username'] == "") {
	echo '<script type="text/javascript">parent.location.href="cloud_index.php";</script>';
	exit;
}
session_write_close();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.min.js"></script>
<link type="text/css" rel="stylesheet" href="../css/common.css" />
<link type="text/css" rel="stylesheet" href="../css/ui-lightness/jquery-ui-custom.css" />
<script type="text/javascript" src="../js/cloud.js"></script>
<script type="text/javascript" src="../js/rootpass.js"></script>
<script type="text/javascript" src="../js/jq.cookie.js"></script>
<script type="text/javascript" src="../js/ixcache.js"></script>
<script type="text/javascript" src="../js/common.js"></script>
<style type="text/css">
	body{
		padding:0px;
		margin:0px;
		font-size:12px;
		padding-top: 47px;
	}
	.head{
		width:100%;
		margin-top:0px;
		display:block;
		height:50px;
	}
	.head a{
		display:inline-block;
		padding:10px 0px;
		float:left;
		margin-left:20px;
		font-size:13px;
		margin-top:10px;
	}
	.head #label1{
		float:left;
		display:inline-block;
		padding:3px 8px;
		margin-top:15px;
		margin-left:20px;
		font-size:13px;
		color:#fff;
		background-color:#1874CD;	
	}
	.head #label2{
		float:left;
		display:inline-block;
		margin-left:20px;
		font-size:13px;
		margin-top:20px;
		color:#1874CD;
	}
	.content{
		display:block;
		width:100%;
		margin-top:0px;
	}
	.aa{
		display:inline-block;
		width:100%;
		margin-top:5px;
		padding:0px;
		
	}

	.aa img{
		width:18px;
		height:18px;
		display:inline-block;
		float:left;
		
	}
	
	.aa a{
		color:#474747;
	}
	.aa label{
		display:inline-block;
		float:left;
	}
	.aa table{
		width:100%;
		font-size:13px;
		
	}
	td{
		height:20px;
	
	}
	
	.bb{
		display:inline-block;
		width:100%;
		margin-top:5px;
		padding:5px 0px;
		background-color:#f5f5f5;
		font-size:14px;
		font-weight:nomal;
	}
	.bb img{
		width:18px;
		height:18px;
		display:inline-block;
		float:left;
		margin-left:5px;
	}
	.bb .a1{
		display:inline-block;
		float:left;
		margin-left:5px;
	}
	.bb a{
		display:inline-block;
		float:right;
		margin-right:10px;
	}
		
	#getmore_show{
		width:100%;
		display:inline-block;
		
	}
	#loadingdiv{
		display:block;
		margin:200px auto;
		width:200px;
	}
	#loadingdiv img{
		display:inline-block;
		margin-left:30px;
		float:left;
		width:25px;
		height:25px;
	}
	#loadingdiv label{
		display:inline-block;
		margin-left:10px;
		float:left;
		font-size:16px;
	}
	.bottom{
		width: 100%;
		border-bottom: 1px solid #d3d3d3;
		background: #2E8AE3;
		display: flex;
		height: 47px;
		line-height: 47px;
		position: fixed;
		top: 0px;	
	}
	.bottom .div1{
		display: inline-block;
		width: 100%;
		margin-top: 10px;
		line-height: 47px;
		margin-right: 24px;
	}
	.bottom .div1 input{
		width: 100%;
		padding: 0px 8px;
		border: 0px;
		line-height: 28px;
	}
	.bottom .div1 img{
		float:left;
		display:inline-block;
		margin-left:10px;
		width:15px;
		height:15px;
		margin-top:8px;
	}
	.bottom .div2{
		display: inline-block;
		padding: 0px;
		margin-right: 8px;
		margin-top: 10px;
	}
	.bottom .div2 select{
		width:80px;
		height:28px;
		font-size:12px;
	}
   
</style>
<script type="text/javascript">
grplist(2,0);
var limit = 5;
var page=1;
var total_page ;
var sort="";
var g_ascdesc="";
function datedifference(sDate1,sDate2){    //sDate1和sDate2是2006-12-18格式  
        var dateSpan,iDays;
        dateSpan = sDate2 - sDate1;
        dateSpan = Math.abs(dateSpan);
        iDays = Math.floor(dateSpan / (24 * 3600));
        return iDays
}

function hd_sort(str)
{
	sort = str;
	//getdata();
	 if(g_ascdesc=="desc"){
		g_ascdesc = "asc";
	}
	else{
		g_ascdesc = "desc";
	}
	getdata();
}
 
/*function hd_sort(){
	sort = str;
	getdata();
	if(g_ascdesc=="desc")
		g_ascdesc = "asc";
	else
		g_ascdesc ="desc";	
}*/


function pagedown()
{
	/*var a=$("#label1").html();
	var b=Number(a)+1;
	console.log(b);*/
	 page++
	if (page>total_page)
		page--;
	$("#label1").html(page);
	$(".content").hide();
	$(".head").hide();
	getdata();
	
}

getdata();
setInterval(function(){getdata()},5000);

function pageup(){
	page--;
	if (page <= 0)
		page = 1;
	$("#label1").html(page);
	getdata();
}

var alldata;

function getdata()
{
	var grpid=$("#grplisthdr").val();
	var key = $("#search").val();
	var key = $.trim(key);
	$("#loadingdiv").show();
	$.ajax({
		url:'system_handle.php',
		type:'post',
		dataType:'json',
		data:{
			page:page,
			limit:limit,
			grpid:grpid,
			sch:key,
			sort:sort,
			g_ascdesc:g_ascdesc,
			type:'cloud_devlist',
			
		},
		complete:function(){
			$("#loadingdiv").hide(1000);
			$(".head").show();
			$(".content").show();
			$(".bottom").show();
		},
		success:function(res){
				processdata(res.rows);
				total_page = Math.ceil(res.total / limit);
				$("#label2").html("总共:"+res.total+"条,每页"+limit+"条");
			
		},
		error:function(){
			console.log('error');
		}
	})
}

function processdata(data)
{
	var str="";
	$.each(data,function(i,k){
        var t1=k.upbps;
        var t3=k.downbps;
		
		if(t1>(1000*1000*1000)){
			var t2 = t1/(8*1024*1024*1024);
			k.upbps  = t2.toFixed(2)+"G";
		}
        else if(t1>(1000*1000)&&t1<(1000*1000*1000)){
			var t2=t1/(8*1024*1024);
            k.upbps = t2.toFixed(2)+"M";
        
        }
        else{
            var t2= t1/(8*1024);
            k.upbps=t2.toFixed(2)+"K";
        }

        if(t3>(1000*1000*1000)){
            var t4 = t3/ (8 * 1024 * 1024*1024);
            k.downbps = t4.toFixed(2) + "G";   
        }
        else if (t3>(1000 * 1000) && t3<(1000*1000*1000)){
            var t4 = t3/(8 * 1024*1024);
            k.downbps = t4.toFixed(2) + "M";
		}
        else{
            var t4 = t3/(8*1024);
            k.downbps = t4.toFixed(2) + "K";
        }
		var name = k.sys_name;
		if(k.sys_name2 != "")
			name = k.sys_name2;	
		if(k.servertime - k.time < 15 ){
			str += '<div style="display:inline-block;padding-bottom:10px;width:92%;margin-left:4%;margin-top:10px;">';
			str += '<div class="bb"><img style="width:20px;height:20px;"  src="../img/10.png" />&nbsp;';
			str += '<a class="a1" onclick=openssh_m(\''+k.license_id12+'\',\''+k.localip+'\',1,0)>'+name+'</a>&nbsp;';
			str += '<a href="javascript:getmore(\''+name+'\',\''+k.license_id12+'\')">更多>></a></div>';
			str += '<div class="aa" ><table ><tr style="color:#474747"><td width=35%><a href="javascript:hd_sort(\'upbps\')">上行速率</a></td><td width=30%><a href="javascript:hd_sort(\'users\')">用户数</a></td><td width=35%><a href="javascript:hd_sort(\'flowcont\')">连接数</a></td></tr>';
			str += '<tr style="color:#1874CD;"><td>'+k.upbps+'</td><td>'
			str += k.users+'</td><td>'+k.flowcont+'</td></tr></table><table style="margin-top:10px;"><tr><td width=35%><a href="javascript:hd_sort(\'downbps\')">下行速率</a></td><td width=30%><a href="javascript:hd_sort(\'temp\')">温度</a></td><td width=35%><a href="javascript:hd_sort(\'license_end\')">到期时间</a></td></tr>';
			str += '<tr style="color:#1874CD"><td>'+k.downbps+'</td><td>'+k.temp+'℃</td><td>';
			str += k.license_end_str+'</td></tr></table></div></div>';	
		}
		else{
			str += '<div style="display:inline-block;padding-bottom:10px;width:92%;margin-left:4%;margin-top:10px;">';
			str += '<div class="bb"><img src="../img/12.png" />&nbsp;&nbsp;';
			str += '<a class="a1">'+name+'</a>';
			str += '&nbsp;<a href="javascript:getmore(\''+name+'\',\''+k.license_id12+'\')">更多>></a></div>';
			str += '<div class="aa" ><table><tr style="color:#474747"><td width=35%><a href="javascript:hd_sort(\'upbps\')">上行速率</a></td><td width=30%><a href="javascript:hd_sort(\'users\')">用户数</a></td><td width=35%><a href="javascript:hd_sort(\'flowcont\')">连接数</a></td></tr>';
			str += '<tr><td>'+k.upbps+'</td><td>'+k.users+'</td><td>'+k.flowcont+'</td></tr></table>';
			str += '<table style="margin-top:10px;"><tr><td width=35%><a href="javascript:hd_sort(\'downbps\')">下行速率</a></td><td width=30%><a href="javascript:hd_sort(\'temp\')">温度</a></td><td width=35%><a href="javascript:hd_sort(\'license_end\')">到期时间</a></td></tr>';
			str += '<tr><td>'+k.downbps+'</td><td>'+k.temp+'℃</td><td>'+k.license_end_str+'</td></tr>';
			str += '</table></div></div>';
		}
			
	})
	
	alldata=data;
	$(".content").html(str); 

}

function getmore(str,std)
{
    for(i=0;i<alldata.length;i++){
		var subject = alldata[i];
		if(subject.license_id12==std){
			var diffday = "";
			if(subject.license_end != "0") 
				diffday = datedifference(subject.time,subject.license_end) + "天";
			var k="";
			k+='<table style="width:100%;height:170px;"><tr><td>授权编号</td><td>'+subject.license_id12+'</td></tr><tr><td>有效期</td><td>'+diffday+'</td></tr><tr><td>最后在线</td><td>'
			+subject.time_str+'</td></tr><tr><td>运行</td><td>'+subject.sys_run+'</td></tr><tr><td>版本</td><td>'+subject.version+'</td></tr></table>'
			$("#getmore_show").html(k);
		}
    }
	$(".appadd-outer").dialog({
		width:250,
		height:300,
		title:str,
		buttons:[
			{
				text: "关闭",
				click: function(){
					$(this).dialog("close");
				},
			},
			
		]
    })
}


function getsearch(){
	//window.location.href="../search.html";
	getdata();
}
	

</script>
</head>
<body>
<div class="bottom">
	<a href="cloud_ex.php" target="_blank" class="logocontainer" style="line-height: 50px;width: 220px;padding: 0px;margin: 0px;">
		<div class="imgbox" style="overflow: hidden;width: 36px;display: inline-block; margin-top: 4px;">
			<img class="logo" src="../cloud/assets/img/logo.gif" style="width: 125px;">
		</div>
		<div class="cloudtxt" style="line-height: 47px;margin-left: 5px;display: inline-block;color: white;
		font-size: 16px;
		font-weight: bold;
		top: 0px;
		position: absolute;
	">云平台</div>
	</a>
	<div class="div1">
		<input type="text" id="search"  name="" placeholder="请输入查询关键字" />
	</div>
	<div class="div2">
		<select id="grplisthdr" name="" style="border:0px;">
			<option value="0">所有组</option>
		</select>
			
	</div>
</div>
<div  class="content"></div>
<div class="head">
	<a href="javascript:pageup()">上一页</a>
	<label id="label1">1</label>
	<a href="javascript:pagedown()">下一页</a>
	<label id="label2"></label>
</div>
<div class="appadd-outer" style="display:none;">
	<div  id="getmore_show">
	</div>
</div>	
<div id="loadingdiv">
	<img src="../img/loading.gif" />
	<label>加载中,请稍后...</label>	
</div>
</body>
<script>
//grplist(2,0);

$("#grplisthdr").change(function(){
	page = 1;
	getdata();	
})
	
</script>
</html>