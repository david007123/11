<?php
session_start();

if (isset($_POST["type"]) && $_POST["type"] == "cloud_logout") {
	unset($_SESSION["cloud_username"]);
	exit;
}

unset($_SESSION["palog_username"]);
unset($_SESSION["palog_password"]);
?>
