<?php
require_once(__DIR__ . '/install.php');
require_once(dirname(__DIR__) . '/apps/system/lib/upgrade.php');

\cloud\apps\system\clean_installphp();
