<?php
require_once(dirname(__DIR__) . '/conf/config.php');
require_once(dirname(__DIR__) . '/apps/user/lib/login.php');

function upgradeSql()
{
	$error = array();

	if(empty(ROOT_DIR) || empty(ROUTE_APPDIR) || is_dir(ROOT_DIR) == false)
		return $error;

	$path = ROOT_DIR . '/' . ROUTE_APPDIR;
	$appfiles = lsdir($path);

	foreach($appfiles as $file) {
		$targetfile = "{$path}/{$file}/install";

		if(is_file("{$targetfile}/sql.php")) {
			exec("/usr/logd/bin/php {$targetfile}/sql.php 2>&1", $output, $ret);
			if($ret) {
				array_push($error, "{$file}/install/sql.php, " . implode(' ', $output));
			}
		}
	}

	return $error;
}

function sqlquery($sql)
{
	global $nidb;
	
	return $nidb->query($sql);
	
//	if($nidb->errorCode()) {
//		$err = $nidb->errorInfo();
//		echo 'sql: [' . $nidb->errorCode() . "] {$err[1]} => {$err[2]}<br>\n";
//	}
}

$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);

// 用户表
$sql = "create table if not exists palog.cloud_users".
        "(username varchar(32) not null default '',".
        "password varchar(32) not null default '', ".
        "loginip bigint(4) not null default '0', ".
        "logintime bigint(4) not null default '0',".
        "grp varchar(512) not null default '', ".
        "grpname varchar(512) not null default '',".
        "remarks varchar(512) not null default '', ".
        "ixc_grpids varchar(512) not null default '',".
        "ixc_grpnames varchar(512) not null default '') engine=myisam";
sqlquery($sql);

// 操作日志
$sql = "create table if not exists palog.cloud_log".
        "(user varchar(32) not null default '', ".
        "time bigint(4) not null default '0', ".
        "cont varchar(512) not null default '',".
        "ipaddr varchar(16) not null default '')".
        "engine=myisam default charset=utf8";
sqlquery($sql);

$sql = "alter table palog.cloud_log add ipaddr varchar(16) not null default ''";
sqlquery($sql);

// 系统日志
$sql = "create table if not exists palog.device_discon (".
		"license_id12 varchar(16) not null default '', ".
		"grpid int(2) not null default '0',".
		"name varchar(128) not null default '', ".
		"time bigint(4) not null default '0', ".
		"uptime bigint(4) not null default '0')engine=myisam";
sqlquery($sql);

$sql = "create table if not exists palog.ixcache_discon(".
		"license_id12 varchar(16) not null default '', ".
		"grpid int(2) not null default '0',".
		"name varchar(128) not null default '', ".
		"time bigint(4) not null default '0', ".
		"uptime bigint(4) not null default '0')engine=myisam";
sqlquery($sql);


$sql = "CREATE TABLE IF NOT EXISTS palog.iptblupload_bags".
		"(filename varchar(64), filesize int(2), ".
		"uptime bigint(4))ENGINE=MyISAM";
sqlquery($sql);

	
// 微信通知
$sql = "create table if not exists palog.weixin_brokennet".
			"(id int not null auto_increment primary key, ".
			"openid varchar(64) not null default '',".
			"birth bigint(4) not null default '0',".
			"myevent varchar(64) not null default '', ".
			"status tinyint not null default '1',".
			"isupdate tinyint not null default '0',".
			"license_id12 varchar(16) not null default '',".
			"sysname varchar(128) not null default '',".
			"tips varchar(512) not null default '')".
			"engine=MyISAM default charset=utf8";
sqlquery($sql);


// 2021-01-09 增加微信执行命令的阻断状态，用于异步同步客户机是否执行。
$sql = "alter table weixin_brokennet add `isupdate` tinyint not null default '0'";
$nidb->query($sql);


$sql = "create table if not exists palog.weixin_brokennet_operation(
			id int not null auto_increment primary key,
			birth bigint(4) not null default '0',
			nickname varchar(128) not null default '', 
			avatarurl varchar(256) not null default '', 
			status tinyint not null default '0', 
			device varchar(16) not null default '', 
			openid varchar(64) not null default '', 
			object varchar(64) not null default ''
		) ENGINE=MyISAM default charset=utf8";
sqlquery($sql);


$sql = "create table if not exists palog.weixin_brokennet_login(".
		"id int not null auto_increment primary key, ".
		"birth bigint(4) not null default '0',".
		"username varchar(64) not null default '',".
		"openid varchar(64) not null default '',".
		"nickname varchar(128) not null default '',".
		"avatarurl varchar(256) not null default '')engine=MyISAM default charset=utf8";
sqlquery($sql);


$sql = "create table if not exists palog.cloud_log".
			"(user varchar(32) not null default '', ".
			"time bigint(4) not null default '0', ".
			"cont varchar(512) not null default '',".
			"ipaddr varchar(16) not null default '')".
			"engine=myisam default charset=utf8";
sqlquery($sql);


$sql = "create table if not exists palog.cloud_otherlog".
		"(id int not null auto_increment primary key, ".
		"license_id12 varchar(16) not null default '', ".
		"name varchar(64) not null default '', ".
		"time bigint(4) not null default '0', ".
		"grpid int(2) not null default '0', ".
		"log varchar(128) not null default '')engine=MyISAM";
sqlquery($sql);


$sql = "CREATE TABLE IF NOT EXISTS palog.urldnsupload_bags".
                "(filename varchar(64), filesize int(2), ".
                "uptime bigint(4))ENGINE=MyISAM";
sqlquery($sql);


$sql = "create table if not exists palog.intool_grp(
			id int not null auto_increment primary key,
			name varchar(128) not null default ''
		) engine=myisam default charset=utf8";
sqlquery($sql);


//# 2019-10-22 创建升级包表
$sql = "create table if not exists upload_bags";
$sql.= " (filename varchar(64), filesize int(2), ";
$sql.= " uptime bigint(4)) ENGINE=MyISAM default charset=latin1";
sqlquery($sql);
 

$sql = "create table if not exists cloud_upgrade";
$sql.= " (task_id int(2), license_id12 varchar(16) not null,";
$sql.= " name varchar(128) not null default '',";
$sql.= " ori_version varchar(64) not null default '',";
$sql.= " last_version varchar(64) not null default '',";
$sql.= " upgrade_bag varchar(64), upgrade_type varchar(16),";
$sql.= " upgrade_start varchar(16) not null default '0',";
$sql.= " upgrade_end bigint(4) not null default '0',";
$sql.= " complete int(2) not null default '0',";
$sql.= " errors varchar(128) not null default '0',";
$sql.= " upgrade_pro varchar(32) not null default ''";
$sql.= " )ENGINE=MyISAM";
sqlquery($sql);


$sql = "create table if not exists cloud_task";
$sql.= " (task_id int(2) not null default '0',";
$sql.= " upgrade_bag varchar(64), upgrade_type varchar(16),";
$sql.= " upgrade_start varchar(16) not null default '0',";
$sql.= " total int(2) not null default 0, succ int(2) not null default 0,";
$sql.= " fail int(2) not null default 0, updesc varchar(512) not null default '0',";
$sql.= " create_user varchar(32) not null default '',";
$sql.= " status int not null default '0',";
$sql.= " upgrade_pro varchar(32) not null default '')ENGINE=MyISAM";
sqlquery($sql);


$sql = "CREATE TABLE IF NOT EXISTS palog.cloud_appup";
$sql.= " (license_id12 varchar(16) not null,";
$sql.= " name varchar(128),";
$sql.= " app_name varchar(64),";
$sql.= " ori_version varchar(64),";
$sql.= " last_version varchar(64) not null default '',";
$sql.= " upgrade_bag varchar(64),";
$sql.= " complete int(2) not null default '0',";
$sql.= " errors varchar(128) not null default '')ENGINE=MyISAM default charset=latin1";
sqlquery($sql);


//# 2019-10-22 自动创建用户组
$sql = "create table if not exists logserver_grp";
$sql.= " (grpid int auto_increment primary key,grpname varchar(64))ENGINE=MyISAM";
sqlquery($sql);


//# 2019-10-22 自动创建日志用户组
$sql = "create table if not exists ixcache_grp";
$sql.= " (grpid int auto_increment primary key,grpname varchar(64))ENGINE=MyISAM";
sqlquery($sql);


//# 2019-10-22 自动创建用户组
$sql = "create table if not exists cloud_grp";
$sql.= " (grpid int auto_increment primary key,grpname varchar(64))ENGINE=MyISAM default charset=latin1";
sqlquery($sql);


$sql = "create table if not exists palog.cloud_backup(".
	"license_id12 varchar(32), ".
	"cname varchar(256),".
	"backup_type int(2) COMMENT '0 now, 1 later', ".
	"backup_time bigint(4) COMMENT 'backup time', ".
	"backup_seg int(2) COMMENT 'backup seg', ".
	"backup_nexttime bigint(4) not null default '0' COMMENT 'next backup time', ".
	"backup_ctime bigint(4) COMMENT 'configure changetime', ".
	"complete int(2) COMMENT '0 ready, 1 succ, 2 fail',".
	"fnum int(2),".
	"grpid int(2),".
	"errors varchar(256))engine=myisam default charset=utf8";
sqlquery($sql);


//# 2019-11-11
$sql = "create table if not exists operation_log(".
		"id int not null auto_increment primary key, ".
		"user varchar(32) not null default '', ".
		"ope_time bigint(4) not null default '0', ".
		"obj varchar(32) not null default '',".
		"cont varchar(256) not null default '')".
		"ENGINE=MyISAM default charset=utf8";
sqlquery($sql);


$sql = "create table if not exists cloud_record_pic(".
		"rdid varchar(16), cid int(2), pid int(2), ".
		"fname varchar(64), width int(2), height int(2))ENGINE=MyISAM";
sqlquery($sql);


$sql = "create table if not exists cloud_record(".
		"rdid varchar(16), cid int(2), timestr varchar(32), ".
		"cont varchar(512))ENGINE=MyISAM";
sqlquery($sql);


$sql = "create table if not exists cloud_appup(".
		"license_id12 varchar(16) not null, ".
		"name varchar(128),".
		"app_name varchar(64),".
		"ori_version varchar(64),".
		"last_version varchar(64) not null default '',".
		"upgrade_bag varchar(64), ".
		"complete int(2) not null default '0',".
		"errors varchar(128) not null default '')ENGINE=MyISAM default charset=latin1";
sqlquery($sql);


//# 2019-11-13 创建主机表
$sql = "create table if not exists intool_list";
$sql.= "(id int not null auto_increment primary key, hostname varchar(128) not null default '',";
$sql.= " hostip varchar(16) not null default '',";
$sql.= "webport int not null default '0', sshport int not null default '0',";
$sql.= "rdpport int not null default '0', hostgrp int(2) not null default '0',"; 
$sql.= "centercode varchar(16) not null default '', centername varchar(128) not null default '',"; 
$sql.= "httpport int not null default '0')engine=myisam default charset=utf8";
sqlquery($sql);


// 2020-04-23 新云数据库
// create database if not exists db_herbal_medicine;
$sql = "create database if not exists cloud_platform";
sqlquery($sql);

// 修正 2020-05-31 项目表
$sql = "drop database if exists panabit_manage";
sqlquery($sql);

// 2020-04-23 项目表
$sql = "create table if not exists cloud_platform.work_project (";
$sql.= "`wkpid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT primary key,";
$sql.= "`name` char(128) not null default '',";
$sql.= "`option` longtext NOT NULL,";
$sql.= "`remarks` varchar(255) not null default ''";
$sql.= ") engine=myisam default charset=utf8";
sqlquery($sql);


// 项目管理员权限表
$sql = "create table if not exists cloud_platform.work_ring (";
$sql.= "`user` varchar(255) NOT NULL DEFAULT '' COMMENT '帐号' ,";
$sql.= "`wkpid` bigint NOT NULL DEFAULT 0 COMMENT '项目ID' ,";
$sql.= "`type` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '类型' ,";
$sql.= "`ring` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '权限' ,";
$sql.= "PRIMARY KEY (`user`, `wkpid`, `type`)";
$sql.= ") engine=myisam default charset=utf8";
sqlquery($sql);


// 2020-06-08 自动创建SAC组
$sql = "create table if not exists sac_grp (";
$sql.= "`grpid` int auto_increment primary key ,";
$sql.= "`grpname` varchar(64) not null default ''";
$sql.= ") ENGINE=MyISAM default charset=utf8";
sqlquery($sql);


// 项目管理员权限表
$sql = "create table if not exists cloud_platform.work_group_ring (";
$sql.= "`wkpid`  bigint NOT NULL DEFAULT 0 COMMENT '项目ID' ,";
$sql.= "`grpid`  bigint NOT NULL DEFAULT 0 COMMENT '项目组ID' ,";
$sql.= "`type`  int UNSIGNED NOT NULL DEFAULT 0 COMMENT '类型' ,";
$sql.= "`ring`  int UNSIGNED NOT NULL DEFAULT 0 COMMENT '权限' ,";
$sql.= "PRIMARY KEY (`type`, `grpid`)";
$sql.= ") engine=myisam default charset=utf8";
sqlquery($sql);


if(defined('OPSTOOL_DIR') && !is_dir(OPSTOOL_DIR)) {
	$sql = "drop table if exists cloud_platform.devops_task";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.devops_process";
	sqlquery($sql);
}
/*
	$sql = "drop table if exists cloud_platform.sdwan_server";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.sdwan_client";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.sdwan_link";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.sdwan_bindline_server";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.sdwan_bindline_client";
	sqlquery($sql);
	

	$sql = "drop table if exists cloud_platform.zeropen_device";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.zeropen_netif";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.zeropen_lan";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.zeropen_wan";
	sqlquery($sql);
	$sql = "drop table if exists cloud_platform.zeropen_route";
	sqlquery($sql);

*/

/*
$sql = "drop table if exists cloud_platform.work_group_ring";
sqlquery($sql);

// 2020-06-08 自动创建SAC组
$sql = "create table if not exists cloud_platform.sac_grp (";
$sql.= "`grpid` int auto_increment primary key ,";
$sql.= "`grpname` varchar(64) not null default '' ,";
$sql.= "`wkpid` bigint NOT NULL DEFAULT 0 COMMENT '项目ID' ,";
$sql.= "`ring` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '权限' ,";
$sql.= ") ENGINE=MyISAM default charset=utf8";
sqlquery($sql);


// 给组增加wkpid和ring
$sql = "alter table cloud_grp add `wkpid` int not null default '0'";
$nidb->query($sql);
$sql = "alter table logserver_grp add `ring` int not null default '0'";
$nidb->query($sql);

$sql = "alter table logserver_grp add `wkpid` int not null default '0'";
$nidb->query($sql);
$sql = "alter table logserver_grp add `ring` int not null default '0'";
$nidb->query($sql);

$sql = "alter table ixcache_grp add `wkpid` int not null default '0'";
$nidb->query($sql);	
$sql = "alter table ixcache_grp add `ring` int not null default '0'";
$nidb->query($sql);	


$sql = "alter table intool_grp add `wkpid` int not null default '0'";
$nidb->query($sql);	
$sql = "alter table intool_grp add `ring` int not null default '0'";
$nidb->query($sql);	




// 项目日志
$sql = "create table if not exists cloud_platform.work_logger (";
$sql.= "`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,";
$sql.= "`type` char(16) not null default 'log',";
$sql.= "`act` char(16) not null default 'log',";
$sql.= "`ret` tinyint(1) not null default '',";
$sql.= "`pass` char(32) not null default '',";
$sql.= "`name` char(32) not null default '',";
$sql.= "`phone` char(32) not null default '',";
$sql.= "`ring` tinyint(4) not null default 0,";
$sql.= "`lastip` bigint(4) not null default 0,";
$sql.= "`lasttime` bigint(4) not null default 0";
$sql.= "primary key (`id`) ) engine=ARCHIVE default charset=utf8";
sqlquery($sql);
*/


$nidb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

upgradeSql();
