<?php

upgrade_execs($upgrade_ret, __DIR__ . "/bin", "/usr/logd/bin");

// 2021-01-21 ���PHPȱ�ٿ��޷��������е�����
$lib64 = __DIR__ . "/system/lib64.tar.gz";
if(is_file($lib64) && 
(!file_exists('/usr/lib64/libexslt.so.0')
|| !file_exists('/usr/lib64/libxslt.so.1')
|| !file_exists('/usr/lib64/libltdl.so.7')
|| !file_exists('/usr/lib64/libpng15.so.15'))) {
	exec("tar zxf {$lib64} -C / 2>&1", $err, $ret);
}
