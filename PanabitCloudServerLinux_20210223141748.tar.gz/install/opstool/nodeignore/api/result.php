<?php
/*
 * $keyno 12位授权编号 
 * $task_id 任务编号
 * $code 错误代码
 * &$msg 当前错误
 * $result_file 工具上传的文件
 * 
 */