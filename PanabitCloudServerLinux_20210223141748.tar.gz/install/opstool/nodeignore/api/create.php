<?php
/*
 * 该文件来自 task.php >> apps/devops/api/task-create.php 的任务创建回调
 * 用于格式化工具所需的参数，然后保存到 $_REQUEST['param'] 中，
 * 以便用 task-create.php 将其当参数存储。 
 *
 */
 
if(isset($_REQUEST['apps']) == false || empty(($_REQUEST['apps'] = trim($_REQUEST['apps'])))) {
	set_errmsg(MSG_LEVEL_ARG, __function__, '应用协议不能为空。');
	return 1;
}
if(preg_match("/^([a-zA-Z0-9-_,]{1,})$/", $_REQUEST['apps'], $match) == false) {
	set_errmsg(MSG_LEVEL_ARG, __function__, "应用协议格式不正确！");
	return 1;
}
/*
$apps = explode(',', $_REQUEST['apps']);
if(count($apps) <= 0) {
	set_errmsg(MSG_LEVEL_ARG, __function__, '应用协议不能为空。');
	return 1;
}
*/

if(isset($_REQUEST['ignore']) == false) {
	$_REQUEST['param'] = "DATA action=get\n";
}
else {
	if(intval($_REQUEST['ignore']))
		$ignore = 1;
	else
		$ignore = 0;

	$_REQUEST['param'] = "DATA action=set\n";
	$_REQUEST['param'].= "DATA ignore=" . $ignore . "\n";
}

$_REQUEST['param'].= "DATA apps=" . $_REQUEST['apps'] . "\n";

return 0;
