<?php
/*
 * 该文件来自 task.php >> apps/devops/api/task-create.php 的任务创建回调
 * 用于格式化工具所需的参数，然后保存到 $_REQUEST['param'] 中，
 * 以便用 task-create.php 将其当参数存储。 
 *
 */


if(isset($_REQUEST['param']) == false)
	$_REQUEST['param'] = '';
else
	$_REQUEST['param'] = trim($_REQUEST['param']);

if(isset($_REQUEST['save_history']) && !empty($_REQUEST['save_history'])) {
	$tooldir = OPSTOOL_DIR . "/shellops/param";
	if(!is_dir($tooldir))
		exec("mkdir -p {$tooldir} 2>&1", $output, $ret);

	if($_REQUEST['save_history'] == '默认的配对运维（无）')
		$_REQUEST['save_history'] = '默认的配对运维';

	file_put_contents("{$tooldir}/{$_REQUEST['save_history']}", $_REQUEST['param']);
}

if(!empty($_REQUEST['param']))
	$_REQUEST['param'] = iconv('utf-8', 'gbk', $_REQUEST['param']);

return 0;
