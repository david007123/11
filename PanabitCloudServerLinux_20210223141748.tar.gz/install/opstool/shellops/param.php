<?php

header("Content-type: application/json; charset=utf-8");

function lsdir_file($path)
{
	$ret = array();
	
	if (($dh = opendir($path))){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				if (is_file($path . '/' . $file)) {
					array_push($ret, $file);
				}
			}
		}
		closedir($dh);
	}

	return $ret;
}

function select($data)
{
	$files = array('默认的配对运维（无）');
	$dir = __DIR__ . "/param";
	if(is_dir($dir)) {
		$data = lsdir_file($dir);
		if(($index = array_search('默认的配对运维', $data)) !== false) {
			$files = array('默认的配对运维');
			array_splice($data, $index, 1);
			$files = array_merge($files, $data);
		}
		else
			$files = array_merge($files, $data);
	}

	$ret = array(
		'ret'	=> 0,
		'data'	=> $files,
		'msg'	=> '',
	);

	echo json_encode($ret);
}

function del($data)
{
	if(isset($data['name']) == false || empty($data['name'] = trim($data['name'])))
	{
		$ret = array(
			'ret'	=> 1,
			'data'	=> '',
			'msg'	=> '名称不能为空！',
		);
		echo json_encode($ret);
		return ;
	}
	if($data['name'] == '默认的配对运维（无）')
		$data['name'] = '默认的配对运维';
	
	$file = __DIR__ . "/param/{$data['name']}";
	if(file_exists($file)) 
		unlink($file);

	$ret = array(
		'ret'	=> 0,
		'data'	=> '',
		'msg'	=> '',
	);

	echo json_encode($ret);
}

function get($data)
{
	if(isset($data['name']) == false || empty($data['name'] = trim($data['name'])))
	{
		$ret = array(
			'ret'	=> 1,
			'data'	=> '',
			'msg'	=> '名称不能为空！',
		);
		echo json_encode($ret);
		return ;
	}
	if($data['name'] == '默认的配对运维（无）')
		$data['name'] = '默认的配对运维';

	$file = __DIR__ . "/param/{$data['name']}";
	if(file_exists($file)) 
		$text = file_get_contents($file);
	else
		$text = '';

	$ret = array(
		'ret'	=> 0,
		'data'	=> $text,
		'msg'	=> '',
	);

	echo json_encode($ret);
}

function save($data)
{
	if(isset($data['name']) == false || empty($name = trim($data['name'])))
	{
		$ret = array(
			'ret'	=> 1,
			'data'	=> '',
			'msg'	=> '名称不能为空！',
		);
		echo json_encode($ret);
		return ;
	}
	if($name == '默认的配对运维（无）')
		$name = '默认的配对运维';

	if(isset($data['text']) == false)
		$data['text'] = '';
	else
		$data['text'] = trim($data['text']);
	
	$tooldir = __DIR__ . "/param";
	$file = "{$tooldir}/{$name}";
	if(!is_dir($tooldir))
		exec("mkdir -p {$tooldir} 2>&1", $output, $ret);

	if(file_put_contents($file, $data['text']) === false)
		$ret = array(
			'ret'	=> 1,
			'data'	=> '',
			'msg'	=> '保存文件失败',
		);
	else
		$ret = array(
			'ret'	=> 0,
			'data'	=> '',
			'msg'	=> '',
		);

	echo json_encode($ret);
}

function logger($data)
{
	if(isset($data['keyno']) == false || empty($data['keyno'] = trim($data['keyno'])))
	{
		$ret = array(
			'ret'	=> 1,
			'data'	=> '',
			'msg'	=> '设备编号不能为空！',
		);
		echo json_encode($ret);
		return ;
	}
	if(isset($data['task_id']) == false || ($data['task_id'] = intval($data['task_id'])) <= 0)
	{
		$ret = array(
			'ret'	=> 1,
			'data'	=> '',
			'msg'	=> '任务ID不能为空！',
		);
		echo json_encode($ret);
		return ;
	}

	$file = dirname(dirname(__DIR__)) . "/task/{$data['keyno']}/{$data['task_id']}/result.dat";
	if(file_exists($file)) 
		$text = file_get_contents($file);
	else
		$text = '';

	$ret = array(
		'ret'	=> 0,
		'data'	=> $text,
		'msg'	=> '',
	);

	echo json_encode($ret);
}

if(isset($_REQUEST['r'])) {
	if($_REQUEST['r'] == 'list')
		select($_REQUEST);
	else
	if($_REQUEST['r'] == 'del')
		del($_REQUEST);
	else
	if($_REQUEST['r'] == 'get')
		get($_REQUEST);
	else
	if($_REQUEST['r'] == 'save')
		save($_REQUEST);
	else
	if($_REQUEST['r'] == 'logger')
		logger($_REQUEST);
}
