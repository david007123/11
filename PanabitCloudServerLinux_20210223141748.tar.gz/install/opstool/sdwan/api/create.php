<?php
/*
 * 该文件来自 task.php >> apps/devops/api/task-create.php 的任务创建回调
 * 用于格式化工具所需的参数，然后保存到 $_REQUEST['param'] 中，
 * 以便用 task-create.php 将其当参数存储。 
 *
 */

if(isset($_REQUEST['act']) == false) {
	set_errmsg(MSG_LEVEL_ARG, __function__, '无效的请求。');
	return 1;
}

if($_REQUEST['act'] == 'pop-add') {
	if(isset($_REQUEST['port']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '端口不能为空。');
		return 1;
	}
	$port = intval($_REQUEST['port']);
	if($port <= 0 || $port > 65535) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '端口必须为1-65535。');
		return 1;
	}
	$_REQUEST['param'] = "port={$port}";
	return 0;
}
if($_REQUEST['act'] == 'pop-del') {
	if(isset($_REQUEST['name']) == false) {
		set_errmsg(MSG_LEVEL_ARG, __function__, '被删除的POP点名称不能为空。');
		return 1;
	}
	$_REQUEST['param'] = "name=" . trim($_REQUEST['name']);
	return 0;
}


if($_REQUEST['act'] == 'cpe-add') {
	set_errmsg(MSG_LEVEL_ARG, __function__, '无效的请求。');
	return 1;
}
if($_REQUEST['act'] == 'cpe-del') {
	set_errmsg(MSG_LEVEL_ARG, __function__, '无效的请求。');
	return 1;
}

return 0;
