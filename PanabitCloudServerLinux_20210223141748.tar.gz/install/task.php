<?php
if(!isset($_REQUEST['r']))
	exit;
if(!isset($_REQUEST['keyno']))
	exit;

$apiname = trim($_REQUEST['r']);
if(preg_match("/^([a-zA-Z0-9-_]{1,})$/", $apiname, $match) == false)
	exit;

$keyno = trim($_REQUEST['keyno']);
if(preg_match("/^([a-zA-Z0-9-_]{12})$/", $keyno, $match) == false)
	exit;

$page_file = __DIR__ . "/apps/devops/task-api/{$apiname}.php";
if(file_exists($page_file) === false) {
	echo 'fail: not this api!';
	exit;
}

define ("CLOUD_CONF", "/etc/cloud.conf");

// opstool path
defined('DEVOPS_DIR') or define('DEVOPS_DIR', '/usr/logdata/devops');
defined('OPSSVC_DIR') or define('OPSSVC_DIR', DEVOPS_DIR . '/opssvc');
defined('OPSHISTORY_DIR') or define('OPSHISTORY_DIR', DEVOPS_DIR . '/history');
defined('OPSWEB_DIR') or define('OPSWEB_DIR', DEVOPS_DIR . '/web');

defined('OPSTOOL_DIR') or define('OPSTOOL_DIR', OPSWEB_DIR . '/tool');
defined('OPSTASK_DIR') or define('OPSTASK_DIR', OPSWEB_DIR . '/task');
defined('OPSCONF_DIR') or define('OPSCONF_DIR', OPSWEB_DIR . '/conf');
defined('OPSTOKEN_DIR') or define('OPSTOKEN_DIR', OPSWEB_DIR . '/token');

// aout link devops path
defined('OPSWEB_LINKS_DIR') or define('OPSWEB_LINKS_DIR', '/usr/logd/www/devops');
if(!file_exists(OPSWEB_LINKS_DIR))
	exec("ln -s " . OPSWEB_DIR . " " . OPSWEB_LINKS_DIR . " 2>&1", $output, $ret);


define ('DATAEYE', '/usr/logd/bin/cloudeye');

define('ROOT_DIR', __DIR__);
// require_once(__DIR__ . '/conf/config.php');

date_default_timezone_set('PRC');


// 检查最大任务数
function maxdown_get()
{
	$maxdown = 5;
	if (file_exists(CLOUD_CONF)) {
		$lines = file(CLOUD_CONF);
		foreach($lines as $val) {
			if (strstr($val, "download_max=") != false) {
				$ds = explode('=', $val);
				$maxdown = intval(trim($ds[1], "\n"));
				break;
			}
		}
	}
	
	return $maxdown;
}
function maxdown_check($name)
{
	$maxdown = maxdown_get();
	$exptm = time() - 180; // 3 分钟超时的任务自动删除
	
	$path = OPSWEB_DIR . "/processes/{$name}";
	if(!is_dir($path))
		exec("mkdir -p ${path}");

	if (is_dir($path) && $dh = opendir($path)){
		while (($file = readdir($dh)) !== false) {
			if($file != "." && $file != "..") {
				$mtime = filemtime("{$path}/{$file}");
				if($mtime < $exptm) {
					unlink("{$path}/{$file}");
					continue;
				}
				if(--$maxdown <= 0)
					break;
			}
		}
		closedir($dh);
	}

	return $maxdown;
}

require_once($page_file);
