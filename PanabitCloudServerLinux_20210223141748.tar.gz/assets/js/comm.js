function urlsplit() 
{
	var i, node, data = {};
	var url = location.href.substr(location.href.search(/\?/)+1).split('&');

	for(i = 0; i < url.length; i++) {
		node = url[i].split('=');
		if(node.length == 2) {
			data[node[0]] = node[1];
		}
	}

	return data;
}

var g_URL_data;
function getURL_val(name)
{
	var i, node;
	var url = location.href.substr(location.href.search(/\?/)+1).split('&');

	if(g_URL_data == undefined)
		g_URL_data = urlsplit();

	if(g_URL_data[name] != undefined)
		return g_URL_data[name];
	
	return '';
}

function ajax_resultCallBack(d) {
	if (d.ret == 302) {
		if (d.msg != '') alert(d.msg);
		window.location.href = d.data;
		return false;
	}
	return d.ret == 0;
}

function ajaxgo(opt, callback, countcallback) {
	var options = $.extend(true, {}, {
		dataType: 'json'
	}, opt, {
		success: function(d) {
			if (typeof(countcallback) == 'function' && countcallback(d) == false) return;
			if (ajax_resultCallBack(d) == false) return;
			callback(d.data, d.msg);
		},
		error: function() {
			if (typeof(countcallback) == 'function' && countcallback(null) == false) return;
			alert('加载数据失败，请稍后再重试！');
		}
	});
	return $.ajax(options);
}

function events() {
	var events = {};

	function on(name, callback) {
		if (events[name])
			events[name] = [callback];
		else
			events[name].push(callback);
		return this;
	}

	function rmv(name, callback) {
		if (!events[name]) return this;

		var i;
		if (callback) {
			for(i = 0; i < events[name].length; i++) {
				if(events[name][i] === callback) {
					events[name].splice(i,1);
					break;
				}
			}
		}
		else {
			delete events[name];
		}
		return this;
	}
	
	function dispatch(name, arg, obj) {
		if (!events[name]) return this;
		if (!obj) obj = window;

		for(i = 0; i < events[name].length; i++) {
			events[name][i].apply(obj, arg);
		}
		return this;
	}

	return {
		on: on,
		rmv: rmv,
		dispatch: dispatch
	}
}

var hiddenProperty = 'hidden' in document ? 'hidden' :    
    'webkitHidden' in document ? 'webkitHidden' :    
    'mozHidden' in document ? 'mozHidden' :    
    null;
function isHiddenMyView()
{
	return window.isHiddenMyWin || document[hiddenProperty];
}

function taskTimer() {
	var tasklist = {};
	var rmvlist = [];

	function add(name, time, task, nowrun, isHiddenCk) {
		if (typeof task != 'object' || typeof task.fuc != 'function') {
			rmv(name);
			return;
		}
		if (!task.obj)
			task.obj = window;
		if (!task.data)
			task.data = [];

		if (tasklist[name])
			tasklist[name].time = time;
		else
			tasklist[name] = {
				time: time,
				curr: 0,
				isHiddenCk: 1
			};

		if(arguments.length > 4)
			tasklist[name].isHiddenCk = (isHiddenCk ? 1 : 0);
		tasklist[name].task = task;
		if (nowrun)
			task.fuc.apply(task.obj, task.data);
	}

	function rmv(name) {
		rmvlist.push(name);
	}

	function go() {
		var i, task;

		for (i in rmvlist) {
			if (tasklist[rmvlist[i]]) delete tasklist[rmvlist[i]];
		}
		rmvlist = [];

		for (i in tasklist) {
			task = tasklist[i];
			if (task.curr >= task.time) {
				if(!task.isHiddenCk || (task.isHiddenCk && !isHiddenMyView())) {
					task.curr = 0;
					task.task.fuc.apply(task.task.obj, task.task.data);
				}
				else
					task.curr++;
			} else
				task.curr++;
		}

		setTimeout(go, 1000);
	}

	setTimeout(go, 1000);

	return {
		add: add,
		rmv: rmv
	};
}

/*
 * 使用方法：
 * var date = new Data();
 * date.format ("yyyy-MM-dd hh:mm:ss")
 */
Date.prototype.format = function(mask) {
	var d = this;

	var zeroize = function(value, length) {

		if (!length) length = 2;

		value = String(value);

		for (var i = 0, zeros = ''; i < (length - value.length); i++)
			zeros += '0';

		return zeros + value;

	};

	return mask.replace(/"[^"]*"|'[^']*'|\b(?:d{1,4}|m{1,4}|yy(?:yy)?|([hHMstT])\1?|[lLZ])\b/g, function($0) {

		switch ($0) {
			case 'd':
				return d.getDate();
			case 'dd':
				return zeroize(d.getDate());
			case 'ddd':
				return ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'][d.getDay()];
			case 'dddd':
				return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getDay()];
			case 'M':
				return d.getMonth() + 1;
			case 'MM':
				return zeroize(d.getMonth() + 1);
			case 'MMM':
				return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
			case 'MMMM':
				return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
					'November', 'December'
				][d.getMonth()];
			case 'yy':
				return String(d.getFullYear()).substr(2);
			case 'yyyy':
				return d.getFullYear();
			case 'h':
				return d.getHours() % 12 || 12;
			case 'hh':
				return zeroize(d.getHours() % 12 || 12);
			case 'H':
				return d.getHours();
			case 'HH':
				return zeroize(d.getHours());
			case 'm':
				return d.getMinutes();
			case 'mm':
				return zeroize(d.getMinutes());
			case 's':
				return d.getSeconds();
			case 'ss':
				return zeroize(d.getSeconds());
			case 'l':
				return zeroize(d.getMilliseconds(), 3);
			case 'L':
				var m = d.getMilliseconds();
				if (m > 99) m = Math.round(m / 10);
				return zeroize(m);
			case 'tt':
				return d.getHours() < 12 ? 'am' : 'pm';
			case 'TT':
				return d.getHours() < 12 ? 'AM' : 'PM';
			case 'Z':
				return d.toUTCString().match(/[A-Z]+$/);
				// Return quoted strings with the surrounding quotes removed
			default:
				return $0.substr(1, $0.length - 2);
		}

	});

};

$.extend({
	myTime: {
		/**
		 * 当前时间戳
		 * @return <int>        unix时间戳(秒)  
		 * 
		 * 使用方法：
		 * console.log($.myTime.DateToUnix('2014-5-15 20:20:20'));
		 * console.log($.myTime.UnixToDate(1325347200));
		 */
		CurTime: function() {
			return Date.parse(new Date()) / 1000;
		},
		/**              
		 * 日期 转换为 Unix时间戳
		 * @param <string> 2014-01-01 20:20:20  日期格式              
		 * @return <int>        unix时间戳(秒)              
		 */
		DateToUnix: function(string) {
			var f = string.split(' ', 2);
			var d = (f[0] ? f[0] : '').split('-', 3);
			var t = (f[1] ? f[1] : '').split(':', 3);
			return (new Date(
				parseInt(d[0], 10) || null,
				(parseInt(d[1], 10) || 1) - 1,
				parseInt(d[2], 10) || null,
				parseInt(t[0], 10) || null,
				parseInt(t[1], 10) || null,
				parseInt(t[2], 10) || null
			)).getTime() / 1000;
		},
		/**              
		 * 时间戳转换日期              
		 * @param <int> unixTime    待时间戳(秒)              
		 * @param <bool> isFull    返回完整时间(Y-m-d 或者 Y-m-d H:i:s)              
		 * @param <int>  timeZone   时区              
		 */
		UnixToStrDate: function(unixTime, isFull, timeZone) {
			if (typeof(timeZone) == 'number')
				unixTime = parseInt(unixTime) + parseInt(timeZone) * 60 * 60;

			var time = new Date(unixTime * 1000);

			if (typeof(isFull) == 'string')
				return time.format(isFull);
			else
			if (typeof(isFull) == 'boolean') {
				if (isFull === true)
					return time.format('yyyy-MM-dd HH:mm:ss');
				else
					return time.format('yyyy-MM-dd');
			} else
				return time;
		},
		/**              
		 * 时间戳转换日期              
		 * @param <int> unixTime    待时间戳(秒)         
		 * @param <int>  timeZone   时区            
		 *
		 */
		UnixToDate: function(unixTime, timeZone) {
			if (typeof(timeZone) == 'number')
				unixTime = parseInt(unixTime) + parseInt(timeZone) * 60 * 60;

			return new Date(unixTime * 1000);
		}
	}
});

//IP转成整型
function _ip2int(ip) {
	var num = 0;
	ip = ip.split(".");
	num = Number(ip[0]) * 256 * 256 * 256 + Number(ip[1]) * 256 * 256 + Number(ip[2]) * 256 + Number(ip[3]);
	num = num >>> 0;
	return num;
}

//整型解析为IP地址
function _int2iP(num) {
	var str;
	var tt = new Array();
	tt[0] = (num >>> 24) >>> 0;
	tt[1] = ((num << 8) >>> 24) >>> 0;
	tt[2] = (num << 16) >>> 24;
	tt[3] = (num << 24) >>> 24;
	str = String(tt[0]) + "." + String(tt[1]) + "." + String(tt[2]) + "." + String(tt[3]);
	return str;
}

function strToInt(str) {
	var number = parseInt($.trim(str), 10);

	if (isNaN(number)) number = 0;

	return number;
}

function parsesysrun(boot) {
	var tm = '',
		h, m, a = parseInt(boot / 86400);
	if (a >= 0 && a <= 9)
		a = a;
	h = parseInt((boot % 86400) / 3600);
	if (h >= 0 && h <= 9)
		h = "0" + h;
	m = parseInt(((boot % 86400) % 3600) / 60);
	if (m >= 0 && m <= 9)
		m = "0" + m;
	s = parseInt(((boot % 86400) % 3600) % 60);
	if (s >= 0 && s <= 9)
		s = "0" + s;
	return a + '/' + h + ':' + m + ':' + s;
}

function numberformats(num) {
	if (num >= 1000 * 1000 * 1000 * 1000)
		return Math.round(parseFloat(num / 1000 / 1000 / 1000 / 1000) * 100) / 100 + 'T';
	else if (num >= 1000 * 1000 * 1000)
		return Math.round(parseFloat(num / 1000 / 1000 / 1000) * 100) / 100 + 'G';
	else if (num >= 1000 * 1000)
		return Math.round(parseFloat(num / 1000 / 1000) * 100) / 100 + 'M';
	else if (num >= 1000)
		return Math.round(parseFloat(num / 1000) * 100) / 100 + 'K';
	else return Math.round(num * 100) / 100;
}

window.myDev = function () {
	var sUserAgent = navigator.userAgent.toLowerCase();
	var dev = {};
		dev.bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		dev.bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		dev.bIsMidp = sUserAgent.match(/midp/i) == "midp";
		dev.bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		dev.bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		dev.bIsAndroid = sUserAgent.match(/android/i) == "android";
		dev.bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		dev.bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
	
	dev.isMobile = function(){
		return this.bIsIpad || this.bIsIphoneOs || this.bIsMidp || this.bIsUc7 || this.bIsUc || this.bIsAndroid || this.bIsCE || this.bIsWM;
	}

	return dev;
}();
