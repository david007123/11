<?php
// ********************************************************
// soft version info manage
// ********************************************************

define('VERSION_SOFTNAME',	'云平台');
define('VERSION_BUILDTIME',     '20210223141748');
define('VERSION_VER',		'1.2.0');
define('VERSION_TAG',		'');
define('VERSION_OEM',		'');
