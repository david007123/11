<?php
error_reporting(E_ALL ^ E_NOTICE);

define ("ADMIN_ACCT", "admin");
define ("URL_PATH_LOGIN", "page.php?r=user@login");

// user role define
define ("ROLE_GUEST", 255);
define ("ROLE_TECHN", 100);
define ("ROLE_ADMIN", 2);
define ("ROLE_ROOT", 1);

function is_supadmin($user)
{
	if($user == ADMIN_ACCT)
		return 1;
	if(file_exists("/usr/logd/supadmin/{$user}"))
		return 2;
	return 0;
}

// 时区文件
defined('TIMEZONE_CONF') or define('TIMEZONE_CONF', '/usr/logdata/timezone.conf');


// version manage
require_once(__DIR__ . '/version.php');
defined('VERSION_SOFTNAME') or define('VERSION_SOFTNAME', '云平台');
defined('VERSION_BUILDTIME') or define('VERSION_BUILDTIME', '201910101000');
defined('VERSION_VER') or define('VERSION_VER', '0.0.0');
defined('VERSION_TAG') or define('VERSION_TAG', 'beta');
defined('VERSION_OEM') or define('VERSION_OEM', '');
defined('VERSION') or define('VERSION', VERSION_VER . ' ' . VERSION_BUILDTIME . (VERSION_TAG == '' ? '' : '  [' . VERSION_TAG . ']') . (VERSION_OEM == '' ? '' : '  to ' . VERSION_OEM));

// opstool path
defined('DEVOPS_DIR') or define('DEVOPS_DIR', '/usr/logdata/devops');
defined('OPSSVC_DIR') or define('OPSSVC_DIR', DEVOPS_DIR . '/opssvc');
defined('OPSHISTORY_DIR') or define('OPSHISTORY_DIR', DEVOPS_DIR . '/history');
defined('OPSWEB_DIR') or define('OPSWEB_DIR', DEVOPS_DIR . '/web');

defined('OPSTOOL_DIR') or define('OPSTOOL_DIR', OPSWEB_DIR . '/tool');
defined('OPSTASK_DIR') or define('OPSTASK_DIR', OPSWEB_DIR . '/task');
defined('OPSCONF_DIR') or define('OPSCONF_DIR', OPSWEB_DIR . '/conf');
defined('OPSTOKEN_DIR') or define('OPSTOKEN_DIR', OPSWEB_DIR . '/token');

// aout link devops path
defined('OPSWEB_LINKS_DIR') or define('OPSWEB_LINKS_DIR', '/usr/logd/www/devops');
if(!file_exists(OPSWEB_LINKS_DIR))
	exec("ln -s " . OPSWEB_DIR . " " . OPSWEB_LINKS_DIR . " 2>&1", $output, $ret);

// web program manage
defined('ROOT_DIR') or define('ROOT_DIR', dirname(__DIR__));
defined('WEB_NAME') or define('WEB_NAME', 'cloud');
defined('WEB_TITLE') or define('WEB_TITLE', 'Panabit - ' . VERSION_SOFTNAME);
defined('WEB_CHARSET') or define('WEB_CHARSET', 'UTF-8');
defined('ROUTE_DEFAULT') or define('ROUTE_DEFAULT', 'gateway');

// define globals version
$GLOBALS['SOFT_VERSION'] = array(
	'softname'	=> VERSION_SOFTNAME,
	'buildtime'	=> VERSION_BUILDTIME,
	'ver'		=> VERSION_VER,
	'tag'		=> VERSION_TAG,
	'oem'		=> VERSION_OEM,
);

require_once(__DIR__ . '/defined.php');
require_once(ROOT_DIR . '/ni-core/loader.php');
