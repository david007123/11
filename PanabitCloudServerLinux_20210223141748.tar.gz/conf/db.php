<?php
// ********************************************************
// db init of manage
// ********************************************************

// delete tag eq 100
define( 'TB_ROW_DEL_VALUE', 100);

/******** 数据库连接信息 ********/
/**
 * mysql地址
 */
if (defined('DB_HOST') == false)
	define( 'DB_HOST', '127.0.0.1' );
/**
 * mysql用户名
 */
if (defined('DB_USER') == false)
	define( 'DB_USER', 'root' );
/**
 * mysql密码 grant all on lisence.* to panabit@'%';
 */
if (defined('DB_PASSWORD') == false)
	define( 'DB_PASSWORD', 'd4r9q8v6@panabit.com' );
/**
 * mysql数据库名称
 */
if (defined('DB_NAME') == false)
	define( 'DB_NAME', 'palog' );
/**
 * mysql 编码
 */
if (defined('DB_CHARSET') == false)
	//define( 'DB_CHARSET', 'utf8mb4' );
	define( 'DB_CHARSET', 'utf8' );
if (defined('DB_COLLATE') == false)
	//define( 'DB_COLLATE', 'utf8mb4_0900_ai_ci' );
	define( 'DB_COLLATE', 'utf8_general_ci' );

// init
if (isset($GLOBALS['nidb']))
	return;
try {
    $GLOBALS['nidb'] = new ni_db('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, // . ';charset=' . DB_CHARSET, 
								DB_USER, DB_PASSWORD,
								array(
									PDO::ATTR_PERSISTENT		=> true,
									PDO::ATTR_EMULATE_PREPARES	=> false,
									PDO::ATTR_ERRMODE			=> PDO::ERRMODE_EXCEPTION
								)
							);
} catch (PDOException $e) {
	json_error_exit(ERR_FAILURE, "nidb err: " . $e->getMessage());
    die();
}

function insert_data($dbname, $data)
{
	global $nidb;
	
	$keys = array_keys($data);
	
	$fields = '`'.implode('`, `',$keys).'`';
	$placeholder = substr(str_repeat('?,',count($keys)),0,-1);

	return $nidb->prepare("insert into `$dbname` ($fields) values ($placeholder)")->execute(array_values($data));
}

function update_data($dbname, $data, $where)
{
	global $nidb;
	
	$values = array();
	$placeholder = '';
	foreach($data as $key => $val) {
		array_push($values, $val);
		$placeholder = "$placeholder`$key` = ?, ";
	}

	if($placeholder == '')
		return false;
	$placeholder = substr($placeholder, 0, -2);

	$where_str = '';
	foreach($where as $key => $val) {
		$where_str = "$where_str`$key` = ? and ";
		array_push($values, $val);
	}

	if($where_str != '') 
		$where_str = substr("where $where_str", 0, -5);

	return $nidb->prepare("update `$dbname` set $placeholder $where_str")->execute($values);
}

function insert_data_duplicate_key_sum($dbname, array $data, array $sum_key, array $update_key = array())
{
	global $nidb;

	// auto insert, if exist then add intval for $sum_key or $update_key
	$keys = array_keys($data);
	$values = array_values($data);

	$fields = '`'.implode('`, `',$keys).'`';
	$placeholder = substr(str_repeat('?,',count($keys)),0,-1);

	$updatekey = '';
	foreach($sum_key as $key => $val) {
		$updatekey .= ", `$key` = `$key` + $val";
	}
	foreach($update_key as $key => $val) {
		$updatekey .= ", `$key` = $val";
	}

	$updatekey = substr($updatekey, 1);

	return $nidb->prepare("insert into `$dbname` ($fields) values ($placeholder) on duplicate key update $updatekey")->execute($values);
}
