<?php
// ********************************************************
// cloud init of manage
// ********************************************************

define ('TOPO', '/usr/logd/bin/topo');
define ('SACEYE', '/usr/logd/bin/saceye');
define ('PANALOGEYE', '/usr/logd/bin/panalogeye');
define ('DATAEYE', '/usr/logd/bin/cloudeye');
define ("CLOUD_CONF", "/etc/cloud.conf");
define ("LOG_CONF", "/usr/logd/bin/log.conf");
define ("PANABIT_BAGS_PATH", "/usr/logd/www/paupbags");
define ("CLOUD_BACKUP_PATH", "/usr/logdata/paconf");
define ("CLOUD_IPTABLES", "/usr/logd/www/cloud_iptables");
define ("CLOUD_URLDNSGRP", "/usr/logd/www/cloud_urldnsgrp");
define ("CLOUD_TOOLBAGS", "/usr/logd/www/cloud_toolbags");


