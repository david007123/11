<?php
//include("common.php");
include("common.php");
header("content-type:text/html; charset=utf-8");
if (($err = index_mysqlerror()) != "yes") {
	$href = 'http://bbs.panabit.com/forum.php?mod=viewthread&tid=12435&page=1&extra=#pid50116';
	echo '<a href="http://bbs.panabit.com/forum.php?mod=viewthread&tid=12435&page=1&extra=#pid50116" target="_blank">';
	echo '对不起，您的数据盘未能正常挂载，暂时不能访问';
	echo '请点击此链接查看修复方法</a>.';
	exit;
}

check_singlelogin();

$nginxconf = "/usr/local/etc/nginx/nginx.conf";
$httpsport = 0;
if (($fp = fopen($nginxconf, "r")) != false) {
	while (!feof($fp)) {
		$buff = fgets($fp);
		if (strstr($buff, "listen") !== false && strstr($buff, "ssl") !== false) {
			for ($i = 0; $i < strlen($buff); $i++) {
				$poschr = substr($buff, $i, 1);
				if ($poschr >= '0' && $poschr <= '9')
					$httpsport = $httpsport * 10 + ($poschr - '0');
			}
		}
	}
	fclose($fp);
}
$serverip = $_SERVER["HTTP_HOST"];
if (strchr($serverip, ':') != false) {
	$p = explode(':', $serverip);
	$serverip = $p[0];
}
if ($_SERVER["HTTPS"] != "on") {
	header("Location: https://".$serverip.":$httpsport");
	exit;
}

$sysname = sysname();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=$sysname?></title>
<meta http-equiv="Content-type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<link type="text/css" href="../css/common.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jq.cookie.js"></script>
<script type="text/javascript">
var disyzm = 0;
var maxnum = 1;
function login()
{
	var colswidth;
	var user = $("#username").val();
	var mypass = $("#password").val();

	if (user == "") {
		$("#username").focus();
		$("#codeno").show();
		$("#codeyes").hide();
		$("#codeme").attr("src", "checkcode.php?a=");
		return false;
	}

	if (mypass == "") {
	       	$("#password").focus();
		$("#codeno").show();
		$("#codeyes").hide();
		$("#codeme").attr("src", "checkcode.php?a=");
		return false;
       	}

	if (yzm == 0 && disyzm >= maxnum) {
		$("#codeno").show();
		$("#codeyes").hide();
		$("#checkcode").val('');
		$("#codeme").attr("src", "checkcode.php?a=");
		return false;
	}

	/* 本地时间 */
	var localt = (new Date()).getTime();
	var sec = (new Date()).getTime() / 1000;
	$.ajax({
		url:'login.php',
		type:'post',
		dataType:'json',
		data:{user:user, mypass:mypass, sec: sec},
		success:function(json) {
			if (json.yn == "yes") {
				$("#loginwin").slideUp("slow");
				setTimeout(function(){location.href="main.php"}, 1000);
			       	if ($("[name='remb']").eq(0).attr("checked")) {
					$.cookie("unamexx", user, {expires: 31});
					$.cookie("upassxx", mypass, {expires: 31});
					$.cookie("uerror", null, {expires: -1});
					$.cookie("remb", 1, {expires: 31});
				}
				else {
					$.cookie("unamexx", null, {expires: -1});
					$.cookie("upassxx", null, {expires: -1});
					$.cookie("remb", null, {expires: -1});
				}
			}
			else {
			       	alert(json.str);
				
				$("#username").val('');
				$("#password").val('');
				$("#checkcode").val('');
				$("#username").focus();
				$("#codeno").show();
				$("#codeyes").hide();
			       	$("#codeme").attr("src", "checkcode.php?a=");
		
				$.cookie("unamexx", null, {expires: -1});
				$.cookie("upassxx", null, {expires: -1});
				$.cookie("uerror", 1, {expires: 1});
			       	$.cookie("remb", null, {expires: -1});
				
				if (++disyzm >= maxnum) {
					$(".myyzm").show();
					return false;
				}
			}
		}
       	});
}

function cs_interval()
{
	$.ajax({
		url:'cs_interval.php',
		success:function(data){
			var now = parseInt(data);
			var cnow = new Date();
			var cnow_ses = parseInt(cnow.getTime()/1000)
			if ((cnow_ses - cnow) >= 30 * 60)
				alert("对不起，您的日志系统时间和您的流控系统时间相差超过30分钟，请核对！");
		}
	});
}

function enterEvent()
{
	var ev = window.event || arguments.callee.caller.arguments[0];
	var th = ev.keyCode || ev.whick;
	if (th == 13)
		login();
	else return false;
}

var yzm = 0;
function mycheckcode()
{
	var code = $("#checkcode").val();
	if (code.length < 4) {
		if (yzm) {
			yzm = 0;
			$("#codeno").show();
			$("#codeyes").hide();
			$("#codeme").attr("src", "checkcode.php?a=");
		}
		return false;
	}
	
	$.ajax({
        url:'yzm.php',
		type:'post',
		data:{code: code},
        success:function(json) {
			if (json == "no") {
				$("#codeno").show();
				$("#codeyes").hide();
				$("#codeme").attr("src", "checkcode.php?a=");
				yzm = 0;
			}
			else {
				yzm = 1;
				$("#codeno").hide();
				$("#codeyes").show();
			}
        }
    });
}
</script>
<style type="text/css">
#loginwin {margin:0 auto;width:310px;}

.login-button {
	margin-top:10px;
	padding:5px 0px;
	background-color: #256fb6;
	font-size:18px;
	font-weight:bold;
	color:white;
	cursor:pointer;
	border:1px solid #eee;
	width:307px;
}

.login-btn-radius {
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
}

#loginwin ul li {display:inline; width: 153px; float:left; text-align: center; padding: 10px 0; font-size:16px; font-weight:bold;color:#fff; cursor: pointer;}
.fm-text {width:275px;padding:10px 10px 10px 20px;color:#000;font-size:12px;line-height:20px;border-radius:1px;border:1px solid #bcb7b7; font-weight:bold;}
.fm-code {width:218px;margin-top:10px;padding:10px 0px;padding-left:5px;ime-mode:disabled;border:1px solid #eee;border-radius:1px;font-weight:bold;color:#000;font-size:12px;}
.lisel {border-bottom:3px solid #cfdc07;}
.linormal {border-bottom:3px solid #ddd;}
</style>
</head>
<body style="background:#256fb6">
<?php
$tbh = "300px";
$cloud_enable = getconfig("cloud_enable");
if ($cloud_enable == "0")
	$tbh = "250px";
?>
<div id="loginwin">
	<div style="width:100%; text-align:center;">
		<img src="../img/logo.gif" />
	</div>
<?php
if ($cloud_enable == "1") {
?>
	<div style="">
		<ul style="width:100%; list-style:none; margin-bottom:10px; padding:0;color:#fff;">
			<li class="lisel" onclick="location.href='/index.php'">日志系统</li>
			<li class="linormal" onclick="location.href='/cloud/page.php?r=user@login'" style="margin-left:1px;">云平台</li>
		</ul>
		<div style="clear:both;"></div>
	</div>
<?php
}
?>
	<table style="width:100%;margin-top:20px;">
		<tr>
			<td align="center">
				<input type="text" value="" id="username" placeholder="用户名" class="fm-text">
			</td>
			<td></td>
		</tr>
		<tr>
			<td align="center">
				<input type="password" value="" id="password" placeholder="密码" class="fm-text">
			</td>
			<td></td>
		</tr>
		<tr class="myyzm" style="display:none;">
			<td>
				<input type="text" value="" id="checkcode" placeholder="验证码" onkeyup="mycheckcode()" class="fm-code">
				<img src="../checkcode.php" style="margin-bottom:-13px;margin-right:-6px;" id="codeme" onclick="this.src='../checkcode.php?a'" /> 
			</td>
			<td>
				<img src="../img/12.png" width="15px" id="codeno" style="display:none;margin-bottom:-13px;" />
				<img src="../img/10.png" width="15px" id="codeyes" style="display:none;margin-bottom:-13px;" />
			</td>
		</tr>
		<tr>
			<td align="left" style="height:40px;line-height:40px;color:#fff;">
				<input type="checkbox" value="" name="remb" />记住用户名密码
			</td>
			<td></td>
		</tr>
		<tr>
			<td style="text-align:center;">
				<input type="button" value="登 录" class="login-button login-btn-radius" onclick="login()" />
			</td>
			<td></td>
		</tr>
	</table>
</div>
<script type="text/javascript">
$("#username").focus();
var h = $(window).height();
var w = $(window).width();
$("#loginwin").css("margin-top", (h-400)/2);
$("body").keydown(function(){enterEvent()});
cs_interval();

$("#typesel").change(function(){
	if ($(this).val() == "cloud")
		location.href = "Maintain/cloud_index.php";
});

if ($.cookie("unamexx") != null && $.cookie("upassxx") != null) {
	$("#username").val($.cookie("unamexx"));
	$("#password").val($.cookie("upassxx"));
}

if ($.cookie("uerror") != null) {
	$(".myyzm").show();
	disyzm = maxnum;
}

if ($.cookie("remb") != null) {
	$("[name='remb']").eq(0).attr("checked", true);
}else {
	$.cookie("unamexx", null, {expires: -1});
	$.cookie("upassxx", null, {expires: -1});
	$.cookie("remb", null, {expires: -1});
}

</script>
</body>
</html>
