<?php
// ********************************************************
// get version info from version.php
// ********************************************************

if(isset($argc) == false) exit;

$version = false;
if($argc > 1 && is_file($argv[1])) {
	require_once($argv[1]);

	if(defined('VERSION_SOFTNAME')
	&& defined('VERSION_BUILDTIME')
	&& defined('VERSION_VER')
	&& defined('VERSION_TAG')
	&& defined('VERSION_OEM')) {
		$version = array(
			'softname'	=> VERSION_SOFTNAME,
			'buildtime'	=> VERSION_BUILDTIME,
			'ver'		=> VERSION_VER,
			'tag'		=> VERSION_TAG,
			'oem'		=> VERSION_OEM,
		);
	}
}

echo serialize($version);
