<?php

function get_query_page($data)
{
	$optional = array();

	if(format_and_push($data, 'sort', $optional, '', 'string', false) == false)
		$optional['sort'] = '';
	
	if(format_and_push($data, 'page', $optional, '', 'int', false) == false)
		$optional['page'] = 1;
	
	if(format_and_push($data, 'limit', $optional, '', 'int', false) == false)
		$optional['limit'] = 20;
	else
		if($optional['limit'] <= 0) $optional['limit'] = 20;

	$optional['sortdesc'] = 0;
	if(format_and_push($data, 'g_ascdesc', $optional, 'ascdesc', 'string', false)) {
		if ($optional['sortdesc'] == 'desc')
			$optional['sortdesc'] = 2;
		else
		if ($optional['sortdesc'] == 'asc')
			$optional['sortdesc'] = 1;
		else
			$optional['sortdesc'] = intval($optional['sortdesc']);
	}

	return $optional;
}

function cloud_insertlog($user, $cont)
{
	global $nidb;
	
	$frmData = array(
		'user' => $user,
		'time' => time(),
		'cont' => $cont,
		'ipaddr' => $_SERVER["REMOTE_ADDR"],
	);
	try {
		if(insert_data('cloud_log', $frmData) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
		$id = $nidb->lastInsertId();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $id;
}

function operation_logger($obj, $str)
{
	global $nidb, $user;
	
	$frmData = array(
		'user'		=> $user->username,
		'ope_time'	=> time(),
		'obj'		=> $obj,
		'cont'		=> $str,
	);
	try {
		if(insert_data('operation_log', $frmData) === false) {
			$errmsg = implode(' ', $nidb->errorInfo());
			set_errmsg(MSG_LEVEL_DEF, __function__, $errmsg);
			return false;
		}
		$id = $nidb->lastInsertId();
	}
	catch (\NiDBException $e) {
		set_errmsg(MSG_LEVEL_EXP, __function__, $e->getMessage());
		return false;
	}

	return $id;
}

function to_utf8($word)
{
	if (json_encode($word) == false
		// is utf8 ?
	|| !preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$word)) {
		$word = iconv("gbk", "utf-8//translit", $word);
		if($word === false)
			$word = '';
	}

	return $word;
}

function hav_logoff() {
	if(file_exists('/root/panalog.cloud')) return 0;
	$conf = myconf_read('/usr/logd/bin/log.conf', array('log_off'));
	return !(isset($conf['log_off']) && intval($conf['log_off']));
}

/*
 * 多国语言转换函数
 * 
 */
/*
function language_jslib_print($dir)
{
	if(isset($_SESSION['lang']))
		$lang = $_SESSION['lang'];
	else
		$lang = 'zh';

	$file = "{$dir}/{$lang}.json";
	if(file_exists($file))
		$contents = file_get_contents($file);
	else
		$contents = '{}';
	return '<!-- language library, now lang="' . $lang . '" -->
		<script type="text/javascript">
			_paga_language_ = ' . $contents . ';
			function _lang(id, default_text)
			{
				if(arguments.length <= 0) return "' . $lang . '"; 
				if(!_paga_language_ || !_paga_language_[id]) return default_text;
				return _paga_language_[id];
			}
		</script>
';
}

$lang = new language($lang);
$lang->load(ROOT_DIR, '.json');

function _lang($id, $default_text)
{
	global $lang;

	return $lang->dump($id, $default_text);
}

function _langvp($id, $data)
{
	global $lang;

	return $lang->format($id, $data);
}
*/