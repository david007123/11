<?php
/*********************************************************
 * 日期：2021-01-21
 * 功能：守护进程
 * 限制：只能后台命令执行
 *********************************************************
 */
if(isset($argc) == false) exit;
define('ROOT_DIR', '/usr/logd/www/cloud');

define('TIMEZONE_CONF', '/usr/logdata/timezone.conf');
define('CLOUD_LOG_FILE', '/usr/logd/bin/log.conf');

$timezone_id = 'PRC';
if (file_exists(TIMEZONE_CONF) && $fp = fopen(TIMEZONE_CONF, "r")) {
	while (!feof($fp)) {
		if(($buf = fgets($fp)) === false)
			break;
		if(empty($buf = trim($buf, "\t\n\r\0\x0B")))
			continue;

		$col = explode('=', $buf, 2);
		if(count($col) != 2)
			continue;
		$key = trim($col[0]);
		$col[1] = trim($col[1]);
		if(strpos($key, ' ') !== false || empty($col[1]))
			continue;

		if($key != 'timezone_id')
			continue;

		$timezone_id = trim($col[1]);
		break;
	}
	fclose($fp);
}
date_default_timezone_set($timezone_id);

function process_monitor($monitor)
{
	exec("ps -xwocommand", $process, $ret);
	if($ret)
		return;

	foreach($monitor as $key => $val) {
		if(isset($val['file']) && file_exists($val['file']) === false) {
			echo "fail: [\033[38;5;1;4m{$key}\033[0m] {$val['file']} not found\n";
			continue;
		}
		$found = 0;
		foreach($process as $line) {
			if(preg_match($val['match'], $line)) {
				$found = 1;
				break;
			}
		}
		if($found)
			continue;

		echo "start [\033[38;5;34;1m{$key}\033[0m] {$val['cmd']}\n";
		system($val['cmd']);
	}
}

$monitor = array(
	"panacloud" => array(
		"match" => "/\/panacloud$/i",
		"cmd" => "/usr/logd/bin/panacloud >/dev/null 2>&1 &",
		"file" => "/usr/logd/bin/panacloud",
	),
	"backupclean" => array(
		"match" => "/\/backupclean$/i",
		"cmd" => "/usr/logd/bin/backupclean >/dev/null 2>&1 &",
		"file" => "/usr/logd/bin/backupclean",
	),
	"sacsvr" => array(
		"match" => "/\/sacsvr$/i",
		"cmd" => "/usr/logd/bin/sacsvr >/dev/null 2>&1 &",
		"file" => "/usr/logd/bin/sacsvr",
	),
	"getwxcontent" => array(
		"match" => "/\/getwxcontent$/i",
		"cmd" => "nohup /usr/logd/bin/getwxcontent >/dev/null 2>&1 &",
		"file" => "/usr/logd/bin/getwxcontent",
	),
	"licmonitor" => array(
		"match" => "/\/licmonitor$/i",
		"cmd" => "nohup /usr/logd/bin/licmonitor >/dev/null 2>&1 &",
		"file" => "/usr/logd/bin/licmonitor",
	)
);

while(true) {
	process_monitor($monitor);
	sleep(1);
}
