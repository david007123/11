<?php
/*********************************************************
 * 日期：2021-01-09
 * 功能：分发一键断网任务给PA客户端
 * 限制：只能后台命令执行
 *********************************************************
 */
if(isset($argc) == false) exit;
define('ROOT_DIR', '/usr/logd/www/cloud');

define('TIMEZONE_CONF', '/usr/logdata/timezone.conf');
define('API_WXDENY_FILE', '/usr/logdata/api_wxdeny.dat');
define('CLOUD_UUID_FILE', '/etc/uuidgen.conf');
define('CLOUD_LOG_FILE', '/usr/logd/bin/log.conf');

$timezone_id = 'PRC';
if (file_exists(TIMEZONE_CONF) && $fp = fopen(TIMEZONE_CONF, "r")) {
	while (!feof($fp)) {
		if(($buf = fgets($fp)) === false)
			break;
		if(empty($buf = trim($buf, "\t\n\r\0\x0B")))
			continue;

		$col = explode('=', $buf, 2);
		if(count($col) != 2)
			continue;
		$key = trim($col[0]);
		$col[1] = trim($col[1]);
		if(strpos($key, ' ') !== false || empty($col[1]))
			continue;

		if($key != 'timezone_id')
			continue;

		$timezone_id = trim($col[1]);
		break;
	}
	fclose($fp);
}
date_default_timezone_set($timezone_id);

function httpPost($url, $data = array(), $verify = true)
{
	$post = '';
	foreach($data as $k => $v) 
		$post .= "&$k=$v";
	
	if($post != '')
		$post = '--data "' . substr($post, 1) . '" ';
	
	$curl = '/usr/logd/bin/curl';
	if(!file_exists($curl))
		$curl = '/usr/local/bin/curl';
	
	if($verify)
		$cmd = $curl . ' -k --connect-timeout 10 --retry-max-time 10 --max-time 10 ' . $post . '"' . $url . '" 2>/dev/null';
	else
		$cmd = $curl . ' --connect-timeout 10 --retry-max-time 10 --max-time 10 ' . $post . '"' . $url . '" 2>/dev/null';

	$fp = popen($cmd, "r");
	$res = '';
	while (!feof($fp)) {
		$buffer = fgets($fp, 4096); 
		$res .= $buffer;
	}
	pclose($fp);
	//return str_replace(PHP_EOL, '', $res);
	return $res;
}

if (file_exists(CLOUD_LOG_FILE) && $fp = fopen(CLOUD_LOG_FILE, "r")) {
	while (!feof($fp)) {
		if(($buf = fgets($fp)) === false)
			break;
		if(empty($buf = trim($buf, "\t\n\r\0\x0B")))
			continue;

		$col = explode('=', $buf, 2);
		if(count($col) != 2)
			continue;
		$key = trim($col[0]);
		if($key == 'denypolicy_enable' && intval($col[1]) != 1)
			return;
	}
	fclose($fp);
}

function is_ipaddr($ip)
{
	return (long2ip(ip2long($ip)) === trim($ip));
}

require_once(ROOT_DIR . '/ni-core/class/ni_db.php');
require_once(ROOT_DIR . '/conf/db.php');

function scan_wxdeny()
{
	global $nidb;
	
	$keys = '`id`,
		`myevent` as `event`,
		`openid`,
		`license_id12` as `serialno`,
		`status`,
		`isupdate`,
		`sysname` as `name`,
		`tips`';

	$sql = "select $keys from weixin_brokennet";
	$sql.= " where `isupdate` != 0 and `myevent` != ''";

	try {
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute();
	}
	catch (NiDBException $e) {
		return;
	}

	if($ret) {
		$rows = $sth->fetchAll(\PDO::FETCH_CLASS);
		echo "count: " . count($rows) . "\n";
		if(count($rows) <= 0)
			return;

		$data = array(
			'ip' => array(
				'allow' => 0,
				'deny' => 0
			),
			'host' => array(
				'allow' => 0,
				'deny' => 0
			)
		);
		$ids = array();

		$guid = '';
		if(file_exists(CLOUD_UUID_FILE)) {
			$guid = file_get_contents(CLOUD_UUID_FILE);
			if($guid === false)
				$guid = '';
			else
				$guid = trim($guid, " \t\n\r\0\x0B");
		}
		$md5 = md5("{$guid}bugeiniwan");
		if($md5 == "") {
			echo "fail: guid " . CLOUD_UUID_FILE . "\n";
			return;
		}

		if (($fd = fopen(API_WXDENY_FILE, 'w')) === false) {
			echo "fail: fopen " . API_WXDENY_FILE . "\n";
			return;
		}

		$first = $text = '';
		foreach($rows as $key => $val) {
			if(is_ipaddr($val->event)) {
				if($val->status) {
					$data['ip']['allow']++;
					$text = "allow=ip ip={$val->event} device={$val->serialno}";
				}
				else {
					$text = "deny=ip ip={$val->event} device={$val->serialno}";
					$data['ip']['deny']++;
				}
				array_push($ids, $val->id);
			}
			else {
				if($val->status) {
					$data['host']['allow']++;
					$text = "allow=host host={$val->event} device={$val->serialno}";
				}
				else {
					$data['host']['deny']++;
					$text = "deny=host host={$val->event} device={$val->serialno}";
				}
				array_push($ids, $val->id);
			}
			fwrite($fd, $text . "\n");
			if($first == "")
				$first = $text;
		}
		fclose($fd);
		
		if(count($rows) > 1) {
			$tag = array();
			foreach($data as $key => $val) {
				if($data[$key]['allow'])
					array_push($tag, "allow=$key count=" . $data[$key]['allow']);
				if($data[$key]['deny'])
					array_push($tag, "deny=$key count=" . $data[$key]['deny']);
			}
			$tag = implode(' ', $tag);
		}
		else
			$tag = $first;

	}
	
	$url = "http://115.29.138.209/wxcloud/getcmd.php?systype=cloud&guid=${guid}&tag=panabit_deny&md5=${md5}";
	$retd = httpPost($url, array(), true);
	if($retd) {

		if (($fd = fopen(API_WXDENY_FILE, 'w')) === false) {
			echo "fail: fopen " . API_WXDENY_FILE . "\n";
			return;
		}

		fwrite($fd, $retd . "\n");

		fclose($fd);
	}
	
	if(count($rows) <= 0 && strlen($retd) <= 0)
		return;
	
	if(count($rows) <= 0)
		$tag = $retd;
	
	$cmd = "/usr/logd/bin/cloudeye device set wxcmd=1 file=" . API_WXDENY_FILE;
	exec($cmd, $out, $ret);
	if($ret != 0)
		return;

	sleep(5);
	unset($out);
	
	$msg = array(
		'send'	=> 0,
		'succ'	=> 0,
		'fail'	=> 0
	);
	for($i = 0; $i < 3; $i++) {
		$cmd = "/usr/logd/bin/cloudeye device set wxcmd=1 wxcmdstatus=1";
		exec($cmd, $out, $ret);
		if($ret != 0)
			return;

		foreach($out as $line) {
			$node = explode('=', $line);
			if(count($node) == 2 && isset($msg[$node[0]]))
				$msg[$node[0]] = $node[1];
		}
		if($msg['send'] > 0 || $msg['succ'] > 0 || $msg['fail'] > 0)
			break;
		sleep(2);
		unset($out);
	}
/*
	# 发送处理结果到微信公众号
	$send = $msg['succ'] + $msg['fail'];
	$result="{$tag},发送设备={$send},成功设备={$msg['succ']},失败设备={$msg['fail']}";
	$url = "https://115.29.138.209/wxcloud/sendresult.php";
	$url.= "?systype=cloud&guid={$guid}&tag=deny_result&md5={$md5}&res={$result}";
	$ret = httpPost($url, array(), true);
*/
	// 更新执行状态。
	$idstr = '?';
	if(count($ids) > 1)
		$idstr .= str_repeat(',?' , count($ids) - 1);

	$sql = "update weixin_brokennet set `isupdate` = 0 where id in($idstr)";
	try {
		$sth = $nidb->prepare($sql);
		$ret = $sth->execute($ids);
	}
	catch (\NiDBException $e) {
	}
}

scan_wxdeny();
